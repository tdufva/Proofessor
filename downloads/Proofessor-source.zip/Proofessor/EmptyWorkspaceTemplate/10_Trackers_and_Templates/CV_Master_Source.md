# CV Master Source

Add imported or pasted CV source text here, or let the app build this file from scanned CV files.

Do not put private material in a shared template.
