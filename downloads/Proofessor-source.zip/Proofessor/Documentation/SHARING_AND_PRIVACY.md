# Sharing And Privacy

This shared version is designed to be distributed without private data.

## Safe To Share

- `TenureEvidenceApp/`
- `EmptyWorkspaceTemplate/`
- `DemoWorkspace/`
- `Documentation/`

## Not Safe To Share

- a real user's `00_Inbox/`;
- PDFs, Word files, Pages files, slides, certificates, and attachments;
- email exports;
- calendar exports;
- imported CV source text;
- profile snapshots;
- `tenure_app_entries.json`;
- `cv_structured_items.json`;
- `automation_connector_settings.json` from a real user;
- exported dossier packets.

## Before Publishing

Search the shared package for personal names, real email addresses, private paths, and institution-specific evidence before uploading it anywhere public.

Suggested checks:

```sh
rg -n "your-name|private-path|CV_Master_Source|tenure_app_entries" Proofessor
```

Review matches manually, because demo files may intentionally contain fake examples.
