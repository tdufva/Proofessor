# Getting Started

## What The App Does

The app helps a tenure candidate collect evidence, verify it, connect claims to proof, build CVs, and export dossier material.

## First Launch

The onboarding flow asks the user to:

- choose whether calendar, mail, public web, profile pages, and local documents can be inspected;
- choose or drag in a folder where evidence material will be dropped;
- add profile links such as ORCID, Google Scholar, LinkedIn, social media, institutional research profile, and website;
- add an optional profile picture for public-facing CV styles.

## Evidence Folder

A good evidence folder can contain:

- CV files;
- certificates;
- presentation slides;
- event programmes;
- teaching evaluations;
- student feedback;
- grant applications;
- publication metadata;
- screenshots or PDFs of public visibility;
- email or calendar exports if the user chooses to provide them.

The app should treat imported material as suggestions until the user approves it.

## Choosing The App Workspace

The included run script points the app at `EmptyWorkspaceTemplate` by default.

For a real user, copy `EmptyWorkspaceTemplate` to a private location and run:

```sh
PROOFESSOR_WORKSPACE="/path/to/MyProofessorWorkspace" TenureEvidenceApp/script/build_and_run.sh
```

The app will display that workspace path during onboarding, and the user can add separate document folders to scan or drag a folder into the drop area.
