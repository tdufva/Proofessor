# Workspace Template

`EmptyWorkspaceTemplate` is the recommended starting point for a new user.

Main folders:

- `00_Inbox` - new imports, suggested evidence, attachments, source URL archives, and profile snapshots.
- `01_Process_and_Criteria` - tenure rules, criteria, HR guidance, and local process notes.
- `02_Profile_CV_and_Portfolios` - CV source files, profile pictures, bios, and portfolios.
- `03_Research_Artistic_Work` - publications, artistic work, projects, and research outputs.
- `04_Teaching_and_Pedagogy` - teaching records, evaluations, feedback, course material, and training.
- `05_Funding_and_Grants` - applications, calls, awards, and collaborator notes.
- `06_Impact_Service_and_Leadership` - service, committees, leadership, hosting, outreach, and impact.
- `07_Supervision_and_Examination` - theses supervised and examined.
- `08_Talks_Visibility_and_Recognition` - invited talks, conferences, keynotes, media, and public recognition.
- `09_Tenure_Application_Dossier` - CV drafts, evidence indexes, readiness reports, and packet exports.
- `10_Trackers_and_Templates` - app JSON files, CV source extraction, and version history.

The folder names are intentionally boring. Boring is good here: evidence should be easy to find under pressure.
