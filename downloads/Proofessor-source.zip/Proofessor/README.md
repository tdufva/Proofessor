# Proofessor App - Shared Version

This is a share-safe version of the Proofessor app.

It includes:

- `TenureEvidenceApp/` - the macOS SwiftUI app source.
- `EmptyWorkspaceTemplate/` - an empty workspace folder structure for a new user.
- `DemoWorkspace/` - small fake demo data for testing the app.
- `Documentation/` - setup and privacy notes.

It does not include private PDFs, email exports, calendar exports, attachments, CV source text, profile links, or personal evidence.

## Recommended Setup

1. In Xcode, open `TenureEvidenceApp/Package.swift` directly. Do not open the outer shared folder as an Xcode project.
2. Launch/build the app from `TenureEvidenceApp`, or use the Codex `Run` action there.
3. Use onboarding to choose the folder where the user will drop tenure evidence material.
4. Add profile links such as ORCID, Google Scholar, LinkedIn, social media, institutional research profile, website, and optional profile picture.
5. Use the app to collect, verify, file, build CV drafts, and export dossier materials.

## Privacy Rule

Do not share a user's workspace folder. Only share this clean package or the compiled app.

The compiled app creates an empty `ProofessorWorkspace` in the user's Documents folder on first launch. It does not need, and should not contain, the original developer's evidence data.

## Running With A Workspace

The bundled `TenureEvidenceApp/script/build_and_run.sh` builds a standalone `.app` with the empty workspace template included.

To run against another workspace:

```sh
PROOFESSOR_WORKSPACE="/path/to/MyProofessorWorkspace" TenureEvidenceApp/script/build_and_run.sh
```

Only use `PROOFESSOR_WORKSPACE` for local testing, because it intentionally embeds that workspace path in the generated app bundle.

To try the fake demo data:

```sh
PROOFESSOR_WORKSPACE="$PWD/DemoWorkspace" TenureEvidenceApp/script/build_and_run.sh
```

## Website Release

Build the website-ready package with:

```sh
TenureEvidenceApp/script/package_for_web.sh
```

The generated files are placed in `TenureEvidenceApp/dist/web/site`. Upload that folder to a static website host. For public macOS distribution, sign and notarize the app with an Apple Developer ID before publishing the zip.
