import XCTest
@testable import TenureEvidence

final class CVFlowTests: XCTestCase {
    func testWorkflowStepsHaveGuidanceText() {
        for step in CVWorkflowStep.allCases {
            XCTAssertFalse(step.guidance.trimmed.isEmpty)
        }
    }

    func testTENKTemplateAllowsOnlyFormalTheme() {
        XCTAssertEqual(CVDraftVariant.tenk.allowedThemes, [.tenkFormal])
    }

    func testPublicProfileAllowsPersonalizedThemes() {
        XCTAssertTrue(CVDraftVariant.publicProfile.allowedThemes.contains(.portraitProfile))
        XCTAssertTrue(CVDraftVariant.publicProfile.allowedThemes.contains(.linkForward))
        XCTAssertTrue(CVDraftTheme.portraitProfile.supportsProfilePicture)
        XCTAssertFalse(CVDraftTheme.tenkFormal.supportsProfilePicture)
    }

    func testCurrentPagesDraftKeepsImportedCVRowsEvenWhenTemplateHintsAreNarrow() {
        var importedPublication = CVStructuredItem()
        importedPublication.section = .publication
        importedPublication.year = "2024"
        importedPublication.title = "Old imported publication from the previous CV"
        importedPublication.includeInTemplates = [CVDraftVariant.tenure.rawValue]
        importedPublication.source = "CV master source: Research output (selected)"

        let draft = CurrentCVBuilder.generate(
            variant: .currentPages,
            sourceText: """
            Personal Details
            Example Candidate

            Profile
            Artist, educator, and researcher.
            """,
            cvItems: [importedPublication],
            appEntries: [],
            options: CVBuildOptions(includeAppEvidence: false, includeDraftNote: false, includeSourceConfidence: false)
        )

        XCTAssertTrue(draft.contains("Old imported publication from the previous CV"))
    }

    func testImportedCVRefreshFindsSupportSectionsFromOldCVSource() {
        let source = """
        Personal Details
        Example Candidate

        Language skills
        Finnish: native language

        Awards and honors
        Example old CV award
        """

        let result = CVStructuredItemBuilder.mergeMissingImportedCVItems(
            into: [],
            sourceText: source,
            entries: []
        )

        XCTAssertTrue(result.items.contains { $0.title == "Finnish: native language" })
        XCTAssertTrue(result.items.contains { $0.title == "Example old CV award" })
    }

    func testStructuredCVDeduplicationPrefersCleanImportedTitles() {
        var oldBadged = CVStructuredItem()
        oldBadged.section = .publication
        oldBadged.year = "2025"
        oldBadged.title = "Example publication [source: medium]."
        oldBadged.sourceConfidence = "medium"
        oldBadged.order = 0

        var clean = CVStructuredItem()
        clean.section = .publication
        clean.year = "2025"
        clean.title = "Example publication"
        clean.sourceConfidence = "high"
        clean.order = 1

        let result = CVStructuredItemBuilder.deduplicated([oldBadged, clean])

        XCTAssertEqual(result.items.count, 1)
        XCTAssertEqual(result.removedCount, 1)
        XCTAssertEqual(result.items.first?.title, "Example publication")
        XCTAssertEqual(result.items.first?.sourceConfidence, "high")
    }

    func testImportedCVScanClassifiesUnstructuredLines() {
        let source = """
        # Imported CV Source Scan

        ## Imported CV file: old-cv.pdf
        Source path: 02_Profile_CV_and_Portfolios/old-cv.pdf

        Candidate, E. (2024). Example article on art education. Journal of Creative Pedagogy. https://doi.org/10.1000/example
        Invited keynote lecture, Creative Coding and Art Education, Example University, 2025.
        ORCID: https://orcid.org/0000-0003-0054-6364
        """

        let result = CVStructuredItemBuilder.mergeMissingImportedCVItems(
            into: [],
            sourceText: source,
            entries: []
        )

        XCTAssertTrue(result.items.contains { $0.section == .publication && $0.title.contains("Example article") })
        XCTAssertTrue(result.items.contains { $0.section == .talk && $0.title.contains("Invited keynote") })
        XCTAssertTrue(result.items.contains { $0.section == .visibility && $0.title.contains("ORCID") })
    }

    func testConnectorSettingsDecodesOlderSettingsWithoutLosingNewDefaults() throws {
        let data = """
        {
          "allowCalendar": false,
          "allowEmail": true,
          "earliestYear": 2026,
          "notes": "Only suggestions."
        }
        """.data(using: .utf8)!

        let settings = try JSONDecoder().decode(ConnectorSettings.self, from: data)

        XCTAssertFalse(settings.allowCalendar)
        XCTAssertTrue(settings.allowEmail)
        XCTAssertEqual(settings.earliestYear, 2026)
        XCTAssertTrue(settings.acrisProfileURL.isEmpty)
        XCTAssertTrue(settings.googleScholarURL.isEmpty)
        XCTAssertTrue(settings.orcidURL.isEmpty)
        XCTAssertTrue(settings.linkedInURL.isEmpty)
        XCTAssertTrue(settings.socialMediaURL.isEmpty)
        XCTAssertEqual(settings.profilePicturePath, "")
        XCTAssertEqual(settings.documentScanFolders, [])
    }
}
