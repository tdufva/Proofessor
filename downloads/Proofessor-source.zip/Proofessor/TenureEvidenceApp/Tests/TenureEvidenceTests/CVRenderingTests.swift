import AppKit
import PDFKit
import XCTest
@testable import TenureEvidence

final class CVRenderingTests: XCTestCase {
    func testPDFTextExtractsInNormalOrder() throws {
        let draft = """
        # Orientation Probe

        - Left aligned evidence line
        """

        let data = try CVDocumentExporter.pdfData(from: draft, theme: .aaltoClean)
        let document = try XCTUnwrap(PDFDocument(data: data))
        let text = document.string ?? ""

        XCTAssertTrue(text.contains("Orientation Probe"))
        XCTAssertTrue(text.contains("Left aligned evidence line"))
        XCTAssertFalse(text.contains("eborP noitatneirO"))
    }

    func testPDFThumbnailPlacesTextNearTopLeft() throws {
        let draft = """
        # Orientation Probe

        - Left aligned evidence line
        """

        let data = try CVDocumentExporter.pdfData(from: draft, theme: .aaltoClean)
        let document = try XCTUnwrap(PDFDocument(data: data))
        let page = try XCTUnwrap(document.page(at: 0))
        let image = page.thumbnail(of: CGSize(width: 420, height: 594), for: .mediaBox)
        let bounds = try darkPixelBounds(in: image)

        XCTAssertLessThan(bounds.minX, 180, "Text should start on the left side of the rendered page.")
        XCTAssertLessThan(bounds.minY, 190, "Text should render near the top, not mirrored to the bottom.")
    }

    func testPortraitProfilePDFRendersProfilePictureMasthead() throws {
        let profileURL = try makeProfileImage()
        let draft = """
        # Test Person
        Assistant Professor
        test@example.com

        ## Research

        - Evidence line
        """

        let data = try CVDocumentExporter.pdfData(from: draft, theme: .portraitProfile, profilePicturePath: profileURL.path)
        let document = try XCTUnwrap(PDFDocument(data: data))
        let page = try XCTUnwrap(document.page(at: 0))
        let image = page.thumbnail(of: CGSize(width: 420, height: 594), for: .mediaBox)

        XCTAssertTrue(try containsRedPixels(in: image), "Portrait/public profile PDF exports should include the selected profile picture masthead.")
    }

    func testTENKPDFIgnoresProfilePictureMasthead() throws {
        let profileURL = try makeProfileImage()
        let draft = """
        # Test Person
        Assistant Professor

        ## Research

        - Evidence line
        """

        let data = try CVDocumentExporter.pdfData(from: draft, theme: .tenkFormal, profilePicturePath: profileURL.path)
        let document = try XCTUnwrap(PDFDocument(data: data))
        let page = try XCTUnwrap(document.page(at: 0))
        let image = page.thumbnail(of: CGSize(width: 420, height: 594), for: .mediaBox)

        XCTAssertFalse(try containsRedPixels(in: image), "TENK exports must stay text-only even when a profile picture is configured.")
    }

    func testAttributedExportsCarryProfilePictureAttachmentOnlyForPersonalizedThemes() throws {
        let profileURL = try makeProfileImage()
        let draft = """
        # Test Person
        Assistant Professor

        ## Research

        - Evidence line
        """

        let portrait = CVDocumentExporter.makeAttributedString(
            from: draft,
            theme: .portraitProfile,
            profilePicturePath: profileURL.path
        )
        let tenk = CVDocumentExporter.makeAttributedString(
            from: draft,
            theme: .tenkFormal,
            profilePicturePath: profileURL.path
        )

        XCTAssertTrue(hasAttachment(in: portrait))
        XCTAssertFalse(hasAttachment(in: tenk))
    }

    private func darkPixelBounds(in image: NSImage) throws -> CGRect {
        var proposedRect = CGRect(origin: .zero, size: image.size)
        let cgImage = try XCTUnwrap(image.cgImage(forProposedRect: &proposedRect, context: nil, hints: nil))
        let width = cgImage.width
        let height = cgImage.height
        var pixels = [UInt8](repeating: 0, count: width * height * 4)

        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(
            data: &pixels,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: width * 4,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        )

        try XCTUnwrap(context).draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        var minX = width
        var minY = height
        var maxX = 0
        var maxY = 0

        for y in 0..<height {
            for x in 0..<width {
                let offset = (y * width + x) * 4
                let red = pixels[offset]
                let green = pixels[offset + 1]
                let blue = pixels[offset + 2]
                let alpha = pixels[offset + 3]

                if alpha > 20 && red < 120 && green < 120 && blue < 120 {
                    minX = min(minX, x)
                    minY = min(minY, y)
                    maxX = max(maxX, x)
                    maxY = max(maxY, y)
                }
            }
        }

        XCTAssertLessThan(minX, width, "Rendered PDF thumbnail should contain dark text pixels.")
        return CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY)
    }

    private func containsRedPixels(in image: NSImage) throws -> Bool {
        var proposedRect = CGRect(origin: .zero, size: image.size)
        let cgImage = try XCTUnwrap(image.cgImage(forProposedRect: &proposedRect, context: nil, hints: nil))
        let width = cgImage.width
        let height = cgImage.height
        var pixels = [UInt8](repeating: 0, count: width * height * 4)

        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(
            data: &pixels,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: width * 4,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        )

        try XCTUnwrap(context).draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        for y in 0..<height {
            for x in 0..<width {
                let offset = (y * width + x) * 4
                let red = pixels[offset]
                let green = pixels[offset + 1]
                let blue = pixels[offset + 2]
                let alpha = pixels[offset + 3]

                if alpha > 20 && red > 150 && green < 110 && blue < 110 {
                    return true
                }
            }
        }

        return false
    }

    private func hasAttachment(in attributed: NSAttributedString) -> Bool {
        var found = false
        attributed.enumerateAttribute(.attachment, in: NSRange(location: 0, length: attributed.length)) { value, _, stop in
            if value != nil {
                found = true
                stop.pointee = true
            }
        }
        return found
    }

    private func makeProfileImage() throws -> URL {
        let image = NSImage(size: NSSize(width: 80, height: 80))
        image.lockFocus()
        NSColor.systemRed.setFill()
        NSRect(x: 0, y: 0, width: 80, height: 80).fill()
        image.unlockFocus()

        let tiff = try XCTUnwrap(image.tiffRepresentation)
        let bitmap = try XCTUnwrap(NSBitmapImageRep(data: tiff))
        let png = try XCTUnwrap(bitmap.representation(using: .png, properties: [:]))
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("png")
        try png.write(to: url)
        return url
    }
}
