import Foundation
import XCTest
@testable import TenureEvidence

@MainActor
final class EvidenceStoreTests: XCTestCase {
    func testAaltoCriteriaRecommendationExplainsTeachingEvidence() {
        var entry = EvidenceEntry()
        entry.category = "Teaching"
        entry.tenureDimension = "Teaching"
        entry.title = "Course feedback and curriculum update"
        entry.eventType = "Course development"
        entry.notes = "Student feedback was analysed and used to improve the course curriculum."

        let recommendation = AaltoCriteriaMatcher.recommendation(
            for: entry,
            school: .aaltoWide,
            stage: .tenure
        )

        XCTAssertEqual(recommendation.dimension, "Teaching")
        XCTAssertEqual(recommendation.category, "Teaching")
        XCTAssertTrue(recommendation.confidenceNote.localizedCaseInsensitiveContains("feedback"))
    }

    func testAaltoCriteriaRecommendationEmphasizesFullProfessorRecognition() {
        var entry = EvidenceEntry()
        entry.category = "Visibility"
        entry.tenureDimension = "Impact and service"
        entry.title = "International invited keynote"
        entry.eventType = "Keynote"
        entry.role = "Invited speaker"
        entry.venue = "International conference"

        let recommendation = AaltoCriteriaMatcher.recommendation(
            for: entry,
            school: .biz,
            stage: .full
        )

        XCTAssertEqual(recommendation.title, "Full professor recognition")
        XCTAssertEqual(recommendation.dimension, "Impact and service")
        XCTAssertTrue(recommendation.reason.localizedCaseInsensitiveContains("international recognition"))
    }

    func testTenureWorkspacePreparesUserWorkspaceWhenNoTemplateIsAvailable() throws {
        let documents = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureWorkspaceDocumentsTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: documents)
        }

        try FileManager.default.createDirectory(at: documents, withIntermediateDirectories: true)

        let located = TenureWorkspace.preparedUserWorkspace(
            documentsURL: documents,
            templateURL: nil
        )

        XCTAssertEqual(located.lastPathComponent, "ProofessorWorkspace")
        XCTAssertTrue(FileManager.default.fileExists(atPath: located.appendingPathComponent("10_Trackers_and_Templates/tenure_app_entries.json").path))
    }

    func testTenureWorkspaceCopiesSharedTemplateToPreparedWorkspace() throws {
        let root = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureWorkspaceTemplateTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: root)
        }

        let documents = root.appendingPathComponent("Documents", isDirectory: true)
        let templateFolder = root.appendingPathComponent("EmptyWorkspaceTemplate", isDirectory: true)
        try FileManager.default.createDirectory(at: documents, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(
            at: templateFolder.appendingPathComponent("10_Trackers_and_Templates", isDirectory: true),
            withIntermediateDirectories: true
        )
        try "template".write(
            to: templateFolder.appendingPathComponent("10_Trackers_and_Templates/CV_Master_Source.md"),
            atomically: true,
            encoding: .utf8
        )

        let located = TenureWorkspace.preparedUserWorkspace(
            documentsURL: documents,
            templateURL: templateFolder
        )

        XCTAssertEqual(located.standardizedFileURL.path, documents.appendingPathComponent("ProofessorWorkspace").standardizedFileURL.path)
        XCTAssertTrue(FileManager.default.fileExists(atPath: located.appendingPathComponent("10_Trackers_and_Templates/CV_Master_Source.md").path))
    }

    func testTenureWorkspaceUsesEnvironmentOverride() throws {
        let root = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureWorkspaceOverrideTests-\(UUID().uuidString)")
        let workspace = root.appendingPathComponent("Workspace", isDirectory: true)
        defer {
            try? FileManager.default.removeItem(at: root)
        }

        try FileManager.default.createDirectory(
            at: workspace.appendingPathComponent("10_Trackers_and_Templates", isDirectory: true),
            withIntermediateDirectories: true
        )

        let located = TenureWorkspace.locate(
            environment: ["PROOFESSOR_WORKSPACE": workspace.path],
            currentDirectoryPath: root.path
        )

        XCTAssertEqual(located.standardizedFileURL.path, workspace.standardizedFileURL.path)
    }

    func testStoreSanitizesMalformedEvidenceAndMissingAttachmentsDoNotCrash() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)

        let duplicateAttachmentID = UUID()
        let json = """
        [
          {
            "id": "\(UUID().uuidString)",
            "date": "2026-04-29",
            "category": "Broken category",
            "eventType": "Meeting",
            "title": "",
            "role": "",
            "venue": "",
            "tenureDimension": "Broken dimension",
            "status": "Broken status",
            "source": "",
            "notes": "",
            "cvReady": false,
            "attachments": [
              {"id": "\(duplicateAttachmentID.uuidString)", "name": "", "path": "missing.pdf"},
              {"id": "\(duplicateAttachmentID.uuidString)", "name": "Duplicate", "path": "missing.pdf"},
              {"id": "\(UUID().uuidString)", "name": "Empty", "path": ""}
            ]
          }
        ]
        """
        try json.write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        let entry = try XCTUnwrap(store.entries.first)

        XCTAssertEqual(entry.category, "Other")
        XCTAssertEqual(entry.status, "Needs review")
        XCTAssertEqual(entry.tenureDimension, "All")
        XCTAssertEqual(entry.title, "Untitled evidence")
        XCTAssertEqual(entry.attachments.count, 1)

        let attachment = try XCTUnwrap(entry.attachments.first)
        let state = store.attachmentState(for: attachment)
        XCTAssertFalse(state.exists)
        XCTAssertEqual(state.label, "Missing file")

        store.openAttachment(attachment)
        XCTAssertTrue(store.lastMessage.contains("missing"))
    }

    func testConfiguredDocumentFolderScanImportsFiles() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let scanFolder = workspace.appendingPathComponent("EvidenceDrop")
        try FileManager.default.createDirectory(at: scanFolder, withIntermediateDirectories: true)
        let fileURL = scanFolder.appendingPathComponent("Keynote lecture 2026.pdf")
        try Data("fake pdf bytes".utf8).write(to: fileURL)

        let store = EvidenceStore(workspaceURL: workspace)
        var settings = store.connectorSettings
        settings.documentScanFolders = [scanFolder.path]
        store.saveConnectorSettings(settings)

        let importedCount = store.scanConfiguredDocumentFolders()

        XCTAssertEqual(importedCount, 1)
        XCTAssertEqual(store.entries.first?.category, "Talk")
        XCTAssertEqual(store.entries.first?.attachments.first?.path, "EvidenceDrop/Keynote lecture 2026.pdf")
    }

    func testDeepScanImportsWorkspaceSubfolderEvidenceWithAaltoTeachingSignals() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let feedbackFolder = workspace
            .appendingPathComponent("04_Teaching_and_Pedagogy")
            .appendingPathComponent("Teaching_Evaluations")
            .appendingPathComponent("Spring")
        try FileManager.default.createDirectory(at: feedbackFolder, withIntermediateDirectories: true)
        try """
        Student feedback summary.
        Course feedback was analysed and used to improve teaching assignments.
        """.write(
            to: feedbackFolder.appendingPathComponent("student_feedback_2026.md"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        let importedCount = store.scanDocumentSources()

        XCTAssertEqual(importedCount, 1)
        XCTAssertEqual(store.entries.first?.category, "Teaching")
        XCTAssertEqual(store.entries.first?.tenureDimension, "Teaching")
        XCTAssertTrue(store.entries.first?.notes.localizedCaseInsensitiveContains("Aalto teaching evidence") == true)
        XCTAssertEqual(
            store.entries.first?.attachments.first?.path,
            "04_Teaching_and_Pedagogy/Teaching_Evaluations/Spring/student_feedback_2026.md"
        )
    }

    func testDeepScanUsesReadableTextToClassifyFundingEvidence() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let nestedFolder = workspace
            .appendingPathComponent("03_Research_Artistic_Work")
            .appendingPathComponent("Projects")
            .appendingPathComponent("Consortium")
        try FileManager.default.createDirectory(at: nestedFolder, withIntermediateDirectories: true)
        try """
        Horizon Europe consortium funding proposal.
        Role: work package lead.
        """.write(
            to: nestedFolder.appendingPathComponent("application_notes.md"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        _ = store.scanDocumentSources()

        XCTAssertEqual(store.entries.first?.category, "Funding")
        XCTAssertEqual(store.entries.first?.tenureDimension, "Research/artistic work")
        XCTAssertTrue(store.entries.first?.notes.localizedCaseInsensitiveContains("competitive funding") == true)
    }

    func testDeepScanKeepsSameFilenameInDifferentSubfolders() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let researchFolder = workspace
            .appendingPathComponent("03_Research_Artistic_Work")
            .appendingPathComponent("Projects")
            .appendingPathComponent("ProjectA")
        let serviceFolder = workspace
            .appendingPathComponent("06_Impact_Service_and_Leadership")
            .appendingPathComponent("Committee_and_Service")
            .appendingPathComponent("Panel")
        try FileManager.default.createDirectory(at: researchFolder, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: serviceFolder, withIntermediateDirectories: true)
        try "Research project documentation".write(to: researchFolder.appendingPathComponent("report.md"), atomically: true, encoding: .utf8)
        try "Committee service documentation".write(to: serviceFolder.appendingPathComponent("report.md"), atomically: true, encoding: .utf8)

        let store = EvidenceStore(workspaceURL: workspace)
        let importedCount = store.scanDocumentSources()

        XCTAssertEqual(importedCount, 2)
        XCTAssertEqual(Set(store.entries.compactMap { $0.attachments.first?.path }).count, 2)
    }

    func testDeepScanPrefillsEditableMetadataFromReadableText() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let talkFolder = workspace
            .appendingPathComponent("08_Talks_Visibility_and_Recognition")
            .appendingPathComponent("Invited_Talks")
        try FileManager.default.createDirectory(at: talkFolder, withIntermediateDirectories: true)
        try """
        Title: Postdigital Art Education Keynote
        Date: 15 April 2026
        Type: Keynote lecture
        Role: Invited speaker
        Venue: University of Helsinki
        Source: https://example.org/keynote
        The invitation confirms host, role, date, and public visibility.
        """.write(
            to: talkFolder.appendingPathComponent("invite.md"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        let importedCount = store.scanDocumentSources()
        let entry = try XCTUnwrap(store.entries.first)

        XCTAssertEqual(importedCount, 1)
        XCTAssertEqual(entry.title, "Postdigital Art Education Keynote")
        XCTAssertEqual(entry.date, "2026-04-15")
        XCTAssertEqual(entry.eventType, "Keynote lecture")
        XCTAssertEqual(entry.role, "Invited speaker")
        XCTAssertEqual(entry.venue, "University of Helsinki")
        XCTAssertEqual(entry.status, "Needs confirmation")
        XCTAssertTrue(entry.source.contains("https://example.org/keynote"))
        XCTAssertTrue(entry.notes.localizedCaseInsensitiveContains("Pre-filled fields"))
    }

    func testDeepScanAddsTenureSpecificDetectedDetails() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let grantFolder = workspace
            .appendingPathComponent("05_Funding_and_Grants")
            .appendingPathComponent("Applications_Submitted")
        try FileManager.default.createDirectory(at: grantFolder, withIntermediateDirectories: true)
        try """
        Title: Postdigital teaching research grant
        Date: 2026-05-01
        Funder: Research Council of Finland
        Role: Principal investigator
        Amount: EUR 250000
        DOI: 10.1234/example.2026
        International invited keynote connected to the project.
        """.write(
            to: grantFolder.appendingPathComponent("grant.md"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        _ = store.scanDocumentSources()
        let entry = try XCTUnwrap(store.entries.first)

        XCTAssertTrue(entry.notes.localizedCaseInsensitiveContains("Detected tenure details"))
        XCTAssertTrue(entry.notes.localizedCaseInsensitiveContains("Research Council of Finland"))
        XCTAssertTrue(entry.notes.localizedCaseInsensitiveContains("EUR 250000"))
        XCTAssertTrue(entry.notes.localizedCaseInsensitiveContains("10.1234/example.2026"))
    }

    func testReviewPeriodSeparatesCurrentAndBackgroundEntries() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        var old = EvidenceEntry(date: "2024-12-31", title: "Older background item")
        old.category = "Teaching"
        var current = EvidenceEntry(date: "2025-01-02", title: "Current review item")
        current.category = "Teaching"
        store.entries = [old, current]

        var settings = store.connectorSettings
        settings.reviewPeriodStartDate = "2025-01-01"
        settings.reviewPeriodEndDate = ""
        store.saveConnectorSettings(settings)

        XCTAssertEqual(store.reviewPeriodEntries().map(\.title), ["Current review item"])
        XCTAssertEqual(store.backgroundContextEntries().map(\.title), ["Older background item"])
    }

    func testReviewScansWizardActionsMoveDraftsOutOfQueue() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        let accepted = EvidenceEntry(
            date: "2026-05-01",
            category: "Talk",
            eventType: "Invited academic talk",
            title: "Accepted scanned talk",
            role: "Invited speaker",
            venue: "Example University",
            tenureDimension: "Impact and service",
            status: "Needs confirmation",
            source: "Imported from workspace evidence folder\nDetected URL: https://example.org/talk",
            notes: "Pre-filled fields from readable evidence text.",
            attachments: []
        )
        let ignored = EvidenceEntry(
            date: "2026-05-02",
            category: "Other",
            eventType: "Scanned note",
            title: "Ignore me",
            role: "",
            venue: "",
            tenureDimension: "All",
            status: "Needs confirmation",
            source: "Imported from workspace evidence folder",
            notes: "Pre-filled fields from readable evidence text.",
            attachments: []
        )
        store.entries = [accepted, ignored]

        XCTAssertEqual(store.scannedDraftEntriesForReview().count, 2)
        store.acceptScannedDraft(accepted.id)
        store.ignoreScannedDraft(ignored.id)

        XCTAssertTrue(store.scannedDraftEntriesForReview().isEmpty)
        XCTAssertEqual(store.entries.first(where: { $0.id == accepted.id })?.status, "Ready for CV")
        XCTAssertEqual(store.entries.first(where: { $0.id == ignored.id })?.status, "Ignored")
    }

    func testSuggestedEvidenceScannerReturnsDuplicateCandidatesAndSourceURLs() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let inbox = workspace.appendingPathComponent(SuggestedEvidenceScanner.folderPath)
        try FileManager.default.createDirectory(at: inbox, withIntermediateDirectories: true)
        try """
        Title: Digital Art Education Keynote
        Date: 2026-02-10
        Venue: Example University
        Role: Keynote speaker
        Source: https://example.org/keynote
        """.write(
            to: inbox.appendingPathComponent("keynote.md"),
            atomically: true,
            encoding: .utf8
        )

        let existing = EvidenceEntry(
            date: "2026-02-10",
            category: "Talk",
            eventType: "Keynote lecture",
            title: "Digital Art Education Keynote",
            role: "Keynote speaker",
            venue: "Example University",
            tenureDimension: "Research/artistic work",
            status: "Filed",
            source: "",
            notes: "",
            cvReady: true,
            attachments: []
        )

        let suggestions = SuggestedEvidenceScanner.scan(workspaceURL: workspace, existingEntries: [existing])
        let suggestion = try XCTUnwrap(suggestions.first)

        XCTAssertEqual(suggestion.duplicateCandidates.first?.title, existing.title)
        XCTAssertEqual(suggestion.duplicateTitles, ["\(existing.date) - \(existing.title)"])
        XCTAssertEqual(suggestion.sourceURLs.first?.absoluteString, "https://example.org/keynote")
    }

    func testImportParserPrefillsBibTeXPublicationMetadata() {
        let entry = ImportParser.parse("""
        @article{demo2026,
          title = {Postdigital Education and Tenure Evidence},
          journal = {Design Studies},
          year = {2026},
          doi = {10.1234/demo.2026}
        }
        """)

        XCTAssertEqual(entry.title, "Postdigital Education and Tenure Evidence")
        XCTAssertEqual(entry.category, "Publication")
        XCTAssertEqual(entry.eventType, "Publication / BibTeX import")
        XCTAssertEqual(entry.role, "Author")
        XCTAssertEqual(entry.venue, "Design Studies")
        XCTAssertEqual(entry.tenureDimension, "Research/artistic work")
        XCTAssertEqual(entry.date, "2026-01-01")
        XCTAssertTrue(entry.source.contains("10.1234/demo.2026"))
    }

    func testDeepScanImportsBibTeXFromSubfoldersWithDOISourceTrace() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let bibliographyFolder = workspace
            .appendingPathComponent("03_Research_Artistic_Work")
            .appendingPathComponent("Publications")
            .appendingPathComponent("Exports")
        try FileManager.default.createDirectory(at: bibliographyFolder, withIntermediateDirectories: true)
        try """
        @inproceedings{demo2026,
          title = {Creative AI Teaching Futures},
          booktitle = {Proceedings of Example Conference},
          year = {2026},
          doi = {10.5555/example.2026}
        }
        """.write(
            to: bibliographyFolder.appendingPathComponent("publications.bib"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        let importedCount = store.scanDocumentSources()
        let entry = try XCTUnwrap(store.entries.first)

        XCTAssertEqual(importedCount, 1)
        XCTAssertEqual(entry.category, "Publication")
        XCTAssertEqual(entry.title, "Creative AI Teaching Futures")
        XCTAssertEqual(entry.venue, "Proceedings of Example Conference")
        XCTAssertEqual(entry.date, "2026-01-01")
        XCTAssertTrue(entry.source.contains("https://doi.org/10.5555/example.2026"))
        XCTAssertEqual(entry.attachments.first?.path, "03_Research_Artistic_Work/Publications/Exports/publications.bib")
    }

    func testStartHereDemoSuggestionsCreateReviewInboxItems() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        XCTAssertEqual(store.createDemoSuggestions(), 3)

        let suggestions = store.suggestedEvidenceItems()
        XCTAssertEqual(suggestions.count, 3)
        XCTAssertTrue(suggestions.contains { $0.entry.tenureDimension == "Teaching" })
        XCTAssertTrue(suggestions.contains { !$0.sourceURLs.isEmpty })
    }

    func testSuggestedEvidenceCanBeMarkedProofMissing() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let inbox = workspace.appendingPathComponent(SuggestedEvidenceScanner.folderPath)
        try FileManager.default.createDirectory(at: inbox, withIntermediateDirectories: true)
        try """
        Title: Course feedback needs proof
        Date: 2026-02-10
        Course: Example Studio
        Role: Teacher
        Student feedback improved the course.
        """.write(
            to: inbox.appendingPathComponent("feedback.md"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        let suggestion = try XCTUnwrap(store.suggestedEvidenceItems().first)
        let importedID = store.markSuggestedEvidenceProofMissing(suggestion)
        let imported = try XCTUnwrap(store.entries.first { $0.id == importedID })

        XCTAssertEqual(imported.status, "Evidence missing")
        XCTAssertFalse(imported.cvReady)
        XCTAssertTrue(imported.notes.localizedCaseInsensitiveContains("proof is missing"))
        XCTAssertTrue(store.suggestedEvidenceItems().isEmpty)
        XCTAssertTrue(FileManager.default.fileExists(atPath: inbox.appendingPathComponent("Proof_Missing/feedback.md").path))
    }

    func testGuidedCaptureTemplatesSetTenureDefaults() {
        let keynote = EvidenceCaptureTemplate.keynote.makeEntry(date: "2026-05-11")
        XCTAssertEqual(keynote.category, "Talk")
        XCTAssertEqual(keynote.eventType, "Keynote lecture")
        XCTAssertEqual(keynote.role, "Keynote speaker")
        XCTAssertEqual(keynote.tenureDimension, "Research/artistic work")

        let course = EvidenceCaptureTemplate.course.makeEntry(date: "2026-05-11")
        XCTAssertEqual(course.category, "Teaching")
        XCTAssertEqual(course.tenureDimension, "Teaching")

        let grant = EvidenceCaptureTemplate.grant.makeEntry(date: "2026-05-11")
        XCTAssertEqual(grant.category, "Funding")
        XCTAssertEqual(grant.role, "Applicant")
    }

    func testMarkEntryAsProofReadySetsCVReadyStatus() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        let id = store.addEntry(EvidenceCaptureTemplate.publication.makeEntry(date: "2026-05-11"))

        store.markEntryAsProofReady(id)

        let entry = try XCTUnwrap(store.entries.first { $0.id == id })
        XCTAssertTrue(entry.cvReady)
        XCTAssertEqual(entry.status, "Ready for CV")
    }

    func testCreateCVLineFromEvidenceAndBackAgain() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let store = EvidenceStore(workspaceURL: workspace)
        var evidence = EvidenceCaptureTemplate.keynote.makeEntry(date: "2026-05-11")
        evidence.title = "Art Education Futures Keynote"
        evidence.venue = "Example Symposium"
        let evidenceID = store.addEntry(evidence)

        let itemID = try XCTUnwrap(store.createCVLineFromEvidence(evidenceID))
        let item = try XCTUnwrap(store.cvItems.first { $0.id == itemID })

        XCTAssertEqual(item.title, evidence.title)
        XCTAssertEqual(item.section, .talk)
        XCTAssertEqual(item.linkedEvidenceIDs, [evidenceID])

        let createdEvidenceID = try XCTUnwrap(store.createEvidenceFromCVItem(itemID))
        let createdEvidence = try XCTUnwrap(store.entries.first { $0.id == createdEvidenceID })
        let updatedItem = try XCTUnwrap(store.cvItems.first { $0.id == itemID })

        XCTAssertEqual(createdEvidence.title, evidence.title)
        XCTAssertTrue(updatedItem.linkedEvidenceIDs?.contains(createdEvidenceID) == true)
    }

    func testAttachmentMetadataExtractionFillsEmptyFields() throws {
        let workspace = FileManager.default.temporaryDirectory
            .appendingPathComponent("TenureEvidenceTests-\(UUID().uuidString)")
        defer {
            try? FileManager.default.removeItem(at: workspace)
        }

        let trackerFolder = workspace.appendingPathComponent("10_Trackers_and_Templates")
        try FileManager.default.createDirectory(at: trackerFolder, withIntermediateDirectories: true)
        try "[]".write(
            to: trackerFolder.appendingPathComponent("tenure_app_entries.json"),
            atomically: true,
            encoding: .utf8
        )

        let source = workspace.appendingPathComponent("certificate.txt")
        try """
        Title: New Manager Programme Certificate
        Date: 2026-03-15
        Venue: Aalto University
        Role: Participant
        """.write(to: source, atomically: true, encoding: .utf8)

        let store = EvidenceStore(workspaceURL: workspace)
        let id = store.addEntry()
        store.attachFiles([source], to: id)
        store.extractAttachmentMetadata(for: id)

        let entry = try XCTUnwrap(store.entries.first { $0.id == id })
        XCTAssertEqual(entry.title, "New Manager Programme Certificate")
        XCTAssertEqual(entry.date, "2026-03-15")
        XCTAssertEqual(entry.venue, "Aalto University")
        XCTAssertTrue(entry.notes.localizedCaseInsensitiveContains("Extracted attachment text"))
    }

    func testTenureReadinessReportIncludesGapsAndActions() {
        var entry = EvidenceCaptureTemplate.publication.makeEntry(date: "2026-05-11")
        entry.title = "Peer-reviewed article"
        entry.source = "https://example.org/article"
        entry.cvReady = true

        let report = TenureReadinessReportExporter.export(entries: [entry])

        XCTAssertTrue(report.contains("Tenure Readiness Report"))
        XCTAssertTrue(report.contains("Research / Artistic Work"))
        XCTAssertTrue(report.contains("Suggested next action"))
        XCTAssertTrue(report.contains("Proof Needed"))
    }

    func testBioDraftBuilderCreatesThirdPersonAcademicBio() {
        var settings = ConnectorSettings()
        settings.publicDisplayName = "Alex Scholar"

        var publication = EvidenceCaptureTemplate.publication.makeEntry(date: "2026-05-11")
        publication.title = "Peer-reviewed article on creative AI"
        publication.cvReady = true
        var teaching = EvidenceCaptureTemplate.course.makeEntry(date: "2026-05-12")
        teaching.title = "Creative AI Studio course feedback"
        teaching.cvReady = true

        let bio = BioDraftBuilder.build(
            useCase: .academic,
            lengthPreset: .short,
            customCharacterLimit: 1_000,
            entries: [publication, teaching],
            cvItems: [],
            sourceText: "Research interests: creative AI, art education, and postdigital culture",
            settings: settings,
            cvReadyOnly: true
        )

        XCTAssertTrue(bio.hasPrefix("Alex Scholar is"))
        XCTAssertTrue(bio.localizedCaseInsensitiveContains("creative AI"))
        XCTAssertTrue(bio.localizedCaseInsensitiveContains("teaching"))
        XCTAssertLessThanOrEqual(BioDraftBuilder.wordCount(bio), 270)
    }

    func testBioDraftBuilderHonorsCustomCharacterLimit() {
        var settings = ConnectorSettings()
        settings.publicDisplayName = "Alex Scholar"
        var entry = EvidenceCaptureTemplate.keynote.makeEntry(date: "2026-05-11")
        entry.title = "International invited keynote on art education"
        entry.cvReady = true

        let bio = BioDraftBuilder.build(
            useCase: .speakerIntro,
            lengthPreset: .custom,
            customCharacterLimit: 260,
            entries: [entry],
            cvItems: [],
            sourceText: "",
            settings: settings,
            cvReadyOnly: true
        )

        XCTAssertLessThanOrEqual(bio.count, 260)
        XCTAssertTrue(bio.localizedCaseInsensitiveContains("Alex Scholar"))
    }

    func testCVDesignPurposeMapsToPurposeFirstDefaults() {
        XCTAssertEqual(CVDesignPurpose.aaltoTenkFormal.variant, .tenk)
        XCTAssertEqual(CVDesignPurpose.aaltoTenkFormal.theme, .tenkFormal)
        XCTAssertTrue(CVDesignPurpose.compactTwoPage.options.finalCleanMode)
        XCTAssertEqual(CVDesignPurpose.compactTwoPage.targetPageLimit, 2)
    }

    func testProfileAutofillFindsProfileBasicsAndSelectedWork() {
        var settings = ConnectorSettings()
        settings.publicDisplayName = ""

        var publication = EvidenceCaptureTemplate.publication.makeEntry(date: "2026-05-11")
        publication.title = "Creative AI and Art Education"
        publication.cvReady = true

        var exhibition = EvidenceCaptureTemplate.artisticWork.makeEntry(date: "2026-05-12")
        exhibition.title = "Postdigital Studio Exhibition"
        exhibition.cvReady = true

        let suggestion = ProfileAutofillExtractor.suggestion(
            settings: settings,
            entries: [publication, exhibition],
            cvItems: [],
            sourceText: """
            Alex Scholar
            Assistant Professor in Art Education
            Aalto University School of Arts, Design and Architecture
            Research themes: creative AI, postdigital culture
            https://orcid.org/0000-0002-1825-0097
            """
        )

        XCTAssertEqual(suggestion.name, "Alex Scholar")
        XCTAssertTrue(suggestion.title.localizedCaseInsensitiveContains("Assistant Professor"))
        XCTAssertTrue(suggestion.affiliation.localizedCaseInsensitiveContains("Aalto University"))
        XCTAssertTrue(suggestion.orcidURL.contains("orcid.org"))
        XCTAssertTrue(suggestion.selectedPublications.localizedCaseInsensitiveContains("Creative AI"))
        XCTAssertTrue(suggestion.selectedExhibitions.localizedCaseInsensitiveContains("Postdigital"))
    }

    func testDossierNarrativeBuilderCreatesSixEvidenceBackedParagraphs() {
        var teaching = EvidenceCaptureTemplate.course.makeEntry(date: "2026-05-12")
        teaching.title = "Creative AI Studio course feedback"
        teaching.source = "https://example.org/course"
        teaching.cvReady = true

        var research = EvidenceCaptureTemplate.publication.makeEntry(date: "2026-05-11")
        research.title = "Peer-reviewed article on creative AI"
        research.source = "https://example.org/article"
        research.cvReady = true

        var settings = ConnectorSettings()
        settings.researchThemes = "creative AI and postdigital culture"
        settings.teachingThemes = "studio pedagogy and supervision"

        let sections = DossierNarrativeBuilder.build(
            entries: [teaching, research],
            cvItems: [],
            settings: settings
        )

        XCTAssertEqual(sections.count, 6)
        XCTAssertTrue(sections.map(\.title).contains("Teaching"))
        XCTAssertTrue(DossierNarrativeBuilder.markdown(from: sections).localizedCaseInsensitiveContains("Peer-reviewed article"))
    }

    func testEvidenceStatusDisplayUsesHumanLabels() {
        var entry = EvidenceEntry(status: "Needs confirmation")
        XCTAssertEqual(entry.displayStatus, "Check this")
        entry.status = "Evidence missing"
        XCTAssertEqual(entry.displayStatus, "Proof needed")
        entry.status = "Ready for CV"
        XCTAssertEqual(entry.displayStatus, "Ready to use")
    }
}
