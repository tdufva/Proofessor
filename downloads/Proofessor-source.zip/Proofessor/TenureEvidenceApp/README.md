# Proofessor App

Native macOS SwiftUI app for keeping tenure evidence in the Tenure folder.

## Current Features

- Show a first-launch onboarding setup for the core workflow and source permissions: calendar events, email text, public web, document folders, profile pages, and academic profile links.
- Use shared visual design tokens for spacing, card styling, section headers, and status chips.
- Use simplified top-level navigation: `Collect`, `Verify & File`, `Build CV`, and `Export`.
- Open on `Collect`, which explains where to add/import material, how automation suggestions work, and what still needs review or proof.
- Use `Export` as the sendable-material hub for CVs, dossier packets, evidence indexes, monthly reviews, and source folders.
- Review local tenure criteria notes, including process criteria, teaching portfolio reminders, teaching demonstration guidance, and useful links.
- See next best actions, attention lists, recent evidence, unverified CV items, publications needing metadata, and recent CV versions.
- Use the Missing Proof Dashboard to find CV claims without linked evidence, evidence records without attachments or source URLs, publication metadata gaps, and uncertain source lines.
- Use the Fix This queue for guided repair of missing proof, missing attachments, and unverified CV rows.
- Add, edit, search, and delete tenure evidence records.
- Use `Collect` as the intake desk for manual evidence, inbox/document-folder scans, pasted calendar/email text, scheduled suggestions, and source settings.
- See the collection workflow in one place: Add, Import, Automate, Review, File.
- Show a completeness score for every record.
- Use `Build CV` for editable templates, source checks, editing, preview, and export.
- Use the simplified Build CV header to choose purpose, visual style, export format, preview, and scan imported CV material from one place.
- Scan imported CV material without deleting existing structured CV edits; the app reads CV/profile folders, extracts text from PDF/text/RTF/Markdown sources, merges missing old-CV rows, and removes duplicate rows with legacy source badges in the title.
- Follow the four-step Build CV flow: Purpose, Source, Edit, Preview & Export.
- Use a responsive CV editor layout that places preview beside the editor on wide windows and stacks it on smaller windows.
- Build editable CV drafts primarily from the structured CV database, using `CV_Master_Source.md` as supporting material for profile and personal details.
- Use the guided CV workflow: Purpose, Source, Edit, Preview & Export.
- Start with presets for tenure dossier, three-page CV, TENK CV, art CV, research CV, teaching CV, and public profile CV, then choose from visible style cards allowed for that template.
- Maintain an editable structured CV database with education, employment, publications, talks, teaching, service, grants, artistic work, supervision, visibility, source confidence, verification status, and template inclusion fields.
- Link structured CV database rows to evidence records, auto-link likely matches, review suggested evidence matches, open linked evidence records, open attachment/source-archive folders, and unlink records when a CV claim needs different proof.
- Edit generated CV lines one by one, including include/exclude, verification, source confidence, template relevance, ordering, and an info note explaining why the line appears.
- Use template-specific export rules for TENK, three-page, art-focused, tenure, and public profile CVs.
- Use template guidance for TENK, tenure, art, research, teaching, three-page, and public CVs, including what each optimizes for and what to cut.
- Use one-click cleanup actions: hide uncertain lines, shorten to three pages, fix publication metadata, use tenure order, and make sendable.
- Turn on Final clean export mode to remove source badges, draft notes, source notes, review scaffolding, and uncertain lines from sendable exports.
- Compare the current CV against the last exported CV with added, removed, edited wording, word-count, and page-count changes.
- Save a CV version snapshot after each CV export, export set, or dossier packet export.
- Review CV version history, reveal saved snapshots, copy old versions, restore a saved version into the current draft, and compare it to the current CV.
- Use Reviewer and Health views to surface top strengths, missing evidence, weak lines, publication readiness, tenure alignment, teaching evidence strength, international visibility, source reliability, and three-page fit.
- Edit with a live side-by-side PDF preview to watch page count and layout while changing the CV.
- Render CV preview and PDF export text in normal readable orientation.
- Clean CV source sections during draft generation by removing repeated/noisy lines, preserving personal details as lines, formatting most sections as bullets, and repairing split publication-style lines where useful.
- Use CV build options for app evidence, CV-ready-only evidence, compact bullets, draft notes, and source notes.
- Include, exclude, and drag-reorder individual CV sections from `Build CV > Edit > Advanced section ordering`.
- Check CV preflight counts for words, sections, bullets, rendered A4 pages, included app items, and CV-ready records before export.
- Preview the rendered PDF/Word-style A4 layout inside the app before exporting.
- Add source-confidence badges to generated CV lines, with a build option to turn them off for final polishing.
- Format publication lines with TENK category, DOI, peer-review, and role hints.
- Export publication/citation lists in APA, Chicago, and TENK/JUFO-oriented styles.
- Open a CV review queue for uncertain lines pulled from older CVs, web profiles, and source extractions.
- Apply CV themes: Clean academic, TENK formal, Current Pages feel, Art portfolio, Compact three-page, Public profile, Research brief, Portrait profile, Link-forward, and Art catalogue.
- Keep TENK exports restricted to formal styling while allowing more personal, graphical, portrait/profile/link-forward choices for public, art, teaching, and research CVs where appropriate.
- Export CV drafts as Markdown, RTF, Word `.docx`, PDF, or Apple Pages `.pages`.
- Export a CV set in one click as Markdown, RTF, Word, and PDF. Pages stays as its own button because it opens Apple Pages to save the document.
- Open the CV draft export folder or reveal the consolidated CV master source directly from the CV tab.
- Export alternative CV styles: academic CV, TENK-style CV, tenure dossier bullets, and public bio notes.
- Build and export a tenure dossier planning view grouped by the main tenure dimensions.
- Export a dossier packet containing the current CV draft, a cover checklist, evidence index, and selected attachments.
- Export the full evidence list as CSV.
- Paste calendar or email text into an import assistant and turn it into a draft evidence entry.
- Review scheduled calendar, email, and web suggestions from `../00_Inbox/Suggested_Evidence` before importing, with duplicate warnings.
- Use `Source Settings` to review and save which calendar, email, public web, local folder, document folder, and profile sources the scheduled automation may inspect.
- Configure academic profile links for institutional research profile, Google Scholar, ORCID, institutional people page, LinkedIn, and website.
- Automatically scan `../00_Inbox` on launch, with a document scan refresh button for new certificates, PDFs, documents, slides, images, notes, and configured scan folders.
- Review activity by month and export a monthly review note.
- Open and snapshot configured public profile links: institutional research profile, Google Scholar, ORCID, institutional people page, LinkedIn, website, and public web search.
- Attach files through a file picker or drag-and-drop; open, reveal, remove, file forward, archive source URLs, or open the attachment folder.
- Safely handle missing, duplicate, malformed, or unsupported evidence attachments with status labels instead of crashing.
- Preview PDF, image, text, CSV, Markdown, and RTF attachments inside evidence records.
- Show an evidence checklist per activity type.
- Warn about possible duplicate records and merge a duplicate directly into the current evidence record.
- Ship with a custom academic app icon generated from `scripts/make_app_icon.swift`.
- Improve keyboard and accessibility basics with shortcuts for common actions, grouped VoiceOver labels, clearer button labels, and safer focus order.

The app stores editable evidence records in:

`../10_Trackers_and_Templates/tenure_app_entries.json`

Attached files are copied to:

`../00_Inbox/Proofessor_Attachments`

Files dropped directly into `../00_Inbox` are scanned into draft records and left in place until you review and file them forward.

Scheduled evidence suggestions are read from:

`../00_Inbox/Suggested_Evidence`

Automation source settings are stored in:

`../10_Trackers_and_Templates/automation_connector_settings.json`

Use the app like this:

1. Start in `Collect`.
2. Add a record manually, scan `00_Inbox`, paste event/email/calendar text, or open suggested evidence.
3. Use `Source Settings` to decide whether calendar, email, public web, local files, and profile pages are allowed sources for scheduled suggestion scans.
4. Review suggestions before importing them into the official evidence list.
5. Open each record, attach proof, archive source URLs, and file the evidence forward.

Run from this folder:

```sh
./script/build_and_run.sh
```

In Xcode, open `Package.swift` in this folder and run the `Proofessor` executable product. If you opened the outer `Proofessor` folder, close it and reopen `TenureEvidenceApp/Package.swift`.

The run script builds a real macOS `.app` bundle at `dist/Proofessor.app`. Without `PROOFESSOR_WORKSPACE`, that bundle is share-safe: it includes the empty workspace template and creates a new `ProofessorWorkspace` in the user's Documents folder on first launch.

Exported CSV goes to:

`../10_Trackers_and_Templates/Proofessor_Evidence_Export.csv`

CV export goes to:

`../10_Trackers_and_Templates/CV_Export_From_App.md`

Editable current-CV drafts go to:

`../09_Tenure_Application_Dossier/Draft_Materials`

The consolidated CV source is:

`../10_Trackers_and_Templates/CV_Master_Source.md`

The structured CV database is:

`../10_Trackers_and_Templates/cv_structured_items.json`

The CV diff baseline is updated after CV exports here:

`../10_Trackers_and_Templates/CV_Last_Export_Snapshot.md`

CV version history is stored here:

`../10_Trackers_and_Templates/cv_version_history.json`

CV version Markdown snapshots are stored here:

`../10_Trackers_and_Templates/CV_Version_History`

Dossier export goes to:

`../09_Tenure_Application_Dossier/Dossier_Builder_From_App.md`

Archived source pages go to:

`../00_Inbox/Source_URL_Archive`

Profile snapshots go to:

`../00_Inbox/Profile_Snapshots`

Local tenure criteria material can be filed here:

`../01_Process_and_Criteria/Tenure_Criteria`
