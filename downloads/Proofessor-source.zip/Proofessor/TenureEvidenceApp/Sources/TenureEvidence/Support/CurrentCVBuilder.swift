import Foundation

enum CurrentCVBuilder {
    static func generate(
        variant: CVDraftVariant,
        sourceText: String,
        cv2025Text: String = "",
        cv2025SummaryText: String = "",
        cvItems: [CVStructuredItem] = [],
        appEntries: [EvidenceEntry],
        options: CVBuildOptions = CVBuildOptions()
    ) -> String {
        if !cvItems.isEmpty {
            return CVStructuredDraftBuilder.generate(
                variant: variant,
                sourceText: sourceText,
                cv2025Text: cv2025Text,
                cv2025SummaryText: cv2025SummaryText,
                items: cvItems,
                appEntries: appEntries,
                options: options
            )
        }

        let rule = CVTemplateRule.rule(for: variant, base: options)
        let effectiveOptions = rule.options
        let source = CVSource(text: sourceText, options: effectiveOptions)
        let recent = appEntries
            .filter { effectiveOptions.onlyCVReadyEvidence ? $0.cvReady : ($0.cvReady || $0.completeness.score >= 75) }
            .sorted { $0.date > $1.date }

        let context = CVBuildContext(options: effectiveOptions, candidateName: CVBuildContext.candidateName(from: sourceText))

        switch variant {
        case .currentPages:
            return currentPages(source: source, recent: recent, context: context)
        case .cv2025Research:
            return cv2025Research(source: source, cv2025Text: cv2025Text, cv2025SummaryText: cv2025SummaryText, recent: recent, context: context)
        case .generalAcademic:
            return generalAcademic(source: source, recent: recent, context: context)
        case .artFocused:
            return artFocused(source: source, recent: recent, context: context)
        case .researchFocused:
            return researchFocused(source: source, recent: recent, context: context)
        case .teachingFocused:
            return teachingFocused(source: source, recent: recent, context: context)
        case .tenk:
            return tenk(source: source, recent: recent, context: context)
        case .threePage:
            return threePage(source: source, recent: recent, context: context)
        case .tenure:
            return tenure(source: source, recent: recent, context: context)
        case .publicProfile:
            return publicProfile(source: source, recent: recent, context: context)
        }
    }

    private static func currentPages(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        [
            header("Example Candidate - Current Pages CV Template", context: context),
            source.section("Personal Details"),
            source.section("Profile"),
            source.section("Degrees"),
            source.section("Other education and expertise"),
            source.section("Language skills"),
            source.section("Current Employment"),
            source.section("Previous work experience"),
            source.section("Research funding and grants"),
            source.section("Research output (selected)"),
            source.section("Artistic Work (selected)"),
            source.section("Research supervision and leadership experience"),
            source.section("Teaching merits"),
            source.section("Awards and honors"),
            source.section("Other key academic merits"),
            source.section("Reviewer and editorial work"),
            source.section("International invited talks and presentations"),
            source.section("Scientific and societal impact"),
            source.section("Other merits"),
            context.recentSection("Recent app-captured additions to place in the CV", entries: recent)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func cv2025Research(
        source: CVSource,
        cv2025Text: String,
        cv2025SummaryText: String,
        recent: [EvidenceEntry],
        context: CVBuildContext
    ) -> String {
        let profile = [
            markdownSection("Core Profile", in: cv2025SummaryText),
            markdownSection("Research Framing From `CV2025.pages`", in: cv2025SummaryText)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")

        let fallback = firstParagraphs(from: cv2025Text, count: 4)
        let researchEntries = recent.filter {
            $0.tenureDimension == "Research/artistic work" || $0.category == "Publication" || $0.category == "Talk"
        }

        return [
            header("Example Candidate - CV2025 Research Profile CV", context: context),
            "## Research Profile Language\n\n" + (profile.isEmpty ? fallback : profile),
            source.section("Personal Details", limit: 12),
            source.section("Degrees", limit: 6),
            source.section("Current Employment"),
            source.section("Research funding and grants", limit: 10),
            source.section("Research output (selected)", limit: 14),
            source.section("Artistic Work (selected)", limit: 8),
            source.section("International invited talks and presentations", limit: 10),
            source.section("Scientific and societal impact", limit: 10),
            context.recentSection("Recent AI, postdigital, art education, and visibility items", entries: researchEntries)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func generalAcademic(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        [
            header("Example Candidate - Academic CV", context: context),
            source.section("Personal Details"),
            source.section("Profile"),
            source.section("Degrees"),
            source.section("Other education and expertise", limit: 8),
            source.section("Language skills"),
            source.section("Current Employment"),
            source.section("Previous work experience"),
            source.section("Research funding and grants"),
            source.section("Research output (selected)"),
            source.section("Artistic Work (selected)"),
            source.section("Research supervision and leadership experience"),
            source.section("Teaching merits"),
            source.section("Other key academic merits"),
            source.section("Reviewer and editorial work"),
            source.section("International invited talks and presentations"),
            source.section("Scientific and societal impact"),
            context.recentSection("Recent app-captured items to review", entries: recent)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func artFocused(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        let artEntries = recent.filter { $0.category == "Artistic Output" || $0.category == "Talk" && $0.title.localizedCaseInsensitiveContains("art") }

        return [
            header("Example Candidate - Art-Focused CV", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            source.section("Current Employment"),
            source.section("Artistic Work (selected)"),
            source.section("Research and artistic project notes", limit: 20),
            source.section("Research funding and grants", limit: 12),
            source.section("Research output (selected)", limit: 12),
            source.section("International invited talks and presentations", limit: 10),
            source.section("Scientific and societal impact", limit: 8),
            source.section("Website and public artistic projects", limit: 12),
            source.section("Other merits", limit: 10),
            context.recentSection("Recent art and visibility items from app", entries: artEntries)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func researchFocused(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        let researchEntries = recent.filter {
            $0.tenureDimension == "Research/artistic work" || $0.category == "Publication" || $0.category == "Funding"
        }

        return [
            header("Example Candidate - Research-Focused CV", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            source.section("Research Framing"),
            source.section("Current Employment"),
            source.section("Research funding and grants"),
            source.section("Research output (selected)"),
            source.section("Research supervision and leadership experience"),
            source.section("Reviewer and editorial work"),
            source.section("International invited talks and presentations", limit: 10),
            source.section("Scientific and societal impact", limit: 10),
            context.recentSection("Recent research items from app", entries: researchEntries)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func teachingFocused(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        let teachingEntries = recent.filter {
            $0.tenureDimension == "Teaching" || $0.category == "Teaching" || $0.category == "Supervision"
        }

        return [
            header("Example Candidate - Teaching-Focused CV", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            "## Teaching Profile\n\nAssistant Professor in the candidate's field and relevant programme leadership. Teaching profile spans art education, media arts, creative coding, AI and visual culture, curriculum development, teacher education, supervision, and educational leadership.",
            source.section("Current Employment"),
            source.section("Research supervision and leadership experience"),
            source.section("Teaching merits"),
            source.section("Other education and expertise"),
            source.section("Other key academic merits", limit: 10),
            source.section("Scientific and societal impact", limit: 8),
            context.recentSection("Recent teaching, supervision, programme, and training items", entries: teachingEntries)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func tenk(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        [
            header("Example Candidate - TENK-Style CV Draft", context: context),
            source.section("Personal Details"),
            "## Degrees\n\n" + source.rawSection("Degrees"),
            "## Current and Previous Employment\n\n" + [source.rawSection("Current Employment"), source.rawSection("Previous work experience")].filter { !$0.isEmpty }.joined(separator: "\n"),
            "## Research Funding and Leadership\n\n" + source.rawSection("Research funding and grants"),
            "## Publications and Research Outputs\n\n" + source.rawSection("Research output (selected)"),
            "## Artistic Activities\n\n" + source.rawSection("Artistic Work (selected)"),
            "## Teaching Merits and Supervision\n\n" + [source.rawSection("Research supervision and leadership experience"), source.rawSection("Teaching merits")].filter { !$0.isEmpty }.joined(separator: "\n"),
            "## Academic Service, Review, and Societal Impact\n\n" + [source.rawSection("Other key academic merits"), source.rawSection("Reviewer and editorial work"), source.rawSection("Scientific and societal impact"), source.rawSection("Press/Media")].filter { !$0.isEmpty }.joined(separator: "\n"),
            source.section("Language skills"),
            context.recentSection("Recent app-captured items to classify into TENK categories", entries: recent)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func threePage(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        let strongest = recent
            .sorted { lhs, rhs in
                if lhs.cvReady != rhs.cvReady { return lhs.cvReady && !rhs.cvReady }
                return lhs.completeness.score > rhs.completeness.score
            }
            .prefix(10)

        return [
            header("Example Candidate - Three-Page CV Draft", context: context),
            source.section("Personal Details", limit: 10),
            source.section("Profile", limit: 1),
            source.section("Current Employment", limit: 5),
            source.section("Research funding and grants", limit: 8),
            source.section("Research output (selected)", limit: 10),
            source.section("Artistic Work (selected)", limit: 8),
            source.section("Research supervision and leadership experience", limit: 8),
            source.section("Teaching merits", limit: 8),
            source.section("International invited talks and presentations", limit: 8),
            source.section("Scientific and societal impact", limit: 8),
            context.recentSection("Recent strongest app items", entries: Array(strongest))
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func tenure(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        let research = recent.filter { $0.tenureDimension == "Research/artistic work" }
        let teaching = recent.filter { $0.tenureDimension == "Teaching" || $0.category == "Teaching" || $0.category == "Supervision" }
        let impact = recent.filter { $0.tenureDimension == "Impact and service" || $0.category == "Service" || $0.category == "Visibility" }

        return [
            header("Example Candidate - Tenure CV Draft", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            "## Research / Artistic Work\n\n" + [source.rawSection("Research funding and grants"), source.rawSection("Research output (selected)"), source.rawSection("Artistic Work (selected)")].filter { !$0.isEmpty }.joined(separator: "\n"),
            context.recentSection("Recent research/artistic evidence", entries: research),
            "## Teaching\n\n" + [source.rawSection("Research supervision and leadership experience"), source.rawSection("Teaching merits")].filter { !$0.isEmpty }.joined(separator: "\n"),
            context.recentSection("Recent teaching/supervision evidence", entries: teaching),
            "## Impact and Service\n\n" + [source.rawSection("Other key academic merits"), source.rawSection("Reviewer and editorial work"), source.rawSection("Scientific and societal impact")].filter { !$0.isEmpty }.joined(separator: "\n"),
            context.recentSection("Recent impact/service evidence", entries: impact)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func publicProfile(source: CVSource, recent: [EvidenceEntry], context: CVBuildContext) -> String {
        let highlights = recent.prefix(8)

        return [
            header("Example Candidate - Public Profile CV", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            source.section("Research Framing", limit: 1),
            source.section("Current Employment", limit: 4),
            source.section("Research output (selected)", limit: 8),
            source.section("Artistic Work (selected)", limit: 8),
            source.section("International invited talks and presentations", limit: 6),
            source.section("Website and public artistic projects", limit: 8),
            context.recentSection("Recent highlights", entries: Array(highlights))
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")
    }

    private static func header(_ title: String, context: CVBuildContext) -> String {
        let resolvedTitle = context.candidateName.trimmed.isEmpty
            ? title
            : title.replacingOccurrences(of: "Example Candidate", with: context.candidateName.trimmed)
        var lines = ["# \(resolvedTitle)"]

        if context.options.includeDraftNote {
            lines.append("Generated as an editable draft from the consolidated CV master source and Proofessor entries. Review, shorten, and polish before use.")
        }

        if context.options.includeSourceNotes {
            lines.append("Source note: local CV files, institutional profile/research portal, personal website, publication lists, art/research portfolio, and app-captured evidence.")
        }

        return lines.joined(separator: "\n\n")
    }

    private static func markdownSection(_ heading: String, in text: String) -> String {
        let lines = text.components(separatedBy: .newlines)
        guard let start = lines.firstIndex(where: { $0.trimmed == "### \(heading)" || $0.trimmed == "## \(heading)" }) else {
            return ""
        }

        var collected: [String] = []
        for line in lines.dropFirst(start + 1) {
            let trimmed = line.trimmed
            if trimmed.hasPrefix("## ") || trimmed.hasPrefix("### ") {
                break
            }
            collected.append(line)
        }

        return collected.joined(separator: "\n").trimmed
    }

    private static func firstParagraphs(from text: String, count: Int) -> String {
        let paragraphs = text
            .components(separatedBy: "\n")
            .map(\.trimmed)
            .filter { !$0.isEmpty }
            .prefix(count)

        return paragraphs.joined(separator: "\n\n")
    }
}

struct CVBuildContext {
    var options: CVBuildOptions
    var candidateName: String = ""

    static func candidateName(from sourceText: String) -> String {
        let lines = sourceText.components(separatedBy: .newlines).map(\.trimmed)
        for line in lines.prefix(30) {
            guard !line.isEmpty,
                  !line.hasPrefix("#"),
                  !line.localizedCaseInsensitiveContains("personal details"),
                  !line.localizedCaseInsensitiveContains("profile") else {
                continue
            }

            let words = line.split(separator: " ")
            if words.count >= 2,
               words.count <= 5,
               line.count <= 80,
               !line.localizedCaseInsensitiveContains("professor"),
               !line.localizedCaseInsensitiveContains("university"),
               !line.localizedCaseInsensitiveContains("orcid"),
               !line.localizedCaseInsensitiveContains("http") {
                return line
            }
        }
        return ""
    }

    func recentSection(_ title: String, entries: [EvidenceEntry]) -> String {
        guard options.includeAppEvidence, !entries.isEmpty else { return "" }

        let lines = entries.map { entry in
            if entry.category == "Publication" {
                var line = PublicationFormatter.cvLine(for: entry, includeSource: options.includeSourceNotes)
                if options.includeSourceConfidence {
                    line += " \(SourceConfidenceEvaluator.badge(for: entry))"
                }
                return line
            }

            var pieces: [String] = []

            if !entry.date.trimmed.isEmpty {
                pieces.append(entry.date.trimmed)
            }

            pieces.append(entry.title.trimmed.isEmpty ? "Untitled evidence" : entry.title.trimmed)

            if !entry.role.trimmed.isEmpty {
                pieces.append(entry.role.trimmed)
            }

            if !entry.venue.trimmed.isEmpty {
                pieces.append(entry.venue.trimmed)
            }

            if !entry.eventType.trimmed.isEmpty && !options.compactBullets {
                pieces.append(entry.eventType.trimmed)
            }

            var line = "- " + pieces.joined(separator: ". ") + "."

            if options.includeSourceNotes, !entry.source.trimmed.isEmpty {
                line += " Source: \(entry.source.trimmed)."
            }

            if options.includeSourceConfidence {
                line += " \(SourceConfidenceEvaluator.badge(for: entry))"
            }

            return line
        }
        .joined(separator: "\n")

        return "## \(title)\n\n\(lines)"
    }
}

struct CVSource {
    let text: String
    var options = CVBuildOptions()

    private let headings = [
        "Personal Details",
        "Profile",
        "Research Framing",
        "Language skills",
        "Keywords and expertise",
        "Sustainable Development Goals / public profile links",
        "Degrees",
        "Other education and expertise",
        "Current Employment",
        "Previous work experience",
        "Research funding and grants",
        "Research output (selected)",
        "Artistic Work (selected)",
        "Research and artistic project notes",
        "Research supervision and leadership experience",
        "Teaching merits",
        "Awards and honors",
        "Other key academic merits",
        "Reviewer and editorial work",
        "International invited talks and presentations",
        "Scientific and societal impact",
        "Press/Media",
        "Website and public artistic projects",
        "Other merits"
    ]

    func section(_ heading: String, limit: Int? = nil) -> String {
        let body = rawSection(heading, limit: limit)
        guard !body.isEmpty else { return "" }
        return "## \(heading)\n\n\(body)"
    }

    func rawSection(_ heading: String, limit: Int? = nil) -> String {
        let lines = text
            .components(separatedBy: .newlines)
            .map(normalizedLine)
            .filter { line in
                !line.isEmpty
                    && !line.hasPrefix("--- Page")
                    && !line.localizedCaseInsensitiveContains("Imported CV Source Scan")
            }

        guard let start = lines.firstIndex(where: { normalizedHeading($0).caseInsensitiveCompare(heading) == .orderedSame }) else {
            return ""
        }

        var collected: [String] = []
        for line in lines.dropFirst(start + 1) {
            let normalized = normalizedHeading(line)
            if headings.contains(where: { $0.caseInsensitiveCompare(normalized) == .orderedSame }) {
                break
            }
            collected.append(line)
        }

        let cleaned = cleanedLines(collected, heading: heading)
        let limited = limit.map { Array(cleaned.prefix($0)) } ?? cleaned
        return formattedBody(limited, heading: heading)
    }

    private func normalizedLine(_ line: String) -> String {
        line
            .replacingOccurrences(of: "\u{2028}", with: " ")
            .replacingOccurrences(of: "\u{2029}", with: " ")
            .replacingOccurrences(of: "\u{00a0}", with: " ")
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func normalizedHeading(_ line: String) -> String {
        line
            .replacingOccurrences(of: "#", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func cleanedLines(_ lines: [String], heading: String) -> [String] {
        var cleaned: [String] = []
        var seen = Set<String>()
        let allowJoining = [
            "Research output (selected)",
            "Research and artistic project notes"
        ]
        .contains { $0.caseInsensitiveCompare(heading) == .orderedSame }

        for raw in lines {
            let line = normalizedLine(raw)
            guard !line.isEmpty, !isNoise(line) else { continue }

            let key = line
                .lowercased()
                .replacingOccurrences(of: " ", with: "")
                .replacingOccurrences(of: ".", with: "")

            guard !seen.contains(key) else { continue }
            seen.insert(key)

            if allowJoining, shouldJoin(line, after: cleaned.last) {
                let previous = cleaned.removeLast()
                cleaned.append(previous + " " + line)
            } else {
                cleaned.append(line)
            }
        }

        return cleaned
    }

    private func formattedBody(_ lines: [String], heading: String) -> String {
        let paragraphHeadings = ["Profile", "Research Framing"]
        if paragraphHeadings.contains(where: { $0.caseInsensitiveCompare(heading) == .orderedSame }) {
            return lines.joined(separator: "\n\n")
        }

        if heading.caseInsensitiveCompare("Personal Details") == .orderedSame {
            return lines.joined(separator: "\n")
        }

        if heading.caseInsensitiveCompare("Research output (selected)") == .orderedSame {
            return lines.map { line in
                if isSubheading(line) {
                    return "### \(line)"
                }
                var formatted = PublicationFormatter.formatSourceLine(line)
                if options.includeSourceConfidence {
                    formatted += " \(SourceConfidenceEvaluator.badge(for: line, section: heading))"
                }
                return formatted
            }
            .filter { !$0.trimmed.isEmpty }
            .joined(separator: "\n")
        }

        return lines.map { line in
            if isSubheading(line) {
                return "### \(line)"
            }
            if line.hasPrefix("- ") {
                return options.includeSourceConfidence
                    ? "\(line) \(SourceConfidenceEvaluator.badge(for: line, section: heading))"
                    : line
            }
            let suffix = options.includeSourceConfidence
                ? " \(SourceConfidenceEvaluator.badge(for: line, section: heading))"
                : ""
            return "- \(line)\(suffix)"
        }
        .joined(separator: "\n")
    }

    private func isNoise(_ line: String) -> Bool {
        let lower = line.lowercased()
        return lower == "tomi slotte dufva"
            || lower.contains("tomi slo(e dufva")
            || lower.contains("tomi slo e dufva")
            || lower == "curriculum vitae"
            || lower == "research publications"
            || lower.hasPrefix("generated 2026-04-24")
            || lower.hasPrefix("source files consulted")
            || lower.hasPrefix("source note:")
    }

    private func isSubheading(_ line: String) -> Bool {
        line.localizedCaseInsensitiveContains("Classification")
            || line.localizedCaseInsensitiveContains("Upcoming")
            || line.localizedCaseInsensitiveContains("Published,")
    }

    private func shouldJoin(_ line: String, after previous: String?) -> Bool {
        guard let previous, !isSubheading(previous), !isSubheading(line) else { return false }
        guard !line.hasPrefix("- ") else { return false }

        let previousEnd = previous.trimmingCharacters(in: .whitespacesAndNewlines).last
        let startsLowercase = line.first.map { String($0).lowercased() == String($0) && String($0).uppercased() != String($0) } ?? false
        let previousLooksOpen = previousEnd.map { !".):;?!".contains($0) } ?? false

        if startsLowercase || previousLooksOpen {
            return true
        }

        if previous.hasSuffix(",") || previous.hasSuffix(" and") || previous.hasSuffix(" of") || previous.hasSuffix(" in") {
            return true
        }

        return false
    }
}
