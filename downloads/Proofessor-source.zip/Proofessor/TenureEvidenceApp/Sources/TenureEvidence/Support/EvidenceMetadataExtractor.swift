import AppKit
import Foundation
import PDFKit
import Vision

struct EvidenceMetadataExtractionResult {
    var text: String
    var fileCount: Int
}

enum EvidenceMetadataExtractor {
    static func extract(from files: [URL]) throws -> EvidenceMetadataExtractionResult {
        var chunks: [String] = []
        var readCount = 0

        for url in files {
            let text = try text(from: url)
            guard !text.trimmed.isEmpty else { continue }
            readCount += 1
            chunks.append("""
            Source file: \(url.lastPathComponent)
            \(text)
            """)
        }

        return EvidenceMetadataExtractionResult(
            text: chunks.joined(separator: "\n\n"),
            fileCount: readCount
        )
    }

    private static func text(from url: URL) throws -> String {
        switch url.pathExtension.lowercased() {
        case "pdf":
            return try pdfText(from: url)
        case "png", "jpg", "jpeg", "heic", "tiff", "gif":
            return try recognizedText(from: url)
        case "txt", "md", "csv":
            return (try? String(contentsOf: url, encoding: .utf8)) ?? ""
        case "rtf":
            guard let data = try? Data(contentsOf: url),
                  let attributed = try? NSAttributedString(
                    data: data,
                    options: [.documentType: NSAttributedString.DocumentType.rtf],
                    documentAttributes: nil
                  ) else {
                return ""
            }
            return attributed.string
        default:
            return ""
        }
    }

    private static func recognizedText(from url: URL) throws -> String {
        let handler = VNImageRequestHandler(url: url)
        return try recognizedText(using: handler)
    }

    private static func recognizedText(from image: CGImage) throws -> String {
        let handler = VNImageRequestHandler(cgImage: image)
        return try recognizedText(using: handler)
    }

    private static func recognizedText(using handler: VNImageRequestHandler) throws -> String {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true

        try handler.perform([request])

        return (request.results ?? [])
            .compactMap { observation in
                observation.topCandidates(1).first?.string
            }
            .joined(separator: "\n")
    }

    private static func pdfText(from url: URL) throws -> String {
        guard let document = PDFDocument(url: url) else { return "" }
        var chunks: [String] = []

        for pageIndex in 0..<document.pageCount {
            guard let page = document.page(at: pageIndex) else { continue }
            let embeddedText = page.string?.trimmed ?? ""

            if !embeddedText.isEmpty {
                chunks.append(embeddedText)
                continue
            }

            guard pageIndex < 8 else { continue }
            let image = page.thumbnail(of: CGSize(width: 1600, height: 2200), for: .mediaBox)
            guard let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { continue }
            let ocrText = try recognizedText(from: cgImage)
            if !ocrText.trimmed.isEmpty {
                chunks.append(ocrText)
            }
        }

        return chunks.joined(separator: "\n\n")
    }
}
