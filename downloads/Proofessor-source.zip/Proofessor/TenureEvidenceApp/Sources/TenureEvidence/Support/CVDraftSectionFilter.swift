import Foundation

enum CVDraftSectionFilter {
    private struct SectionChunk {
        let title: String
        let lines: [String]
    }

    static func sections(in markdown: String) -> [CVDraftSection] {
        documentParts(in: markdown).sections.map { chunk in
            CVDraftSection(title: chunk.title, body: Array(chunk.lines.dropFirst()))
        }
    }

    static func filteredMarkdown(_ markdown: String, includedSectionIDs: Set<String>) -> String {
        let order = sections(in: markdown).map(\.id)
        return orderedMarkdown(markdown, includedSectionIDs: includedSectionIDs, orderedSectionIDs: order)
    }

    static func orderedMarkdown(
        _ markdown: String,
        includedSectionIDs: Set<String>,
        orderedSectionIDs: [String]
    ) -> String {
        let parts = documentParts(in: markdown)
        var output = parts.preamble
        let chunksByTitle = Dictionary(uniqueKeysWithValues: parts.sections.map { ($0.title, $0) })
        var emitted = Set<String>()

        for title in orderedSectionIDs {
            guard includedSectionIDs.contains(title),
                  let chunk = chunksByTitle[title] else {
                continue
            }
            appendSeparatorIfNeeded(to: &output)
            output.append(contentsOf: chunk.lines)
            emitted.insert(title)
        }

        for chunk in parts.sections where includedSectionIDs.contains(chunk.title) && !emitted.contains(chunk.title) {
            appendSeparatorIfNeeded(to: &output)
            output.append(contentsOf: chunk.lines)
        }

        return output.joined(separator: "\n").trimmed + "\n"
    }

    private static func documentParts(in markdown: String) -> (preamble: [String], sections: [SectionChunk]) {
        let lines = markdown.components(separatedBy: .newlines)
        var preamble: [String] = []
        var chunks: [SectionChunk] = []
        var currentTitle: String?
        var currentLines: [String] = []

        func flush() {
            guard let currentTitle else { return }
            chunks.append(SectionChunk(title: currentTitle, lines: currentLines))
            currentLines.removeAll()
        }

        for line in lines {
            if let title = sectionTitle(from: line) {
                flush()
                currentTitle = title
                currentLines = [line]
            } else if currentTitle != nil {
                currentLines.append(line)
            } else {
                preamble.append(line)
            }
        }

        flush()
        return (preamble, chunks)
    }

    private static func appendSeparatorIfNeeded(to output: inout [String]) {
        guard let last = output.last, !last.trimmed.isEmpty else { return }
        output.append("")
    }

    private static func sectionTitle(from line: String) -> String? {
        let trimmed = line.trimmed
        guard trimmed.hasPrefix("## "), !trimmed.hasPrefix("### ") else { return nil }
        return String(trimmed.dropFirst(3)).trimmed
    }
}
