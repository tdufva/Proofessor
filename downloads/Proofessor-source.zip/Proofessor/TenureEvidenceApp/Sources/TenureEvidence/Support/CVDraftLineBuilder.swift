import Foundation

enum CVDraftLineBuilder {
    static func items(from markdown: String, template: CVDraftVariant) -> [CVDraftLineItem] {
        var section = "Header"

        return markdown
            .components(separatedBy: .newlines)
            .enumerated()
            .filter { !$0.element.trimmed.isEmpty }
            .map { index, rawLine in
                let line = rawLine.trimmed
                if line.hasPrefix("## ") {
                    section = String(line.dropFirst(3)).trimmed
                }

                var item = CVDraftLineItem()
                item.section = section
                item.text = line
                item.included = true
                item.sourceConfidence = confidence(in: line)
                item.verified = item.isStructural || item.sourceConfidence != "review"
                item.templateRelevance = relevance(for: line, section: section, template: template)
                item.inclusionReason = inclusionReason(
                    for: line,
                    section: section,
                    template: template,
                    confidence: item.sourceConfidence,
                    relevance: item.templateRelevance,
                    isStructural: item.isStructural
                )
                item.order = index
                return item
            }
    }

    static func markdown(from items: [CVDraftLineItem], cleanOnly: Bool = false) -> String {
        let lines = items
            .sorted { $0.order < $1.order }
            .filter { item in
                guard item.included else { return false }
                guard cleanOnly else { return true }
                return item.isStructural || item.verified
            }
            .map { item in
                cleanOnly ? cleanLine(item.text) : item.text
            }
            .filter { line in
                guard cleanOnly else { return true }
                let lower = line.lowercased()
                return !lower.hasPrefix("generated as an editable draft")
                    && !lower.hasPrefix("source note:")
                    && !lower.contains("[source:")
            }

        return lines.joined(separator: "\n").trimmed + "\n"
    }

    private static func confidence(in line: String) -> String {
        if line.localizedCaseInsensitiveContains("[source: high]") {
            return "high"
        }
        if line.localizedCaseInsensitiveContains("[source: medium]") {
            return "medium"
        }
        if line.localizedCaseInsensitiveContains("[source: profile]") {
            return "profile"
        }
        if line.localizedCaseInsensitiveContains("[source: review]") {
            return "review"
        }
        return "medium"
    }

    private static func relevance(for line: String, section: String, template: CVDraftVariant) -> String {
        let text = "\(line) \(section)".lowercased()

        switch template {
        case .tenk:
            return text.contains("tenk") || text.contains("publication") || text.contains("degree") ? "essential" : "keep"
        case .threePage:
            return text.contains("selected") || text.contains("strongest") || text.contains("current employment") ? "essential" : "optional"
        case .artFocused:
            return text.contains("art") || text.contains("exhibition") ? "essential" : "keep"
        case .tenure:
            return text.contains("research") || text.contains("teaching") || text.contains("impact") ? "essential" : "keep"
        case .publicProfile:
            return text.count < 180 ? "keep" : "optional"
        default:
            return "keep"
        }
    }

    private static func cleanLine(_ line: String) -> String {
        line
            .replacingOccurrences(of: #"\s*\[source:\s*(high|medium|review|profile)\]\s*"#, with: "", options: [.regularExpression, .caseInsensitive])
            .trimmed
    }

    private static func inclusionReason(
        for line: String,
        section: String,
        template: CVDraftVariant,
        confidence: String,
        relevance: String,
        isStructural: Bool
    ) -> String {
        if isStructural {
            return "This is a heading or title line, so it preserves the structure of the \(template.rawValue)."
        }

        var reasons: [String] = []
        reasons.append("It appears in the \(section) section for the \(template.rawValue).")

        switch relevance {
        case "essential":
            reasons.append("The template rules marked it as essential for this CV type.")
        case "optional":
            reasons.append("The template rules marked it as optional; keep it if it strengthens the current audience.")
        case "omit":
            reasons.append("It is currently marked omit, so consider excluding it before export.")
        default:
            reasons.append("It is treated as useful background for this template.")
        }

        switch confidence {
        case "high":
            reasons.append("The source-confidence signal is high.")
        case "medium":
            reasons.append("The source-confidence signal is medium; it is usable but worth checking before final export.")
        case "profile":
            reasons.append("The line appears to come from public profile material.")
        default:
            reasons.append("The source-confidence signal is review, so verify or exclude it for a sendable CV.")
        }

        if line.localizedCaseInsensitiveContains("DOI")
            || line.localizedCaseInsensitiveContains("TENK")
            || line.localizedCaseInsensitiveContains("JUFO") {
            reasons.append("It contains publication metadata that affects academic CV formatting.")
        }

        return reasons.joined(separator: " ")
    }
}
