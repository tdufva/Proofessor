import Foundation

enum CVDiffEngine {
    static func compare(current: String, previous: String, theme: CVDraftTheme) -> CVDiffReport {
        let currentLines = meaningfulLines(current)
        let previousLines = meaningfulLines(previous)
        let currentSet = Set(currentLines)
        let previousSet = Set(previousLines)
        let oldLayout = CVDocumentExporter.layoutReport(for: previous, theme: theme)
        let newLayout = CVDocumentExporter.layoutReport(for: current, theme: theme)

        return CVDiffReport(
            added: Array(Array(currentSet.subtracting(previousSet)).sorted().prefix(25)),
            removed: Array(Array(previousSet.subtracting(currentSet)).sorted().prefix(25)),
            editedHint: editedHints(current: currentLines, previous: previousLines),
            oldWordCount: previous.split(whereSeparator: \.isWhitespace).count,
            newWordCount: current.split(whereSeparator: \.isWhitespace).count,
            oldPageCount: oldLayout.pageCount,
            newPageCount: newLayout.pageCount
        )
    }

    private static func meaningfulLines(_ text: String) -> [String] {
        text.components(separatedBy: .newlines)
            .map { $0.trimmed }
            .filter { !$0.isEmpty && !$0.hasPrefix("# ") }
    }

    private static func editedHints(current: [String], previous: [String]) -> [String] {
        let previousTokens = previous.map { normalized($0) }
        var hints: [String] = []

        for line in current {
            let norm = normalized(line)
            guard !previousTokens.contains(norm) else { continue }
            if previousTokens.contains(where: { similarity(norm, $0) > 0.72 }) {
                hints.append(line)
            }
        }

        return Array(hints.prefix(15))
    }

    private static func normalized(_ value: String) -> String {
        value
            .lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }

    private static func similarity(_ lhs: String, _ rhs: String) -> Double {
        let left = Set(lhs.split(separator: " ").map(String.init))
        let right = Set(rhs.split(separator: " ").map(String.init))
        guard !left.isEmpty, !right.isEmpty else { return 0 }
        return Double(left.intersection(right).count) / Double(left.union(right).count)
    }
}
