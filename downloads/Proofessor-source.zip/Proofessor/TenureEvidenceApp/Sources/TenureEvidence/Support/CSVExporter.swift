import Foundation

enum CSVExporter {
    static func export(entries: [EvidenceEntry]) -> String {
        let header = [
            "Date",
            "Category",
            "Type",
            "Title",
            "Role",
            "Venue",
            "Tenure Dimension",
            "Status",
            "CV Ready",
            "Source",
            "Notes",
            "Attachments"
        ]

        let rows = entries.map { entry in
            [
                entry.date,
                entry.category,
                entry.eventType,
                entry.title,
                entry.role,
                entry.venue,
                entry.tenureDimension,
                entry.status,
                entry.cvReady ? "yes" : "no",
                entry.source,
                entry.notes,
                entry.attachments.map(\.path).joined(separator: " | ")
            ]
        }

        return ([header] + rows)
            .map { $0.map(escape).joined(separator: ",") }
            .joined(separator: "\n") + "\n"
    }

    private static func escape(_ value: String) -> String {
        let escaped = value.replacingOccurrences(of: "\"", with: "\"\"")
        if escaped.contains(",") || escaped.contains("\n") || escaped.contains("\"") {
            return "\"\(escaped)\""
        }
        return escaped
    }
}
