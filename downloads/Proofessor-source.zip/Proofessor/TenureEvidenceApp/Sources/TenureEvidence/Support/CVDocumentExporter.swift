import AppKit
import CoreText
import Foundation

enum CVDocumentExporter {
    private struct RenderedPDF {
        var data: Data
        var pageCount: Int
    }

    private struct RenderPlan {
        var bodyMarkdown: String
        var masthead: CVMasthead?
    }

    private struct CVMasthead {
        var title: String
        var details: [String]
        var image: NSImage
    }

    static func export(
        draft: String,
        variant: CVDraftVariant,
        theme: CVDraftTheme,
        format: CVExportFormat,
        workspaceURL: URL,
        profilePicturePath: String? = nil
    ) throws -> URL {
        let folder = workspaceURL
            .appendingPathComponent("09_Tenure_Application_Dossier")
            .appendingPathComponent("Draft_Materials")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

        let fileURL = folder.appendingPathComponent("\(variant.fileStem)_\(theme.fileStem).\(format.fileExtension)")
        let resolvedProfilePicturePath = profilePicturePathForExport(
            profilePicturePath,
            variant: variant,
            theme: theme,
            format: format
        )

        switch format {
        case .markdown:
            try draft.write(to: fileURL, atomically: true, encoding: .utf8)
        case .rtf:
            let attributed = makeAttributedString(from: draft, theme: theme, profilePicturePath: resolvedProfilePicturePath)
            try writeAttributed(attributed, documentType: .rtf, to: fileURL)
        case .word:
            let attributed = makeAttributedString(from: draft, theme: theme, profilePicturePath: resolvedProfilePicturePath)
            try writeAttributed(attributed, documentType: .officeOpenXML, to: fileURL)
        case .pdf:
            let plan = renderPlan(from: draft, theme: theme, profilePicturePath: resolvedProfilePicturePath)
            let attributed = makeAttributedString(from: plan.bodyMarkdown, theme: theme, mastheadAttachment: nil)
            try writePDF(attributed, theme: theme, masthead: plan.masthead, to: fileURL)
        case .pages:
            let attributed = makeAttributedString(from: draft, theme: theme, profilePicturePath: resolvedProfilePicturePath)
            try writePages(attributed, variant: variant, theme: theme, destination: fileURL, in: folder)
        }

        return fileURL
    }

    static func pdfData(from draft: String, theme: CVDraftTheme, profilePicturePath: String? = nil) throws -> Data {
        let plan = renderPlan(from: draft, theme: theme, profilePicturePath: profilePicturePath)
        let attributed = makeAttributedString(from: plan.bodyMarkdown, theme: theme, mastheadAttachment: nil)
        return try renderPDF(attributed, theme: theme, masthead: plan.masthead).data
    }

    static func layoutReport(for draft: String, theme: CVDraftTheme, profilePicturePath: String? = nil) -> CVLayoutReport {
        guard !draft.trimmed.isEmpty else { return .empty }

        do {
            let plan = renderPlan(from: draft, theme: theme, profilePicturePath: profilePicturePath)
            let attributed = makeAttributedString(from: plan.bodyMarkdown, theme: theme, mastheadAttachment: nil)
            let rendered = try renderPDF(attributed, theme: theme, masthead: plan.masthead)
            let status: String

            if rendered.pageCount <= 3 {
                status = "Three-page safe"
            } else {
                status = "\(rendered.pageCount - 3) page(s) over three"
            }

            return CVLayoutReport(pageCount: rendered.pageCount, threePageStatus: status)
        } catch {
            return CVLayoutReport(pageCount: 0, threePageStatus: "Layout failed")
        }
    }

    static func makeAttributedString(
        from markdown: String,
        theme: CVDraftTheme,
        profilePicturePath: String? = nil
    ) -> NSAttributedString {
        let plan = renderPlan(from: markdown, theme: theme, profilePicturePath: profilePicturePath)
        return makeAttributedString(from: plan.bodyMarkdown, theme: theme, mastheadAttachment: plan.masthead)
    }

    private static func makeAttributedString(
        from markdown: String,
        theme: CVDraftTheme,
        mastheadAttachment: CVMasthead?
    ) -> NSAttributedString {
        let output = NSMutableAttributedString()
        let bodyParagraph = paragraphStyle(lineSpacing: theme.lineSpacing, paragraphSpacing: 4)
        let headingParagraph = paragraphStyle(lineSpacing: theme.lineSpacing, paragraphSpacing: 8)
        let bulletParagraph = paragraphStyle(lineSpacing: theme.lineSpacing, paragraphSpacing: 3, firstLineHeadIndent: 0, headIndent: 18)

        if let mastheadAttachment {
            appendMastheadAttachment(mastheadAttachment, to: output, theme: theme)
        }

        for rawLine in markdown.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)

            if line.isEmpty {
                output.append(NSAttributedString(string: "\n", attributes: [.font: theme.bodyFont, .paragraphStyle: bodyParagraph]))
                continue
            }

            if line.hasPrefix("# ") {
                append(String(line.dropFirst(2)), to: output, font: theme.titleFont, color: .labelColor, paragraph: headingParagraph, trailingNewlines: 2)
            } else if line.hasPrefix("## ") {
                append(String(line.dropFirst(3)), to: output, font: theme.headingFont, color: theme.accentColor, paragraph: headingParagraph, trailingNewlines: 1)
            } else if line.hasPrefix("### ") {
                append(String(line.dropFirst(4)), to: output, font: theme.headingFont, color: .labelColor, paragraph: headingParagraph, trailingNewlines: 1)
            } else if line.hasPrefix("- ") {
                append("- \(line.dropFirst(2))", to: output, font: theme.bodyFont, color: .labelColor, paragraph: bulletParagraph, trailingNewlines: 1)
            } else {
                append(line, to: output, font: theme.bodyFont, color: .labelColor, paragraph: bodyParagraph, trailingNewlines: 1)
            }
        }

        return output
    }

    private static func profilePicturePathForExport(
        _ path: String?,
        variant: CVDraftVariant,
        theme: CVDraftTheme,
        format: CVExportFormat
    ) -> String? {
        guard variant != .tenk,
              theme != .tenkFormal,
              format != .markdown,
              theme.rendersProfilePictureMasthead else {
            return nil
        }

        return path
    }

    private static func renderPlan(from markdown: String, theme: CVDraftTheme, profilePicturePath: String?) -> RenderPlan {
        guard theme.rendersProfilePictureMasthead,
              let image = profileImage(from: profilePicturePath) else {
            return RenderPlan(bodyMarkdown: markdown, masthead: nil)
        }

        let parsed = parseMastheadSource(from: markdown)
        let masthead = CVMasthead(title: parsed.title, details: parsed.details, image: image)
        return RenderPlan(bodyMarkdown: parsed.remainingMarkdown, masthead: masthead)
    }

    private static func profileImage(from path: String?) -> NSImage? {
        guard let path = path?.trimmed, !path.isEmpty else { return nil }
        return NSImage(contentsOfFile: path)
    }

    private static func parseMastheadSource(from markdown: String) -> (title: String, details: [String], remainingMarkdown: String) {
        var lines = markdown.components(separatedBy: .newlines)
        var title = "Curriculum Vitae"
        var titleIndex: Int?

        for index in lines.indices {
            let line = lines[index].trimmed
            guard !line.isEmpty else { continue }
            if line.hasPrefix("# ") {
                title = String(line.dropFirst(2)).trimmed
                titleIndex = index
            }
            break
        }

        guard let titleIndex else {
            return (title, [], markdown)
        }

        var details: [String] = []
        var removeIndices = Set<Int>([titleIndex])
        var index = titleIndex + 1

        while index < lines.count {
            let line = lines[index].trimmed

            if line.isEmpty {
                removeIndices.insert(index)
                index += 1
                continue
            }

            if line.hasPrefix("## ") || line.hasPrefix("### ") || line.hasPrefix("- ") {
                break
            }

            details.append(line)
            removeIndices.insert(index)
            index += 1

            if details.count >= 4 {
                break
            }
        }

        lines = lines.enumerated()
            .filter { !removeIndices.contains($0.offset) }
            .map(\.element)

        return (title, details, lines.joined(separator: "\n").trimmed)
    }

    private static func append(
        _ string: String,
        to output: NSMutableAttributedString,
        font: NSFont,
        color: NSColor,
        paragraph: NSParagraphStyle,
        trailingNewlines: Int
    ) {
        output.append(
            NSAttributedString(
                string: string + String(repeating: "\n", count: trailingNewlines),
                attributes: [
                    .font: font,
                    .foregroundColor: color,
                    .paragraphStyle: paragraph
                ]
            )
        )
    }

    private static func appendMastheadAttachment(
        _ masthead: CVMasthead,
        to output: NSMutableAttributedString,
        theme: CVDraftTheme
    ) {
        let width = 595.2 - theme.pageMargin * 2
        guard let mastheadImage = makeMastheadImage(masthead, theme: theme, width: width) else { return }

        let attachment = NSTextAttachment()
        attachment.image = mastheadImage
        attachment.bounds = CGRect(origin: .zero, size: mastheadImage.size)

        let paragraph = paragraphStyle(lineSpacing: theme.lineSpacing, paragraphSpacing: 12)
        let attached = NSMutableAttributedString(attachment: attachment)
        attached.addAttributes(
            [.paragraphStyle: paragraph],
            range: NSRange(location: 0, length: attached.length)
        )

        output.append(attached)
        output.append(NSAttributedString(string: "\n\n", attributes: [.font: theme.bodyFont, .paragraphStyle: paragraph]))
    }

    private static func paragraphStyle(
        lineSpacing: CGFloat,
        paragraphSpacing: CGFloat,
        firstLineHeadIndent: CGFloat = 0,
        headIndent: CGFloat = 0
    ) -> NSParagraphStyle {
        let style = NSMutableParagraphStyle()
        style.lineSpacing = lineSpacing
        style.paragraphSpacing = paragraphSpacing
        style.firstLineHeadIndent = firstLineHeadIndent
        style.headIndent = headIndent
        return style
    }

    private static func writeAttributed(
        _ attributed: NSAttributedString,
        documentType: NSAttributedString.DocumentType,
        to fileURL: URL
    ) throws {
        let range = NSRange(location: 0, length: attributed.length)
        let data = try attributed.data(
            from: range,
            documentAttributes: [
                .documentType: documentType,
                .paperSize: NSValue(size: NSSize(width: 595.2, height: 841.8))
            ]
        )
        try data.write(to: fileURL, options: .atomic)
    }

    private static func writePDF(_ attributed: NSAttributedString, theme: CVDraftTheme, masthead: CVMasthead?, to fileURL: URL) throws {
        let rendered = try renderPDF(attributed, theme: theme, masthead: masthead)
        try rendered.data.write(to: fileURL, options: .atomic)
    }

    private static func renderPDF(_ attributed: NSAttributedString, theme: CVDraftTheme, masthead: CVMasthead?) throws -> RenderedPDF {
        let pageSize = CGSize(width: 595.2, height: 841.8)
        var mediaBox = CGRect(origin: .zero, size: pageSize)
        let data = NSMutableData()
        var pageCount = 0

        guard let consumer = CGDataConsumer(data: data),
              let context = CGContext(consumer: consumer, mediaBox: &mediaBox, nil) else {
            throw CocoaError(.fileWriteUnknown)
        }

        let framesetter = CTFramesetterCreateWithAttributedString(attributed)
        var range = CFRange(location: 0, length: 0)

        while range.location < attributed.length || (pageCount == 0 && masthead != nil) {
            context.beginPDFPage(nil)
            pageCount += 1
            context.saveGState()
            context.textMatrix = .identity

            let firstPageMasthead = pageCount == 1 ? masthead : nil
            let mastheadHeight = firstPageMasthead.map { height(for: $0, theme: theme) } ?? 0

            if let firstPageMasthead {
                let contentWidth = pageSize.width - theme.pageMargin * 2
                let origin = CGPoint(
                    x: theme.pageMargin,
                    y: pageSize.height - theme.pageMargin - mastheadHeight
                )
                drawMasthead(firstPageMasthead, in: context, origin: origin, width: contentWidth, theme: theme)
            }

            let textRect = CGRect(
                x: theme.pageMargin,
                y: theme.pageMargin,
                width: pageSize.width - theme.pageMargin * 2,
                height: pageSize.height - theme.pageMargin * 2 - mastheadHeight - (firstPageMasthead == nil ? 0 : 18)
            )

            if attributed.length == 0 {
                context.restoreGState()
                context.endPDFPage()
                break
            }

            let path = CGMutablePath()
            path.addRect(textRect)
            let frame = CTFramesetterCreateFrame(framesetter, range, path, nil)
            CTFrameDraw(frame, context)
            let visible = CTFrameGetVisibleStringRange(frame)
            range.location += max(visible.length, 1)

            context.restoreGState()
            context.endPDFPage()
        }

        context.closePDF()
        return RenderedPDF(data: data as Data, pageCount: pageCount)
    }

    private static func makeMastheadImage(_ masthead: CVMasthead, theme: CVDraftTheme, width: CGFloat) -> NSImage? {
        let height = height(for: masthead, theme: theme)
        let image = NSImage(size: NSSize(width: width, height: height))
        image.lockFocus()
        defer { image.unlockFocus() }

        guard let context = NSGraphicsContext.current?.cgContext else { return nil }
        context.clear(CGRect(origin: .zero, size: CGSize(width: width, height: height)))
        drawMasthead(masthead, in: context, origin: .zero, width: width, theme: theme)
        return image
    }

    private static func height(for masthead: CVMasthead, theme: CVDraftTheme) -> CGFloat {
        let imageSize = mastheadImageSize(for: theme)
        let detailHeight = CGFloat(min(masthead.details.count, 4)) * 17
        let textHeight = theme.titleFont.ascender - theme.titleFont.descender + detailHeight + 20
        return max(imageSize, textHeight) + 18
    }

    private static func mastheadImageSize(for theme: CVDraftTheme) -> CGFloat {
        switch theme {
        case .portraitProfile:
            106
        default:
            94
        }
    }

    private static func drawMasthead(
        _ masthead: CVMasthead,
        in context: CGContext,
        origin: CGPoint,
        width: CGFloat,
        theme: CVDraftTheme
    ) {
        let height = height(for: masthead, theme: theme)
        let topY = origin.y + height
        let imageSize = mastheadImageSize(for: theme)
        let imageRect = CGRect(
            x: origin.x,
            y: topY - imageSize,
            width: imageSize,
            height: imageSize
        )

        context.saveGState()
        let clipPath = CGPath(
            roundedRect: imageRect,
            cornerWidth: 10,
            cornerHeight: 10,
            transform: nil
        )
        context.addPath(clipPath)
        context.clip()

        if let cgImage = masthead.image.cgImage(forProposedRect: nil, context: nil, hints: nil) {
            context.draw(cgImage, in: aspectFillRect(imageSize: CGSize(width: cgImage.width, height: cgImage.height), target: imageRect))
        }
        context.restoreGState()

        context.setStrokeColor(NSColor.separatorColor.cgColor)
        context.setLineWidth(0.6)
        context.addPath(clipPath)
        context.strokePath()

        let textX = imageRect.maxX + 18
        let titleBaseline = topY - 30
        let detailStart = titleBaseline - 26
        let textWidth = max(120, width - imageSize - 18)

        drawTextLine(
            masthead.title,
            font: NSFont.systemFont(ofSize: max(theme.titleFont.pointSize, 24), weight: .semibold),
            color: theme.accentColor,
            at: CGPoint(x: textX, y: titleBaseline),
            maxWidth: textWidth,
            in: context
        )

        for (index, detail) in masthead.details.prefix(4).enumerated() {
            drawTextLine(
                detail,
                font: theme.bodyFont,
                color: .secondaryLabelColor,
                at: CGPoint(x: textX, y: detailStart - CGFloat(index) * 17),
                maxWidth: textWidth,
                in: context
            )
        }

        let lineY = origin.y + 4
        context.setStrokeColor((theme.accentColor.usingColorSpace(.deviceRGB) ?? theme.accentColor).cgColor)
        context.setLineWidth(1.2)
        context.move(to: CGPoint(x: origin.x, y: lineY))
        context.addLine(to: CGPoint(x: origin.x + width, y: lineY))
        context.strokePath()
    }

    private static func drawTextLine(
        _ text: String,
        font: NSFont,
        color: NSColor,
        at point: CGPoint,
        maxWidth: CGFloat,
        in context: CGContext
    ) {
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineBreakMode = .byTruncatingTail

        let attributed = NSAttributedString(
            string: text,
            attributes: [
                .font: font,
                .foregroundColor: color,
                .paragraphStyle: paragraph
            ]
        )
        let line = CTLineCreateWithAttributedString(attributed)
        let ellipsis = CTLineCreateWithAttributedString(
            NSAttributedString(
                string: "...",
                attributes: [
                    .font: font,
                    .foregroundColor: color
                ]
            )
        )
        let drawableLine = CTLineCreateTruncatedLine(line, Double(maxWidth), .end, ellipsis) ?? line

        context.saveGState()
        context.textPosition = point
        CTLineDraw(drawableLine, context)
        context.restoreGState()
    }

    private static func aspectFillRect(imageSize: CGSize, target: CGRect) -> CGRect {
        guard imageSize.width > 0, imageSize.height > 0 else { return target }

        let scale = max(target.width / imageSize.width, target.height / imageSize.height)
        let width = imageSize.width * scale
        let height = imageSize.height * scale

        return CGRect(
            x: target.midX - width / 2,
            y: target.midY - height / 2,
            width: width,
            height: height
        )
    }

    private static func writePages(
        _ attributed: NSAttributedString,
        variant: CVDraftVariant,
        theme: CVDraftTheme,
        destination: URL,
        in folder: URL
    ) throws {
        let intermediate = folder.appendingPathComponent("\(variant.fileStem)_\(theme.fileStem)_pages_source.rtf")
        try writeAttributed(attributed, documentType: .rtf, to: intermediate)

        if FileManager.default.fileExists(atPath: destination.path) {
            try FileManager.default.removeItem(at: destination)
        }

        let script = """
        set sourceFile to POSIX file "\(intermediate.path)" as alias
        set targetFile to POSIX file "\(destination.path)"
        tell application "Pages"
            activate
            open sourceFile
            delay 0.5
            set theDoc to front document
            save theDoc in targetFile
            close theDoc saving no
        end tell
        """

        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
        process.arguments = ["-e", script]

        let errorPipe = Pipe()
        process.standardError = errorPipe
        try process.run()
        process.waitUntilExit()

        if process.terminationStatus != 0 {
            let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
            let errorText = String(data: errorData, encoding: .utf8) ?? "Pages export failed."
            throw NSError(
                domain: "CVDocumentExporter",
                code: Int(process.terminationStatus),
                userInfo: [NSLocalizedDescriptionKey: errorText.trimmed.isEmpty ? "Pages export failed." : errorText.trimmed]
            )
        }
    }
}
