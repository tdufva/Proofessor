import Foundation

enum CVStructuredItemBuilder {
    static func build(sourceText: String, entries: [EvidenceEntry]) -> [CVStructuredItem] {
        var items: [CVStructuredItem] = []
        var order = 0

        for entry in entries {
            items.append(item(from: entry, order: order))
            order += 1
        }

        var sourceOptions = CVBuildOptions()
        sourceOptions.includeSourceConfidence = false
        let source = CVSource(text: sourceText, options: sourceOptions)
        let mappings: [(CVStructuredSection, String)] = [
            (.other, "Language skills"),
            (.other, "Keywords and expertise"),
            (.visibility, "Sustainable Development Goals / public profile links"),
            (.education, "Degrees"),
            (.education, "Other education and expertise"),
            (.employment, "Current Employment"),
            (.employment, "Previous work experience"),
            (.grant, "Research funding and grants"),
            (.publication, "Research output (selected)"),
            (.artisticWork, "Artistic Work (selected)"),
            (.artisticWork, "Research and artistic project notes"),
            (.supervision, "Research supervision and leadership experience"),
            (.teaching, "Teaching merits"),
            (.other, "Awards and honors"),
            (.service, "Other key academic merits"),
            (.service, "Reviewer and editorial work"),
            (.talk, "International invited talks and presentations"),
            (.visibility, "Scientific and societal impact"),
            (.visibility, "Press/Media"),
            (.visibility, "Website and public artistic projects"),
            (.other, "Other merits")
        ]

        for (section, heading) in mappings {
            let lines = source.rawSection(heading)
                .components(separatedBy: .newlines)
                .map { $0.trimmed.removingLeadingMarkdownBullet }
                .filter { !$0.isEmpty && !$0.hasPrefix("###") }

            for line in lines {
                items.append(item(fromSourceLine: line, section: section, source: heading, order: order))
                order += 1
            }
        }

        for line in importedCVScanLines(in: sourceText) {
            guard let section = inferredSection(forImportedLine: line) else { continue }
            items.append(item(fromSourceLine: line, section: section, source: "Imported CV file scan", order: order))
            order += 1
        }

        var seen = Set<String>()
        return items.filter { item in
            let key = matchKey(for: item)
            guard !seen.contains(key) else { return false }
            seen.insert(key)
            return true
        }
    }

    static func mergeMissingImportedCVItems(
        into existingItems: [CVStructuredItem],
        sourceText: String,
        entries: [EvidenceEntry]
    ) -> (items: [CVStructuredItem], addedCount: Int) {
        var merged = existingItems
        var seen = Set(existingItems.map(matchKey(for:)))
        var nextOrder = (existingItems.map(\.order).max() ?? -1) + 1
        var addedCount = 0

        for candidate in build(sourceText: sourceText, entries: entries) {
            let key = matchKey(for: candidate)
            guard !seen.contains(key) else { continue }

            var item = candidate
            item.order = nextOrder
            nextOrder += 1
            merged.append(item)
            seen.insert(key)
            addedCount += 1
        }

        return (merged, addedCount)
    }

    static func deduplicated(_ items: [CVStructuredItem]) -> (items: [CVStructuredItem], removedCount: Int) {
        var output: [CVStructuredItem] = []
        var indexByKey: [String: Int] = [:]
        var removedCount = 0

        for item in items.sorted(by: { $0.order < $1.order }) {
            let key = matchKey(for: item)
            guard !key.isEmpty else {
                output.append(item)
                continue
            }

            if let existingIndex = indexByKey[key] {
                output[existingIndex] = mergedPreferred(output[existingIndex], item)
                removedCount += 1
            } else {
                indexByKey[key] = output.count
                output.append(item)
            }
        }

        for index in output.indices {
            output[index].order = index
        }

        return (output, removedCount)
    }

    static func matchKey(for item: CVStructuredItem) -> String {
        [
            item.section.rawValue,
            item.year,
            titleWithoutEmbeddedSourceBadge(item.title)
        ]
        .joined(separator: "|")
        .lowercased()
        .components(separatedBy: CharacterSet.alphanumerics.inverted)
        .filter { !$0.isEmpty }
        .joined()
    }

    private static func titleWithoutEmbeddedSourceBadge(_ title: String) -> String {
        title
            .replacingOccurrences(of: #"\s*\[source:[^\]]+\]\.?\s*$"#, with: "", options: .regularExpression)
            .trimmed
    }

    private static func mergedPreferred(_ lhs: CVStructuredItem, _ rhs: CVStructuredItem) -> CVStructuredItem {
        var keeper = preferredItem(lhs, rhs)
        let other = keeper.id == lhs.id ? rhs : lhs

        keeper.verified = keeper.verified || other.verified
        keeper.sourceConfidence = strongerConfidence(keeper.sourceConfidence, other.sourceConfidence)
        keeper.linkedEvidenceIDs = mergedIDs(keeper.linkedEvidenceIDs, other.linkedEvidenceIDs)

        if keeper.source.trimmed.isEmpty {
            keeper.source = other.source
        } else if !other.source.trimmed.isEmpty,
                  !keeper.source.localizedCaseInsensitiveContains(other.source.trimmed) {
            keeper.source += " | \(other.source.trimmed)"
        }

        if keeper.notes.trimmed.isEmpty {
            keeper.notes = other.notes
        }

        if keeper.includeInTemplates.isEmpty {
            keeper.includeInTemplates = other.includeInTemplates
        } else {
            keeper.includeInTemplates = Array(Set(keeper.includeInTemplates + other.includeInTemplates)).sorted()
        }

        return keeper
    }

    private static func preferredItem(_ lhs: CVStructuredItem, _ rhs: CVStructuredItem) -> CVStructuredItem {
        let lhsHasEmbeddedBadge = lhs.title.localizedCaseInsensitiveContains("[source:")
        let rhsHasEmbeddedBadge = rhs.title.localizedCaseInsensitiveContains("[source:")

        if lhsHasEmbeddedBadge != rhsHasEmbeddedBadge {
            return lhsHasEmbeddedBadge ? rhs : lhs
        }

        if lhs.verified != rhs.verified {
            return lhs.verified ? lhs : rhs
        }

        if confidenceRank(lhs.sourceConfidence) != confidenceRank(rhs.sourceConfidence) {
            return confidenceRank(lhs.sourceConfidence) > confidenceRank(rhs.sourceConfidence) ? lhs : rhs
        }

        return lhs.order <= rhs.order ? lhs : rhs
    }

    private static func mergedIDs(_ lhs: [UUID]?, _ rhs: [UUID]?) -> [UUID]? {
        let ids = Array(Set((lhs ?? []) + (rhs ?? [])))
        return ids.isEmpty ? nil : ids
    }

    private static func strongerConfidence(_ lhs: String, _ rhs: String) -> String {
        confidenceRank(lhs) >= confidenceRank(rhs) ? lhs : rhs
    }

    private static func item(from entry: EvidenceEntry, order: Int) -> CVStructuredItem {
        var item = CVStructuredItem()
        item.section = section(for: entry)
        item.year = String(entry.date.prefix(4))
        item.title = entry.title
        item.role = entry.role
        item.venue = entry.venue
        item.doi = PublicationFormatter.doi(in: [entry.title, entry.source, entry.notes].joined(separator: " ")) ?? ""
        item.peerReview = peerReview(from: [entry.eventType, entry.notes, entry.source].joined(separator: " "))
        item.tenkClass = item.section == .publication ? PublicationFormatter.tenkCategory(for: [entry.title, entry.venue, entry.notes].joined(separator: " ")) : ""
        item.jufoLevel = "check"
        item.sourceConfidence = SourceConfidenceEvaluator.badge(for: entry).confidenceValue
        item.visibility = entry.category == "Visibility" ? "public" : "academic"
        item.verified = entry.cvReady || entry.completeness.score >= 90
        item.includeInTemplates = CVDraftVariant.allCases.filter { include(entry: entry, in: $0) }.map(\.rawValue)
        item.linkedEvidenceIDs = [entry.id]
        item.source = entry.source
        item.notes = entry.notes
        item.order = order
        return item
    }

    private static func item(fromSourceLine line: String, section: CVStructuredSection, source: String, order: Int) -> CVStructuredItem {
        var item = CVStructuredItem()
        item.section = section
        item.year = line.firstFourDigitYear ?? ""
        item.title = line
        item.doi = PublicationFormatter.doi(in: line) ?? ""
        item.peerReview = peerReview(from: line)
        item.tenkClass = section == .publication ? PublicationFormatter.tenkCategory(for: line) : ""
        item.jufoLevel = section == .publication ? "check" : ""
        item.role = line.localizedCaseInsensitiveContains("dufva") ? "author/contributor" : ""
        item.sourceConfidence = SourceConfidenceEvaluator.badge(for: line, section: source).confidenceValue
        item.visibility = section == .visibility ? "public" : "academic"
        item.verified = item.sourceConfidence == "high"
        item.includeInTemplates = defaultTemplates(for: section)
        item.source = "CV master source: \(source)"
        item.order = order
        return item
    }

    private static func importedCVScanLines(in sourceText: String) -> [String] {
        let lines = sourceText
            .components(separatedBy: .newlines)
            .map { $0.trimmed.removingLeadingMarkdownBullet }

        guard lines.contains(where: { $0.localizedCaseInsensitiveContains("Imported CV Source Scan") }) else {
            return []
        }

        var importedLines: [String] = []
        var inImportedFile = false

        for line in lines {
            if line.localizedCaseInsensitiveContains("Imported CV file:") {
                inImportedFile = true
                continue
            }

            guard inImportedFile else { continue }
            guard shouldKeepImportedCVLine(line) else { continue }
            importedLines.append(line)
        }

        var seen = Set<String>()
        return importedLines.filter { line in
            let key = normalizedLineKey(line)
            guard !seen.contains(key) else { return false }
            seen.insert(key)
            return true
        }
    }

    private static func shouldKeepImportedCVLine(_ line: String) -> Bool {
        let lower = line.lowercased()
        guard line.count >= 12, line.count <= 420 else { return false }
        guard !line.hasPrefix("#"), line != "---" else { return false }
        guard !lower.hasPrefix("source path:"),
              !lower.hasPrefix("generated:"),
              !lower.hasPrefix("files scanned:"),
              !lower.hasPrefix("files imported:"),
              !lower.hasPrefix("files skipped:"),
              !lower.hasPrefix("page "),
              !lower.hasPrefix("curriculum vitae"),
              lower != "tomi slotte dufva" else {
            return false
        }

        if lower.hasPrefix("http"), !lower.contains("orcid"), !lower.contains("scholar"), !lower.contains("aalto") {
            return false
        }

        let hasYear = line.range(of: #"\b(19|20)\d{2}\b"#, options: .regularExpression) != nil
        let strongProfileLine = lower.contains("orcid")
            || lower.contains("google scholar")
            || lower.contains("research.aalto")
            || lower.contains("aalto.fi/en/people")
        return hasYear || strongProfileLine
    }

    private static func inferredSection(forImportedLine line: String) -> CVStructuredSection? {
        let lower = line.lowercased()

        if lower.contains("orcid")
            || lower.contains("google scholar")
            || lower.contains("research.aalto")
            || lower.contains("aalto.fi/en/people") {
            return .visibility
        }

        if lower.contains("doi")
            || lower.contains("journal")
            || lower.contains("article")
            || lower.contains("chapter")
            || lower.contains("proceedings")
            || lower.contains("isbn")
            || (lower.contains("dufva") && lower.contains("(") && lower.contains(")")) {
            return .publication
        }

        if lower.contains("keynote")
            || lower.contains("invited talk")
            || lower.contains("lecture")
            || lower.contains("presentation")
            || lower.contains("conference")
            || lower.contains("symposium")
            || lower.contains("seminar")
            || lower.contains("workshop")
            || lower.contains("panel") {
            return .talk
        }

        if lower.contains("exhibition")
            || lower.contains("gallery")
            || lower.contains("galleria")
            || lower.contains("artistic")
            || lower.contains("artwork") {
            return .artisticWork
        }

        if lower.contains("grant")
            || lower.contains("funding")
            || lower.contains("funded")
            || lower.contains("consortium")
            || lower.contains(" eur ") {
            return .grant
        }

        if lower.contains("doctoral thesis")
            || lower.contains("supervisor")
            || lower.contains("supervision")
            || lower.contains("examiner") {
            return .supervision
        }

        if lower.contains("doctor of")
            || lower.contains("master of")
            || lower.contains("phd")
            || lower.contains("degree")
            || lower.contains("dissertation") {
            return .education
        }

        if lower.contains("assistant professor")
            || lower.contains("lecturer")
            || lower.contains("head of")
            || lower.contains("university teacher") {
            return .employment
        }

        if lower.contains("teaching")
            || lower.contains("teacher")
            || lower.contains("course")
            || lower.contains("pedagog") {
            return .teaching
        }

        if lower.contains("committee")
            || lower.contains("board")
            || lower.contains("reviewer")
            || lower.contains("editorial")
            || lower.contains("member") {
            return .service
        }

        return nil
    }

    private static func normalizedLineKey(_ line: String) -> String {
        line
            .lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined()
    }

    private static func section(for entry: EvidenceEntry) -> CVStructuredSection {
        switch entry.category {
        case "Publication": .publication
        case "Talk": .talk
        case "Teaching": .teaching
        case "Service": .service
        case "Funding": .grant
        case "Artistic Output": .artisticWork
        case "Supervision": .supervision
        case "Visibility": .visibility
        default: .other
        }
    }

    private static func include(entry: EvidenceEntry, in variant: CVDraftVariant) -> Bool {
        switch variant {
        case .artFocused:
            entry.category == "Artistic Output" || entry.category == "Talk" || entry.category == "Publication"
        case .researchFocused:
            entry.category == "Publication" || entry.category == "Funding" || entry.tenureDimension == "Research/artistic work"
        case .teachingFocused:
            entry.category == "Teaching" || entry.category == "Supervision"
        case .tenure:
            true
        case .publicProfile:
            entry.category == "Visibility" || entry.cvReady
        case .threePage:
            entry.cvReady || entry.completeness.score >= 90
        default:
            true
        }
    }

    private static func defaultTemplates(for section: CVStructuredSection) -> [String] {
        let broadDefaults = [
            CVDraftVariant.currentPages.rawValue,
            CVDraftVariant.generalAcademic.rawValue
        ]

        switch section {
        case .publication:
            return broadDefaults + [
                CVDraftVariant.cv2025Research.rawValue,
                CVDraftVariant.researchFocused.rawValue,
                CVDraftVariant.artFocused.rawValue,
                CVDraftVariant.tenk.rawValue,
                CVDraftVariant.tenure.rawValue,
                CVDraftVariant.publicProfile.rawValue
            ]
        case .artisticWork:
            return broadDefaults + [
                CVDraftVariant.artFocused.rawValue,
                CVDraftVariant.researchFocused.rawValue,
                CVDraftVariant.tenure.rawValue,
                CVDraftVariant.publicProfile.rawValue
            ]
        case .teaching, .supervision:
            return broadDefaults + [
                CVDraftVariant.teachingFocused.rawValue,
                CVDraftVariant.tenk.rawValue,
                CVDraftVariant.tenure.rawValue
            ]
        case .visibility, .service:
            return broadDefaults + [
                CVDraftVariant.researchFocused.rawValue,
                CVDraftVariant.teachingFocused.rawValue,
                CVDraftVariant.artFocused.rawValue,
                CVDraftVariant.publicProfile.rawValue,
                CVDraftVariant.tenure.rawValue
            ]
        default:
            return CVDraftVariant.allCases.map(\.rawValue)
        }
    }

    private static func peerReview(from text: String) -> String {
        let lower = text.lowercased()
        if lower.contains("peer-reviewed") || lower.contains("peer reviewed") || lower.contains("refereed") {
            return "yes"
        }
        if lower.contains("journal") || lower.contains("proceedings") {
            return "check"
        }
        return "not stated"
    }
}

private func confidenceRank(_ confidence: String) -> Int {
    switch confidence.lowercased() {
    case "high": 4
    case "medium": 3
    case "profile": 2
    default: 1
    }
}

private extension String {
    var removingLeadingMarkdownBullet: String {
        hasPrefix("- ") ? String(dropFirst(2)).trimmed : self
    }

    var firstFourDigitYear: String? {
        guard let range = range(of: #"\b(19|20)\d{2}\b"#, options: .regularExpression) else {
            return nil
        }
        return String(self[range])
    }
}

private extension String {
    var confidenceValue: String {
        if localizedCaseInsensitiveContains("high") { return "high" }
        if localizedCaseInsensitiveContains("profile") { return "profile" }
        if localizedCaseInsensitiveContains("review") { return "review" }
        return "medium"
    }
}
