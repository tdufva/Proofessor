import Foundation

enum PublicationCitationExporter {
    static func export(entries: [EvidenceEntry], sourceText: String, structuredItems: [CVStructuredItem], style: CitationExportStyle) -> String {
        let publicationEntries = entries
            .filter { $0.category == "Publication" }
            .sorted { $0.date > $1.date }
        let structuredPublications = structuredItems
            .filter { $0.section == .publication }
            .sorted { lhs, rhs in
                if lhs.year == rhs.year { return lhs.title < rhs.title }
                return lhs.year > rhs.year
            }
        let sourceLines = sourcePublicationLines(from: sourceText)

        var output = """
        # \(style.rawValue) Publication Export

        Generated from Proofessor records and CV master source publication lines. Review before formal use.

        """

        if !structuredPublications.isEmpty {
            output += "\n## Structured Publication Records\n\n"
            output += structuredPublications.map { line(for: $0, style: style) }.joined(separator: "\n")
            output += "\n"
        } else if !publicationEntries.isEmpty {
            output += "\n## App Publication Records\n\n"
            output += publicationEntries.map { line(for: $0, style: style) }.joined(separator: "\n")
            output += "\n"
        }

        if !sourceLines.isEmpty {
            output += "\n## CV Master Source Publication Lines\n\n"
            output += sourceLines.map { line(forSourceLine: $0, style: style) }.joined(separator: "\n")
            output += "\n"
        }

        if structuredPublications.isEmpty, publicationEntries.isEmpty, sourceLines.isEmpty {
            output += "No publication records found yet.\n"
        }

        return output
    }

    private static func line(for item: CVStructuredItem, style: CitationExportStyle) -> String {
        let year = item.year.trimmed.isEmpty ? "n.d." : item.year.trimmed
        let title = item.title.trimmed.isEmpty ? "Untitled publication" : item.title.trimmed
        let venue = item.venue.trimmed
        let doi = item.doi.trimmed.isEmpty ? nil : item.doi.trimmed

        switch style {
        case .apa:
            let authors = item.authors.trimmed.isEmpty ? "Candidate, E." : item.authors.trimmed
            return "- \(authors) (\(year)). \(title). \(venue)\(doi.map { ". https://doi.org/\($0)" } ?? "")."
        case .chicago:
            let authors = item.authors.trimmed.isEmpty ? "Candidate, Example" : item.authors.trimmed
            return "- \(authors). \"\(title).\" \(venue)\(year == "n.d." ? "" : ", \(year)")\(doi.map { ". doi:\($0)" } ?? "")."
        case .tenkJufo:
            return "- \(year) | \(title) | \(venue) | TENK: \(item.tenkClass) | JUFO: \(item.jufoLevel) | Role: \(item.role) | Peer review: \(item.peerReview) | DOI: \(doi ?? "missing") | Source confidence: \(item.sourceConfidence)."
        }
    }

    private static func sourcePublicationLines(from sourceText: String) -> [String] {
        var options = CVBuildOptions()
        options.includeSourceConfidence = false

        return CVSource(text: sourceText, options: options).rawSection("Research output (selected)")
            .components(separatedBy: .newlines)
            .map(\.trimmed)
            .filter { line in
                line.hasPrefix("- ") && !line.localizedCaseInsensitiveContains("Classification")
            }
    }

    private static func line(for entry: EvidenceEntry, style: CitationExportStyle) -> String {
        let year = String(entry.date.prefix(4)).trimmed
        let title = entry.title.trimmed.isEmpty ? "Untitled publication" : entry.title.trimmed
        let venue = entry.venue.trimmed
        let basis = [entry.title, entry.venue, entry.notes, entry.source].joined(separator: " ")
        let doi = PublicationFormatter.doi(in: basis)

        switch style {
        case .apa:
            return "- \(title). (\(year.isEmpty ? "n.d." : year)). \(venue)\(doi.map { ". https://doi.org/\($0)" } ?? "")."
        case .chicago:
            return "- \(title). \(venue)\(year.isEmpty ? "" : ", \(year)")\(doi.map { ". doi:\($0)" } ?? "")."
        case .tenkJufo:
            return PublicationFormatter.cvLine(for: entry, includeSource: true) + " JUFO: check."
        }
    }

    private static func line(forSourceLine line: String, style: CitationExportStyle) -> String {
        let clean = line.removingLeadingMarkdownBullet
        let year = clean.firstFourDigitYear ?? "n.d."
        let doi = PublicationFormatter.doi(in: clean)

        switch style {
        case .apa:
            return "- \(clean). (\(year)).\(doi.map { " https://doi.org/\($0)" } ?? "")"
        case .chicago:
            return "- \(clean)\(year == "n.d." ? "" : ", \(year)")\(doi.map { ". doi:\($0)" } ?? "")."
        case .tenkJufo:
            return PublicationFormatter.formatSourceLine(clean) + " | JUFO: check."
        }
    }
}

private extension String {
    var removingLeadingMarkdownBullet: String {
        hasPrefix("- ") ? String(dropFirst(2)).trimmed : self
    }

    var firstFourDigitYear: String? {
        guard let range = range(of: #"\b(19|20)\d{2}\b"#, options: .regularExpression) else {
            return nil
        }
        return String(self[range])
    }
}
