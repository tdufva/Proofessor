import Foundation

enum DossierNarrativeBuilder {
    static func build(
        entries: [EvidenceEntry],
        cvItems: [CVStructuredItem],
        settings: ConnectorSettings
    ) -> [DossierNarrativeSection] {
        [
            makeSection(
                title: "Research / Artistic Work",
                systemImage: "sparkle.magnifyingglass",
                theme: firstNonEmpty(settings.researchThemes, settings.artisticThemes, "research and artistic work"),
                entries: selected(entries, matching: { $0.tenureDimension == "Research/artistic work" || ["Publication", "Funding", "Artistic Output"].contains($0.category) }),
                cvItems: selected(cvItems, sections: [.publication, .grant, .artisticWork]),
                frame: "shows a coherent programme of research or artistic work",
                contribution: "quality, originality, methodological clarity, and development of the field"
            ),
            makeSection(
                title: "Teaching",
                systemImage: "graduationcap",
                theme: firstNonEmpty(settings.teachingThemes, "teaching, supervision, and curriculum development"),
                entries: selected(entries, matching: { $0.tenureDimension == "Teaching" || ["Teaching", "Supervision"].contains($0.category) }),
                cvItems: selected(cvItems, sections: [.teaching, .supervision, .education]),
                frame: "shows sustained contribution to teaching, supervision, and learning environments",
                contribution: "pedagogical development, student learning, supervision quality, and programme work"
            ),
            makeSection(
                title: "Impact / Service",
                systemImage: "person.2.wave.2",
                theme: "academic service, public impact, and contribution beyond individual outputs",
                entries: selected(entries, matching: { $0.tenureDimension == "Impact and service" || ["Service", "Visibility", "Talk"].contains($0.category) }),
                cvItems: selected(cvItems, sections: [.service, .visibility, .talk]),
                frame: "shows contribution to the university, discipline, publics, and professional communities",
                contribution: "societal relevance, service, visibility, public engagement, and peer trust"
            ),
            makeSection(
                title: "Future Trajectory",
                systemImage: "arrow.up.forward",
                theme: firstNonEmpty(settings.researchThemes, settings.artisticThemes, settings.teachingThemes, "the next stage of the profile"),
                entries: selected(entries, matching: { ["Funding", "Publication", "Artistic Output", "Teaching"].contains($0.category) }),
                cvItems: selected(cvItems, sections: [.grant, .publication, .artisticWork, .teaching]),
                frame: "points toward a clear future trajectory",
                contribution: "continuity, ambition, feasibility, and fit with the candidate's academic environment"
            ),
            makeSection(
                title: "Leadership",
                systemImage: "person.3.sequence",
                theme: "research, artistic, educational, or institutional leadership",
                entries: selected(entries, matching: { $0.role.localizedCaseInsensitiveContains("lead") || $0.role.localizedCaseInsensitiveContains("principal") || ["Funding", "Supervision", "Service"].contains($0.category) }),
                cvItems: selected(cvItems, sections: [.grant, .supervision, .service]),
                frame: "shows leadership through responsibility, initiative, mentoring, or coordination",
                contribution: "independence, capacity to guide others, and ability to shape shared work"
            ),
            makeSection(
                title: "International Recognition",
                systemImage: "globe.europe.africa",
                theme: "international recognition and field-level visibility",
                entries: selected(entries, matching: { $0.venue.localizedCaseInsensitiveContains("international") || $0.title.localizedCaseInsensitiveContains("international") || ["Talk", "Visibility"].contains($0.category) }),
                cvItems: selected(cvItems, sections: [.talk, .visibility, .publication]),
                frame: "shows recognition beyond the immediate local setting",
                contribution: "international peer recognition, networks, invited roles, publications, and public visibility"
            )
        ]
    }

    static func markdown(from sections: [DossierNarrativeSection]) -> String {
        sections.map { section in
            """
            ## \(section.title)

            \(section.paragraph)

            Evidence used: \(section.evidenceTitles.isEmpty ? "Add stronger proof-backed examples." : section.evidenceTitles.joined(separator: "; "))
            """
        }
        .joined(separator: "\n\n")
    }

    private static func makeSection(
        title: String,
        systemImage: String,
        theme: String,
        entries: [EvidenceEntry],
        cvItems: [CVStructuredItem],
        frame: String,
        contribution: String
    ) -> DossierNarrativeSection {
        let evidenceTitles = evidenceList(entries: entries, cvItems: cvItems)
        let evidencePhrase = evidenceTitles.isEmpty
            ? "The current evidence set does not yet contain enough proof-backed examples for this paragraph."
            : "The strongest evidence currently includes \(evidenceTitles.prefix(3).joined(separator: "; "))."
        let proofPhrase = entries.contains(where: TenureGapAnalyzer.hasProof)
            ? "At least some of these records already have proof attached or a source link."
            : "Before using this paragraph, add proof files or source links for the selected claims."

        let paragraph = """
        The candidate's work in \(theme) \(frame). \(evidencePhrase) Together, these examples can be used to argue \(contribution). \(proofPhrase)
        """

        return DossierNarrativeSection(
            title: title,
            systemImage: systemImage,
            paragraph: paragraph,
            evidenceTitles: Array(evidenceTitles.prefix(5)),
            missingNote: missingNote(entries: entries, cvItems: cvItems)
        )
    }

    private static func selected(_ entries: [EvidenceEntry], matching predicate: (EvidenceEntry) -> Bool) -> [EvidenceEntry] {
        entries
            .filter(predicate)
            .sorted { lhs, rhs in
                if lhs.cvReady != rhs.cvReady { return lhs.cvReady && !rhs.cvReady }
                if lhs.completeness.score != rhs.completeness.score { return lhs.completeness.score > rhs.completeness.score }
                return lhs.date > rhs.date
            }
            .prefix(8)
            .map { $0 }
    }

    private static func selected(_ items: [CVStructuredItem], sections: [CVStructuredSection]) -> [CVStructuredItem] {
        items
            .filter { sections.contains($0.section) }
            .sorted { lhs, rhs in
                if lhs.verified != rhs.verified { return lhs.verified && !rhs.verified }
                return lhs.year > rhs.year
            }
            .prefix(8)
            .map { $0 }
    }

    private static func evidenceList(entries: [EvidenceEntry], cvItems: [CVStructuredItem]) -> [String] {
        let entryTitles = entries.map { entry in
            [entry.date.prefix(4).isEmpty ? "" : String(entry.date.prefix(4)), entry.title]
                .map(\.trimmed)
                .filter { !$0.isEmpty }
                .joined(separator: " - ")
        }

        let itemTitles = cvItems.map { item in
            [item.year, item.title]
                .map(\.trimmed)
                .filter { !$0.isEmpty }
                .joined(separator: " - ")
        }

        var seen = Set<String>()
        return (entryTitles + itemTitles)
            .filter { !$0.trimmed.isEmpty }
            .filter { seen.insert($0.lowercased()).inserted }
    }

    private static func missingNote(entries: [EvidenceEntry], cvItems: [CVStructuredItem]) -> String {
        if entries.isEmpty && cvItems.isEmpty {
            return "Add evidence before using this paragraph."
        }
        let missingProof = entries.filter { !TenureGapAnalyzer.hasProof($0) }.count
        if missingProof > 0 {
            return "\(missingProof) selected evidence item(s) still need proof."
        }
        return "Proof looks present for the selected evidence."
    }

    private static func firstNonEmpty(_ values: String...) -> String {
        values.map(\.trimmed).first { !$0.isEmpty } ?? ""
    }
}
