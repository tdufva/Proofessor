import Foundation

enum ImportParser {
    static func parse(_ text: String) -> EvidenceEntry {
        let lines = text
            .components(separatedBy: .newlines)
            .map(\.trimmed)
            .filter { !$0.isEmpty }

        var entry = EvidenceEntry()
        entry.status = "Needs review"
        entry.source = "Pasted calendar/email text"
        entry.notes = text.trimmed

        entry.date = firstDate(in: text) ?? ""
        if entry.date.isEmpty, let year = bibTeXValue(in: text, keys: ["year"]) {
            entry.date = "\(year)-01-01"
        }
        entry.title = firstTitle(in: lines)
        entry.venue = firstValue(in: lines, keys: ["venue", "location", "place", "host", "institution", "organisation", "organization", "university", "journal", "booktitle", "publisher", "conference", "event", "school", "department"]) ?? ""
        entry.role = inferredRole(from: text)
        entry.eventType = inferredType(from: text)
        entry.category = inferredCategory(from: text)
        entry.tenureDimension = inferredDimension(from: text, category: entry.category)

        if isBibTeX(text) || PublicationFormatter.doi(in: text) != nil {
            entry.source = "Imported publication metadata"
            entry.category = "Publication"
            entry.eventType = entry.eventType.trimmed.isEmpty ? "Publication / DOI or BibTeX import" : entry.eventType
            entry.role = entry.role.trimmed.isEmpty ? "Author" : entry.role
            entry.tenureDimension = "Research/artistic work"
            entry.title = bibTeXValue(in: text, keys: ["title"]) ?? entry.title
            entry.venue = bibTeXValue(in: text, keys: ["journal", "booktitle", "publisher"]) ?? entry.venue
        }

        if let profileLabel = profileSourceLabel(in: text) {
            entry.source = "Imported \(profileLabel) profile text"
            entry.category = entry.category == "Other" || entry.category == "Talk" ? "Visibility" : entry.category
            entry.eventType = entry.eventType.trimmed.isEmpty ? "\(profileLabel) profile / public scholarly visibility" : entry.eventType
            entry.tenureDimension = entry.tenureDimension == "All" ? "Impact and service" : entry.tenureDimension
            if entry.title == "Imported evidence" || entry.title.trimmed.isEmpty {
                entry.title = "\(profileLabel) profile snapshot"
            }
        }

        if entry.title == "Imported evidence" || entry.title.trimmed.isEmpty,
           let course = firstValue(in: lines, keys: ["course", "course name", "course title", "course code"]) {
            entry.title = "Course feedback: \(course)"
            entry.category = "Teaching"
            entry.eventType = entry.eventType.trimmed.isEmpty ? "Teaching evaluation / feedback" : entry.eventType
            entry.role = entry.role.trimmed.isEmpty ? "Teacher" : entry.role
            entry.tenureDimension = "Teaching"
        }

        if let url = firstURL(in: text) {
            entry.source += "\nSource URL: \(url)"
        }
        if let doi = PublicationFormatter.doi(in: text),
           !entry.source.localizedCaseInsensitiveContains(doi) {
            entry.source += "\nDOI: \(doi)"
        }

        if entry.title.isEmpty {
            entry.title = "Imported evidence"
        }

        return entry
    }

    private static func firstTitle(in lines: [String]) -> String {
        let combined = lines.joined(separator: "\n")
        if let bibTitle = bibTeXValue(in: combined, keys: ["title"]) {
            return bibTitle
        }

        for key in ["subject:", "summary:", "title:", "event:", "course:", "project:", "publication:", "name:"] {
            if let line = lines.first(where: { $0.lowercased().hasPrefix(key) }) {
                return String(line.dropFirst(key.count)).trimmed
            }
        }

        return lines.first(where: { line in
            line.count < 140 && !line.localizedCaseInsensitiveContains("zoom") && !line.localizedCaseInsensitiveContains("teams")
        }) ?? ""
    }

    private static func firstValue(in lines: [String], keys: [String]) -> String? {
        for line in lines {
            let lower = line.lowercased()
            for key in keys {
                let prefix = key + ":"
                if lower.hasPrefix(prefix) {
                    return String(line.dropFirst(prefix.count)).trimmed
                }
            }
        }
        return nil
    }

    private static func inferredRole(from text: String) -> String {
        let lower = text.lowercased()
        if lower.contains("principal investigator") || lower.contains(" pi ") { return "Principal investigator" }
        if lower.contains("co-pi") || lower.contains("co pi") { return "Co-principal investigator" }
        if lower.contains("work package lead") { return "Work package lead" }
        if lower.contains("keynote") { return "Keynote speaker" }
        if lower.contains("invited speaker") || lower.contains("invited talk") { return "Invited speaker" }
        if lower.contains("chair") { return "Chair" }
        if lower.contains("panel") { return "Panelist" }
        if lower.contains("presenter") || lower.contains("presentation") { return "Presenter" }
        if lower.contains("speaker") { return "Speaker" }
        if lower.contains("reviewer") || lower.contains("evaluator") { return "Reviewer" }
        if lower.contains("examiner") || lower.contains("opponent") { return "Examiner" }
        if lower.contains("supervisor") { return "Supervisor" }
        if lower.contains("teacher") { return "Teacher" }
        if lower.contains("@article") || lower.contains("@inproceedings") || lower.contains("doi") { return "Author" }
        return ""
    }

    private static func inferredType(from text: String) -> String {
        let lower = text.lowercased()
        if isBibTeX(text) { return "Publication / BibTeX import" }
        if PublicationFormatter.doi(in: text) != nil { return "Publication / DOI import" }
        if lower.contains("orcid.org") { return "ORCID profile / public scholarly visibility" }
        if lower.contains("scholar.google") || lower.contains("google scholar") { return "Google Scholar profile / citation visibility" }
        if lower.contains("curriculum vitae") || lower.contains("\ncv\n") { return "CV source material" }
        if lower.contains("keynote") { return "Keynote lecture" }
        if lower.contains("invited") { return "Invited academic talk" }
        if lower.contains("conference") || lower.contains("convention") { return "Conference presentation" }
        if lower.contains("webinar") { return "Webinar presentation" }
        if lower.contains("exhibition") || lower.contains("näyttely") { return "Exhibition" }
        if lower.contains("seminar") { return "Seminar presentation" }
        if lower.contains("workshop") { return "Workshop" }
        if lower.contains("teaching evaluation") || lower.contains("course feedback") || lower.contains("student feedback") { return "Teaching evaluation / feedback" }
        if lower.contains("grant") || lower.contains("funding") || lower.contains("proposal") { return "Grant / funding evidence" }
        if lower.contains("thesis") || lower.contains("supervision") { return "Supervision / examination evidence" }
        return ""
    }

    private static func inferredCategory(from text: String) -> String {
        let lower = text.lowercased()
        if lower.contains("exhibition") || lower.contains("näyttely") { return "Artistic Output" }
        if isBibTeX(text) || lower.contains("publication") || lower.contains("doi") || lower.contains("journal") || lower.contains("peer reviewed") || lower.contains("peer-reviewed") { return "Publication" }
        if lower.contains("grant") || lower.contains("funding") || lower.contains("proposal") || lower.contains("horizon") || lower.contains("erc") { return "Funding" }
        if lower.contains("supervision") || lower.contains("thesis") { return "Supervision" }
        if lower.contains("course") || lower.contains("teaching") || lower.contains("feedback") || lower.contains("pedagog") { return "Teaching" }
        if lower.contains("media") || lower.contains("public engagement") || lower.contains("orcid") || lower.contains("google scholar") || lower.contains("research.aalto") { return "Visibility" }
        if lower.contains("reviewer") || lower.contains("advisor") || lower.contains("committee") { return "Service" }
        return "Talk"
    }

    private static func inferredDimension(from text: String, category: String) -> String {
        let lower = text.lowercased()
        if ["Publication", "Artistic Output", "Funding"].contains(category) {
            return "Research/artistic work"
        }
        if ["Teaching", "Supervision"].contains(category) {
            return "Teaching"
        }
        if ["Service", "Visibility"].contains(category) {
            return "Impact and service"
        }
        if lower.contains("teaching") || lower.contains("course") || lower.contains("supervision") {
            return "Teaching"
        }
        if lower.contains("impact") || lower.contains("service") || lower.contains("media") || lower.contains("committee") {
            return "Impact and service"
        }
        if lower.contains("research") || lower.contains("artistic") || lower.contains("funding") || lower.contains("publication") {
            return "Research/artistic work"
        }
        return "All"
    }

    private static func firstURL(in text: String) -> String? {
        let pattern = #"https?://[^\s<>)"\]]+"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let match = regex.firstMatch(in: text, range: range),
              let matchRange = Range(match.range, in: text) else {
            return nil
        }
        return String(text[matchRange]).trimmingCharacters(in: CharacterSet(charactersIn: ".,;:"))
    }

    private static func isBibTeX(_ text: String) -> Bool {
        text.range(of: #"@\w+\s*\{"#, options: [.regularExpression, .caseInsensitive]) != nil
    }

    private static func bibTeXValue(in text: String, keys: [String]) -> String? {
        for key in keys {
            let escapedKey = NSRegularExpression.escapedPattern(for: key)
            let pattern = #"(?is)\b"# + escapedKey + #"\s*=\s*[\{\"]([^}\"]+)"#
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let range = NSRange(text.startIndex..<text.endIndex, in: text)
            guard let match = regex.firstMatch(in: text, range: range),
                  let matchRange = Range(match.range(at: 1), in: text) else {
                continue
            }
            let value = String(text[matchRange])
                .replacingOccurrences(of: "{", with: "")
                .replacingOccurrences(of: "}", with: "")
                .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
                .trimmed
            if !value.isEmpty {
                return value
            }
        }
        return nil
    }

    private static func profileSourceLabel(in text: String) -> String? {
        let lower = text.lowercased()
        if lower.contains("orcid.org") || lower.contains("orcid") { return "ORCID" }
        if lower.contains("scholar.google") || lower.contains("google scholar") { return "Google Scholar" }
        if lower.contains("research.aalto") || lower.contains("aalto people") { return "Aalto profile" }
        return nil
    }

    private static func firstDate(in text: String) -> String? {
        let patterns = [
            #"(?<!\d)(20\d{2})-(\d{1,2})-(\d{1,2})(?!\d)"#,
            #"(?<!\d)(\d{1,2})[./](\d{1,2})[./](20\d{2})(?!\d)"#,
            #"(?i)\b(\d{1,2})\s+(jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december)\s+(20\d{2})\b"#,
            #"(?i)\b(jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december)\s+(\d{1,2}),?\s+(20\d{2})\b"#
        ]

        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let range = NSRange(text.startIndex..<text.endIndex, in: text)
            guard let match = regex.firstMatch(in: text, range: range) else { continue }

            if pattern.contains("(20\\d{2})-") {
                return components(match, in: text, order: [1, 2, 3])
            }

            if pattern.contains("[./]") {
                return components(match, in: text, order: [3, 2, 1])
            }

            if pattern.hasPrefix("(?i)\\b(\\d") {
                let day = capture(match, in: text, at: 1)
                let monthName = capture(match, in: text, at: 2).lowercased()
                let year = capture(match, in: text, at: 3)
                guard let month = monthNumber(monthName) else { continue }
                return "\(year)-\(month)-\(day.leftPadded(to: 2))"
            } else {
                let monthName = capture(match, in: text, at: 1).lowercased()
                let day = capture(match, in: text, at: 2)
                let year = capture(match, in: text, at: 3)
                guard let month = monthNumber(monthName) else { continue }
                return "\(year)-\(month)-\(day.leftPadded(to: 2))"
            }
        }

        return nil
    }

    private static func components(_ match: NSTextCheckingResult, in text: String, order: [Int]) -> String {
        let values = order.map { capture(match, in: text, at: $0) }
        return "\(values[0])-\(values[1].leftPadded(to: 2))-\(values[2].leftPadded(to: 2))"
    }

    private static func capture(_ match: NSTextCheckingResult, in text: String, at index: Int) -> String {
        guard let range = Range(match.range(at: index), in: text) else { return "" }
        return String(text[range])
    }

    private static func monthNumber(_ name: String) -> String? {
        let months = [
            "jan": "01", "january": "01",
            "feb": "02", "february": "02",
            "mar": "03", "march": "03",
            "apr": "04", "april": "04",
            "may": "05",
            "jun": "06", "june": "06",
            "jul": "07", "july": "07",
            "aug": "08", "august": "08",
            "sep": "09", "sept": "09", "september": "09",
            "oct": "10", "october": "10",
            "nov": "11", "november": "11",
            "dec": "12", "december": "12"
        ]
        return months[name]
    }
}

private extension String {
    func leftPadded(to length: Int) -> String {
        if count >= length { return self }
        return String(repeating: "0", count: length - count) + self
    }
}
