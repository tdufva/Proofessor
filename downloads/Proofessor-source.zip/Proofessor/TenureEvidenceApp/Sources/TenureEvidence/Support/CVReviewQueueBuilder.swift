import Foundation

enum CVReviewQueueBuilder {
    static func items(from sourceText: String) -> [CVReviewItem] {
        var section = "Unsectioned"
        var items: [CVReviewItem] = []
        var seen = Set<String>()

        for rawLine in sourceText.components(separatedBy: .newlines) {
            let line = rawLine.trimmed
            guard !line.isEmpty, !line.hasPrefix("# ") else { continue }

            if line.hasPrefix("## ") || line.hasPrefix("### ") {
                section = line
                    .replacingOccurrences(of: "#", with: "")
                    .trimmed
                continue
            }

            let reasons = reasonsForReview(line: line, section: section)
            guard !reasons.isEmpty else { continue }

            let key = "\(section)|\(line)"
                .lowercased()
                .replacingOccurrences(of: " ", with: "")
            guard !seen.contains(key) else { continue }
            seen.insert(key)

            items.append(
                CVReviewItem(
                    id: String(key.hashValue),
                    section: section,
                    line: line.removingLeadingMarkdownBullet,
                    reason: reasons.joined(separator: "; "),
                    sourceHint: sourceHint(line)
                )
            )
        }

        return Array(items.prefix(120))
    }

    private static func reasonsForReview(line: String, section: String) -> [String] {
        let lower = line.lowercased()
        var reasons: [String] = []

        if lower.contains("todo") || lower.contains("tbc") || lower.contains("unclear") || line.contains("?") {
            reasons.append("uncertain wording")
        }

        if lower.contains("source:") || lower.contains("retrieved") || lower.contains("website") || lower.contains("research portal") || lower.contains("google scholar") {
            reasons.append("public-source detail")
        }

        let datedSections = [
            "Research funding and grants",
            "Research output (selected)",
            "Artistic Work (selected)",
            "Teaching merits",
            "International invited talks and presentations",
            "Scientific and societal impact",
            "Other merits",
            "Website and public artistic projects"
        ]

        if datedSections.contains(where: { $0.caseInsensitiveCompare(section) == .orderedSame }),
           !line.containsFourDigitYear {
            reasons.append("missing year/date")
        }

        if section.localizedCaseInsensitiveContains("Other") || section.localizedCaseInsensitiveContains("Website") {
            reasons.append("classification to check")
        }

        if lower.contains("cv") || lower.contains("portfolio") || lower.contains("pages") {
            reasons.append("older CV/source extraction")
        }

        return reasons
    }

    private static func sourceHint(_ line: String) -> String {
        let lower = line.lowercased()
        if lower.contains("institution") || lower.contains("university") { return "Institutional/public profile" }
        if lower.contains("google scholar") { return "Google Scholar" }
        if lower.contains("personal-website-example") { return "Personal website" }
        if lower.contains("portfolio") { return "Portfolio/CV source" }
        return "CV master source"
    }
}

private extension String {
    var containsFourDigitYear: Bool {
        range(of: #"\b(19|20)\d{2}\b"#, options: .regularExpression) != nil
    }

    var removingLeadingMarkdownBullet: String {
        hasPrefix("- ") ? String(dropFirst(2)).trimmed : self
    }
}
