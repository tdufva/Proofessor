import Foundation

enum SuggestedEvidenceScanner {
    static let folderPath = "00_Inbox/Suggested_Evidence"

    static func scan(workspaceURL: URL, existingEntries: [EvidenceEntry]) -> [SuggestedEvidenceItem] {
        let folder = workspaceURL.appendingPathComponent(folderPath)
        guard let urls = try? FileManager.default.contentsOfDirectory(
            at: folder,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        ) else {
            return []
        }

        return urls
            .filter(isSuggestionFile)
            .compactMap { item(from: $0, workspaceURL: workspaceURL, existingEntries: existingEntries) }
            .sorted { lhs, rhs in
                if lhs.entry.date == rhs.entry.date {
                    return lhs.entry.title.localizedCaseInsensitiveCompare(rhs.entry.title) == .orderedAscending
                }
                return lhs.entry.date > rhs.entry.date
            }
    }

    private static func item(from url: URL, workspaceURL: URL, existingEntries: [EvidenceEntry]) -> SuggestedEvidenceItem? {
        guard let text = try? String(contentsOf: url, encoding: .utf8), !text.trimmed.isEmpty else {
            return nil
        }

        var entry = ImportParser.parse(text)
        entry.status = "Needs confirmation"
        entry.source = "Suggested evidence: \(relativePath(for: url, workspaceURL: workspaceURL))"
        if entry.notes.trimmed.isEmpty {
            entry.notes = text.trimmed
        }

        let duplicates = Array(duplicateCandidates(for: entry, existingEntries: existingEntries).prefix(3))

        return SuggestedEvidenceItem(
            id: url.path,
            sourceURL: url,
            relativePath: relativePath(for: url, workspaceURL: workspaceURL),
            rawText: text,
            entry: entry,
            duplicateCandidates: duplicates
        )
    }

    private static func isSuggestionFile(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        return ["txt", "md", "markdown", "ics", "eml", "bib", "bibtex", "ris"].contains(ext)
    }

    private static func duplicateCandidates(for entry: EvidenceEntry, existingEntries: [EvidenceEntry]) -> [EvidenceEntry] {
        let title = normalized(entry.title)
        guard !title.isEmpty else { return [] }

        return existingEntries.filter { candidate in
            let candidateTitle = normalized(candidate.title)
            guard !candidateTitle.isEmpty else { return false }

            if candidateTitle == title {
                return true
            }

            if !entry.date.trimmed.isEmpty,
               entry.date == candidate.date,
               titleSimilarity(title, candidateTitle) > 0.62 {
                return true
            }

            return titleSimilarity(title, candidateTitle) > 0.82
        }
    }

    private static func normalized(_ value: String) -> String {
        value
            .lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }

    private static func titleSimilarity(_ lhs: String, _ rhs: String) -> Double {
        let left = Set(lhs.split(separator: " ").map(String.init))
        let right = Set(rhs.split(separator: " ").map(String.init))
        guard !left.isEmpty, !right.isEmpty else { return 0 }
        return Double(left.intersection(right).count) / Double(left.union(right).count)
    }

    private static func relativePath(for url: URL, workspaceURL: URL) -> String {
        let workspacePath = workspaceURL.standardizedFileURL.path
        let filePath = url.standardizedFileURL.path
        guard filePath.hasPrefix(workspacePath + "/") else { return filePath }
        return String(filePath.dropFirst(workspacePath.count + 1))
    }
}
