import Foundation

enum SourceConfidenceEvaluator {
    static func badge(for entry: EvidenceEntry) -> String {
        let score = entry.completeness.score

        if score >= 90 && (!entry.attachments.isEmpty || entry.source.localizedCaseInsensitiveContains("http")) {
            return "[source: high]"
        }

        if score >= 70 {
            return "[source: medium]"
        }

        return "[source: review]"
    }

    static func badge(for line: String, section: String = "") -> String {
        let lower = line.lowercased()
        var score = 0

        if line.containsFourDigitYear {
            score += 2
        }

        if lower.contains("doi") || PublicationFormatter.doi(in: line) != nil {
            score += 2
        }

        if lower.contains("http") || lower.contains("aalto") || lower.contains("google scholar") {
            score += 2
        }

        if lower.contains("source") || lower.contains("retrieved") || lower.contains("portfolio") {
            score += 1
        }

        if lower.contains("todo") || lower.contains("tbc") || lower.contains("unclear") || line.contains("?") {
            score -= 2
        }

        if section.localizedCaseInsensitiveContains("Personal") {
            return "[source: profile]"
        }

        if score >= 4 {
            return "[source: high]"
        }

        if score >= 2 {
            return "[source: medium]"
        }

        return "[source: review]"
    }
}

private extension String {
    var containsFourDigitYear: Bool {
        range(of: #"\b(19|20)\d{2}\b"#, options: .regularExpression) != nil
    }
}

