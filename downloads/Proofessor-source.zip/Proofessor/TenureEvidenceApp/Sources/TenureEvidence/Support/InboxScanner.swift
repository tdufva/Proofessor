import AppKit
import Foundation
import PDFKit

struct InboxScanResult {
    var entries: [EvidenceEntry]
    var skippedCount: Int
}

enum InboxScanner {
    private static let workspaceSourceFolders = [
        "02_Profile_CV_and_Portfolios",
        "03_Research_Artistic_Work",
        "04_Teaching_and_Pedagogy",
        "05_Funding_and_Grants",
        "06_Impact_Service_and_Leadership",
        "07_Supervision_and_Examination",
        "08_Talks_Visibility_and_Recognition"
    ]

    static func scan(workspaceURL: URL, existingEntries: [EvidenceEntry]) -> InboxScanResult {
        let inboxURL = workspaceURL.appendingPathComponent("00_Inbox")
        return scanFolders(
            [inboxURL],
            workspaceURL: workspaceURL,
            existingEntries: existingEntries,
            sourceLabel: "00_Inbox"
        )
    }

    static func scanWorkspaceEvidenceFolders(workspaceURL: URL, existingEntries: [EvidenceEntry]) -> InboxScanResult {
        let folderURLs = workspaceSourceFolders
            .map { workspaceURL.appendingPathComponent($0, isDirectory: true) }
            .filter { FileManager.default.fileExists(atPath: $0.path) }

        return scanFolders(
            folderURLs,
            workspaceURL: workspaceURL,
            existingEntries: existingEntries,
            sourceLabel: "tenure workspace subfolder"
        )
    }

    static func scanFolders(
        _ folderURLs: [URL],
        workspaceURL: URL,
        existingEntries: [EvidenceEntry],
        sourceLabel: String
    ) -> InboxScanResult {
        var imported: [EvidenceEntry] = []
        var skipped = 0

        for folderURL in folderURLs {
            let result = scanFolder(
                folderURL,
                workspaceURL: workspaceURL,
                existingEntries: existingEntries + imported,
                sourceLabel: sourceLabel
            )
            imported.append(contentsOf: result.entries)
            skipped += result.skippedCount
        }

        return InboxScanResult(entries: imported, skippedCount: skipped)
    }

    private static func scanFolder(
        _ folderURL: URL,
        workspaceURL: URL,
        existingEntries: [EvidenceEntry],
        sourceLabel: String
    ) -> InboxScanResult {
        guard FileManager.default.fileExists(atPath: folderURL.path) else {
            return InboxScanResult(entries: [], skippedCount: 0)
        }

        guard let enumerator = FileManager.default.enumerator(
            at: folderURL,
            includingPropertiesForKeys: [.isDirectoryKey, .isRegularFileKey, .contentModificationDateKey],
            options: [.skipsHiddenFiles]
        ) else {
            return InboxScanResult(entries: [], skippedCount: 0)
        }

        var imported: [EvidenceEntry] = []
        var skipped = 0

        for case let fileURL as URL in enumerator {
            if shouldSkip(fileURL) {
                enumerator.skipDescendants()
                continue
            }

            let values = try? fileURL.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey])
            let isDirectory = values?.isDirectory == true
            let isRegularFile = values?.isRegularFile == true

            if isDirectory && isSupportedFile(fileURL) {
                enumerator.skipDescendants()
            } else if isDirectory {
                continue
            } else if !isRegularFile {
                continue
            }

            guard isSupportedFile(fileURL) else {
                continue
            }

            let relativePath = relativePath(for: fileURL, workspaceURL: workspaceURL)
            if alreadyImported(relativePath: relativePath, existingEntries: existingEntries + imported) {
                skipped += 1
                continue
            }

            imported.append(entry(for: fileURL, workspaceURL: workspaceURL, sourceLabel: sourceLabel))
        }

        return InboxScanResult(entries: imported, skippedCount: skipped)
    }

    private static func isSupportedFile(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        return [
            "pdf", "docx", "doc", "pages", "pptx", "ppt", "key",
            "xlsx", "xls", "numbers", "csv",
            "txt", "md", "markdown", "rtf", "bib", "bibtex", "ris",
            "jpg", "jpeg", "png", "heic", "tiff", "gif"
        ].contains(ext)
    }

    private static func shouldSkip(_ url: URL) -> Bool {
        let ignoredPathParts = [
            ".build",
            ".git",
            ".swiftpm",
            "CV_Source_Extractions",
            "CV_Version_History",
            "Draft_Materials",
            "Packet_Exports",
            "Profile_Photos",
            "Profile_Snapshots",
            "Source_URL_Archive",
            "Suggested_Evidence",
            "Proofessor_Attachments",
            "TenureEvidenceApp_Attachments",
            "dist",
            "node_modules"
        ]

        let pathParts = url.pathComponents.map { $0.lowercased() }
        return ignoredPathParts.contains { ignored in
            pathParts.contains(ignored.lowercased())
        }
    }

    private static func alreadyImported(relativePath: String, existingEntries: [EvidenceEntry]) -> Bool {
        existingEntries.contains { entry in
            entry.attachments.contains { attachment in
                attachment.path == relativePath
            }
        }
    }

    private static func entry(for fileURL: URL, workspaceURL: URL, sourceLabel: String) -> EvidenceEntry {
        let fileName = fileURL.deletingPathExtension().lastPathComponent
        let modified = modificationDateString(for: fileURL)
        let relative = relativePath(for: fileURL, workspaceURL: workspaceURL)
        let context = EvidenceFileContext(
            fileName: fileName,
            relativePath: relative,
            textPreview: textPreview(from: fileURL)
        )
        let inferred = inferredMetadata(context)
        let prefill = EvidenceScannerPrefill.build(from: context)

        var entry = EvidenceEntry()
        entry.date = prefill.date ?? modified
        entry.category = inferred.category
        entry.eventType = prefill.eventType ?? inferred.eventType
        entry.title = prefill.title ?? inferred.title
        entry.role = prefill.role ?? inferred.role
        entry.venue = prefill.venue ?? inferred.venue
        entry.tenureDimension = inferred.dimension
        entry.status = prefill.hasUsefulFields ? "Needs confirmation" : "Needs review"
        entry.source = sourceText(sourceLabel: sourceLabel, relativePath: relative, urls: prefill.urls)
        entry.notes = (inferred.notes + prefill.notes).joined(separator: "\n")
        entry.cvReady = false
        entry.attachments = [
            EvidenceAttachment(name: fileURL.lastPathComponent, path: relative)
        ]

        return entry
    }

    private static func inferredMetadata(_ context: EvidenceFileContext) -> (
        title: String,
        category: String,
        eventType: String,
        role: String,
        venue: String,
        dimension: String,
        notes: [String]
    ) {
        if context.hasAny(["cv", "curriculum vitae", "resume"]) || context.hasPathPart("02_Profile_CV_and_Portfolios") {
            return (
                "CV source material: \(cleanTitle(context.fileName))",
                "Other",
                "CV / profile source material",
                "",
                inferredVenue(from: context),
                "All",
                notes(for: context, signal: "Aalto tenure support: CV/profile source material. Use Build CV > Source to import useful rows, then link claims to proof.")
            )
        }

        if context.hasTeachingFeedbackSignal {
            return (
                "Teaching feedback: \(cleanTitle(context.fileName))",
                "Teaching",
                "Teaching evaluation / feedback",
                "Teacher",
                inferredVenue(from: context),
                "Teaching",
                notes(for: context, signal: "Aalto teaching evidence: student/peer feedback and proof that feedback was used to improve teaching.")
            )
        }

        if context.hasAny(["pedagogical", "pedagogy", "pedagogi", "certificate", "todistus", "training", "workshop", "teacher development", "university pedagogy"]) {
            let leadership = context.hasAny(["amp", "new manager", "manager", "leadership", "lead"])
            return (
                leadership ? "Leadership training: \(cleanTitle(context.fileName))" : "Certificate: \(cleanTitle(context.fileName))",
                leadership ? "Service" : "Teaching",
                leadership ? "Leadership / professional development" : "Pedagogical / professional development",
                "Participant",
                inferredVenue(from: context),
                leadership ? "Impact and service" : "Teaching",
                notes(for: context, signal: leadership ? "Aalto impact/service evidence: development as an academic leader." : "Aalto teaching evidence: pedagogical competence and continuing teaching development.")
            )
        }

        if context.hasAny(["grant", "proposal", "funding", "funded", "academy of finland", "research council of finland", "business finland", "horizon", "erc", "cost action", "seed funding", "consortium", "work package", "budget"]) {
            return (
                "Funding evidence: \(cleanTitle(context.fileName))",
                "Funding",
                "Grant / funding evidence",
                context.hasAny(["pi", "principal investigator"]) ? "Principal investigator" : "Applicant or collaborator",
                inferredVenue(from: context),
                "Research/artistic work",
                notes(for: context, signal: "Aalto research/artistic evidence: capability of raising competitive funding. Confirm funder, call, amount, status, role, and consortium details.")
            )
        }

        if context.hasAny(["@article", "@inproceedings", "@book", "doi", "publication", "article", "journal", "booktitle", "conference paper", "proceedings", "manuscript", "accepted", "peer reviewed", "peer-reviewed", "jufo", "tenk"]) {
            return (
                "Publication evidence: \(cleanTitle(context.fileName))",
                "Publication",
                "Publication / research output evidence",
                "Author",
                inferredVenue(from: context),
                "Research/artistic work",
                notes(for: context, signal: "Aalto research evidence: quality, independence, impact, peer review, publication forum/JUFO, DOI, and author role.")
            )
        }

        if context.hasAny(["exhibition", "catalogue", "catalog", "gallery", "biennial", "artistic", "artwork", "curator", "screening", "festival", "portfolio"]) {
            return (
                "Artistic work evidence: \(cleanTitle(context.fileName))",
                "Artistic Output",
                "Artistic / practice-based merit",
                context.hasAny(["curator", "curated"]) ? "Curator" : "",
                inferredVenue(from: context),
                "Research/artistic work",
                notes(for: context, signal: "Aalto research/artistic evidence: artistic quality, venue, impact, independence, role, and documentation.")
            )
        }

        if context.hasAny(["thesis", "supervision", "supervisor", "opinn", "doctoral", "phd", "master", "bachelor", "examiner", "opponent", "pre-examiner", "pre examiner"]) {
            return (
                "Supervision evidence: \(cleanTitle(context.fileName))",
                "Supervision",
                "Supervision / examination evidence",
                context.hasAny(["examiner", "opponent", "pre-examiner", "pre examiner"]) ? "Examiner" : "Supervisor",
                inferredVenue(from: context),
                "Teaching",
                notes(for: context, signal: "Aalto teaching evidence: supervision and examination of doctoral, master, and bachelor theses. Confirm level, role, student/title, and completion status.")
            )
        }

        if context.hasAny(["course", "syllabus", "curriculum", "mycourses", "assignment", "rubric", "lecture slides", "teaching material", "learning outcome", "programme development", "program development"]) {
            return (
                "Teaching evidence: \(cleanTitle(context.fileName))",
                "Teaching",
                "Course / teaching development evidence",
                "Teacher",
                inferredVenue(from: context),
                "Teaching",
                notes(for: context, signal: "Aalto teaching evidence: teaching experience, course development, teaching skills, curriculum work, and programme development.")
            )
        }

        if context.hasAny(["head of", "chair", "director", "leader", "leadership", "coordinator", "research group", "doctoral student", "postdoc", "post-doctoral", "line manager", "committee chair", "programme director", "program director"]) {
            return (
                "Leadership evidence: \(cleanTitle(context.fileName))",
                "Service",
                "Academic leadership / team building",
                "Leader or coordinator",
                inferredVenue(from: context),
                "Impact and service",
                notes(for: context, signal: "Aalto impact/service evidence: academic leadership, programme leadership, team building, mentoring, and contribution to field development.")
            )
        }

        if context.hasAny(["committee", "board", "working group", "reviewer", "editorial", "journal review", "peer review", "task force", "external examiner", "evaluation panel", "assessment panel", "service"]) {
            return (
                "Service evidence: \(cleanTitle(context.fileName))",
                "Service",
                "Academic service / committee work",
                context.hasAny(["reviewer", "peer review", "external examiner"]) ? "Reviewer or examiner" : "Member",
                inferredVenue(from: context),
                "Impact and service",
                notes(for: context, signal: "Aalto impact/service evidence: academic service, evaluation work, institutional contribution, leadership, and field development.")
            )
        }

        if context.hasAny(["keynote", "invited", "lecture", "presentation", "talk", "seminar", "conference", "symposium", "panel"]) {
            return (
                "Presentation evidence: \(cleanTitle(context.fileName))",
                "Talk",
                "Talk / presentation evidence",
                context.hasAny(["invited", "keynote"]) ? "Invited speaker" : "Speaker",
                inferredVenue(from: context),
                context.hasAny(["research", "paper", "conference paper", "artistic"]) ? "Research/artistic work" : "Impact and service",
                notes(for: context, signal: "Aalto visibility evidence: invited talks, international/national visibility, external recognition, host, audience, and event context.")
            )
        }

        if context.hasAny(["media", "press", "interview", "podcast", "public engagement", "policy", "impact", "outreach", "website", "profile", "google scholar", "orcid", "aalto people", "research portal"]) {
            return (
                "Visibility evidence: \(cleanTitle(context.fileName))",
                "Visibility",
                "Public / field visibility evidence",
                "",
                inferredVenue(from: context),
                "Impact and service",
                notes(for: context, signal: "Aalto impact evidence: societal contribution, public visibility, field-level recognition, and profile evidence.")
            )
        }

        return (
            cleanTitle(context.fileName),
            "Other",
            "Inbox evidence",
            "",
            inferredVenue(from: context),
            inferredDimension(from: context),
            notes(for: context, signal: "Imported by recursive tenure scan. Classify this item and decide whether it supports research/artistic work, teaching, or impact/service.")
        )
    }

    private static func inferredDimension(from context: EvidenceFileContext) -> String {
        if context.hasPathPart("04_Teaching_and_Pedagogy") || context.hasPathPart("07_Supervision_and_Examination") {
            return "Teaching"
        }
        if context.hasPathPart("06_Impact_Service_and_Leadership") || context.hasPathPart("08_Talks_Visibility_and_Recognition") {
            return "Impact and service"
        }
        if context.hasPathPart("03_Research_Artistic_Work") || context.hasPathPart("05_Funding_and_Grants") {
            return "Research/artistic work"
        }
        if context.hasAny(["teaching", "course", "feedback", "supervision", "thesis", "pedagogy"]) {
            return "Teaching"
        }
        if context.hasAny(["committee", "service", "impact", "media", "leadership", "reviewer", "invited"]) {
            return "Impact and service"
        }
        if context.hasAny(["research", "artistic", "publication", "grant", "funding", "exhibition"]) {
            return "Research/artistic work"
        }
        return "All"
    }

    private static func notes(for context: EvidenceFileContext, signal: String) -> [String] {
        var notes = [
            signal,
            "Found in: \(context.parentPathLabel). Review before marking ready to use.",
            "Aalto check: record the role, host/venue, date, source/proof, and why this matters for tenure evaluation."
        ]

        if !context.textPreview.trimmed.isEmpty {
            notes.append("Scan used filename, folder path, and readable text preview.")
        } else {
            notes.append("Scan used filename and folder path. Use Extract Metadata after opening the record if the file contains readable text.")
        }

        return notes
    }

    private static func inferredVenue(from context: EvidenceFileContext) -> String {
        if context.hasAny(["aalto", "mycourses"]) {
            return "Aalto University"
        }
        return ""
    }

    private static func sourceText(sourceLabel: String, relativePath: String, urls: [URL]) -> String {
        var lines = ["Imported from \(sourceLabel): \(relativePath)"]
        if !urls.isEmpty {
            lines.append(contentsOf: urls.prefix(5).map { "Detected URL: \($0.absoluteString)" })
        }
        return lines.joined(separator: "\n")
    }

    private static func cleanTitle(_ fileName: String) -> String {
        fileName
            .replacingOccurrences(of: "Microsoft Word - ", with: "")
            .replacingOccurrences(of: " (kopio)", with: "")
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: "-", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func textPreview(from url: URL) -> String {
        switch url.pathExtension.lowercased() {
        case "pdf":
            guard let document = PDFDocument(url: url) else { return "" }
            let pageLimit = min(document.pageCount, 4)
            return (0..<pageLimit)
                .compactMap { document.page(at: $0)?.string }
                .joined(separator: "\n")
                .prefixString(maxLength: 16_000)
        case "txt", "md", "markdown", "csv", "bib", "bibtex", "ris":
            return ((try? String(contentsOf: url, encoding: .utf8)) ?? "")
                .prefixString(maxLength: 16_000)
        case "rtf":
            guard let data = try? Data(contentsOf: url),
                  let attributed = try? NSAttributedString(
                    data: data,
                    options: [.documentType: NSAttributedString.DocumentType.rtf],
                    documentAttributes: nil
                  ) else {
                return ""
            }
            return attributed.string.prefixString(maxLength: 16_000)
        default:
            return ""
        }
    }

    private static func modificationDateString(for url: URL) -> String {
        let values = try? url.resourceValues(forKeys: [.contentModificationDateKey])
        let date = values?.contentModificationDate ?? Date()
        return DateFormatter.shortDate.string(from: date)
    }

    private static func relativePath(for url: URL, workspaceURL: URL) -> String {
        let workspacePath = workspaceURL.standardizedFileURL.path
        let filePath = url.standardizedFileURL.path
        guard filePath.hasPrefix(workspacePath + "/") else { return filePath }
        return String(filePath.dropFirst(workspacePath.count + 1))
    }
}

private struct EvidenceFileContext {
    let fileName: String
    let relativePath: String
    let textPreview: String

    var lower: String {
        [fileName, relativePath, textPreview]
            .joined(separator: " ")
            .lowercased()
    }

    var pathParts: [String] {
        relativePath
            .split(separator: "/")
            .map { String($0).lowercased() }
    }

    var parentPathLabel: String {
        let parent = NSString(string: relativePath).deletingLastPathComponent
        return parent.isEmpty || parent == "." ? "selected folder" : parent
    }

    var hasTeachingFeedbackSignal: Bool {
        hasAny(["student feedback", "course feedback", "teaching feedback", "peer feedback", "opintopalaute", "kurssipalaute"])
            || (hasAny(["feedback", "evaluation"]) && hasAny(["course", "teaching", "student", "mycourses", "pedagog"]))
    }

    func hasAny(_ terms: [String]) -> Bool {
        terms.contains { lower.contains($0.lowercased()) }
    }

    func hasPathPart(_ part: String) -> Bool {
        pathParts.contains(part.lowercased())
    }
}

private struct EvidenceScannerPrefill {
    var date: String?
    var title: String?
    var eventType: String?
    var role: String?
    var venue: String?
    var urls: [URL] = []
    var notes: [String] = []

    var hasUsefulFields: Bool {
        date != nil || title != nil || eventType != nil || role != nil || venue != nil || !urls.isEmpty
    }

    static func build(from context: EvidenceFileContext) -> EvidenceScannerPrefill {
        let lines = context.textPreview
            .components(separatedBy: .newlines)
            .map(\.trimmed)
            .filter { !$0.isEmpty }

        let combined = [context.fileName, context.relativePath, context.textPreview]
            .joined(separator: "\n")

        var prefill = EvidenceScannerPrefill()
        prefill.date = labelledValue(in: lines, keys: ["date", "when"])
            .flatMap { firstDate(in: $0) }
            ?? firstDate(in: combined)
            ?? bibValue(in: combined, keys: ["year"]).map { "\($0)-01-01" }
        prefill.title = labelledValue(in: lines, keys: ["title", "subject", "event", "name"])
            ?? bibValue(in: combined, keys: ["title"])
            ?? headingTitle(in: lines)
        prefill.eventType = labelledValue(in: lines, keys: ["type", "activity", "format"])
            ?? inferredEventType(from: combined)
        prefill.role = labelledValue(in: lines, keys: ["role", "my role", "capacity", "position"])
            ?? inferredRole(from: combined)
        prefill.venue = labelledValue(in: lines, keys: ["venue", "host", "location", "place", "organizer", "organiser", "institution", "conference", "journal", "booktitle", "publisher", "school", "department"])
            ?? bibValue(in: combined, keys: ["journal", "booktitle", "publisher"])
            ?? inferredVenue(from: combined)
        prefill.urls = URLTools.extractURLs(from: combined)
        if let doi = PublicationFormatter.doi(in: combined),
           let doiURL = URL(string: "https://doi.org/\(doi)"),
           !prefill.urls.contains(doiURL) {
            prefill.urls.append(doiURL)
        }
        let detectedDetails = detectedTenureDetails(in: lines, combined: combined)

        let fieldNames = [
            prefill.date == nil ? nil : "date",
            prefill.title == nil ? nil : "title",
            prefill.eventType == nil ? nil : "type",
            prefill.role == nil ? nil : "role",
            prefill.venue == nil ? nil : "venue/host",
            prefill.urls.isEmpty ? nil : "source URL"
        ]
        .compactMap { $0 }

        if !fieldNames.isEmpty {
            prefill.notes.append("Pre-filled fields from readable evidence text: \(fieldNames.joined(separator: ", ")).")
        }

        if !detectedDetails.isEmpty {
            prefill.notes.append("Detected tenure details: \(detectedDetails.joined(separator: "; ")).")
        }

        if let excerpt = evidenceExcerpt(from: lines, excluding: prefill) {
            prefill.notes.append("Readable excerpt: \(excerpt)")
        }

        return prefill
    }

    private static func labelledValue(in lines: [String], keys: [String]) -> String? {
        for line in lines {
            let lower = line.lowercased()
            for key in keys {
                let prefixes = [
                    "\(key):",
                    "\(key) -",
                    "\(key) --"
                ]
                for prefix in prefixes where lower.hasPrefix(prefix) {
                    let value = String(line.dropFirst(prefix.count)).trimmed
                    if !value.isEmpty {
                        return cleanValue(value)
                    }
                }
            }
        }
        return nil
    }

    private static func bibValue(in text: String, keys: [String]) -> String? {
        for key in keys {
            let escapedKey = NSRegularExpression.escapedPattern(for: key)
            let pattern = #"(?is)\b"# + escapedKey + #"\s*=\s*[\{\"]([^}\"]+)"#
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let range = NSRange(text.startIndex..<text.endIndex, in: text)
            guard let match = regex.firstMatch(in: text, range: range),
                  let matchRange = Range(match.range(at: 1), in: text) else {
                continue
            }
            let value = cleanValue(
                String(text[matchRange])
                    .replacingOccurrences(of: "{", with: "")
                    .replacingOccurrences(of: "}", with: "")
                    .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
            )
            if !value.isEmpty {
                return value
            }
        }
        return nil
    }

    private static func headingTitle(in lines: [String]) -> String? {
        for line in lines.prefix(12) {
            let cleaned = line
                .replacingOccurrences(of: "#", with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard cleaned.count >= 8,
                  cleaned.count <= 140,
                  !cleaned.localizedCaseInsensitiveContains("http"),
                  !cleaned.localizedCaseInsensitiveContains("zoom"),
                  !cleaned.localizedCaseInsensitiveContains("teams"),
                  !cleaned.localizedCaseInsensitiveContains("source file") else {
                continue
            }
            return cleanValue(cleaned)
        }
        return nil
    }

    private static func inferredEventType(from text: String) -> String? {
        let lower = text.lowercased()
        if lower.contains("@article") || lower.contains("@inproceedings") || lower.contains("doi") { return "Publication / DOI or BibTeX import" }
        if lower.contains("orcid.org") { return "ORCID profile / public scholarly visibility" }
        if lower.contains("scholar.google") || lower.contains("google scholar") { return "Google Scholar profile / citation visibility" }
        if lower.contains("keynote") { return "Keynote lecture" }
        if lower.contains("invited talk") || lower.contains("invited lecture") { return "Invited academic talk" }
        if lower.contains("conference") || lower.contains("symposium") { return "Conference presentation" }
        if lower.contains("panel") { return "Panel discussion" }
        if lower.contains("webinar") { return "Webinar presentation" }
        if lower.contains("workshop") { return "Workshop" }
        if lower.contains("student feedback") || lower.contains("course feedback") { return "Teaching evaluation / feedback" }
        if lower.contains("thesis") || lower.contains("supervision") { return "Supervision / examination evidence" }
        if lower.contains("grant") || lower.contains("funding") || lower.contains("proposal") { return "Grant / funding evidence" }
        if lower.contains("exhibition") || lower.contains("gallery") { return "Exhibition" }
        if lower.contains("publication") || lower.contains("doi") || lower.contains("journal") { return "Publication / research output evidence" }
        if lower.contains("course") || lower.contains("curriculum") { return "Course / curriculum evidence" }
        if lower.contains("committee") || lower.contains("board") || lower.contains("working group") { return "Committee / academic service" }
        if lower.contains("award") || lower.contains("recognition") || lower.contains("prize") { return "Recognition / award" }
        return nil
    }

    private static func inferredRole(from text: String) -> String? {
        let lower = text.lowercased()
        if lower.contains("principal investigator") || lower.contains(" pi ") { return "Principal investigator" }
        if lower.contains("work package lead") || lower.contains("wp lead") { return "Work package lead" }
        if lower.contains("keynote") { return "Keynote speaker" }
        if lower.contains("invited speaker") || lower.contains("invited talk") || lower.contains("invited lecture") { return "Invited speaker" }
        if lower.contains("panelist") || lower.contains("panellist") { return "Panelist" }
        if lower.contains("presenter") || lower.contains("presentation") { return "Presenter" }
        if lower.contains("speaker") { return "Speaker" }
        if lower.contains("reviewer") || lower.contains("evaluator") || lower.contains("referee") { return "Reviewer" }
        if lower.contains("examiner") || lower.contains("opponent") { return "Examiner" }
        if lower.contains("supervisor") || lower.contains("advisor") { return "Supervisor" }
        if lower.contains("teacher") || lower.contains("course") { return "Teacher" }
        if lower.contains("participant") || lower.contains("certificate") { return "Participant" }
        if lower.contains("author") || lower.contains("publication") || lower.contains("@article") || lower.contains("@inproceedings") || lower.contains("doi") { return "Author" }
        if lower.contains("artist") || lower.contains("artistic") { return "Artist" }
        return nil
    }

    private static func inferredVenue(from text: String) -> String? {
        let lower = text.lowercased()
        if lower.contains("aalto") || lower.contains("mycourses") {
            return "Aalto University"
        }
        return nil
    }

    private static func detectedTenureDetails(in lines: [String], combined: String) -> [String] {
        var details: [String] = []

        if let doi = PublicationFormatter.doi(in: combined) {
            details.append("DOI \(doi)")
        }

        if let funder = labelledValue(in: lines, keys: ["funder", "funded by", "funding body", "grantor"])
            ?? inferredFunder(from: combined) {
            details.append("funder \(funder)")
        }

        if let amount = grantAmount(in: combined) {
            details.append("grant amount \(amount)")
        }

        if let course = labelledValue(in: lines, keys: ["course", "course name", "course title", "course code"]) {
            details.append("course \(course)")
        }

        if let studentLevel = studentLevel(in: combined) {
            details.append("student level \(studentLevel)")
        }

        if let supervision = supervisionRole(in: combined) {
            details.append("supervision role \(supervision)")
        }

        if let host = labelledValue(in: lines, keys: ["exhibition host", "gallery", "museum", "curator"]) {
            details.append("exhibition host \(host)")
        }

        if let committeeLevel = committeeLevel(in: combined) {
            details.append("committee/service level \(committeeLevel)")
        }

        if let recognition = recognitionSignal(in: combined) {
            details.append("recognition signal \(recognition)")
        }

        return details
    }

    private static func inferredFunder(from text: String) -> String? {
        let knownFunders = [
            "Research Council of Finland",
            "Academy of Finland",
            "Business Finland",
            "European Research Council",
            "ERC",
            "Horizon Europe",
            "NordForsk",
            "Kone Foundation",
            "Finnish Cultural Foundation",
            "Aalto University"
        ]
        return knownFunders.first { text.localizedCaseInsensitiveContains($0) }
    }

    private static func grantAmount(in text: String) -> String? {
        let patterns = [
            #"(€|EUR|USD|\$)\s?[\d][\d\s.,]*(?:\s?(k|M|million))?"#,
            #"[\d][\d\s.,]*\s?(€|EUR|USD|k€|M€|million euros)"#
        ]

        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else { continue }
            let range = NSRange(text.startIndex..<text.endIndex, in: text)
            guard let match = regex.firstMatch(in: text, range: range),
                  let matchRange = Range(match.range, in: text) else { continue }
            return cleanValue(String(text[matchRange]))
        }

        return nil
    }

    private static func studentLevel(in text: String) -> String? {
        let lower = text.lowercased()
        if lower.contains("doctoral") || lower.contains("phd") || lower.contains("doctorate") { return "doctoral" }
        if lower.contains("master") || lower.contains("ma ") || lower.contains("ma thesis") { return "master" }
        if lower.contains("bachelor") || lower.contains("ba ") || lower.contains("ba thesis") { return "bachelor" }
        return nil
    }

    private static func supervisionRole(in text: String) -> String? {
        let lower = text.lowercased()
        if lower.contains("main supervisor") || lower.contains("principal supervisor") { return "main supervisor" }
        if lower.contains("co-supervisor") || lower.contains("cosupervisor") { return "co-supervisor" }
        if lower.contains("opponent") { return "opponent" }
        if lower.contains("examiner") || lower.contains("pre-examiner") { return "examiner" }
        if lower.contains("supervisor") || lower.contains("advisor") { return "supervisor" }
        return nil
    }

    private static func committeeLevel(in text: String) -> String? {
        let lower = text.lowercased()
        if lower.contains("international") { return "international" }
        if lower.contains("national") { return "national" }
        if lower.contains("university") || lower.contains("aalto") { return "university" }
        if lower.contains("school") { return "school" }
        if lower.contains("department") || lower.contains("programme") || lower.contains("program") { return "department/programme" }
        return nil
    }

    private static func recognitionSignal(in text: String) -> String? {
        let lower = text.lowercased()
        if lower.contains("international") && (lower.contains("invited") || lower.contains("keynote")) { return "international invited visibility" }
        if lower.contains("award") || lower.contains("prize") { return "award/prize" }
        if lower.contains("media") || lower.contains("press") || lower.contains("interview") { return "media visibility" }
        if lower.contains("external reviewer") || lower.contains("external examiner") { return "external expert role" }
        return nil
    }

    private static func firstDate(in text: String) -> String? {
        let patterns = [
            #"(?<!\d)(20\d{2})-(\d{1,2})-(\d{1,2})(?!\d)"#,
            #"(?<!\d)(\d{1,2})[./](\d{1,2})[./](20\d{2})(?!\d)"#,
            #"(?i)\b(\d{1,2})\s+(jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december)\s+(20\d{2})\b"#,
            #"(?i)\b(jan|january|feb|february|mar|march|apr|april|may|jun|june|jul|july|aug|august|sep|sept|september|oct|october|nov|november|dec|december)\s+(\d{1,2}),?\s+(20\d{2})\b"#,
            #"(?<!\d)(20\d{2})-(\d{1,2})(?!\d)"#
        ]

        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let range = NSRange(text.startIndex..<text.endIndex, in: text)
            guard let match = regex.firstMatch(in: text, range: range) else { continue }

            if pattern.contains("(20\\d{2})-") && match.numberOfRanges == 4 {
                return components(match, in: text, order: [1, 2, 3])
            }

            if pattern.contains("[./]") {
                return components(match, in: text, order: [3, 2, 1])
            }

            if pattern.contains("\\d{1,2})\\s+") {
                let day = capture(match, in: text, at: 1)
                let monthName = capture(match, in: text, at: 2).lowercased()
                let year = capture(match, in: text, at: 3)
                guard let month = monthNumber(monthName) else { continue }
                return "\(year)-\(month)-\(day.leftPadded(to: 2))"
            }

            if pattern.contains("\\s+(\\d{1,2})") {
                let monthName = capture(match, in: text, at: 1).lowercased()
                let day = capture(match, in: text, at: 2)
                let year = capture(match, in: text, at: 3)
                guard let month = monthNumber(monthName) else { continue }
                return "\(year)-\(month)-\(day.leftPadded(to: 2))"
            }

            if match.numberOfRanges == 3 {
                let year = capture(match, in: text, at: 1)
                let month = capture(match, in: text, at: 2)
                return "\(year)-\(month.leftPadded(to: 2))-01"
            }
        }

        return nil
    }

    private static func components(_ match: NSTextCheckingResult, in text: String, order: [Int]) -> String {
        let values = order.map { capture(match, in: text, at: $0) }
        return "\(values[0])-\(values[1].leftPadded(to: 2))-\(values[2].leftPadded(to: 2))"
    }

    private static func capture(_ match: NSTextCheckingResult, in text: String, at index: Int) -> String {
        guard let range = Range(match.range(at: index), in: text) else { return "" }
        return String(text[range])
    }

    private static func monthNumber(_ name: String) -> String? {
        let months = [
            "jan": "01", "january": "01",
            "feb": "02", "february": "02",
            "mar": "03", "march": "03",
            "apr": "04", "april": "04",
            "may": "05",
            "jun": "06", "june": "06",
            "jul": "07", "july": "07",
            "aug": "08", "august": "08",
            "sep": "09", "sept": "09", "september": "09",
            "oct": "10", "october": "10",
            "nov": "11", "november": "11",
            "dec": "12", "december": "12"
        ]
        return months[name]
    }

    private static func evidenceExcerpt(from lines: [String], excluding prefill: EvidenceScannerPrefill) -> String? {
        let excluded = [
            prefill.title,
            prefill.date,
            prefill.role,
            prefill.venue,
            prefill.eventType
        ]
        .compactMap { $0?.lowercased() }

        let excerpt = lines
            .filter { line in
                let lower = line.lowercased()
                return line.count > 24
                    && !lower.contains("http")
                    && !excluded.contains(lower)
                    && !lower.hasPrefix("date:")
                    && !lower.hasPrefix("role:")
                    && !lower.hasPrefix("venue:")
                    && !lower.hasPrefix("title:")
            }
            .prefix(3)
            .joined(separator: " ")
            .prefixString(maxLength: 320)
            .trimmed

        return excerpt.isEmpty ? nil : excerpt
    }

    private static func cleanValue(_ value: String) -> String {
        value
            .replacingOccurrences(of: #"^\s*[-–—]\s*"#, with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

private extension DateFormatter {
    static let shortDate: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
}

private extension String {
    func prefixString(maxLength: Int) -> String {
        guard count > maxLength else { return self }
        return String(prefix(maxLength))
    }

    func leftPadded(to length: Int) -> String {
        if count >= length { return self }
        return String(repeating: "0", count: length - count) + self
    }
}
