import Foundation

enum TenureReadinessReportExporter {
    static func export(entries: [EvidenceEntry]) -> String {
        let sorted = entries.sorted { lhs, rhs in
            if lhs.cvReady == rhs.cvReady { return lhs.date > rhs.date }
            return lhs.cvReady && !rhs.cvReady
        }

        var output: [String] = [
            "# Tenure Readiness Report",
            "",
            "Generated: \(dateString())",
            "",
            "This report is an internal readiness check. It separates strong evidence, weak evidence, proof needed, and suggested next actions for tenure preparation.",
            "",
            "## Summary",
            "",
            "- Evidence records: \(entries.count)",
            "- Ready-to-use records: \(entries.filter(\.cvReady).count)",
            "- Records with proof: \(entries.filter(hasProof).count)",
            "- Records needing proof: \(entries.filter { !hasProof($0) }.count)",
            ""
        ]

        for criterion in ReadinessCriterion.allCases {
            let matching = sorted.filter { criterion.matches($0) }
            let strong = matching.filter { $0.cvReady && hasProof($0) && $0.completeness.score >= 80 }
            let weak = matching.filter { !strong.contains($0) && hasProof($0) }
            let missingProof = matching.filter { !hasProof($0) }

            output.append("## \(criterion.title)")
            output.append("")
            output.append(criterion.description)
            output.append("")
            output.append("- Total mapped evidence: \(matching.count)")
            output.append("- Strong evidence: \(strong.count)")
            output.append("- Weak evidence: \(weak.count)")
            output.append("- Proof needed: \(missingProof.count)")
            output.append("- Suggested next action: \(nextAction(total: matching.count, strong: strong.count, weak: weak.count, missing: missingProof.count))")
            output.append("")
            output.append("### Strong Evidence")
            output.append(strong.isEmpty ? "- None yet." : strong.prefix(8).map(line(for:)).joined(separator: "\n"))
            output.append("")
            output.append("### Weak Evidence")
            output.append(weak.isEmpty ? "- None." : weak.prefix(8).map(line(for:)).joined(separator: "\n"))
            output.append("")
            output.append("### Proof Needed")
            output.append(missingProof.isEmpty ? "- None." : missingProof.prefix(8).map(line(for:)).joined(separator: "\n"))
            output.append("")
        }

        return output.joined(separator: "\n")
    }

    private static func line(for entry: EvidenceEntry) -> String {
        let subtitle = [entry.date, entry.role, entry.venue]
            .filter { !$0.trimmed.isEmpty }
            .joined(separator: ", ")
        let suffix = subtitle.isEmpty ? "" : " (\(subtitle))"
        return "- \(entry.title.trimmed.isEmpty ? "Untitled evidence" : entry.title)\(suffix) - \(entry.completeness.score)%"
    }

    private static func nextAction(total: Int, strong: Int, weak: Int, missing: Int) -> String {
        if total == 0 {
            return "Add at least one evidence record for this criterion."
        }
        if missing > 0 {
            return "Attach files or archive URLs for the records that still need proof."
        }
        if strong == 0 && weak > 0 {
            return "Mark the best supported record ready to use after checking wording."
        }
        if strong < 2 {
            return "Add or elevate another strong record so this area does not depend on one example."
        }
        return "Looks covered; keep the strongest examples concise and evaluator-facing."
    }

    private static func hasProof(_ entry: EvidenceEntry) -> Bool {
        !entry.attachments.isEmpty || !URLTools.extractURLs(from: [entry.source, entry.notes].joined(separator: "\n")).isEmpty
    }

    private static func dateString() -> String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
}

private enum ReadinessCriterion: String, CaseIterable {
    case research
    case teaching
    case impactService
    case leadership
    case funding
    case visibility

    var title: String {
        switch self {
        case .research: "Research / Artistic Work"
        case .teaching: "Teaching"
        case .impactService: "Impact / Service"
        case .leadership: "Leadership"
        case .funding: "Funding"
        case .visibility: "Visibility"
        }
    }

    var description: String {
        switch self {
        case .research:
            "Publications, artistic outputs, research talks, exhibitions, and research-facing projects."
        case .teaching:
            "Courses, pedagogy, programme development, feedback, and supervision."
        case .impactService:
            "Committees, academic service, public impact, hosting, review work, and institutional activity."
        case .leadership:
            "Programme leadership, head roles, management training, strategic committees, and coordination."
        case .funding:
            "Grant applications, awarded funding, EU projects, consortium roles, and seed funding."
        case .visibility:
            "Keynotes, invited talks, panels, public profiles, media, international recognition, and external activity."
        }
    }

    func matches(_ entry: EvidenceEntry) -> Bool {
        switch self {
        case .research:
            return entry.tenureDimension == "Research/artistic work"
                || ["Publication", "Artistic Output"].contains(entry.category)
        case .teaching:
            return entry.tenureDimension == "Teaching"
                || ["Teaching", "Supervision"].contains(entry.category)
        case .impactService:
            return entry.tenureDimension == "Impact and service"
                || ["Service", "Visibility"].contains(entry.category)
        case .leadership:
            let text = [entry.title, entry.role, entry.eventType, entry.notes].joined(separator: " ").lowercased()
            return text.contains("head")
                || text.contains("lead")
                || text.contains("manager")
                || text.contains("director")
                || text.contains("chair")
                || text.contains("programme")
                || text.contains("program")
                || text.contains("committee")
        case .funding:
            let text = [entry.title, entry.eventType, entry.source, entry.notes].joined(separator: " ").lowercased()
            return entry.category == "Funding"
                || text.contains("grant")
                || text.contains("funding")
                || text.contains("horizon")
                || text.contains("academy")
                || text.contains("business finland")
        case .visibility:
            let text = [entry.title, entry.role, entry.eventType, entry.notes].joined(separator: " ").lowercased()
            return entry.category == "Visibility"
                || text.contains("keynote")
                || text.contains("invited")
                || text.contains("panel")
                || text.contains("international")
                || text.contains("media")
        }
    }
}
