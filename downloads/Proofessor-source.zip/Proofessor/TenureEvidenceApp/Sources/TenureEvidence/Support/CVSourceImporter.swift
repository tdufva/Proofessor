import AppKit
import Foundation
import PDFKit

struct CVSourceImportReport: Hashable {
    var scannedFileCount: Int
    var importedFileCount: Int
    var skippedFileCount: Int
    var lineCount: Int
    var outputURL: URL
}

enum CVSourceImporter {
    static func importSources(workspaceURL: URL, outputURL: URL) throws -> CVSourceImportReport {
        let candidates = candidateFiles(workspaceURL: workspaceURL, outputURL: outputURL)
        var importedBlocks: [String] = []
        var skippedCount = 0

        for url in candidates {
            guard let text = readableText(from: url), !text.trimmed.isEmpty else {
                skippedCount += 1
                continue
            }

            importedBlocks.append(
                """
                ## Imported CV file: \(url.lastPathComponent)
                Source path: \(relativePath(for: url, workspaceURL: workspaceURL))

                \(text)
                """
            )
        }

        let stamp = fileStamp.string(from: Date())
        let output = """
        # Imported CV Source Scan

        Generated: \(stamp)
        Files scanned: \(candidates.count)
        Files imported: \(importedBlocks.count)
        Files skipped: \(skippedCount)

        \(importedBlocks.joined(separator: "\n\n---\n\n"))
        """

        try FileManager.default.createDirectory(at: outputURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        try output.write(to: outputURL, atomically: true, encoding: .utf8)

        return CVSourceImportReport(
            scannedFileCount: candidates.count,
            importedFileCount: importedBlocks.count,
            skippedFileCount: skippedCount,
            lineCount: output.components(separatedBy: .newlines).filter { !$0.trimmed.isEmpty }.count,
            outputURL: outputURL
        )
    }

    static func combinedSourceText(workspaceURL: URL, masterURL: URL, importedURL: URL) -> String {
        [
            readText(masterURL),
            readText(importedURL)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n---\n\n")
    }

    private static func candidateFiles(workspaceURL: URL, outputURL: URL) -> [URL] {
        let folders = [
            workspaceURL.appendingPathComponent("02_Profile_CV_and_Portfolios"),
            workspaceURL
                .appendingPathComponent("10_Trackers_and_Templates")
                .appendingPathComponent("CV_Source_Extractions")
        ]

        var urls: [URL] = []
        for folder in folders {
            guard let enumerator = FileManager.default.enumerator(
                at: folder,
                includingPropertiesForKeys: [.isRegularFileKey],
                options: [.skipsHiddenFiles]
            ) else {
                continue
            }

            for case let url as URL in enumerator where isSupported(url) {
                guard url.standardizedFileURL.path != outputURL.standardizedFileURL.path else { continue }
                urls.append(url)
            }
        }

        return urls.sorted { $0.path.localizedCaseInsensitiveCompare($1.path) == .orderedAscending }
    }

    private static func isSupported(_ url: URL) -> Bool {
        ["pdf", "txt", "md", "rtf"].contains(url.pathExtension.lowercased())
    }

    private static func readableText(from url: URL) -> String? {
        switch url.pathExtension.lowercased() {
        case "pdf":
            return PDFDocument(url: url)?.string.map(limitText)
        case "rtf":
            guard let attributed = try? NSAttributedString(url: url, options: [:], documentAttributes: nil) else {
                return nil
            }
            return limitText(attributed.string)
        case "txt", "md":
            return readText(url).trimmed.isEmpty ? nil : limitText(readText(url))
        default:
            return nil
        }
    }

    private static func readText(_ url: URL) -> String {
        (try? String(contentsOf: url, encoding: .utf8)) ?? ""
    }

    private static func limitText(_ text: String) -> String {
        String(text.prefix(120_000))
    }

    private static func relativePath(for url: URL, workspaceURL: URL) -> String {
        let workspacePath = workspaceURL.standardizedFileURL.path
        let filePath = url.standardizedFileURL.path
        guard filePath.hasPrefix(workspacePath + "/") else { return filePath }
        return String(filePath.dropFirst(workspacePath.count + 1))
    }

    private static let fileStamp: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd_HHmmss"
        return formatter
    }()
}
