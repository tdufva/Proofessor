import Foundation

enum CVMarkdownExporter {
    static func export(entries: [EvidenceEntry], style: CVExportStyle = .academic) -> String {
        switch style {
        case .academic:
            academicExport(entries: entries)
        case .tenk:
            tenkExport(entries: entries)
        case .tenureBullets:
            tenureBullets(entries: entries)
        case .publicBio:
            publicBio(entries: entries)
        }
    }

    private static func academicExport(entries: [EvidenceEntry]) -> String {
        let sorted = entries.sorted { lhs, rhs in
            if lhs.date == rhs.date {
                return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
            }
            return lhs.date > rhs.date
        }

        let sections: [(String, (EvidenceEntry) -> Bool)] = [
            ("Invited Talks and Panels", { entry in
                entry.category == "Talk" && (
                    entry.eventType.localizedCaseInsensitiveContains("invited")
                    || entry.role.localizedCaseInsensitiveContains("invited")
                    || entry.eventType.localizedCaseInsensitiveContains("panel")
                )
            }),
            ("Conference Presentations", { entry in
                entry.category == "Talk" && entry.eventType.localizedCaseInsensitiveContains("conference")
            }),
            ("Artistic Outputs and Exhibitions", { entry in
                entry.category == "Artistic Output"
            }),
            ("Academic Service and Leadership", { entry in
                entry.category == "Service" || entry.eventType.localizedCaseInsensitiveContains("advisor") || entry.role.localizedCaseInsensitiveContains("reviewer")
            }),
            ("Teaching and Supervision", { entry in
                entry.category == "Teaching" || entry.category == "Supervision"
            }),
            ("Funding and Grants", { entry in
                entry.category == "Funding"
            }),
            ("Other Visibility", { entry in
                entry.category == "Visibility" || entry.category == "Other"
            })
        ]

        var output = """
        # CV Export from Proofessor

        Generated from Proofessor.

        """

        for section in sections {
            let matches = sorted.filter(section.1)
            guard !matches.isEmpty else { continue }
            output += "\n## \(section.0)\n\n"
            output += matches.map(cvLine).joined(separator: "\n")
            output += "\n"
        }

        let uncategorized = sorted.filter { entry in
            !sections.contains { section in section.1(entry) }
        }

        if !uncategorized.isEmpty {
            output += "\n## Uncategorized Review\n\n"
            output += uncategorized.map(cvLine).joined(separator: "\n")
            output += "\n"
        }

        return output
    }

    private static func tenkExport(entries: [EvidenceEntry]) -> String {
        let sorted = entries.sorted { $0.date > $1.date }
        let publications = sorted.filter { $0.category == "Publication" }
        let artistic = sorted.filter { $0.category == "Artistic Output" }
        let talks = sorted.filter { $0.category == "Talk" }
        let service = sorted.filter { $0.category == "Service" || $0.category == "Visibility" }
        let teaching = sorted.filter { $0.category == "Teaching" || $0.category == "Supervision" }
        let funding = sorted.filter { $0.category == "Funding" }

        return """
        # TENK-Style CV Export

        ## Publications and Research Outputs

        \(sectionLines(publications))

        ## Artistic Activities and Outputs

        \(sectionLines(artistic))

        ## Research Funding and Projects

        \(sectionLines(funding))

        ## Teaching Merits and Supervision

        \(sectionLines(teaching))

        ## Scientific and Societal Impact

        \(sectionLines(talks + service))

        """
    }

    private static func tenureBullets(entries: [EvidenceEntry]) -> String {
        let dimensions = ["Research/artistic work", "Teaching", "Impact and service", "All"]
        var output = "# Tenure Dossier Narrative Bullets\n\n"

        for dimension in dimensions {
            let matches = entries
                .filter { $0.tenureDimension == dimension }
                .sorted { lhs, rhs in
                    if lhs.cvReady != rhs.cvReady { return lhs.cvReady && !rhs.cvReady }
                    return lhs.completeness.score > rhs.completeness.score
                }

            guard !matches.isEmpty else { continue }
            output += "## \(dimension)\n\n"
            output += matches.prefix(10).map { entry in
                "- \(entry.title) demonstrates \(dimension.lowercased()) through \(entry.role.isEmpty ? "documented activity" : entry.role) at \(entry.venue.isEmpty ? "the recorded venue/context" : entry.venue). Evidence status: \(entry.completeness.displayLabel.lowercased()), \(entry.completeness.score)% complete."
            }
            .joined(separator: "\n")
            output += "\n\n"
        }

        return output
    }

    private static func publicBio(entries: [EvidenceEntry]) -> String {
        let recent = entries
            .filter { $0.cvReady || $0.completeness.score >= 80 }
            .sorted { $0.date > $1.date }
            .prefix(8)

        return """
        # Public Bio / Website Update Notes

        Dr. Example Candidate is an assistant professor at Example University. This demo biography should be replaced with the user's own field, position, research themes, artistic practice, teaching profile, and public-facing links.

        ## Recent Highlights

        \(recent.map(cvLine).joined(separator: "\n"))

        """
    }

    static func monthlyReview(entries: [EvidenceEntry], month: String) -> String {
        let selected = entries
            .filter { $0.date.hasPrefix(month) }
            .sorted { $0.date > $1.date }
        let incomplete = entries
            .filter { !$0.completeness.missing.isEmpty }
            .sorted { $0.completeness.score < $1.completeness.score }

        var output = """
        # Monthly Tenure Review: \(month)

        ## Entries This Month

        """

        if selected.isEmpty {
            output += "No entries dated \(month).\n"
        } else {
            output += selected.map(cvLine).joined(separator: "\n")
            output += "\n"
        }

        output += "\n## Items Needing Attention\n\n"

        if incomplete.isEmpty {
            output += "All entries look complete.\n"
        } else {
            output += incomplete.prefix(20).map { entry in
                "- \(entry.title): \(entry.completeness.score)% complete; missing \(entry.completeness.missing.joined(separator: ", "))."
            }
            .joined(separator: "\n")
            output += "\n"
        }

        return output
    }

    private static func cvLine(_ entry: EvidenceEntry) -> String {
        if entry.category == "Publication" {
            return PublicationFormatter.cvLine(for: entry)
        }

        var pieces: [String] = []

        if !entry.date.trimmed.isEmpty {
            pieces.append(entry.date)
        }

        let title = entry.title.trimmed.isEmpty ? "Untitled evidence" : entry.title.trimmed
        pieces.append("\"\(title)\"")

        if !entry.role.trimmed.isEmpty {
            pieces.append(entry.role.trimmed)
        }

        if !entry.venue.trimmed.isEmpty {
            pieces.append(entry.venue.trimmed)
        }

        if !entry.eventType.trimmed.isEmpty {
            pieces.append(entry.eventType.trimmed)
        }

        var line = "- " + pieces.joined(separator: ". ") + "."

        if !entry.source.trimmed.isEmpty {
            line += " Evidence/source: \(entry.source.trimmed)."
        }

        return line
    }

    private static func sectionLines(_ entries: [EvidenceEntry]) -> String {
        if entries.isEmpty {
            return "No entries yet."
        }
        return entries.map(cvLine).joined(separator: "\n")
    }
}
