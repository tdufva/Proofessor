import Foundation

struct CVTemplateRule: Hashable {
    var summary: String
    var targetPages: Int?
    var preferVerifiedOnly: Bool
    var options: CVBuildOptions

    static func rule(for variant: CVDraftVariant, base: CVBuildOptions) -> CVTemplateRule {
        var options = base
        var summary = "Balanced editable draft."
        var targetPages: Int?
        var preferVerifiedOnly = false

        switch variant {
        case .tenk:
            options.includeSourceConfidence = false
            options.includeDraftNote = false
            options.compactBullets = true
            summary = "TENK rule: formal, dense, no source badges."
        case .threePage:
            options.compactBullets = true
            options.onlyCVReadyEvidence = true
            targetPages = 3
            preferVerifiedOnly = true
            summary = "Three-page rule: strongest ready-to-use items, hard page awareness."
        case .artFocused:
            summary = "Art CV rule: exhibitions, artistic research, public projects, and cultural visibility are prioritised."
        case .tenure:
            summary = "Tenure rule: map content to research/artistic work, teaching, and impact/service."
        case .publicProfile:
            options.includeSourceConfidence = false
            options.includeDraftNote = false
            options.includeSourceNotes = false
            options.compactBullets = true
            targetPages = 2
            preferVerifiedOnly = true
            summary = "Public profile rule: short, elegant, and scaffolding-free."
        default:
            break
        }

        if base.finalCleanMode {
            options.includeSourceConfidence = false
            options.includeSourceNotes = false
            options.includeDraftNote = false
            options.onlyCVReadyEvidence = true
            options.compactBullets = true
            preferVerifiedOnly = true
            summary += " Final clean mode is active."
        }

        return CVTemplateRule(summary: summary, targetPages: targetPages, preferVerifiedOnly: preferVerifiedOnly, options: options)
    }
}
