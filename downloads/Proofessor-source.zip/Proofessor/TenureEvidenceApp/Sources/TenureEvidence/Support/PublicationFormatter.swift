import Foundation

enum PublicationFormatter {
    static func formatSourceLine(_ line: String) -> String {
        let clean = line.trimmed.removingLeadingBullet
        guard !clean.isEmpty else { return "" }

        var parts = [clean]
        let category = tenkCategory(for: clean)
        let role = role(for: clean)
        let peerReview = peerReviewLabel(for: clean)

        parts.append("TENK: \(category)")
        parts.append("Role: \(role)")
        parts.append(peerReview)

        if let doi = doi(in: clean) {
            parts.append("DOI: \(doi)")
        }

        return "- " + parts.joined(separator: " | ")
    }

    static func cvLine(for entry: EvidenceEntry, includeSource: Bool = true) -> String {
        var parts: [String] = []

        if !entry.date.trimmed.isEmpty {
            parts.append(entry.date.trimmed)
        }

        parts.append(entry.title.trimmed.isEmpty ? "Untitled publication" : entry.title.trimmed)

        if !entry.role.trimmed.isEmpty {
            parts.append("Role: \(cleanRole(entry.role))")
        } else {
            parts.append("Role: \(role(for: entry.title + " " + entry.notes))")
        }

        if !entry.venue.trimmed.isEmpty {
            parts.append(entry.venue.trimmed)
        }

        let basis = [entry.title, entry.eventType, entry.venue, entry.notes, entry.source].joined(separator: " ")
        parts.append("TENK: \(tenkCategory(for: basis, fallbackCategory: entry.category))")
        parts.append(peerReviewLabel(for: basis))

        if let doi = doi(in: basis) {
            parts.append("DOI: \(doi)")
        }

        if includeSource, !entry.source.trimmed.isEmpty {
            parts.append("Source: \(entry.source.trimmed)")
        }

        return "- " + parts.joined(separator: " | ") + "."
    }

    static func tenkCategory(for text: String, fallbackCategory: String = "Publication") -> String {
        let lower = text.lowercased()

        if fallbackCategory == "Artistic Output" || lower.contains("exhibition") || lower.contains("artistic") {
            return "F Artistic and design activities"
        }

        if lower.contains("doctoral") || lower.contains("dissertation") || lower.contains("thesis") {
            return "G Theses"
        }

        if lower.contains("edited book") || lower.contains("monograph") || lower.contains("book") {
            return "C Scientific books"
        }

        if lower.contains("journal") || lower.contains("peer") || lower.contains("reviewed") || lower.contains("refereed") {
            return "A Peer-reviewed scientific articles"
        }

        if lower.contains("conference") || lower.contains("proceedings") {
            return lower.contains("peer") || lower.contains("reviewed")
                ? "A Peer-reviewed scientific articles"
                : "B Non-refereed scientific articles"
        }

        if lower.contains("professional") || lower.contains("practitioner") {
            return "D Publications for professional communities"
        }

        if lower.contains("media") || lower.contains("blog") || lower.contains("newspaper") || lower.contains("magazine") {
            return "E Publications for the general public"
        }

        return fallbackCategory == "Publication" ? "B Non-refereed scientific articles" : fallbackCategory
    }

    static func doi(in text: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: #"(?i)\b10\.\d{4,9}/[-._;()/:A-Z0-9]+\b"#) else {
            return nil
        }

        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let match = regex.firstMatch(in: text, range: range),
              let swiftRange = Range(match.range, in: text) else {
            return nil
        }

        return String(text[swiftRange]).trimmingCharacters(in: CharacterSet(charactersIn: ".,;)"))
    }

    private static func peerReviewLabel(for text: String) -> String {
        let lower = text.lowercased()
        if lower.contains("peer-reviewed") || lower.contains("peer reviewed") || lower.contains("refereed") {
            return "Peer review: yes"
        }

        if lower.contains("journal") || lower.contains("proceedings") {
            return "Peer review: check"
        }

        return "Peer review: not stated"
    }

    private static func role(for text: String) -> String {
        let lower = text.lowercased()
        if lower.contains("editor") || lower.contains("(ed") {
            return "editor"
        }

        if lower.contains("slotte dufva") || lower.contains("dufva") {
            return "author"
        }

        return "role to check"
    }

    private static func cleanRole(_ role: String) -> String {
        role
            .trimmed
            .replacingOccurrences(of: "Co-author", with: "co-author")
            .replacingOccurrences(of: "Author", with: "author")
            .replacingOccurrences(of: "Editor", with: "editor")
    }
}

private extension String {
    var removingLeadingBullet: String {
        trimPrefix("- ").trimmed
    }

    func trimPrefix(_ prefix: String) -> String {
        hasPrefix(prefix) ? String(dropFirst(prefix.count)) : self
    }
}

