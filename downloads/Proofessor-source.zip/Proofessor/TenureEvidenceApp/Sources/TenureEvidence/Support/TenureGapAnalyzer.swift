import Foundation

struct TenureDimensionCoverage: Identifiable, Hashable {
    let dimension: AaltoTenureDimension
    let entries: [EvidenceEntry]
    let proofCount: Int
    let readyCount: Int
    let strongCount: Int
    let gapNotes: [String]

    var id: String { dimension.id }
}

enum AaltoTenureDimension: String, CaseIterable, Identifiable {
    case researchArtistic
    case teaching
    case impactService

    var id: String { rawValue }

    var title: String {
        switch self {
        case .researchArtistic: "Research / Artistic Work"
        case .teaching: "Teaching"
        case .impactService: "Impact / Service"
        }
    }

    var systemImage: String {
        switch self {
        case .researchArtistic: "paintpalette"
        case .teaching: "graduationcap"
        case .impactService: "building.columns"
        }
    }

    var description: String {
        switch self {
        case .researchArtistic:
            "Quality, independence, artistic/research outputs, funding, supervision of researchers, and international profile."
        case .teaching:
            "Teaching experience, course development, supervision, pedagogical studies, feedback quality, and use of feedback."
        case .impactService:
            "Societal contribution, academic service, field development, leadership, public visibility, and university service."
        }
    }

    func matches(_ entry: EvidenceEntry) -> Bool {
        switch self {
        case .researchArtistic:
            entry.tenureDimension == "Research/artistic work"
                || ["Publication", "Artistic Output", "Funding", "Talk"].contains(entry.category)
        case .teaching:
            entry.tenureDimension == "Teaching"
                || ["Teaching", "Supervision"].contains(entry.category)
        case .impactService:
            entry.tenureDimension == "Impact and service"
                || ["Service", "Visibility"].contains(entry.category)
        }
    }
}

enum TenureGapAnalyzer {
    static func coverage(entries: [EvidenceEntry]) -> [TenureDimensionCoverage] {
        AaltoTenureDimension.allCases.map { dimension in
            let matching = entries
                .filter { dimension.matches($0) }
                .sorted {
                    if $0.cvReady == $1.cvReady { return $0.date > $1.date }
                    return $0.cvReady && !$1.cvReady
                }
            return TenureDimensionCoverage(
                dimension: dimension,
                entries: matching,
                proofCount: matching.filter(hasProof).count,
                readyCount: matching.filter(\.cvReady).count,
                strongCount: matching.filter { hasProof($0) && ($0.cvReady || $0.completeness.score >= 80) }.count,
                gapNotes: gapNotes(for: dimension, entries: matching, allEntries: entries)
            )
        }
    }

    static func gapMessages(entries: [EvidenceEntry]) -> [String] {
        let coverage = coverage(entries: entries)
        var messages = coverage.flatMap(\.gapNotes)

        let teaching = entries.filter { AaltoTenureDimension.teaching.matches($0) }
        if !teaching.isEmpty,
           !teaching.contains(where: { containsAny($0, ["feedback", "course feedback", "student feedback", "peer feedback", "used feedback", "improved teaching"]) }) {
            messages.append("Teaching has evidence, but weak proof of feedback and how feedback improved teaching.")
        }

        let funding = entries.filter { $0.category == "Funding" || containsAny($0, ["grant", "funding", "funded", "funder"]) }
        if !funding.isEmpty,
           funding.contains(where: { !containsAmount($0) || roleNeedsClarification($0.role) }) {
            messages.append("Funding entries need clearer amounts, funders, and your role.")
        }

        let impact = entries.filter { AaltoTenureDimension.impactService.matches($0) }
        if impact.count >= 3,
           impact.filter({ containsAny($0, ["international", "external", "national", "invited", "media", "public"]) }).count < 2 {
            messages.append("Impact/service has activity, but few international or external examples are explicit.")
        }

        var seen = Set<String>()
        return messages.filter { seen.insert($0).inserted }.prefix(6).map { $0 }
    }

    static func hasProof(_ entry: EvidenceEntry) -> Bool {
        !entry.attachments.isEmpty || !URLTools.extractURLs(from: [entry.source, entry.notes].joined(separator: "\n")).isEmpty
    }

    private static func gapNotes(for dimension: AaltoTenureDimension, entries: [EvidenceEntry], allEntries: [EvidenceEntry]) -> [String] {
        guard !entries.isEmpty else {
            return ["No evidence mapped to \(dimension.title.lowercased()) in the current review period."]
        }

        var notes: [String] = []
        if entries.filter(hasProof).isEmpty {
            notes.append("\(dimension.title) needs attachments or source URLs.")
        }

        if !entries.contains(where: \.cvReady) {
            notes.append("Choose the strongest \(dimension.title.lowercased()) records for the CV.")
        }

        switch dimension {
        case .researchArtistic:
            if !allEntries.contains(where: { $0.category == "Funding" || containsAny($0, ["grant", "funding", "funded"]) }) {
                notes.append("Research/artistic work lacks explicit funding evidence.")
            }
        case .teaching:
            if !entries.contains(where: { containsAny($0, ["feedback", "pedagogical", "course development", "supervision"]) }) {
                notes.append("Teaching needs feedback, course development, pedagogy, or supervision proof.")
            }
        case .impactService:
            if !entries.contains(where: { containsAny($0, ["committee", "leadership", "chair", "public", "media", "international"]) }) {
                notes.append("Impact/service needs clearer leadership, service, or societal-impact proof.")
            }
        }

        return notes
    }

    private static func roleNeedsClarification(_ role: String) -> Bool {
        let trimmed = role.trimmed.lowercased()
        return trimmed.isEmpty || trimmed == "applicant or collaborator" || trimmed == "member"
    }

    private static func containsAmount(_ entry: EvidenceEntry) -> Bool {
        let text = joinedText(entry)
        return text.range(of: #"(€|eur|usd|\$)\s?\d|\d[\d\s,.]+(€|eur|usd|k|m|million)"#, options: [.regularExpression, .caseInsensitive]) != nil
    }

    private static func containsAny(_ entry: EvidenceEntry, _ terms: [String]) -> Bool {
        let text = joinedText(entry).lowercased()
        return terms.contains { text.contains($0.lowercased()) }
    }

    private static func joinedText(_ entry: EvidenceEntry) -> String {
        [
            entry.title,
            entry.category,
            entry.eventType,
            entry.role,
            entry.venue,
            entry.tenureDimension,
            entry.source,
            entry.notes
        ]
        .joined(separator: " ")
    }
}
