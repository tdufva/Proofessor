import Foundation

enum ProfileAutofillExtractor {
    static func suggestion(
        settings: ConnectorSettings,
        entries: [EvidenceEntry],
        cvItems: [CVStructuredItem],
        sourceText: String
    ) -> ProfileAutofillSuggestion {
        let combinedText = [
            sourceText,
            entries.map { [$0.title, $0.role, $0.venue, $0.source, $0.notes].joined(separator: "\n") }.joined(separator: "\n"),
            cvItems.map { [$0.title, $0.role, $0.venue, $0.source, $0.notes].joined(separator: "\n") }.joined(separator: "\n")
        ]
        .joined(separator: "\n")

        let urls = URLTools.extractURLs(from: combinedText)

        return ProfileAutofillSuggestion(
            name: firstNonEmpty(settings.publicDisplayName, guessedName(from: sourceText)),
            title: firstNonEmpty(settings.profileTitle, guessedTitle(from: sourceText), commonRole(from: entries)),
            affiliation: firstNonEmpty(settings.affiliation, guessedAffiliation(from: sourceText)),
            researchThemes: firstNonEmpty(settings.researchThemes, labelledValue(in: sourceText, keys: ["research themes", "research interests", "research focus", "keywords"]), themes(from: entries, cvItems: cvItems, sections: [.publication, .grant, .supervision])),
            artisticThemes: firstNonEmpty(settings.artisticThemes, labelledValue(in: sourceText, keys: ["artistic themes", "artistic focus", "artistic practice"]), themes(from: entries, cvItems: cvItems, sections: [.artisticWork])),
            teachingThemes: firstNonEmpty(settings.teachingThemes, labelledValue(in: sourceText, keys: ["teaching themes", "teaching interests", "teaching profile"]), themes(from: entries, cvItems: cvItems, sections: [.teaching, .supervision])),
            orcidURL: firstNonEmpty(settings.orcidURL, firstURL(containing: "orcid.org", urls: urls)),
            googleScholarURL: firstNonEmpty(settings.googleScholarURL, firstURL(containing: "scholar.google", urls: urls)),
            aaltoProfileURL: firstNonEmpty(settings.aaltoPeopleURL, settings.acrisProfileURL, firstURL(containing: "aalto", urls: urls), firstURL(containing: "research.aalto", urls: urls)),
            selectedPublications: firstNonEmpty(settings.selectedPublications, selectedLines(entries: entries, cvItems: cvItems, categories: ["Publication"], sections: [.publication])),
            selectedExhibitions: firstNonEmpty(settings.selectedExhibitions, selectedLines(entries: entries, cvItems: cvItems, categories: ["Artistic Output"], sections: [.artisticWork]))
        )
    }

    private static func firstNonEmpty(_ values: String...) -> String {
        values.map(\.trimmed).first { !$0.isEmpty } ?? ""
    }

    private static func guessedName(from sourceText: String) -> String {
        let lines = sourceText.components(separatedBy: .newlines).map(\.trimmed)
        for line in lines.prefix(40) {
            let words = line.split(separator: " ")
            if words.count >= 2,
               words.count <= 5,
               line.count <= 70,
               !line.localizedCaseInsensitiveContains("curriculum"),
               !line.localizedCaseInsensitiveContains("profile"),
               !line.localizedCaseInsensitiveContains("university"),
               !line.localizedCaseInsensitiveContains("department") {
                return line
            }
        }
        return ""
    }

    private static func guessedTitle(from sourceText: String) -> String {
        let roleHints = [
            "assistant professor",
            "associate professor",
            "professor",
            "university lecturer",
            "lecturer",
            "postdoctoral researcher",
            "researcher",
            "artist",
            "designer",
            "curator"
        ]
        for line in sourceText.components(separatedBy: .newlines).map(\.trimmed).prefix(100) {
            let lower = line.lowercased()
            if roleHints.contains(where: { lower.contains($0) }) {
                return cleanInlineLabel(line)
            }
        }
        return ""
    }

    private static func commonRole(from entries: [EvidenceEntry]) -> String {
        let roles = entries
            .map(\.role)
            .map(\.trimmed)
            .filter { !$0.isEmpty }
        let grouped = Dictionary(grouping: roles, by: { $0.lowercased() })
        return grouped
            .max { lhs, rhs in lhs.value.count < rhs.value.count }?
            .value
            .first ?? ""
    }

    private static func guessedAffiliation(from sourceText: String) -> String {
        let affiliationHints = ["aalto", "university", "school of", "department", "academy"]
        for line in sourceText.components(separatedBy: .newlines).map(\.trimmed).prefix(120) {
            let lower = line.lowercased()
            if line.count <= 140, affiliationHints.contains(where: { lower.contains($0) }) {
                return cleanInlineLabel(line)
            }
        }
        return ""
    }

    private static func labelledValue(in text: String, keys: [String]) -> String {
        for line in text.components(separatedBy: .newlines).map(\.trimmed) {
            let lower = line.lowercased()
            for key in keys {
                let prefix = "\(key):"
                if lower.hasPrefix(prefix) {
                    return String(line.dropFirst(prefix.count)).trimmed
                }
            }
        }
        return ""
    }

    private static func themes(
        from entries: [EvidenceEntry],
        cvItems: [CVStructuredItem],
        sections: [CVStructuredSection]
    ) -> String {
        let entryTitles = entries
            .filter { entry in
                switch sections {
                case let sections where sections.contains(.publication):
                    ["Publication", "Funding", "Talk"].contains(entry.category)
                case let sections where sections.contains(.artisticWork):
                    entry.category == "Artistic Output"
                case let sections where sections.contains(.teaching):
                    ["Teaching", "Supervision"].contains(entry.category)
                default:
                    false
                }
            }
            .map(\.title)

        let itemTitles = cvItems
            .filter { sections.contains($0.section) }
            .map(\.title)

        return shortThemePhrase(from: entryTitles + itemTitles)
    }

    private static func selectedLines(
        entries: [EvidenceEntry],
        cvItems: [CVStructuredItem],
        categories: [String],
        sections: [CVStructuredSection]
    ) -> String {
        let entryLines = entries
            .filter { categories.contains($0.category) }
            .sorted { lhs, rhs in
                if lhs.cvReady != rhs.cvReady { return lhs.cvReady && !rhs.cvReady }
                return lhs.date > rhs.date
            }
            .map { entry in
                [String(entry.date.prefix(4)), entry.title, entry.venue]
                    .map(\.trimmed)
                    .filter { !$0.isEmpty }
                    .joined(separator: " - ")
            }

        let itemLines = cvItems
            .filter { sections.contains($0.section) }
            .sorted { lhs, rhs in lhs.year > rhs.year }
            .map { item in
                [item.year, item.title, item.venue]
                    .map(\.trimmed)
                    .filter { !$0.isEmpty }
                    .joined(separator: " - ")
            }

        return Array((entryLines + itemLines).filter { !$0.isEmpty }.prefix(6))
            .joined(separator: "\n")
    }

    private static func firstURL(containing needle: String, urls: [URL]) -> String {
        urls
            .first { $0.absoluteString.localizedCaseInsensitiveContains(needle) }?
            .absoluteString ?? ""
    }

    private static func shortThemePhrase(from titles: [String]) -> String {
        let cleaned = titles
            .flatMap { title in
                title
                    .replacingOccurrences(of: #"[^\p{L}\p{N}\s-]"#, with: " ", options: .regularExpression)
                    .components(separatedBy: .whitespacesAndNewlines)
            }
            .map { $0.lowercased().trimmed }
            .filter { word in
                word.count > 4
                    && !stopWords.contains(word)
                    && Int(word) == nil
            }

        let counts = Dictionary(grouping: cleaned, by: { $0 }).mapValues(\.count)
        let top = counts
            .sorted { lhs, rhs in
                if lhs.value == rhs.value { return lhs.key < rhs.key }
                return lhs.value > rhs.value
            }
            .prefix(6)
            .map(\.key)

        return top.isEmpty ? "" : top.joined(separator: ", ")
    }

    private static func cleanInlineLabel(_ value: String) -> String {
        value
            .replacingOccurrences(of: #"^\s*[-•]\s*"#, with: "", options: .regularExpression)
            .replacingOccurrences(of: #"^[A-Za-z ]+:\s*"#, with: "", options: .regularExpression)
            .trimmed
    }

    private static let stopWords: Set<String> = [
        "and", "with", "from", "this", "that", "into", "within", "about", "through",
        "research", "teaching", "publication", "conference", "university", "aalto",
        "project", "course", "paper", "article", "chapter", "workshop", "invited"
    ]
}
