import Foundation

enum CVStructuredDraftBuilder {
    static func generate(
        variant: CVDraftVariant,
        sourceText: String,
        cv2025Text: String,
        cv2025SummaryText: String,
        items: [CVStructuredItem],
        appEntries: [EvidenceEntry],
        options: CVBuildOptions
    ) -> String {
        let rule = CVTemplateRule.rule(for: variant, base: options)
        let effectiveOptions = rule.options
        let source = CVSource(text: sourceText, options: effectiveOptions)
        let context = CVBuildContext(options: effectiveOptions, candidateName: CVBuildContext.candidateName(from: sourceText))
        let selected = selectedItems(from: items, variant: variant, rule: rule)

        let sections: [String]
        switch variant {
        case .currentPages:
            sections = currentPages(source: source, items: selected, context: context, appEntries: appEntries)
        case .cv2025Research:
            sections = cv2025Research(
                source: source,
                cv2025Text: cv2025Text,
                cv2025SummaryText: cv2025SummaryText,
                items: selected,
                context: context,
                appEntries: appEntries
            )
        case .generalAcademic:
            sections = generalAcademic(source: source, items: selected, context: context, appEntries: appEntries)
        case .artFocused:
            sections = artFocused(source: source, items: selected, context: context, appEntries: appEntries)
        case .researchFocused:
            sections = researchFocused(source: source, items: selected, context: context, appEntries: appEntries)
        case .teachingFocused:
            sections = teachingFocused(source: source, items: selected, context: context, appEntries: appEntries)
        case .tenk:
            sections = tenk(source: source, items: selected, context: context, appEntries: appEntries)
        case .threePage:
            sections = threePage(source: source, items: selected, context: context, appEntries: appEntries)
        case .tenure:
            sections = tenure(source: source, items: selected, context: context, appEntries: appEntries)
        case .publicProfile:
            sections = publicProfile(source: source, items: selected, context: context, appEntries: appEntries)
        }

        return sections
            .filter { !$0.trimmed.isEmpty }
            .joined(separator: "\n\n")
    }

    private static func currentPages(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        [
            header("Example Candidate - Current Pages CV Template", context: context),
            source.section("Personal Details"),
            source.section("Profile"),
            section("Education", items, [.education], context: context),
            section("Employment", items, [.employment], context: context),
            section("Research funding and grants", items, [.grant], context: context),
            section("Research output", items, [.publication], context: context),
            section("Artistic work", items, [.artisticWork], context: context),
            section("Supervision and leadership", items, [.supervision], context: context),
            section("Teaching merits", items, [.teaching], context: context),
            section("Academic service", items, [.service], context: context),
            section("Talks and visibility", items, [.talk, .visibility], context: context),
            section("Other merits", items, [.other], context: context),
            unstructuredEvidenceSection(title: "Evidence records not yet in structured CV database", context: context, items: items, appEntries: appEntries)
        ]
    }

    private static func cv2025Research(
        source: CVSource,
        cv2025Text: String,
        cv2025SummaryText: String,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        let profile = [
            markdownSection("Core Profile", in: cv2025SummaryText),
            markdownSection("Research Framing From `CV2025.pages`", in: cv2025SummaryText)
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")

        let fallback = firstParagraphs(from: cv2025Text, count: 4)
        let researchEntries = appEntries.filter {
            $0.tenureDimension == "Research/artistic work" || $0.category == "Publication" || $0.category == "Talk"
        }

        return [
            header("Example Candidate - CV2025 Research Profile CV", context: context),
            "## Research Profile Language\n\n" + (profile.isEmpty ? fallback : profile),
            source.section("Personal Details", limit: 12),
            section("Employment", items, [.employment], context: context, limit: 5),
            section("Research funding and grants", items, [.grant], context: context, limit: 12),
            section("Research output", items, [.publication], context: context, limit: 16),
            section("Artistic work", items, [.artisticWork], context: context, limit: 10),
            section("Invited talks and presentations", items, [.talk], context: context, limit: 10),
            section("Scientific and societal impact", items, [.visibility, .service], context: context, limit: 10),
            unstructuredEvidenceSection(title: "Recent research evidence not yet structured", context: context, items: items, appEntries: researchEntries)
        ]
    }

    private static func generalAcademic(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        [
            header("Example Candidate - Academic CV", context: context),
            source.section("Personal Details"),
            source.section("Profile"),
            section("Education", items, [.education], context: context),
            section("Employment", items, [.employment], context: context),
            section("Research funding and grants", items, [.grant], context: context),
            section("Research output", items, [.publication], context: context),
            section("Artistic work", items, [.artisticWork], context: context),
            section("Supervision and leadership", items, [.supervision], context: context),
            section("Teaching merits", items, [.teaching], context: context),
            section("Academic service and review", items, [.service], context: context),
            section("Invited talks and visibility", items, [.talk, .visibility], context: context),
            unstructuredEvidenceSection(title: "Evidence records not yet structured", context: context, items: items, appEntries: appEntries)
        ]
    }

    private static func artFocused(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        let artEntries = appEntries.filter { entry in
            entry.category == "Artistic Output"
                || entry.title.localizedCaseInsensitiveContains("art")
                || entry.venue.localizedCaseInsensitiveContains("gallery")
        }

        return [
            header("Example Candidate - Art-Focused CV", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            section("Employment", items, [.employment], context: context, limit: 6),
            section("Artistic work", items, [.artisticWork], context: context),
            section("Artistic research and publications", items, [.publication], context: context, limit: 14),
            section("Funding and projects", items, [.grant], context: context, limit: 12),
            section("Talks and public artistic visibility", items, [.talk, .visibility], context: context, limit: 14),
            section("Service and other art-world merits", items, [.service, .other], context: context, limit: 12),
            unstructuredEvidenceSection(title: "Recent art evidence not yet structured", context: context, items: items, appEntries: artEntries)
        ]
    }

    private static func researchFocused(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        let researchEntries = appEntries.filter {
            $0.tenureDimension == "Research/artistic work" || $0.category == "Publication" || $0.category == "Funding"
        }

        return [
            header("Example Candidate - Research-Focused CV", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            source.section("Research Framing"),
            section("Employment", items, [.employment], context: context, limit: 6),
            section("Research funding and grants", items, [.grant], context: context),
            section("Research output", items, [.publication], context: context),
            section("Research supervision and leadership", items, [.supervision], context: context),
            section("Reviewer and editorial work", items, [.service], context: context, limit: 12),
            section("International talks and visibility", items, [.talk, .visibility], context: context, limit: 14),
            unstructuredEvidenceSection(title: "Recent research evidence not yet structured", context: context, items: items, appEntries: researchEntries)
        ]
    }

    private static func teachingFocused(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        let teachingEntries = appEntries.filter {
            $0.tenureDimension == "Teaching" || $0.category == "Teaching" || $0.category == "Supervision"
        }

        return [
            header("Example Candidate - Teaching-Focused CV", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            "## Teaching Profile\n\nAssistant Professor in the candidate's field and relevant programme leadership. Teaching profile spans art education, media arts, creative coding, AI and visual culture, curriculum development, teacher education, supervision, and educational leadership.",
            section("Employment", items, [.employment], context: context, limit: 6),
            section("Teaching merits", items, [.teaching], context: context),
            section("Supervision and leadership", items, [.supervision], context: context),
            section("Pedagogical and academic service", items, [.service, .education], context: context, limit: 14),
            section("Education-related visibility", items, [.talk, .visibility], context: context, limit: 10),
            unstructuredEvidenceSection(title: "Recent teaching evidence not yet structured", context: context, items: items, appEntries: teachingEntries)
        ]
    }

    private static func tenk(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        [
            header("Example Candidate - TENK-Style CV Draft", context: context),
            source.section("Personal Details"),
            section("Degrees", items, [.education], context: context),
            section("Current and previous employment", items, [.employment], context: context),
            section("Research funding and leadership", items, [.grant, .supervision], context: context),
            section("Publications and research outputs", items, [.publication], context: context),
            section("Artistic activities", items, [.artisticWork], context: context),
            section("Teaching merits and supervision", items, [.teaching, .supervision], context: context),
            section("Academic service, review, and societal impact", items, [.service, .talk, .visibility], context: context),
            unstructuredEvidenceSection(title: "Recent app-captured items to classify into TENK categories", context: context, items: items, appEntries: appEntries)
        ]
    }

    private static func threePage(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        let strongestEntries = appEntries
            .sorted { lhs, rhs in
                if lhs.cvReady != rhs.cvReady { return lhs.cvReady && !rhs.cvReady }
                return lhs.completeness.score > rhs.completeness.score
            }
            .prefix(8)

        return [
            header("Example Candidate - Three-Page CV Draft", context: context),
            source.section("Personal Details", limit: 10),
            source.section("Profile", limit: 1),
            section("Current employment", items, [.employment], context: context, limit: 4),
            section("Selected funding", items, [.grant], context: context, limit: 5),
            section("Selected research output", items, [.publication], context: context, limit: 8),
            section("Selected artistic work", items, [.artisticWork], context: context, limit: 6),
            section("Selected supervision and teaching", items, [.supervision, .teaching], context: context, limit: 8),
            section("Selected talks and impact", items, [.talk, .visibility, .service], context: context, limit: 8),
            unstructuredEvidenceSection(title: "Strongest recent evidence not yet structured", context: context, items: items, appEntries: Array(strongestEntries))
        ]
    }

    private static func tenure(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        let researchEntries = appEntries.filter { $0.tenureDimension == "Research/artistic work" }
        let teachingEntries = appEntries.filter { $0.tenureDimension == "Teaching" || $0.category == "Teaching" || $0.category == "Supervision" }
        let impactEntries = appEntries.filter { $0.tenureDimension == "Impact and service" || $0.category == "Service" || $0.category == "Visibility" }

        return [
            header("Example Candidate - Tenure CV Draft", context: context),
            source.section("Personal Details", limit: 12),
            source.section("Profile"),
            section("Research / Artistic Work", items, [.grant, .publication, .artisticWork], context: context),
            unstructuredEvidenceSection(title: "Recent research/artistic evidence not yet structured", context: context, items: items, appEntries: researchEntries),
            section("Teaching", items, [.teaching, .supervision], context: context),
            unstructuredEvidenceSection(title: "Recent teaching/supervision evidence not yet structured", context: context, items: items, appEntries: teachingEntries),
            section("Impact and Service", items, [.service, .talk, .visibility], context: context),
            unstructuredEvidenceSection(title: "Recent impact/service evidence not yet structured", context: context, items: items, appEntries: impactEntries)
        ]
    }

    private static func publicProfile(
        source: CVSource,
        items: [CVStructuredItem],
        context: CVBuildContext,
        appEntries: [EvidenceEntry]
    ) -> [String] {
        [
            header("Example Candidate - Public Profile CV", context: context),
            source.section("Personal Details", limit: 8),
            source.section("Profile", limit: 1),
            source.section("Research Framing", limit: 1),
            section("Selected work", items, [.employment, .publication, .artisticWork], context: context, limit: 10),
            section("Talks and public visibility", items, [.talk, .visibility], context: context, limit: 8),
            unstructuredEvidenceSection(title: "Recent highlights not yet structured", context: context, items: items, appEntries: Array(appEntries.prefix(6)))
        ]
    }

    private static func selectedItems(
        from items: [CVStructuredItem],
        variant: CVDraftVariant,
        rule: CVTemplateRule
    ) -> [CVStructuredItem] {
        var seen = Set<String>()

        return items
            .filter { item in
                guard belongs(item, to: variant) else { return false }
                if rule.preferVerifiedOnly {
                    return item.verified || item.sourceConfidence == "high"
                }
                return true
            }
            .sorted { lhs, rhs in
                if lhs.verified != rhs.verified { return lhs.verified && !rhs.verified }
                if confidenceRank(lhs.sourceConfidence) != confidenceRank(rhs.sourceConfidence) {
                    return confidenceRank(lhs.sourceConfidence) > confidenceRank(rhs.sourceConfidence)
                }
                if lhs.year != rhs.year { return lhs.year > rhs.year }
                return lhs.order < rhs.order
            }
            .filter { item in
                let key = normalizedKey(item)
                guard !seen.contains(key) else { return false }
                seen.insert(key)
                return true
            }
    }

    private static func section(
        _ title: String,
        _ items: [CVStructuredItem],
        _ sections: [CVStructuredSection],
        context: CVBuildContext,
        limit: Int? = nil
    ) -> String {
        let matching = items
            .filter { sections.contains($0.section) }
            .prefix(limit ?? Int.max)
            .map { line(for: $0, context: context) }
            .filter { !$0.trimmed.isEmpty }

        guard !matching.isEmpty else { return "" }
        return "## \(title)\n\n" + matching.joined(separator: "\n")
    }

    private static func line(for item: CVStructuredItem, context: CVBuildContext) -> String {
        let title = item.title.trimmed.isEmpty ? "Untitled CV item" : item.title.trimmed
        var pieces: [String] = []

        if item.section == .publication {
            let authors = item.authors.trimmed
            let year = item.year.trimmed
            if !authors.isEmpty, !year.isEmpty {
                pieces.append("\(authors) (\(year)). \(title)")
            } else if !year.isEmpty {
                pieces.append("\(year). \(title)")
            } else {
                pieces.append(title)
            }

            appendIfPresent(item.venue, to: &pieces)
            appendLabeled("Role", item.role, to: &pieces)
            appendLabeled("TENK", item.tenkClass, to: &pieces)
            appendLabeled("JUFO", item.jufoLevel, to: &pieces)
            appendLabeled("Peer review", item.peerReview, to: &pieces)
            appendLabeled("DOI", item.doi, to: &pieces)
        } else {
            appendIfPresent(item.year, to: &pieces)
            pieces.append(title)
            appendIfPresent(item.role, to: &pieces)
            appendIfPresent(item.venue, to: &pieces)
        }

        if context.options.includeSourceNotes {
            appendLabeled("Source", item.source, to: &pieces)
        }

        var line = "- " + pieces.joined(separator: " | ")
        if context.options.includeSourceConfidence {
            line += " [source: \(item.sourceConfidence.trimmed.isEmpty ? "review" : item.sourceConfidence.trimmed)]"
        }
        return line + "."
    }

    private static func unstructuredEvidenceSection(
        title: String,
        context: CVBuildContext,
        items: [CVStructuredItem],
        appEntries: [EvidenceEntry]
    ) -> String {
        let structuredKeys = Set(items.map { normalizedLoose($0.title) })
        let missingEntries = appEntries.filter { entry in
            guard context.options.includeAppEvidence else { return false }
            if context.options.onlyCVReadyEvidence, !entry.cvReady { return false }
            return !structuredKeys.contains(normalizedLoose(entry.title))
        }

        return context.recentSection(title, entries: missingEntries)
    }

    private static func belongs(_ item: CVStructuredItem, to variant: CVDraftVariant) -> Bool {
        if item.includeInTemplates.contains(variant.rawValue) {
            return true
        }

        switch variant {
        case .currentPages, .generalAcademic:
            return true
        case .cv2025Research, .researchFocused:
            return [.employment, .grant, .publication, .artisticWork, .supervision, .service, .talk, .visibility].contains(item.section)
        case .artFocused:
            return [.employment, .artisticWork, .publication, .grant, .talk, .visibility, .service, .other].contains(item.section)
        case .teachingFocused:
            return [.employment, .teaching, .supervision, .education, .service, .talk, .visibility].contains(item.section)
        case .tenk:
            return true
        case .threePage:
            return item.verified || item.sourceConfidence == "high"
        case .tenure:
            return [.grant, .publication, .artisticWork, .teaching, .supervision, .service, .talk, .visibility].contains(item.section)
        case .publicProfile:
            return item.visibility == "public" || [.employment, .publication, .artisticWork, .talk, .visibility].contains(item.section)
        }
    }

    private static func header(_ title: String, context: CVBuildContext) -> String {
        let resolvedTitle = context.candidateName.trimmed.isEmpty
            ? title
            : title.replacingOccurrences(of: "Example Candidate", with: context.candidateName.trimmed)
        var lines = ["# \(resolvedTitle)"]

        if context.options.includeDraftNote {
            lines.append("Generated as an editable draft from the structured CV database, with profile details from the CV master source and recent app evidence where needed. Review, shorten, and polish before use.")
        }

        if context.options.includeSourceNotes {
            lines.append("Source note: structured CV database, local CV master source, institutional profile/research portal, publication lists, portfolio material, and app-captured evidence.")
        }

        return lines.joined(separator: "\n\n")
    }

    private static func markdownSection(_ heading: String, in text: String) -> String {
        let lines = text.components(separatedBy: .newlines)
        guard let start = lines.firstIndex(where: { $0.trimmed == "### \(heading)" || $0.trimmed == "## \(heading)" }) else {
            return ""
        }

        var collected: [String] = []
        for line in lines.dropFirst(start + 1) {
            let trimmed = line.trimmed
            if trimmed.hasPrefix("## ") || trimmed.hasPrefix("### ") {
                break
            }
            collected.append(line)
        }

        return collected.joined(separator: "\n").trimmed
    }

    private static func firstParagraphs(from text: String, count: Int) -> String {
        text
            .components(separatedBy: "\n")
            .map(\.trimmed)
            .filter { !$0.isEmpty }
            .prefix(count)
            .joined(separator: "\n\n")
    }

    private static func appendIfPresent(_ value: String, to pieces: inout [String]) {
        let trimmed = value.trimmed
        if !trimmed.isEmpty {
            pieces.append(trimmed)
        }
    }

    private static func appendLabeled(_ label: String, _ value: String, to pieces: inout [String]) {
        let trimmed = value.trimmed
        if !trimmed.isEmpty, trimmed != "check" {
            pieces.append("\(label): \(trimmed)")
        }
    }

    private static func normalizedKey(_ item: CVStructuredItem) -> String {
        normalizedLoose([item.section.rawValue, item.year, item.title].joined(separator: "|"))
    }

    private static func normalizedLoose(_ value: String) -> String {
        value
            .lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined()
    }

    private static func confidenceRank(_ confidence: String) -> Int {
        switch confidence.lowercased() {
        case "high": 4
        case "medium": 3
        case "profile": 2
        default: 1
        }
    }
}
