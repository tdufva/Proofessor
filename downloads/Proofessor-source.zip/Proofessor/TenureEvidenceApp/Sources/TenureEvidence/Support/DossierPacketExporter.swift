import Foundation

enum DossierPacketExporter {
    static func export(
        entries: [EvidenceEntry],
        draft: String,
        variant: CVDraftVariant,
        theme: CVDraftTheme,
        workspaceURL: URL
    ) throws -> URL {
        let stamp = fileStamp.string(from: Date())
        let folder = workspaceURL
            .appendingPathComponent("09_Tenure_Application_Dossier")
            .appendingPathComponent("Packet_\(stamp)")
        let attachmentsFolder = folder.appendingPathComponent("Attachments")

        try FileManager.default.createDirectory(at: attachmentsFolder, withIntermediateDirectories: true)

        let selectedEntries = entries
            .filter { $0.cvReady || $0.completeness.score >= 80 || $0.status == "Filed" }
            .sorted { lhs, rhs in
                if lhs.tenureDimension == rhs.tenureDimension {
                    if lhs.completeness.score == rhs.completeness.score {
                        return lhs.date > rhs.date
                    }
                    return lhs.completeness.score > rhs.completeness.score
                }
                return lhs.tenureDimension < rhs.tenureDimension
            }

        try coverChecklist(entries: selectedEntries, variant: variant, theme: theme)
            .write(to: folder.appendingPathComponent("00_Cover_Checklist.md"), atomically: true, encoding: .utf8)

        try draft
            .write(to: folder.appendingPathComponent("01_CV_Draft.md"), atomically: true, encoding: .utf8)

        try evidenceIndex(entries: selectedEntries)
            .write(to: folder.appendingPathComponent("02_Evidence_Index.md"), atomically: true, encoding: .utf8)

        try copySelectedAttachments(from: selectedEntries, workspaceURL: workspaceURL, to: attachmentsFolder)

        return folder
    }

    private static func coverChecklist(entries: [EvidenceEntry], variant: CVDraftVariant, theme: CVDraftTheme) -> String {
        let dimensions = ["Research/artistic work", "Teaching", "Impact and service"]
        let dimensionLines = dimensions.map { dimension in
            let count = entries.filter { $0.tenureDimension == dimension || $0.tenureDimension == "All" }.count
            return "- \(dimension): \(count) selected evidence item(s)"
        }

        return """
        # Tenure Dossier Packet Checklist

        CV variant: \(variant.rawValue)
        CV theme: \(theme.rawValue)
        Selected evidence items: \(entries.count)

        ## Contents

        - 01_CV_Draft.md
        - 02_Evidence_Index.md
        - Attachments/

        ## Dimension Coverage

        \(dimensionLines.joined(separator: "\n"))

        ## Before Sending

        - Confirm CV length and style match the call or evaluation context.
        - Remove temporary source-confidence notes if the exported CV is final.
        - Check TENK/JUFO and DOI hints manually.
        - Confirm every selected attachment is appropriate to share.
        - Add any formal institutional forms or official templates required by HR.
        """
    }

    private static func evidenceIndex(entries: [EvidenceEntry]) -> String {
        var output = "# Evidence Index\n\n"

        for dimension in ["Research/artistic work", "Teaching", "Impact and service", "All"] {
            let matches = entries.filter { $0.tenureDimension == dimension }
            guard !matches.isEmpty else { continue }

            output += "## \(dimension)\n\n"
            output += matches.map { entry in
                let attachmentList = entry.attachments.isEmpty
                    ? "No attachments"
                    : entry.attachments.map(\.path).joined(separator: "; ")
                return "- \(entry.date) | \(entry.title) | \(entry.category) | \(entry.role) | \(entry.venue) | \(entry.completeness.score)% | \(attachmentList)"
            }
            .joined(separator: "\n")
            output += "\n\n"
        }

        return output
    }

    private static func copySelectedAttachments(
        from entries: [EvidenceEntry],
        workspaceURL: URL,
        to attachmentsFolder: URL
    ) throws {
        for entry in entries {
            let entryFolder = attachmentsFolder.appendingPathComponent(safeFileName(entry.title))
            try FileManager.default.createDirectory(at: entryFolder, withIntermediateDirectories: true)

            for attachment in entry.attachments {
                let source = workspaceURL.appendingPathComponent(attachment.path)
                guard FileManager.default.fileExists(atPath: source.path) else { continue }
                let destination = uniqueDestination(for: attachment.name, in: entryFolder)
                try FileManager.default.copyItem(at: source, to: destination)
            }
        }
    }

    private static func safeFileName(_ value: String) -> String {
        let cleaned = value
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: "_")
        return cleaned.isEmpty ? "Evidence" : String(cleaned.prefix(80))
    }

    private static func uniqueDestination(for fileName: String, in folder: URL) -> URL {
        let base = URL(fileURLWithPath: fileName).deletingPathExtension().lastPathComponent
        let ext = URL(fileURLWithPath: fileName).pathExtension
        var candidate = folder.appendingPathComponent(fileName)
        var counter = 2

        while FileManager.default.fileExists(atPath: candidate.path) {
            let nextName = ext.isEmpty ? "\(base)-\(counter)" : "\(base)-\(counter).\(ext)"
            candidate = folder.appendingPathComponent(nextName)
            counter += 1
        }

        return candidate
    }

    private static let fileStamp: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd_HHmmss"
        return formatter
    }()
}
