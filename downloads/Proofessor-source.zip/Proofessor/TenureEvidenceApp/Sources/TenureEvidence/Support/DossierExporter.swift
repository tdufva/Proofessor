import Foundation

enum DossierExporter {
    static func export(entries: [EvidenceEntry]) -> String {
        let dimensions = [
            "Research/artistic work",
            "Teaching",
            "Impact and service"
        ]

        var output = """
        # Tenure Dossier Builder

        Generated from Proofessor. Use this as a planning view, not as final prose.

        """

        for dimension in dimensions {
            let matches = entries
                .filter { entry in
                    entry.tenureDimension == dimension || entry.tenureDimension == "All" || inferredDimension(for: entry) == dimension
                }
                .sorted(by: rank)

            output += "\n## \(dimension)\n\n"

            if matches.isEmpty {
                output += "No evidence filed yet.\n"
                continue
            }

            output += "### Strongest Evidence\n\n"
            output += matches.prefix(8).map(dossierLine).joined(separator: "\n")
            output += "\n\n### Evidence Gaps\n\n"

            let gaps = matches
                .filter { !$0.completeness.missing.isEmpty }
                .prefix(8)

            if gaps.isEmpty {
                output += "- No major gaps in the current records.\n"
            } else {
                output += gaps.map { entry in
                    "- \(entry.title): missing \(entry.completeness.missing.joined(separator: ", "))."
                }
                .joined(separator: "\n")
                output += "\n"
            }
        }

        return output
    }

    private static func dossierLine(_ entry: EvidenceEntry) -> String {
        "- \(entry.date) \(entry.title) (\(entry.role), \(entry.venue)). \(entry.completeness.score)% complete."
    }

    private static func rank(_ lhs: EvidenceEntry, _ rhs: EvidenceEntry) -> Bool {
        if lhs.cvReady != rhs.cvReady {
            return lhs.cvReady && !rhs.cvReady
        }
        if lhs.completeness.score != rhs.completeness.score {
            return lhs.completeness.score > rhs.completeness.score
        }
        return lhs.date > rhs.date
    }

    private static func inferredDimension(for entry: EvidenceEntry) -> String {
        switch entry.category {
        case "Teaching", "Supervision":
            "Teaching"
        case "Service", "Visibility":
            "Impact and service"
        default:
            "Research/artistic work"
        }
    }
}
