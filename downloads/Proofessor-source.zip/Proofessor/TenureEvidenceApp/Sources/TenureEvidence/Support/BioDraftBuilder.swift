import Foundation

enum BioDraftBuilder {
    static func build(
        useCase: BioUseCase,
        lengthPreset: BioLengthPreset,
        customCharacterLimit: Int,
        entries: [EvidenceEntry],
        cvItems: [CVStructuredItem],
        sourceText: String,
        settings: ConnectorSettings,
        cvReadyOnly: Bool
    ) -> String {
        let sourceEntries = cvReadyOnly
            ? entries.filter { $0.cvReady || $0.status == "Ready for CV" || $0.status == "Filed" }
            : entries
        let sortedEntries = sourceEntries.sorted { lhs, rhs in
            if lhs.cvReady != rhs.cvReady { return lhs.cvReady && !rhs.cvReady }
            if lhs.date == rhs.date { return lhs.title < rhs.title }
            return lhs.date > rhs.date
        }

        let context = BioContext(
            name: candidateName(settings: settings, sourceText: sourceText),
            role: candidateRole(useCase: useCase, sourceText: sourceText, settings: settings),
            affiliation: settings.affiliation.trimmed,
            focus: focusPhrase(useCase: useCase, sourceText: sourceText, entries: sortedEntries, cvItems: cvItems, settings: settings),
            selectedPublications: settings.selectedPublications.trimmed,
            selectedExhibitions: settings.selectedExhibitions.trimmed,
            entries: sortedEntries,
            cvItems: cvItems,
            sourceText: sourceText,
            useCase: useCase
        )

        let draft = paragraphs(for: context).joined(separator: "\n\n")

        if lengthPreset == .custom {
            return fitToCharacters(draft, limit: customCharacterLimit)
        }

        if let targetWords = lengthPreset.targetWords {
            return fitToWords(draft, targetWords: targetWords)
        }

        return draft
    }

    static func wordCount(_ text: String) -> Int {
        text.split(whereSeparator: \.isWhitespace).count
    }

    private struct BioContext {
        var name: String
        var role: String
        var affiliation: String
        var focus: String
        var selectedPublications: String
        var selectedExhibitions: String
        var entries: [EvidenceEntry]
        var cvItems: [CVStructuredItem]
        var sourceText: String
        var useCase: BioUseCase

        var lastName: String {
            name.split(separator: " ").last.map(String.init) ?? name
        }
    }

    private static func paragraphs(for context: BioContext) -> [String] {
        switch context.useCase {
        case .speakerIntro:
            return speakerIntro(context)
        case .publicProfile:
            return publicProfile(context)
        case .artistic:
            return artisticBio(context)
        case .research:
            return researchBio(context)
        case .teaching:
            return teachingBio(context)
        case .academic:
            return academicBio(context)
        }
    }

    private static func academicBio(_ context: BioContext) -> [String] {
        let selected = selectedOutputSentence(context, preferredCategories: ["Publication", "Artistic Output", "Funding", "Talk"])
        return [
            "\(context.name) is \(article(for: context.role)) \(context.role) whose work focuses on \(context.focus). \(context.lastName)'s academic profile brings together research or artistic work, teaching, supervision, and service in ways that can be adapted for university websites, conference programmes, grant applications, and public introductions.",
            "\(selected) \(evidenceSummary(context.entries)) The strongest version should keep only verifiable examples: publications, exhibitions, grants, invited talks, public programmes, course feedback, supervision records, and other sources that can be traced back to a file or link.",
            "\(teachingSentence(context)) \(serviceSentence(context)) This paragraph gives the bio the usual academic shape: it moves from role and field to concrete achievements, then to teaching and contribution beyond the individual research agenda.",
            "For a longer biography, \(context.lastName) can add a current project, selected collaborators, major outputs, and a short account of how the work matters to students, peers, institutions, or publics. For a shorter version, keep the first sentence, one sentence of evidence-backed achievements, and one sentence about teaching or impact."
        ]
    }

    private static func artisticBio(_ context: BioContext) -> [String] {
        let selected = selectedOutputSentence(context, preferredCategories: ["Artistic Output", "Talk", "Visibility", "Publication"])
        return [
            "\(context.name) is \(article(for: context.role)) \(context.role) working across \(context.focus). This artistic biography foregrounds practice, research, public presentation, and the contexts in which the work circulates.",
            "\(selected) When adapting the bio for exhibitions, catalogues, residencies, festivals, or public programmes, lead with the clearest artistic contribution and then name the research, pedagogical, or cultural questions that frame the work.",
            "\(teachingSentence(context)) \(serviceSentence(context)) A strong artistic academic bio usually avoids exhaustive lists and instead chooses a few documented projects, exhibitions, publications, grants, or talks that show quality, recognition, and relevance.",
            "The final version should stay concrete: describe the kind of work, the arenas where it has been shown or discussed, the communities it addresses, and the evidence that supports those claims."
        ]
    }

    private static func researchBio(_ context: BioContext) -> [String] {
        let selected = selectedOutputSentence(context, preferredCategories: ["Publication", "Funding", "Supervision", "Talk"])
        return [
            "\(context.name) is \(article(for: context.role)) \(context.role) whose research focuses on \(context.focus). This version starts with the research agenda, then moves quickly to publications, projects, funding, supervision, and collaborations.",
            "\(selected) \(publicationSentence(context)) \(fundingSentence(context))",
            "\(teachingSentence(context)) \(serviceSentence(context)) The research-focused bio should still include teaching or service when those activities clarify research leadership, doctoral training, public impact, or contribution to the field.",
            "For grant and collaborator audiences, keep the language precise, active, and evidence-backed: name the topic, methods or materials, selected outputs, and the wider scholarly or societal question the work addresses."
        ]
    }

    private static func teachingBio(_ context: BioContext) -> [String] {
        let selected = selectedOutputSentence(context, preferredCategories: ["Teaching", "Supervision", "Service", "Publication"])
        return [
            "\(context.name) is \(article(for: context.role)) \(context.role) whose teaching and supervision are connected to \(context.focus). This version foregrounds courses, pedagogy, curriculum work, feedback, supervision, and educational leadership.",
            "\(selected) \(teachingSentence(context))",
            "\(researchBridgeSentence(context)) \(serviceSentence(context)) A teaching-focused academic bio normally works best when it names what the person teaches, how students or programmes benefit, and how the teaching connects to research, artistic practice, or the discipline.",
            "For a concise version, keep one sentence on role and field, one sentence on teaching responsibilities or development work, and one sentence on selected evidence such as course feedback, supervision, curriculum leadership, pedagogical training, or teaching-related publications."
        ]
    }

    private static func publicProfile(_ context: BioContext) -> [String] {
        let selected = selectedOutputSentence(context, preferredCategories: ["Visibility", "Talk", "Artistic Output", "Publication", "Teaching"])
        return [
            "\(context.name) is \(article(for: context.role)) \(context.role) working on \(context.focus). This public profile version is written for readers who need a clear sense of the work without academic CV detail.",
            "\(selected) \(teachingSentence(context))",
            "\(serviceSentence(context)) The public version should keep specialist terms only when they are central to the work, and it should favour vivid, verifiable examples over lists."
        ]
    }

    private static func speakerIntro(_ context: BioContext) -> [String] {
        let selected = selectedOutputSentence(context, preferredCategories: ["Talk", "Publication", "Artistic Output", "Teaching", "Funding"])
        return [
            "\(context.name) is \(article(for: context.role)) \(context.role) whose work focuses on \(context.focus). \(selected) \(context.name) brings together research, teaching, and public engagement in work that is documented in the evidence record."
        ]
    }

    private static func selectedOutputSentence(_ context: BioContext, preferredCategories: [String]) -> String {
        if preferredCategories.contains("Publication"), !context.selectedPublications.trimmed.isEmpty {
            return "Selected publications include \(inlineList(from: context.selectedPublications))."
        }

        if preferredCategories.contains("Artistic Output"), !context.selectedExhibitions.trimmed.isEmpty {
            return "Selected artistic projects and exhibitions include \(inlineList(from: context.selectedExhibitions))."
        }

        let selected = preferredCategories
            .flatMap { category in context.entries.filter { $0.category == category }.prefix(2) }
            .removingDuplicates()
            .prefix(4)

        guard !selected.isEmpty else {
            return "The current evidence set does not yet contain enough verified highlights, so this draft uses broad academic wording that should be edited once stronger proof is added."
        }

        let titles = selected
            .map { entry in entry.title.trimmed.isEmpty ? entry.eventType : entry.title }
            .filter { !$0.trimmed.isEmpty }
            .prefix(3)
            .joined(separator: "; ")

        return "Selected evidence points to work such as \(titles)."
    }

    private static func publicationSentence(_ context: BioContext) -> String {
        let count = context.entries.filter { $0.category == "Publication" }.count
        guard count > 0 else {
            return "Add publication records, DOI metadata, or BibTeX imports to make this paragraph more specific."
        }
        return "The evidence database currently includes \(count) publication or research-output \(count == 1 ? "record" : "records"), which can be used to name selected outputs rather than relying on generic claims."
    }

    private static func fundingSentence(_ context: BioContext) -> String {
        let count = context.entries.filter { $0.category == "Funding" }.count
        guard count > 0 else {
            return "If competitive funding is important for this audience, add the funder, role, amount, decision letter, and project source before using the claim."
        }
        return "It also includes \(count) funding \(count == 1 ? "record" : "records"), useful for showing research independence, project leadership, and the capacity to attract external support."
    }

    private static func teachingSentence(_ context: BioContext) -> String {
        let teaching = context.entries.filter { $0.category == "Teaching" || $0.category == "Supervision" }
        guard !teaching.isEmpty else {
            return "\(context.lastName)'s teaching, supervision, and curriculum work should be added here once the relevant evidence is reviewed."
        }
        let examples = teaching.prefix(2).map { $0.title.trimmed.isEmpty ? $0.eventType : $0.title }.joined(separator: " and ")
        return "\(context.lastName)'s teaching and supervision evidence includes \(examples), giving the bio a concrete teaching dimension."
    }

    private static func serviceSentence(_ context: BioContext) -> String {
        let service = context.entries.filter { ["Service", "Visibility", "Talk"].contains($0.category) }
        guard !service.isEmpty else {
            return "Impact, service, and public engagement can be added with committee roles, invited talks, media, expert work, or field-level service."
        }
        let examples = service.prefix(2).map { $0.title.trimmed.isEmpty ? $0.eventType : $0.title }.joined(separator: " and ")
        return "Impact and service are represented through \(examples), which can support a concise statement about contribution beyond the immediate institution."
    }

    private static func researchBridgeSentence(_ context: BioContext) -> String {
        let researchCount = context.entries.filter { ["Publication", "Funding", "Artistic Output"].contains($0.category) }.count
        guard researchCount > 0 else {
            return "The draft can be strengthened by linking teaching claims to reviewed research, artistic, or publication evidence."
        }
        return "The teaching profile is connected to \(researchCount) reviewed research, artistic, publication, or funding \(researchCount == 1 ? "item" : "items"), helping the bio read as an integrated academic profile."
    }

    private static func evidenceSummary(_ entries: [EvidenceEntry]) -> String {
        let grouped = Dictionary(grouping: entries, by: \.category)
        let parts = ["Publication", "Artistic Output", "Funding", "Teaching", "Supervision", "Service", "Visibility", "Talk"]
            .compactMap { category -> String? in
                guard let count = grouped[category]?.count, count > 0 else { return nil }
                return "\(count) \(category.lowercased())"
            }
            .prefix(5)
        return parts.isEmpty ? "No reviewed evidence records were available yet." : "The reviewed material currently includes \(parts.joined(separator: ", "))."
    }

    private static func candidateName(settings: ConnectorSettings, sourceText: String) -> String {
        if !settings.publicDisplayName.trimmed.isEmpty {
            return settings.publicDisplayName.trimmed
        }

        for line in sourceText.components(separatedBy: .newlines).map(\.trimmed).prefix(18) {
            let words = line.split(separator: " ")
            if words.count >= 2,
               words.count <= 5,
               line.count <= 70,
               !line.localizedCaseInsensitiveContains("curriculum"),
               !line.localizedCaseInsensitiveContains("profile"),
               !line.localizedCaseInsensitiveContains("university") {
                return line
            }
        }

        return "The candidate"
    }

    private static func candidateRole(useCase: BioUseCase, sourceText: String, settings: ConnectorSettings) -> String {
        if !settings.profileTitle.trimmed.isEmpty {
            return settings.profileTitle.trimmed
        }

        let lines = sourceText.components(separatedBy: .newlines).map(\.trimmed).filter { !$0.isEmpty }
        let roleHints = ["assistant professor", "associate professor", "professor", "lecturer", "researcher", "postdoctoral", "artist", "designer", "curator", "teacher"]
        for line in lines.prefix(80) {
            let lower = line.lowercased()
            if roleHints.contains(where: { lower.contains($0) }) {
                return cleanRole(line)
            }
        }

        switch useCase {
        case .artistic:
            return "artist-researcher"
        case .teaching:
            return "academic educator"
        case .publicProfile:
            return "researcher and educator"
        default:
            return "academic researcher"
        }
    }

    private static func focusPhrase(
        useCase: BioUseCase,
        sourceText: String,
        entries: [EvidenceEntry],
        cvItems: [CVStructuredItem],
        settings: ConnectorSettings
    ) -> String {
        switch useCase {
        case .artistic:
            if !settings.artisticThemes.trimmed.isEmpty { return settings.artisticThemes.trimmed }
        case .teaching:
            if !settings.teachingThemes.trimmed.isEmpty { return settings.teachingThemes.trimmed }
        case .research:
            if !settings.researchThemes.trimmed.isEmpty { return settings.researchThemes.trimmed }
        case .academic, .publicProfile, .speakerIntro:
            let combined = [settings.researchThemes, settings.artisticThemes, settings.teachingThemes]
                .map(\.trimmed)
                .filter { !$0.isEmpty }
                .prefix(3)
                .joined(separator: "; ")
            if !combined.isEmpty { return combined }
        }

        if let labelled = labelledValue(in: sourceText, keys: ["research interests", "research focus", "artistic focus", "teaching interests", "keywords"]) {
            return labelled
        }

        let titles = (entries.map(\.title) + cvItems.map(\.title))
            .map(\.trimmed)
            .filter { !$0.isEmpty && $0.count <= 100 }
            .prefix(3)

        if !titles.isEmpty {
            return titles.joined(separator: ", ")
        }

        switch useCase {
        case .academic:
            return "research, teaching, and academic service"
        case .artistic:
            return "artistic practice, artistic research, and public cultural work"
        case .research:
            return "research questions, publications, collaborations, and funded projects"
        case .teaching:
            return "teaching, supervision, curriculum development, and pedagogy"
        case .publicProfile:
            return "research, creative work, teaching, and public engagement"
        case .speakerIntro:
            return "research, teaching, and public-facing academic work"
        }
    }

    private static func labelledValue(in text: String, keys: [String]) -> String? {
        let lines = text.components(separatedBy: .newlines).map(\.trimmed)
        for line in lines {
            let lower = line.lowercased()
            for key in keys {
                let prefix = "\(key):"
                if lower.hasPrefix(prefix) {
                    let value = String(line.dropFirst(prefix.count)).trimmed
                    if !value.isEmpty { return value }
                }
            }
        }
        return nil
    }

    private static func fitToWords(_ text: String, targetWords: Int) -> String {
        let maxWords = Int(Double(targetWords) * 1.08)
        guard wordCount(text) > maxWords else { return text }

        var output: [String] = []
        var count = 0
        for sentence in sentences(from: text) {
            let sentenceCount = wordCount(sentence)
            guard count + sentenceCount <= maxWords || output.isEmpty else { break }
            output.append(sentence)
            count += sentenceCount
        }
        return output.joined(separator: " ").trimmed
    }

    private static func fitToCharacters(_ text: String, limit: Int) -> String {
        let limit = max(160, limit)
        guard text.count > limit else { return text }

        var output = ""
        for sentence in sentences(from: text) {
            let candidate = output.isEmpty ? sentence : output + " " + sentence
            guard candidate.count <= limit || output.isEmpty else { break }
            output = candidate
        }

        if output.count <= limit, !output.isEmpty {
            return output.trimmed
        }

        return String(text.prefix(limit)).trimmed
    }

    private static func sentences(from text: String) -> [String] {
        let normalized = text.replacingOccurrences(of: "\n\n", with: " ")
        guard let regex = try? NSRegularExpression(pattern: #"(?<=[.!?])\s+"#) else {
            return normalized.components(separatedBy: ".").map(\.trimmed).filter { !$0.isEmpty }
        }

        let nsRange = NSRange(normalized.startIndex..<normalized.endIndex, in: normalized)
        var start = normalized.startIndex
        var result: [String] = []

        for match in regex.matches(in: normalized, range: nsRange) {
            guard let range = Range(match.range, in: normalized) else { continue }
            let sentence = String(normalized[start..<range.lowerBound]).trimmed
            if !sentence.isEmpty {
                result.append(sentence)
            }
            start = range.upperBound
        }

        let tail = String(normalized[start...]).trimmed
        if !tail.isEmpty {
            result.append(tail)
        }

        return result
    }

    private static func cleanRole(_ role: String) -> String {
        role
            .replacingOccurrences(of: #"^\s*[-•]\s*"#, with: "", options: .regularExpression)
            .trimmed
    }

    private static func article(for phrase: String) -> String {
        guard let firstCharacter = phrase.trimmed.first else { return "a" }
        let first = String(firstCharacter).lowercased()
        return ["a", "e", "i", "o", "u"].contains(first) ? "an" : "a"
    }

    private static func inlineList(from text: String) -> String {
        let lines = text
            .components(separatedBy: .newlines)
            .map { line in
                line
                    .replacingOccurrences(of: #"^\s*[-•]\s*"#, with: "", options: .regularExpression)
                    .trimmed
            }
            .filter { !$0.isEmpty }
            .prefix(3)

        return lines.joined(separator: "; ")
    }
}

private extension Array where Element == EvidenceEntry {
    func removingDuplicates() -> [EvidenceEntry] {
        var seen = Set<UUID>()
        return filter { seen.insert($0.id).inserted }
    }
}
