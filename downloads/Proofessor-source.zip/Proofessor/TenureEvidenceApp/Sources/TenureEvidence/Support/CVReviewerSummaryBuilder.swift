import Foundation

enum CVReviewerSummaryBuilder {
    static func summary(draft: String, entries: [EvidenceEntry], cvItems: [CVStructuredItem]) -> CVReviewerSummary {
        let research = strongest(entries) {
            $0.tenureDimension == "Research/artistic work"
                || $0.category == "Publication"
                || $0.category == "Artistic Output"
                || $0.category == "Funding"
        }

        let teaching = strongest(entries) {
            $0.tenureDimension == "Teaching"
                || $0.category == "Teaching"
                || $0.category == "Supervision"
        }

        let impact = strongest(entries) {
            $0.tenureDimension == "Impact and service"
                || $0.category == "Service"
                || $0.category == "Visibility"
                || $0.category == "Talk"
        }

        let missing = entries
            .filter { !$0.completeness.missing.isEmpty || !$0.cvReady }
            .sorted {
                if $0.completeness.score == $1.completeness.score {
                    return $0.date > $1.date
                }
                return $0.completeness.score < $1.completeness.score
            }
            .prefix(8)

        return CVReviewerSummary(
            researchHighlights: Array(research.prefix(5)),
            teachingHighlights: Array(teaching.prefix(5)),
            impactHighlights: Array(impact.prefix(5)),
            missingEvidence: Array(missing),
            weakLines: weakLines(in: draft, cvItems: cvItems)
        )
    }

    private static func strongest(
        _ entries: [EvidenceEntry],
        matching predicate: (EvidenceEntry) -> Bool
    ) -> [EvidenceEntry] {
        entries
            .filter(predicate)
            .sorted { lhs, rhs in
                if lhs.cvReady != rhs.cvReady { return lhs.cvReady && !rhs.cvReady }
                if lhs.completeness.score != rhs.completeness.score {
                    return lhs.completeness.score > rhs.completeness.score
                }
                return lhs.date > rhs.date
            }
    }

    private static func weakLines(in draft: String, cvItems: [CVStructuredItem]) -> [String] {
        var lines = draft
            .components(separatedBy: .newlines)
            .map(\.trimmed)
            .filter { line in
                let lower = line.lowercased()
                return !line.isEmpty
                    && !line.hasPrefix("#")
                    && (
                        lower.contains("[source: review]")
                            || lower.contains("review before")
                            || lower.contains("check")
                            || lower.contains("missing")
                            || lower.contains("role to check")
                    )
            }

        let uncertainItems = cvItems
            .filter { !$0.verified || $0.sourceConfidence == "review" || $0.peerReview == "check" || $0.jufoLevel == "check" }
            .map { item in
                "\(item.section.rawValue): \(item.title)"
            }

        lines.append(contentsOf: uncertainItems)
        return Array(lines.prefix(12))
    }
}
