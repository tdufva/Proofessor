import Foundation

enum CVHealthReportBuilder {
    static func report(
        draft: String,
        entries: [EvidenceEntry],
        cvItems: [CVStructuredItem],
        theme: CVDraftTheme,
        variant: CVDraftVariant
    ) -> CVHealthReport {
        let publications = cvItems.filter { $0.section == .publication }
        let layout = CVDocumentExporter.layoutReport(for: draft, theme: theme)

        return CVHealthReport(metrics: [
            publicationReadiness(publications: publications, entries: entries),
            tenureAlignment(entries: entries, cvItems: cvItems),
            teachingStrength(entries: entries, cvItems: cvItems),
            internationalVisibility(entries: entries, cvItems: cvItems),
            sourceReliability(cvItems: cvItems, draft: draft),
            threePageFit(pageCount: layout.pageCount, variant: variant)
        ])
    }

    private static func publicationReadiness(publications: [CVStructuredItem], entries: [EvidenceEntry]) -> CVHealthMetric {
        let fallbackCount = entries.filter { $0.category == "Publication" }.count
        let count = max(publications.count, fallbackCount)
        guard count > 0 else {
            return CVHealthMetric(title: "Publication readiness", score: 20, note: "No structured publications yet.")
        }

        let ready = publications.filter { item in
            item.verified
                && !item.title.trimmed.isEmpty
                && item.peerReview != "check"
                && item.peerReview != "not stated"
                && item.jufoLevel != "check"
        }
        let score = publications.isEmpty ? 45 : Int((Double(ready.count) / Double(publications.count) * 100).rounded())
        return CVHealthMetric(
            title: "Publication readiness",
            score: score.clampedHealthScore,
            note: "\(ready.count) of \(publications.count) structured publication(s) verified with peer-review and JUFO cleanup."
        )
    }

    private static func tenureAlignment(entries: [EvidenceEntry], cvItems: [CVStructuredItem]) -> CVHealthMetric {
        let dimensions = [
            "Research/artistic work": entries.contains { $0.tenureDimension == "Research/artistic work" || $0.category == "Publication" || $0.category == "Artistic Output" },
            "Teaching": entries.contains { $0.tenureDimension == "Teaching" || $0.category == "Teaching" || $0.category == "Supervision" },
            "Impact and service": entries.contains { $0.tenureDimension == "Impact and service" || $0.category == "Service" || $0.category == "Visibility" }
        ]
        let represented = dimensions.values.filter { $0 }.count
        let verifiedStructured = cvItems.filter { $0.verified }.count
        let score = represented * 25 + min(25, verifiedStructured * 2)
        return CVHealthMetric(
            title: "Tenure alignment",
            score: score.clampedHealthScore,
            note: "\(represented) of 3 tenure dimensions have evidence; \(verifiedStructured) structured item(s) are verified."
        )
    }

    private static func teachingStrength(entries: [EvidenceEntry], cvItems: [CVStructuredItem]) -> CVHealthMetric {
        let teachingEntries = entries.filter { $0.category == "Teaching" || $0.category == "Supervision" || $0.tenureDimension == "Teaching" }
        let teachingItems = cvItems.filter { $0.section == .teaching || $0.section == .supervision }
        let ready = teachingEntries.filter(\.cvReady).count + teachingItems.filter(\.verified).count
        let score = min(100, teachingEntries.count * 10 + teachingItems.count * 8 + ready * 8)
        return CVHealthMetric(
            title: "Teaching evidence strength",
            score: score.clampedHealthScore,
            note: "\(teachingEntries.count) evidence record(s), \(teachingItems.count) structured teaching/supervision item(s), \(ready) ready or verified."
        )
    }

    private static func internationalVisibility(entries: [EvidenceEntry], cvItems: [CVStructuredItem]) -> CVHealthMetric {
        let terms = ["international", "keynote", "invited", "conference", "university", "europe", "eu", "abroad"]
        let visibleEntries = entries.filter { entry in
            let text = [entry.title, entry.eventType, entry.role, entry.venue, entry.notes].joined(separator: " ").lowercased()
            return terms.contains { text.contains($0) }
        }
        let visibleItems = cvItems.filter { item in
            let text = [item.title, item.role, item.venue, item.notes].joined(separator: " ").lowercased()
            return terms.contains { text.contains($0) }
        }
        let score = min(100, visibleEntries.count * 8 + visibleItems.count * 5)
        return CVHealthMetric(
            title: "International visibility",
            score: score.clampedHealthScore,
            note: "\(visibleEntries.count) evidence record(s) and \(visibleItems.count) structured CV item(s) look internationally visible."
        )
    }

    private static func sourceReliability(cvItems: [CVStructuredItem], draft: String) -> CVHealthMetric {
        guard !cvItems.isEmpty else {
            let reviewBadges = draft.components(separatedBy: "[source: review]").count - 1
            return CVHealthMetric(
                title: "Source reliability",
                score: reviewBadges == 0 ? 55 : 35,
                note: "Structured database is empty; draft has \(max(0, reviewBadges)) review badge(s)."
            )
        }

        let reliable = cvItems.filter { $0.verified || $0.sourceConfidence == "high" || $0.sourceConfidence == "medium" }.count
        let score = Int((Double(reliable) / Double(cvItems.count) * 100).rounded())
        return CVHealthMetric(
            title: "Source reliability",
            score: score.clampedHealthScore,
            note: "\(reliable) of \(cvItems.count) structured item(s) are verified or medium/high confidence."
        )
    }

    private static func threePageFit(pageCount: Int, variant: CVDraftVariant) -> CVHealthMetric {
        let score: Int
        if pageCount == 0 {
            score = 0
        } else if pageCount <= 3 {
            score = 100
        } else {
            score = max(20, 100 - ((pageCount - 3) * 20))
        }

        let note = variant == .threePage
            ? "\(pageCount) rendered page(s) for the three-page template."
            : "\(pageCount) rendered page(s); use this as a quick length warning."

        return CVHealthMetric(title: "Three-page fit", score: score.clampedHealthScore, note: note)
    }
}

private extension Int {
    var clampedHealthScore: Int {
        Swift.min(100, Swift.max(0, self))
    }
}
