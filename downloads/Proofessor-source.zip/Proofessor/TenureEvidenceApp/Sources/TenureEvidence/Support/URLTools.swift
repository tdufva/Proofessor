import Foundation

enum URLTools {
    static func extractURLs(from text: String) -> [URL] {
        guard let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) else {
            return []
        }

        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        let urls = detector.matches(in: text, range: range).compactMap(\.url)
        var seen = Set<String>()

        return urls.filter { url in
            let key = url.absoluteString
            guard !seen.contains(key) else { return false }
            seen.insert(key)
            return true
        }
    }

    static func safeFileStem(for url: URL) -> String {
        let host = url.host ?? "source"
        let path = url.pathComponents
            .filter { $0 != "/" }
            .suffix(2)
            .joined(separator: "-")
        let raw = path.isEmpty ? host : "\(host)-\(path)"
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))
        return raw.unicodeScalars.map { allowed.contains($0) ? String($0) : "-" }
            .joined()
            .trimmingCharacters(in: CharacterSet(charactersIn: "-"))
    }
}
