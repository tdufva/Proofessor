import Foundation

struct ProfileLink: Identifiable, Hashable {
    var id: String { title }
    var title: String
    var url: URL
    var systemImage: String
    var snapshotEligible: Bool = true

    static func links(from settings: ConnectorSettings) -> [ProfileLink] {
        var links: [ProfileLink] = []

        append("Institutional research profile", settings.acrisProfileURL, "building.columns", to: &links)
        append("Google Scholar", settings.googleScholarURL, "graduationcap", to: &links)
        append("ORCID", settings.orcidURL, "person.crop.circle.badge.checkmark", to: &links)
        append("Institutional people page", settings.aaltoPeopleURL, "person.text.rectangle", to: &links)
        append("LinkedIn", settings.linkedInURL, "person.crop.square", to: &links)
        append("Social Media", settings.socialMediaURL, "at", to: &links)
        append("Website", settings.websiteURL, "globe", to: &links)

        let name = settings.publicDisplayName.trimmed
        if !name.isEmpty,
           let searchURL = URL(string: "https://www.google.com/search?q=\(searchQuery(for: name))") {
            links.append(
                ProfileLink(
                    title: "Public Web Search",
                    url: searchURL,
                    systemImage: "magnifyingglass",
                    snapshotEligible: false
                )
            )
        }

        return links
    }

    private static func append(_ title: String, _ rawURL: String, _ systemImage: String, to links: inout [ProfileLink]) {
        guard let url = URL(string: rawURL.trimmed), !rawURL.trimmed.isEmpty else { return }
        links.append(ProfileLink(title: title, url: url, systemImage: systemImage))
    }

    private static func searchQuery(for name: String) -> String {
        "\"\(name)\" 2025 2026 lecture keynote presentation"
            .addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? name
    }
}
