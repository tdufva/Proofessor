import Foundation

struct EvidenceAttachment: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String = ""
    var path: String = ""

    init(id: UUID = UUID(), name: String = "", path: String = "") {
        self.id = id
        self.name = name
        self.path = path
    }
}

struct EvidenceCompletenessReport: Hashable {
    var score: Int
    var missing: [String]

    var label: String {
        if score >= 90 { return "Ready evidence" }
        if score >= 70 { return "Nearly complete" }
        if score >= 45 { return "Needs attention" }
        return "Proof needed"
    }

    var displayLabel: String {
        if score >= 90 { return "Ready to use" }
        if score >= 70 { return "Almost ready" }
        if score >= 45 { return "Check this" }
        return "Proof needed"
    }
}

struct EvidenceEntry: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var date: String = ""
    var category: String = "Other"
    var eventType: String = ""
    var title: String = ""
    var role: String = ""
    var venue: String = ""
    var tenureDimension: String = "All"
    var status: String = "Needs review"
    var source: String = ""
    var notes: String = ""
    var cvReady: Bool = false
    var attachments: [EvidenceAttachment] = []

    var displaySubtitle: String {
        [date, category, role, venue]
            .map(\.trimmed)
            .filter { !$0.isEmpty }
            .joined(separator: " - ")
    }

    var displayStatus: String {
        EvidenceOptions.displayStatus(for: status)
    }

    var completeness: EvidenceCompletenessReport {
        var missing: [String] = []
        if date.trimmed.isEmpty { missing.append("date") }
        if title.trimmed.isEmpty || title == "Untitled evidence" { missing.append("clear title") }
        if category.trimmed.isEmpty || category == "Other" { missing.append("category") }
        if eventType.trimmed.isEmpty { missing.append("type") }
        if role.trimmed.isEmpty { missing.append("role") }
        if venue.trimmed.isEmpty { missing.append("venue / host") }
        if tenureDimension.trimmed.isEmpty { missing.append("tenure dimension") }
        if source.trimmed.isEmpty { missing.append("source") }
        if notes.trimmed.isEmpty { missing.append("notes") }
        if attachments.isEmpty && !source.localizedCaseInsensitiveContains("http") && !notes.localizedCaseInsensitiveContains("http") {
            missing.append("proof file or source URL")
        }

        let total = 10
        let present = max(0, total - missing.count)
        var score = Int((Double(present) / Double(total) * 100).rounded())
        if cvReady { score = max(score, 80) }
        if status == "Filed" { score = max(score, 90) }
        return EvidenceCompletenessReport(score: min(score, 100), missing: missing)
    }

    init(
        id: UUID = UUID(),
        date: String = "",
        category: String = "Other",
        eventType: String = "",
        title: String = "",
        role: String = "",
        venue: String = "",
        tenureDimension: String = "All",
        status: String = "Needs review",
        source: String = "",
        notes: String = "",
        cvReady: Bool = false,
        attachments: [EvidenceAttachment] = []
    ) {
        self.id = id
        self.date = date
        self.category = category
        self.eventType = eventType
        self.title = title
        self.role = role
        self.venue = venue
        self.tenureDimension = tenureDimension
        self.status = status
        self.source = source
        self.notes = notes
        self.cvReady = cvReady
        self.attachments = attachments
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        date = try container.decodeIfPresent(String.self, forKey: .date) ?? ""
        category = try container.decodeIfPresent(String.self, forKey: .category) ?? "Other"
        eventType = try container.decodeIfPresent(String.self, forKey: .eventType) ?? ""
        title = try container.decodeIfPresent(String.self, forKey: .title) ?? ""
        role = try container.decodeIfPresent(String.self, forKey: .role) ?? ""
        venue = try container.decodeIfPresent(String.self, forKey: .venue) ?? ""
        tenureDimension = try container.decodeIfPresent(String.self, forKey: .tenureDimension) ?? "All"
        status = try container.decodeIfPresent(String.self, forKey: .status) ?? "Needs review"
        source = try container.decodeIfPresent(String.self, forKey: .source) ?? ""
        notes = try container.decodeIfPresent(String.self, forKey: .notes) ?? ""
        cvReady = try container.decodeIfPresent(Bool.self, forKey: .cvReady) ?? false
        attachments = try container.decodeIfPresent([EvidenceAttachment].self, forKey: .attachments) ?? []
    }
}

enum EvidenceOptions {
    static let categories = [
        "Talk",
        "Publication",
        "Artistic Output",
        "Funding",
        "Teaching",
        "Supervision",
        "Service",
        "Visibility",
        "Other"
    ]

    static let statuses = [
        "Needs review",
        "Needs confirmation",
        "Evidence missing",
        "Ready for CV",
        "Filed",
        "Ignored"
    ]

    static func displayStatus(for status: String) -> String {
        switch status {
        case "Needs review", "Needs confirmation":
            "Check this"
        case "Evidence missing":
            "Proof needed"
        case "Ready for CV":
            "Ready to use"
        default:
            status
        }
    }

    static let dimensions = [
        "Research/artistic work",
        "Teaching",
        "Impact and service",
        "All"
    ]
}
