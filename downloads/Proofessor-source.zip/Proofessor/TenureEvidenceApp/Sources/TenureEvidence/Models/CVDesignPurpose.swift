import Foundation

enum CVDesignPurpose: String, CaseIterable, Identifiable {
    case aaltoTenkFormal = "Aalto/TENK formal CV"
    case elegantAcademic = "Elegant academic CV"
    case researchFocused = "Research-focused CV"
    case artisticPortfolio = "Artistic portfolio CV"
    case teachingFocused = "Teaching-focused CV"
    case compactTwoPage = "2-page compact CV"
    case publicProfile = "Website/public profile CV"

    var id: String { rawValue }

    var variant: CVDraftVariant {
        switch self {
        case .aaltoTenkFormal:
            .tenk
        case .elegantAcademic:
            .generalAcademic
        case .researchFocused:
            .researchFocused
        case .artisticPortfolio:
            .artFocused
        case .teachingFocused:
            .teachingFocused
        case .compactTwoPage:
            .threePage
        case .publicProfile:
            .publicProfile
        }
    }

    var theme: CVDraftTheme {
        switch self {
        case .aaltoTenkFormal:
            .tenkFormal
        case .elegantAcademic:
            .aaltoClean
        case .researchFocused:
            .researchBrief
        case .artisticPortfolio:
            .artPortfolio
        case .teachingFocused:
            .aaltoClean
        case .compactTwoPage:
            .compact
        case .publicProfile:
            .publicProfile
        }
    }

    var options: CVBuildOptions {
        var options = CVBuildOptions()
        switch self {
        case .aaltoTenkFormal:
            options.includeSourceNotes = false
            options.includeDraftNote = false
            options.includeSourceConfidence = false
            options.finalCleanMode = true
        case .elegantAcademic:
            options.includeDraftNote = true
            options.includeSourceConfidence = true
        case .researchFocused:
            options.includeDraftNote = true
            options.includeSourceConfidence = true
        case .artisticPortfolio:
            options.onlyCVReadyEvidence = false
            options.compactBullets = false
            options.includeDraftNote = true
        case .teachingFocused:
            options.includeDraftNote = true
            options.includeSourceConfidence = true
        case .compactTwoPage:
            options.onlyCVReadyEvidence = true
            options.compactBullets = true
            options.includeSourceNotes = false
            options.includeDraftNote = false
            options.includeSourceConfidence = false
            options.finalCleanMode = true
        case .publicProfile:
            options.compactBullets = true
            options.includeSourceNotes = false
            options.includeDraftNote = false
            options.includeSourceConfidence = false
            options.finalCleanMode = true
        }
        return options
    }

    var systemImage: String {
        switch self {
        case .aaltoTenkFormal:
            "building.columns"
        case .elegantAcademic:
            "doc.text"
        case .researchFocused:
            "magnifyingglass"
        case .artisticPortfolio:
            "paintpalette"
        case .teachingFocused:
            "graduationcap"
        case .compactTwoPage:
            "rectangle.compress.vertical"
        case .publicProfile:
            "person.text.rectangle"
        }
    }

    var shortHint: String {
        switch self {
        case .aaltoTenkFormal:
            "Plain, formal, evaluator-safe."
        case .elegantAcademic:
            "Balanced research, teaching, service."
        case .researchFocused:
            "Publications, grants, profile."
        case .artisticPortfolio:
            "Projects, exhibitions, practice."
        case .teachingFocused:
            "Courses, supervision, pedagogy."
        case .compactTwoPage:
            "Strongest verified material only."
        case .publicProfile:
            "Readable web/profile version."
        }
    }

    var whySuggested: String {
        switch self {
        case .aaltoTenkFormal:
            "Best when the reader expects Finnish formal CV categories and conservative typography."
        case .elegantAcademic:
            "Best as the default academic CV because it keeps the whole profile visible without becoming decorative."
        case .researchFocused:
            "Best when publications, research themes, grants, supervision, and recognition should lead."
        case .artisticPortfolio:
            "Best when artistic work, exhibitions, public projects, and practice-based research should lead."
        case .teachingFocused:
            "Best when the audience is evaluating teaching, supervision, curriculum, and educational leadership."
        case .compactTwoPage:
            "Best when the recipient needs a quick scan and only the strongest evidence-backed items."
        case .publicProfile:
            "Best for websites, introductions, public profile pages, and shareable short CVs."
        }
    }

    var targetPageLimit: Int? {
        switch self {
        case .compactTwoPage:
            2
        case .aaltoTenkFormal, .elegantAcademic, .researchFocused, .artisticPortfolio, .teachingFocused:
            4
        case .publicProfile:
            2
        }
    }
}
