import Foundation

struct CVDraftSection: Identifiable, Hashable {
    let id: String
    let title: String
    let wordCount: Int
    let bulletCount: Int

    init(title: String, body: [String]) {
        self.id = title
        self.title = title
        self.wordCount = body.joined(separator: " ").split(whereSeparator: \.isWhitespace).count
        self.bulletCount = body.filter { $0.trimmed.hasPrefix("- ") }.count
    }
}

