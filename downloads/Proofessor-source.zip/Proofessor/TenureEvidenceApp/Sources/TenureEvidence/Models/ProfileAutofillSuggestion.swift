import Foundation

struct ProfileAutofillSuggestion: Hashable {
    var name: String = ""
    var title: String = ""
    var affiliation: String = ""
    var researchThemes: String = ""
    var artisticThemes: String = ""
    var teachingThemes: String = ""
    var orcidURL: String = ""
    var googleScholarURL: String = ""
    var aaltoProfileURL: String = ""
    var selectedPublications: String = ""
    var selectedExhibitions: String = ""

    var filledCount: Int {
        [
            name,
            title,
            affiliation,
            researchThemes,
            artisticThemes,
            teachingThemes,
            orcidURL,
            googleScholarURL,
            aaltoProfileURL,
            selectedPublications,
            selectedExhibitions
        ]
        .filter { !$0.trimmed.isEmpty }
        .count
    }
}
