import Foundation

enum CVDraftVariant: String, CaseIterable, Identifiable {
    case currentPages = "Current Pages CV"
    case cv2025Research = "CV2025 research profile CV"
    case generalAcademic = "General academic CV"
    case artFocused = "Art-focused CV"
    case researchFocused = "Research-focused CV"
    case teachingFocused = "Teaching-focused CV"
    case tenk = "TENK CV"
    case threePage = "Three-page CV"
    case tenure = "Tenure CV"
    case publicProfile = "Public profile CV"

    var id: String { rawValue }

    var fileStem: String {
        switch self {
        case .currentPages:
            "Editable_CV_Current_Pages"
        case .cv2025Research:
            "Editable_CV_CV2025_Research_Profile"
        case .generalAcademic:
            "Editable_CV_General_Academic"
        case .artFocused:
            "Editable_CV_Art_Focused"
        case .researchFocused:
            "Editable_CV_Research_Focused"
        case .teachingFocused:
            "Editable_CV_Teaching_Focused"
        case .tenk:
            "Editable_CV_TENK"
        case .threePage:
            "Editable_CV_Three_Page"
        case .tenure:
            "Editable_CV_Tenure"
        case .publicProfile:
            "Editable_CV_Public_Profile"
        }
    }

    var systemImage: String {
        switch self {
        case .currentPages:
            "doc.text"
        case .cv2025Research:
            "text.book.closed"
        case .generalAcademic:
            "building.columns"
        case .artFocused:
            "paintpalette"
        case .researchFocused:
            "magnifyingglass"
        case .teachingFocused:
            "graduationcap"
        case .tenk:
            "list.bullet.rectangle"
        case .threePage:
            "doc.on.doc"
        case .tenure:
            "checklist"
        case .publicProfile:
            "person.text.rectangle"
        }
    }

    var description: String {
        switch self {
        case .currentPages:
            "Keeps close to the structure of the current extracted Pages CV, then adds recent app-captured items for review."
        case .cv2025Research:
            "Uses the CV2025.pages research framing as profile language alongside the current CV spine."
        case .generalAcademic:
            "A balanced academic CV covering research, art, teaching, leadership, service, and visibility."
        case .artFocused:
            "Prioritises artistic work, exhibitions, artistic research, art/technology projects, and cultural visibility."
        case .researchFocused:
            "Prioritises publications, AI/postdigital research, grants, supervision, editorial work, and collaborations."
        case .teachingFocused:
            "Prioritises teaching, pedagogy, supervision, curriculum work, programme leadership, and training."
        case .tenk:
            "A concise Finnish academic CV structure aligned with TENK-style categories."
        case .threePage:
            "A compressed draft intended for heavy editing into roughly three pages."
        case .tenure:
            "Organises evidence around tenure dimensions: research/artistic work, teaching, and impact/service."
        case .publicProfile:
            "A short public-facing CV/bio draft for websites, profile pages, and introductions."
        }
    }

    var optimizesFor: String {
        switch self {
        case .currentPages:
            "Continuity with the current Pages CV while making it editable and evidence-aware."
        case .cv2025Research:
            "Research identity, profile language, and themes from the CV2025 material."
        case .generalAcademic:
            "A complete academic picture across research, art, teaching, service, funding, and visibility."
        case .artFocused:
            "Artistic research, exhibitions, public projects, cultural visibility, and art-education practice."
        case .researchFocused:
            "Research themes, publications, grants, collaborators, supervision, and international profile."
        case .teachingFocused:
            "Pedagogy, programme leadership, supervision, curriculum work, feedback, and educational development."
        case .tenk:
            "Formal Finnish academic evaluation categories and rule-compliant density."
        case .threePage:
            "Fast evaluator scanning: strongest, most current, and most relevant material only."
        case .tenure:
            "tenure evaluation: research/artistic work, teaching, and impact/service evidence."
        case .publicProfile:
            "Public readability, quick recognition, contactability, and selected highlights."
        }
    }

    var cutAdvice: String {
        switch self {
        case .currentPages:
            "Cut repeated older lines, weak undated activities, and anything already better expressed in the structured database."
        case .cv2025Research:
            "Cut administrative detail and long lists that distract from the research voice."
        case .generalAcademic:
            "Cut only weak or unverified material; this can stay broad."
        case .artFocused:
            "Cut routine committee/service detail unless it supports artistic impact or cultural leadership."
        case .researchFocused:
            "Cut local-only teaching detail unless it demonstrates research supervision or research-led teaching."
        case .teachingFocused:
            "Cut dense publication lists unless they support pedagogy, supervision, or educational research."
        case .tenk:
            "Cut decorative text, profile prose, portraits, social emphasis, and unclassified or unverifiable items."
        case .threePage:
            "Cut anything not recent, distinctive, evaluator-relevant, or strongly evidenced."
        case .tenure:
            "Cut unlinked claims, weak source-confidence lines, and details that do not map to tenure criteria."
        case .publicProfile:
            "Cut exhaustive lists, internal service detail, and source scaffolding."
        }
    }

    var designAdvice: String {
        switch self {
        case .tenk:
            "Use TENK formal only. Keep formatting plain and institutional."
        case .threePage:
            "Use compact or clean styles. Visual personality should never cost space."
        case .artFocused:
            "Art portfolio and art catalogue styles are appropriate; selected documentation links can be prominent."
        case .publicProfile:
            "Profile, portrait, and link-forward styles are appropriate when you want quick social and profile links."
        case .researchFocused, .cv2025Research:
            "Research brief or Clean academic works best for collaborators, grants, and academic visibility."
        case .teachingFocused:
            "Clean academic, public profile, or portrait profile can work when leadership and pedagogy need warmth."
        case .tenure:
            "Clean academic is safest. Use research brief only if the dossier context allows a less formal design."
        case .currentPages, .generalAcademic:
            "Clean academic, current Pages feel, or research brief are good defaults."
        }
    }

    var allowedThemes: [CVDraftTheme] {
        switch self {
        case .tenk:
            return [.tenkFormal]
        case .threePage:
            return [.compact, .aaltoClean, .researchBrief]
        case .artFocused:
            return [.artPortfolio, .artCatalogue, .aaltoClean, .currentPages, .linkForward]
        case .publicProfile:
            return [.publicProfile, .portraitProfile, .linkForward, .researchBrief, .aaltoClean]
        case .researchFocused, .cv2025Research:
            return [.researchBrief, .aaltoClean, .currentPages, .publicProfile, .linkForward]
        case .teachingFocused:
            return [.aaltoClean, .publicProfile, .portraitProfile, .researchBrief, .currentPages]
        case .tenure:
            return [.aaltoClean, .researchBrief, .currentPages, .compact]
        case .currentPages:
            return [.currentPages, .aaltoClean, .researchBrief, .publicProfile]
        case .generalAcademic:
            return [.aaltoClean, .researchBrief, .currentPages, .compact, .publicProfile]
        }
    }
}
