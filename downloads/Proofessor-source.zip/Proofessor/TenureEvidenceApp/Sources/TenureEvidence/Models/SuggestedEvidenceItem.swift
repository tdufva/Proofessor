import Foundation

struct SuggestedEvidenceItem: Identifiable, Hashable {
    let id: String
    let sourceURL: URL
    let relativePath: String
    let rawText: String
    var entry: EvidenceEntry
    var duplicateCandidates: [EvidenceEntry]

    var hasDuplicates: Bool {
        !duplicateCandidates.isEmpty
    }

    var duplicateTitles: [String] {
        duplicateCandidates.map { candidate in
            [candidate.date, candidate.title]
                .filter { !$0.trimmed.isEmpty }
                .joined(separator: " - ")
        }
    }

    var sourceURLs: [URL] {
        URLTools.extractURLs(from: rawText + "\n" + entry.source + "\n" + entry.notes)
    }

    var missingFields: [String] {
        entry.completeness.missing
    }
}
