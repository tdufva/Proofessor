import Foundation

enum CVExportStyle: String, CaseIterable, Identifiable {
    case academic = "Academic CV"
    case tenk = "TENK-style CV"
    case tenureBullets = "Tenure dossier bullets"
    case publicBio = "Public bio / website update"

    var id: String { rawValue }

    var fileName: String {
        switch self {
        case .academic:
            "CV_Export_Academic.md"
        case .tenk:
            "CV_Export_TENK.md"
        case .tenureBullets:
            "CV_Export_Tenure_Bullets.md"
        case .publicBio:
            "CV_Export_Public_Bio.md"
        }
    }

    var systemImage: String {
        switch self {
        case .academic:
            "doc.text"
        case .tenk:
            "list.bullet.rectangle"
        case .tenureBullets:
            "checklist"
        case .publicBio:
            "person.text.rectangle"
        }
    }

    var description: String {
        switch self {
        case .academic:
            "Grouped academic CV sections from ready-to-use evidence records."
        case .tenk:
            "Compact Finnish academic CV categories from app evidence."
        case .tenureBullets:
            "Evaluator-facing bullets grouped by tenure dimensions."
        case .publicBio:
            "Short public profile notes and recent highlights."
        }
    }
}
