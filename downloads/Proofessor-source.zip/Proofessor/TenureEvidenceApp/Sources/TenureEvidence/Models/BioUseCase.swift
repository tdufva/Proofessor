import Foundation

enum BioUseCase: String, CaseIterable, Identifiable {
    case academic = "Academic bio"
    case artistic = "Artistic bio"
    case research = "Research-focused bio"
    case teaching = "Teaching-focused bio"
    case publicProfile = "Public profile bio"
    case speakerIntro = "Speaker intro"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .academic:
            "building.columns"
        case .artistic:
            "paintpalette"
        case .research:
            "magnifyingglass"
        case .teaching:
            "graduationcap"
        case .publicProfile:
            "person.text.rectangle"
        case .speakerIntro:
            "quote.bubble"
        }
    }

    var fileStem: String {
        switch self {
        case .academic:
            "Academic"
        case .artistic:
            "Artistic"
        case .research:
            "Research_Focused"
        case .teaching:
            "Teaching_Focused"
        case .publicProfile:
            "Public_Profile"
        case .speakerIntro:
            "Speaker_Intro"
        }
    }

    var guidance: String {
        switch self {
        case .academic:
            "Balanced institutional profile: role, field, research/artistic work, teaching, selected achievements, and service."
        case .artistic:
            "Emphasizes artistic practice, exhibitions, design/cultural projects, public work, and artistic research."
        case .research:
            "Leads with research agenda, publications, funding, collaborations, supervision, and international profile."
        case .teaching:
            "Highlights pedagogy, courses, supervision, curriculum work, student learning, and educational leadership."
        case .publicProfile:
            "Clear, less formal public-facing version for websites, profiles, and press introductions."
        case .speakerIntro:
            "Compact host-friendly introduction for talks, panels, events, and programmes."
        }
    }
}

enum BioLengthPreset: String, CaseIterable, Identifiable {
    case short = "Short"
    case long = "Long"
    case custom = "Custom"

    var id: String { rawValue }

    var targetWords: Int? {
        switch self {
        case .short:
            250
        case .long:
            500
        case .custom:
            nil
        }
    }

    var label: String {
        switch self {
        case .short:
            "250 words"
        case .long:
            "500 words"
        case .custom:
            "character limit"
        }
    }
}
