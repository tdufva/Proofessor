import Foundation

struct CVReviewerSummary: Hashable {
    var researchHighlights: [EvidenceEntry]
    var teachingHighlights: [EvidenceEntry]
    var impactHighlights: [EvidenceEntry]
    var missingEvidence: [EvidenceEntry]
    var weakLines: [String]
}

