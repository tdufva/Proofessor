import Foundation

struct DossierNarrativeSection: Identifiable, Hashable {
    var id: String { title }
    var title: String
    var systemImage: String
    var paragraph: String
    var evidenceTitles: [String]
    var missingNote: String
}
