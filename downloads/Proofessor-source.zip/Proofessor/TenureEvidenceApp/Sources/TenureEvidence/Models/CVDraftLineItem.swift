import Foundation

struct CVDraftLineItem: Identifiable, Hashable {
    var id = UUID()
    var section: String = ""
    var text: String = ""
    var included: Bool = true
    var verified: Bool = false
    var sourceConfidence: String = "medium"
    var templateRelevance: String = "keep"
    var inclusionReason: String = ""
    var order: Int = 0

    var isStructural: Bool {
        text.hasPrefix("#")
    }
}
