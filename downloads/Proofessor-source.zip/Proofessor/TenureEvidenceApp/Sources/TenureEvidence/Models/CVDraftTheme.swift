import AppKit
import Foundation

enum CVDraftTheme: String, CaseIterable, Identifiable {
    case aaltoClean = "Clean academic"
    case tenkFormal = "TENK formal"
    case currentPages = "Current Pages feel"
    case artPortfolio = "Art portfolio"
    case compact = "Compact three-page"
    case publicProfile = "Public profile"
    case researchBrief = "Research brief"
    case portraitProfile = "Portrait profile"
    case linkForward = "Link-forward"
    case artCatalogue = "Art catalogue"

    var id: String { rawValue }

    var fileStem: String {
        rawValue
            .lowercased()
            .replacingOccurrences(of: " ", with: "_")
            .replacingOccurrences(of: "-", with: "_")
    }

    var systemImage: String {
        switch self {
        case .aaltoClean:
            "rectangle.grid.1x2"
        case .tenkFormal:
            "list.bullet.rectangle"
        case .currentPages:
            "doc.text"
        case .artPortfolio:
            "paintpalette"
        case .compact:
            "rectangle.compress.vertical"
        case .publicProfile:
            "person.text.rectangle"
        case .researchBrief:
            "doc.text.magnifyingglass"
        case .portraitProfile:
            "person.crop.rectangle"
        case .linkForward:
            "link.circle"
        case .artCatalogue:
            "photo.on.rectangle"
        }
    }

    var description: String {
        switch self {
        case .aaltoClean:
            "Calm, readable clean academic formatting."
        case .tenkFormal:
            "Plain, dense, formal formatting for Finnish academic CV use."
        case .currentPages:
            "Closest to the present Pages/PDF CV: strong headings and generous spacing."
        case .artPortfolio:
            "More expressive visual hierarchy for artistic practice and portfolio CVs."
        case .compact:
            "Smaller type and tighter spacing for short CV drafts."
        case .publicProfile:
            "Readable, public-facing profile style for web bios and introductions."
        case .researchBrief:
            "A crisp research-forward layout for grants, academic profiles, and collaborations."
        case .portraitProfile:
            "A personal profile layout that works well when the draft includes a portrait, short bio, and contact links."
        case .linkForward:
            "A public-facing layout that highlights web, Scholar, LinkedIn, and social links when they are present."
        case .artCatalogue:
            "A more editorial art-catalogue rhythm for exhibitions, projects, images, and public-facing art CVs."
        }
    }

    var designUse: String {
        switch self {
        case .tenkFormal:
            "Formal academic submission. Keep it plain, dense, and rule-compliant."
        case .compact:
            "Length control. Use when the page count matters more than visual personality."
        case .artPortfolio, .artCatalogue:
            "Artistic and public-cultural contexts. Stronger hierarchy is appropriate."
        case .publicProfile, .portraitProfile, .linkForward:
            "Public profile and introduction contexts. Contact links and a short profile can be prominent."
        case .researchBrief:
            "Research-first contexts. Good for grants, collaborators, and research profile sharing."
        case .currentPages:
            "Continuity with the existing Pages CV."
        case .aaltoClean:
            "A balanced academic default for institution-facing material."
        }
    }

    var personalizationHint: String {
        switch self {
        case .portraitProfile:
            "Best with a portrait line, short bio, email, institutional profile, Google Scholar, LinkedIn, and website links near the top."
        case .linkForward:
            "Best when the first section includes quick links: Scholar, institutional research profile, LinkedIn, website, and selected public profiles."
        case .artCatalogue:
            "Best when selected projects, exhibitions, and documentation links are foregrounded."
        case .artPortfolio:
            "Best when artistic work and public projects appear before dense academic service."
        case .researchBrief:
            "Best when publications, grants, research themes, and collaborators are foregrounded."
        case .tenkFormal:
            "Do not add portrait, decorative styling, or social-link emphasis. Keep the content formal."
        case .compact:
            "Use short lines, selected items, and minimal contact details."
        case .publicProfile:
            "Use an elegant short profile with selected highlights and useful external links."
        case .aaltoClean, .currentPages:
            "Use clear contact details and links only where they help the reader verify or contact you."
        }
    }

    var supportsProfilePicture: Bool {
        switch self {
        case .publicProfile, .portraitProfile, .linkForward, .artCatalogue, .artPortfolio:
            true
        case .aaltoClean, .tenkFormal, .currentPages, .compact, .researchBrief:
            false
        }
    }

    var rendersProfilePictureMasthead: Bool {
        switch self {
        case .publicProfile, .portraitProfile, .linkForward:
            true
        case .aaltoClean, .tenkFormal, .currentPages, .artPortfolio, .compact, .researchBrief, .artCatalogue:
            false
        }
    }

    var titleFont: NSFont {
        switch self {
        case .compact:
            .systemFont(ofSize: 18, weight: .semibold)
        case .artPortfolio, .artCatalogue:
            .systemFont(ofSize: 25, weight: .semibold)
        case .portraitProfile, .linkForward:
            .systemFont(ofSize: 24, weight: .semibold)
        default:
            .systemFont(ofSize: 23, weight: .semibold)
        }
    }

    var headingFont: NSFont {
        switch self {
        case .compact:
            .systemFont(ofSize: 12.5, weight: .semibold)
        case .artPortfolio, .artCatalogue:
            .systemFont(ofSize: 16, weight: .semibold)
        case .researchBrief:
            .systemFont(ofSize: 13.5, weight: .semibold)
        default:
            .systemFont(ofSize: 14, weight: .semibold)
        }
    }

    var bodyFont: NSFont {
        switch self {
        case .compact:
            .systemFont(ofSize: 9.5)
        case .tenkFormal:
            .systemFont(ofSize: 10.5)
        case .publicProfile:
            .systemFont(ofSize: 11.5)
        case .portraitProfile, .linkForward:
            .systemFont(ofSize: 11.5)
        case .researchBrief:
            .systemFont(ofSize: 10.75)
        default:
            .systemFont(ofSize: 11)
        }
    }

    var accentColor: NSColor {
        switch self {
        case .aaltoClean:
            .systemBlue
        case .tenkFormal:
            .labelColor
        case .currentPages:
            .darkGray
        case .artPortfolio:
            .systemTeal
        case .compact:
            .secondaryLabelColor
        case .publicProfile:
            .systemIndigo
        case .researchBrief:
            .systemBlue
        case .portraitProfile:
            .systemGreen
        case .linkForward:
            .systemCyan
        case .artCatalogue:
            .systemPink
        }
    }

    var lineSpacing: CGFloat {
        switch self {
        case .compact:
            1.5
        case .currentPages, .artPortfolio, .artCatalogue, .portraitProfile:
            4
        default:
            2.5
        }
    }

    var pageMargin: CGFloat {
        switch self {
        case .compact:
            44
        case .artPortfolio, .artCatalogue, .portraitProfile:
            62
        default:
            54
        }
    }
}
