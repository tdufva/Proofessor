import Foundation

enum CVStructuredSection: String, CaseIterable, Codable, Hashable, Identifiable {
    case education = "Education"
    case employment = "Employment"
    case publication = "Publication"
    case talk = "Talk"
    case teaching = "Teaching"
    case service = "Service"
    case grant = "Grant"
    case artisticWork = "Artistic work"
    case supervision = "Supervision"
    case visibility = "Visibility"
    case other = "Other"

    var id: String { rawValue }
}

struct CVStructuredItem: Identifiable, Codable, Hashable {
    var id = UUID()
    var section: CVStructuredSection = .other
    var year: String = ""
    var title: String = ""
    var authors: String = ""
    var role: String = ""
    var venue: String = ""
    var doi: String = ""
    var peerReview: String = "check"
    var tenkClass: String = ""
    var jufoLevel: String = "check"
    var sourceConfidence: String = "medium"
    var visibility: String = "internal"
    var verified: Bool = false
    var includeInTemplates: [String] = []
    var linkedEvidenceIDs: [UUID]? = nil
    var source: String = ""
    var notes: String = ""
    var order: Int = 0
}
