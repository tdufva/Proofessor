import Foundation

enum CVWorkbenchTab: String, CaseIterable, Identifiable {
    case draft = "Draft"
    case lines = "Lines"
    case database = "Database"
    case publications = "Publications"
    case diff = "Diff"
    case reviewer = "Reviewer"
    case health = "Health"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .draft:
            "doc.text"
        case .lines:
            "list.bullet.rectangle"
        case .database:
            "tablecells"
        case .publications:
            "text.book.closed"
        case .diff:
            "arrow.left.arrow.right"
        case .reviewer:
            "person.badge.key"
        case .health:
            "gauge.with.dots.needle.bottom.50percent"
        }
    }
}
