import Foundation

struct CVVersionSnapshot: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var createdAt: String
    var variant: String
    var theme: String
    var format: String
    var wordCount: Int
    var pageCount: Int
    var draftPath: String
    var exportedPath: String
    var note: String = ""

    var displayTitle: String {
        "\(variant) · \(format)"
    }

    var displaySubtitle: String {
        "\(createdAt) · \(wordCount) words · \(pageCount) page(s)"
    }
}
