import Foundation

enum AaltoSchoolPreset: String, CaseIterable, Identifiable {
    case aaltoWide = "Aalto-wide"
    case arts = "ARTS"
    case biz = "BIZ"
    case technology = "Technical schools"

    var id: String { rawValue }

    var shortName: String {
        switch self {
        case .aaltoWide: "Aalto"
        case .arts: "ARTS"
        case .biz: "BIZ"
        case .technology: "Technical"
        }
    }

    var emphasis: String {
        switch self {
        case .aaltoWide:
            "Use the university-wide dimensions: research/artistic work, teaching, and impact/service."
        case .arts:
            "Give artistic and professional work, exhibitions, public projects, design outputs, and teaching portfolios a visible place beside research."
        case .biz:
            "Emphasize scholarly publications, competitive funding, international recognition, teaching quality, and field contribution."
        case .technology:
            "Emphasize research quality, doctoral/postdoctoral team building, competitive funding, teaching, and societal or field impact."
        }
    }
}

enum AaltoCareerStage: String, CaseIterable, Identifiable {
    case assistantFirst = "Assistant professor, first term"
    case assistantSecond = "Assistant professor, second term"
    case tenure = "Associate / tenure review"
    case full = "Full professor"

    var id: String { rawValue }

    var shortName: String {
        switch self {
        case .assistantFirst: "Assistant 1"
        case .assistantSecond: "Assistant 2"
        case .tenure: "Tenure"
        case .full: "Full"
        }
    }

    var emphasis: String {
        switch self {
        case .assistantFirst:
            "Potential, trajectory, independence, and early evidence across research/artistic work, teaching, and impact/service."
        case .assistantSecond:
            "Demonstrated merits plus potential since the previous review."
        case .tenure:
            "Excellence in research/artistic work or teaching, with high quality in the other dimension."
        case .full:
            "International recognition, sustained competitive funding, field development, leadership, and impact/service."
        }
    }
}

struct AaltoCriteriaRecommendation: Hashable {
    enum Confidence: String {
        case high = "High"
        case medium = "Medium"
        case review = "Review"
    }

    var title: String
    var dimension: String
    var category: String
    var confidence: Confidence
    var reason: String
    var matchedSignals: [String]

    var confidenceNote: String {
        let signalText = matchedSignals.isEmpty ? "limited metadata" : matchedSignals.prefix(3).joined(separator: ", ")
        return "\(confidence.rawValue) confidence: \(reason) Signals: \(signalText)."
    }
}

enum AaltoCriteriaMatcher {
    static func recommendation(
        for entry: EvidenceEntry,
        school: AaltoSchoolPreset,
        stage: AaltoCareerStage
    ) -> AaltoCriteriaRecommendation {
        let signals = signalMatches(for: entry, school: school, stage: stage)
        let best = signals.max { lhs, rhs in
            if lhs.score == rhs.score {
                return lhs.priority < rhs.priority
            }
            return lhs.score < rhs.score
        }

        guard let best else {
            return AaltoCriteriaRecommendation(
                title: "Needs human review",
                dimension: entry.tenureDimension.trimmed.isEmpty ? "All" : entry.tenureDimension,
                category: entry.category.trimmed.isEmpty ? "Other" : entry.category,
                confidence: .review,
                reason: "The scan did not find strong Aalto criteria signals yet.",
                matchedSignals: []
            )
        }

        return AaltoCriteriaRecommendation(
            title: best.title,
            dimension: best.dimension,
            category: best.category,
            confidence: confidence(for: best.score, entry: entry),
            reason: reason(for: best, school: school, stage: stage),
            matchedSignals: best.matchedSignals
        )
    }

    static func guidance(school: AaltoSchoolPreset, stage: AaltoCareerStage) -> String {
        "\(school.emphasis) \(stage.emphasis)"
    }

    private struct Signal {
        var title: String
        var dimension: String
        var category: String
        var keywords: [String]
        var priority: Int
        var score: Int
        var matchedSignals: [String]
    }

    private static func signalMatches(
        for entry: EvidenceEntry,
        school: AaltoSchoolPreset,
        stage: AaltoCareerStage
    ) -> [Signal] {
        let text = [
            entry.title,
            entry.category,
            entry.eventType,
            entry.role,
            entry.venue,
            entry.source,
            entry.notes
        ]
        .joined(separator: " ")
        .lowercased()

        var definitions = baseSignals

        if school == .arts {
            definitions.append(Signal(title: "Artistic / professional work", dimension: "Research/artistic work", category: "Artistic Output", keywords: ["exhibition", "artistic", "design", "curator", "screening", "catalogue", "public work"], priority: 8, score: 0, matchedSignals: []))
        }

        if school == .biz {
            definitions.append(Signal(title: "Scholarly publication / field contribution", dimension: "Research/artistic work", category: "Publication", keywords: ["journal", "publication", "article", "impact", "field", "conference paper", "abs"], priority: 8, score: 0, matchedSignals: []))
        }

        if school == .technology {
            definitions.append(Signal(title: "Research team / doctoral pipeline", dimension: "Research/artistic work", category: "Service", keywords: ["doctoral", "postdoc", "research group", "lab", "principal investigator", "pi", "consortium"], priority: 8, score: 0, matchedSignals: []))
        }

        if stage == .full {
            definitions.append(Signal(title: "Full professor recognition", dimension: "Impact and service", category: "Visibility", keywords: ["international", "keynote", "invited", "award", "recognition", "external", "field", "editor", "board"], priority: 10, score: 0, matchedSignals: []))
        }

        if stage == .assistantFirst || stage == .assistantSecond {
            definitions.append(Signal(title: "Trajectory / potential", dimension: entry.tenureDimension, category: entry.category, keywords: ["invited", "accepted", "selected", "proposal", "seed", "pilot", "emerging", "future"], priority: 4, score: 0, matchedSignals: []))
        }

        return definitions.compactMap { definition in
            var signal = definition
            let matches = definition.keywords.filter { text.contains($0) }
            signal.matchedSignals = matches
            signal.score = matches.count * 2

            if entry.category == definition.category {
                signal.score += 2
                signal.matchedSignals.append(entry.category)
            }

            if entry.tenureDimension == definition.dimension {
                signal.score += 1
            }

            return signal.score > 0 ? signal : nil
        }
    }

    private static var baseSignals: [Signal] {
        [
            Signal(title: "Research / artistic quality", dimension: "Research/artistic work", category: "Publication", keywords: ["publication", "doi", "article", "research", "artistic", "exhibition", "conference", "proceedings"], priority: 7, score: 0, matchedSignals: []),
            Signal(title: "Competitive funding", dimension: "Research/artistic work", category: "Funding", keywords: ["grant", "funding", "academy", "horizon", "business finland", "erc", "consortium", "budget"], priority: 9, score: 0, matchedSignals: []),
            Signal(title: "Teaching quality", dimension: "Teaching", category: "Teaching", keywords: ["teaching", "course", "curriculum", "syllabus", "pedagog", "student", "feedback", "mycourses"], priority: 7, score: 0, matchedSignals: []),
            Signal(title: "Supervision", dimension: "Teaching", category: "Supervision", keywords: ["supervision", "supervisor", "thesis", "doctoral", "master", "bachelor", "examiner"], priority: 8, score: 0, matchedSignals: []),
            Signal(title: "Impact / service", dimension: "Impact and service", category: "Service", keywords: ["committee", "service", "leadership", "chair", "board", "review", "societal", "public", "impact"], priority: 6, score: 0, matchedSignals: []),
            Signal(title: "International recognition", dimension: "Impact and service", category: "Visibility", keywords: ["international", "keynote", "invited", "visiting", "external", "award", "media", "panel"], priority: 8, score: 0, matchedSignals: []),
            Signal(title: "Team building", dimension: "Research/artistic work", category: "Service", keywords: ["team", "research group", "doctoral", "postdoc", "post-doctoral", "principal investigator", "pi", "work package"], priority: 7, score: 0, matchedSignals: [])
        ]
    }

    private static func confidence(for score: Int, entry: EvidenceEntry) -> AaltoCriteriaRecommendation.Confidence {
        if score >= 7 && entry.completeness.score >= 70 {
            return .high
        }
        if score >= 4 {
            return .medium
        }
        return .review
    }

    private static func reason(
        for signal: Signal,
        school: AaltoSchoolPreset,
        stage: AaltoCareerStage
    ) -> String {
        switch signal.title {
        case "Competitive funding":
            return "Aalto tenure review treats competitive funding as a key research/artistic work signal, especially for tenure and full professor review."
        case "Teaching quality":
            return "Aalto evaluates teaching as a core dimension, including teaching experience, development, feedback, and teaching skills."
        case "Supervision":
            return "Aalto teaching evidence includes supervision across doctoral, master, and bachelor levels."
        case "Full professor recognition":
            return "Full professor review adds international recognition, sustained funding, and contributions to the field."
        case "Artistic / professional work":
            return "The \(school.shortName) preset gives artistic and professional outputs explicit visibility within the research/artistic work dimension."
        default:
            return "\(stage.shortName) / \(school.shortName) preset matched this item to \(signal.dimension.lowercased())."
        }
    }
}
