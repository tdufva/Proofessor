import Foundation

struct CVLayoutReport: Hashable {
    var pageCount: Int
    var threePageStatus: String

    static let empty = CVLayoutReport(pageCount: 0, threePageStatus: "No layout")
}

