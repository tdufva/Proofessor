import Foundation

struct EvidenceSourceTrace: Hashable {
    var fileName: String
    var folder: String
    var date: String
    var snippet: String
    var links: [URL]

    var locationLabel: String {
        folder.trimmed.isEmpty ? fileName : "\(folder)/\(fileName)"
    }

    static func suggestion(_ item: SuggestedEvidenceItem) -> EvidenceSourceTrace {
        let folder = NSString(string: item.relativePath).deletingLastPathComponent
        return EvidenceSourceTrace(
            fileName: item.sourceURL.lastPathComponent,
            folder: folder == "." ? "" : folder,
            date: item.entry.date,
            snippet: bestSnippet(from: item.rawText),
            links: item.sourceURLs
        )
    }

    static func entry(_ entry: EvidenceEntry) -> EvidenceSourceTrace {
        let attachment = entry.attachments.first
        let attachmentPath = attachment?.path ?? ""
        let folder = NSString(string: attachmentPath).deletingLastPathComponent
        let fileName = attachment?.name ?? sourceFileName(from: entry.source)

        return EvidenceSourceTrace(
            fileName: fileName,
            folder: folder == "." ? "" : folder,
            date: entry.date,
            snippet: bestSnippet(from: entry.notes),
            links: URLTools.extractURLs(from: [entry.source, entry.notes].joined(separator: "\n"))
        )
    }

    private static func sourceFileName(from source: String) -> String {
        for line in source.components(separatedBy: .newlines) {
            if line.localizedCaseInsensitiveContains("Imported from"),
               let path = line.components(separatedBy: ": ").last?.trimmed,
               !path.isEmpty {
                return URL(fileURLWithPath: path).lastPathComponent
            }
        }
        return "Source text"
    }

    private static func bestSnippet(from text: String) -> String {
        let lines = text
            .components(separatedBy: .newlines)
            .map(\.trimmed)
            .filter { line in
                line.count > 16
                    && !line.localizedCaseInsensitiveContains("source url:")
                    && !line.localizedCaseInsensitiveContains("detected url:")
                    && !line.localizedCaseInsensitiveContains("imported from")
            }

        if let explicit = lines.first(where: { $0.localizedCaseInsensitiveContains("Readable excerpt:") }) {
            return explicit
                .replacingOccurrences(of: "Readable excerpt:", with: "")
                .trimmed
                .limited(to: 260)
        }

        return (lines.first ?? text.trimmed)
            .limited(to: 260)
    }
}

private extension String {
    func limited(to maxLength: Int) -> String {
        guard count > maxLength else { return self }
        return String(prefix(maxLength))
    }
}
