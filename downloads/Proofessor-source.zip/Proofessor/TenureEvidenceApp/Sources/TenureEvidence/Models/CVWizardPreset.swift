import Foundation

struct CVWizardPreset: Identifiable, Hashable {
    var id: CVDraftVariant { variant }
    var title: String
    var subtitle: String
    var variant: CVDraftVariant
    var theme: CVDraftTheme
    var options: CVBuildOptions
    var systemImage: String

    static let all: [CVWizardPreset] = [
        CVWizardPreset(
            title: "Aalto dossier CV",
            subtitle: "Evaluator-facing structure for research/artistic work, teaching, and impact/service.",
            variant: .tenure,
            theme: .aaltoClean,
            options: CVBuildOptions(includeAppEvidence: true, onlyCVReadyEvidence: false, includeSourceNotes: false, includeDraftNote: true, compactBullets: false, includeSourceConfidence: true, finalCleanMode: false),
            systemImage: "checklist"
        ),
        CVWizardPreset(
            title: "Three-page CV",
            subtitle: "Short, selective, compact, and ready-to-use focused.",
            variant: .threePage,
            theme: .compact,
            options: CVBuildOptions(includeAppEvidence: true, onlyCVReadyEvidence: true, includeSourceNotes: false, includeDraftNote: false, compactBullets: true, includeSourceConfidence: false, finalCleanMode: true),
            systemImage: "doc.on.doc"
        ),
        CVWizardPreset(
            title: "TENK CV",
            subtitle: "Formal Finnish academic categories with dense publication and merit formatting.",
            variant: .tenk,
            theme: .tenkFormal,
            options: CVBuildOptions(includeAppEvidence: true, onlyCVReadyEvidence: true, includeSourceNotes: false, includeDraftNote: false, compactBullets: true, includeSourceConfidence: false, finalCleanMode: false),
            systemImage: "list.bullet.rectangle"
        ),
        CVWizardPreset(
            title: "Research/artistic portfolio",
            subtitle: "Artistic work, research outputs, exhibitions, grants, public projects, and talks first.",
            variant: .artFocused,
            theme: .artPortfolio,
            options: CVBuildOptions(includeAppEvidence: true, onlyCVReadyEvidence: false, includeSourceNotes: false, includeDraftNote: true, compactBullets: false, includeSourceConfidence: true, finalCleanMode: false),
            systemImage: "paintpalette"
        ),
        CVWizardPreset(
            title: "Research CV",
            subtitle: "Research themes, publications, grants, collaborations, and supervision first.",
            variant: .researchFocused,
            theme: .researchBrief,
            options: CVBuildOptions(includeAppEvidence: true, onlyCVReadyEvidence: false, includeSourceNotes: false, includeDraftNote: true, compactBullets: false, includeSourceConfidence: true, finalCleanMode: false),
            systemImage: "doc.text.magnifyingglass"
        ),
        CVWizardPreset(
            title: "Teaching portfolio CV",
            subtitle: "Pedagogy, programme leadership, teaching evidence, supervision, and training first.",
            variant: .teachingFocused,
            theme: .aaltoClean,
            options: CVBuildOptions(includeAppEvidence: true, onlyCVReadyEvidence: false, includeSourceNotes: false, includeDraftNote: true, compactBullets: false, includeSourceConfidence: true, finalCleanMode: false),
            systemImage: "graduationcap"
        ),
        CVWizardPreset(
            title: "Public web CV",
            subtitle: "Short, elegant, readable, and scaffolding-free for websites or introductions.",
            variant: .publicProfile,
            theme: .publicProfile,
            options: CVBuildOptions(includeAppEvidence: true, onlyCVReadyEvidence: true, includeSourceNotes: false, includeDraftNote: false, compactBullets: true, includeSourceConfidence: false, finalCleanMode: true),
            systemImage: "person.text.rectangle"
        )
    ]
}
