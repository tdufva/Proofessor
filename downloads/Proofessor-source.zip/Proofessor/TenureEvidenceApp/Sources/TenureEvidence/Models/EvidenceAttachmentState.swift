import Foundation

struct EvidenceAttachmentState: Hashable {
    var url: URL
    var exists: Bool
    var isDirectory: Bool
    var isSupportedPreview: Bool

    var label: String {
        if !exists {
            return "Missing file"
        }
        if isDirectory {
            return "Folder"
        }
        return isSupportedPreview ? "Ready" : "Unsupported preview"
    }

    var systemImage: String {
        if !exists {
            return "exclamationmark.triangle"
        }
        if isDirectory {
            return "folder"
        }
        return isSupportedPreview ? "checkmark.circle" : "questionmark.circle"
    }
}
