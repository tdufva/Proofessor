import Foundation

enum CVWorkflowStep: String, CaseIterable, Identifiable {
    case choose = "1. Purpose"
    case check = "2. Source"
    case edit = "3. Edit"
    case export = "4. Preview & Export"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .choose:
            "wand.and.stars"
        case .check:
            "doc.text.magnifyingglass"
        case .edit:
            "square.and.pencil"
        case .export:
            "square.and.arrow.up"
        }
    }

    var guidance: String {
        switch self {
        case .choose:
            "Choose what this CV is for. This sets the template, style, length posture, and export cleanliness."
        case .check:
            "Confirm that old CV material, structured CV rows, publications, and ready-to-use evidence are available before editing."
        case .edit:
            "Edit the draft text first. Line rows, source rows, and publication metadata are available when you need deeper control."
        case .export:
            "Preview the final layout, choose a format, export a set, or create a dossier packet."
        }
    }

    var shortHint: String {
        switch self {
        case .choose:
            "Purpose, template, and style."
        case .check:
            "Old CV, rows, publications, evidence."
        case .edit:
            "Draft, line rows, database, publications."
        case .export:
            "Preview, formats, packet, versions."
        }
    }
}

enum CVEditorPane: String, CaseIterable, Identifiable {
    case draft = "Draft"
    case lines = "Lines"
    case database = "Database"
    case publications = "Publications"

    var id: String { rawValue }
}

enum CVCheckPane: String, CaseIterable, Identifiable {
    case preview = "Preview"
    case diff = "Diff"
    case versions = "Versions"
    case reviewer = "Reviewer"
    case health = "Health"

    var id: String { rawValue }
}
