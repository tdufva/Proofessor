import Foundation

struct ChecklistItem: Identifiable, Hashable {
    var id: String { label }
    var label: String
    var isSatisfied: Bool
}

enum EvidenceChecklist {
    static func items(for entry: EvidenceEntry) -> [ChecklistItem] {
        let common = [
            ChecklistItem(label: "Date", isSatisfied: !entry.date.trimmed.isEmpty),
            ChecklistItem(label: "Clear title", isSatisfied: !entry.title.trimmed.isEmpty && entry.title != "Untitled evidence"),
            ChecklistItem(label: "Role", isSatisfied: !entry.role.trimmed.isEmpty),
            ChecklistItem(label: "Venue / host", isSatisfied: !entry.venue.trimmed.isEmpty),
            ChecklistItem(label: "Source URL or note", isSatisfied: !entry.source.trimmed.isEmpty),
            ChecklistItem(label: "At least one evidence file or archived URL", isSatisfied: !entry.attachments.isEmpty || entry.source.localizedCaseInsensitiveContains("http"))
        ]

        let category = entry.category.lowercased()
        let type = entry.eventType.lowercased()

        let specific: [ChecklistItem]
        if category == "talk" || type.contains("talk") || type.contains("presentation") || type.contains("keynote") {
            specific = [
                ChecklistItem(label: "Invite, programme, or event page", isSatisfied: hasEvidence(entry, ["programme", "program", "invite", "invitation", "webinar", "conference", "http"])),
                ChecklistItem(label: "Slides or abstract", isSatisfied: hasEvidence(entry, ["slide", "key", "ppt", "abstract", "presentation"])),
                ChecklistItem(label: "Invited status clarified where relevant", isSatisfied: !type.contains("invited") || entry.role.localizedCaseInsensitiveContains("invited") || entry.notes.localizedCaseInsensitiveContains("invited"))
            ]
        } else if category == "artistic output" || type.contains("exhibition") {
            specific = [
                ChecklistItem(label: "Venue page or announcement", isSatisfied: hasEvidence(entry, ["venue", "gallery", "exhibition", "announcement", "http"])),
                ChecklistItem(label: "Images, catalogue, or documentation", isSatisfied: hasEvidence(entry, ["image", "catalogue", "catalog", "photo", "png", "jpg", "pdf"])),
                ChecklistItem(label: "Dates and location", isSatisfied: !entry.date.trimmed.isEmpty && !entry.venue.trimmed.isEmpty)
            ]
        } else if category == "funding" {
            specific = [
                ChecklistItem(label: "Submitted proposal", isSatisfied: hasEvidence(entry, ["proposal", "application", "submitted"])),
                ChecklistItem(label: "Decision or result", isSatisfied: hasEvidence(entry, ["decision", "result", "funded", "rejected", "review"])),
                ChecklistItem(label: "Role and consortium notes", isSatisfied: !entry.role.trimmed.isEmpty && entry.notes.localizedCaseInsensitiveContains("consortium"))
            ]
        } else if category == "teaching" {
            specific = [
                ChecklistItem(label: "Course page or syllabus", isSatisfied: hasEvidence(entry, ["course", "syllabus", "curriculum"])),
                ChecklistItem(label: "Feedback or evaluation", isSatisfied: hasEvidence(entry, ["feedback", "evaluation"])),
                ChecklistItem(label: "Material example", isSatisfied: hasEvidence(entry, ["slides", "assignment", "material", "key", "ppt", "pdf"]))
            ]
        } else if category == "supervision" {
            specific = [
                ChecklistItem(label: "Student / thesis title", isSatisfied: entry.notes.localizedCaseInsensitiveContains("thesis") || entry.title.localizedCaseInsensitiveContains("thesis")),
                ChecklistItem(label: "Role clarified", isSatisfied: !entry.role.trimmed.isEmpty),
                ChecklistItem(label: "Completion or status evidence", isSatisfied: hasEvidence(entry, ["completed", "examined", "tracking", "schedule", "statement"]))
            ]
        } else if category == "service" {
            specific = [
                ChecklistItem(label: "Appointment, invitation, or official page", isSatisfied: hasEvidence(entry, ["appointment", "invitation", "committee", "official", "http"])),
                ChecklistItem(label: "Role and period", isSatisfied: !entry.role.trimmed.isEmpty && !entry.date.trimmed.isEmpty),
                ChecklistItem(label: "Impact note", isSatisfied: !entry.notes.trimmed.isEmpty)
            ]
        } else {
            specific = [
                ChecklistItem(label: "Why this matters for tenure", isSatisfied: !entry.notes.trimmed.isEmpty),
                ChecklistItem(label: "Filed or archived evidence", isSatisfied: !entry.attachments.isEmpty)
            ]
        }

        return common + specific
    }

    private static func hasEvidence(_ entry: EvidenceEntry, _ terms: [String]) -> Bool {
        let haystack = (
            entry.source + " " +
            entry.notes + " " +
            entry.attachments.map { $0.name + " " + $0.path }.joined(separator: " ")
        ).lowercased()

        return terms.contains { haystack.contains($0.lowercased()) }
    }
}
