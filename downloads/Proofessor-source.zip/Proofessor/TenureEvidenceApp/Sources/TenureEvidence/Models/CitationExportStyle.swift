import Foundation

enum CitationExportStyle: String, CaseIterable, Identifiable {
    case apa = "APA"
    case chicago = "Chicago"
    case tenkJufo = "TENK/JUFO"

    var id: String { rawValue }

    var fileName: String {
        switch self {
        case .apa:
            "Citation_Export_APA.md"
        case .chicago:
            "Citation_Export_Chicago.md"
        case .tenkJufo:
            "Citation_Export_TENK_JUFO.md"
        }
    }

    var systemImage: String {
        switch self {
        case .apa:
            "text.book.closed"
        case .chicago:
            "text.quote"
        case .tenkJufo:
            "building.columns"
        }
    }

    var description: String {
        switch self {
        case .apa:
            "Export publication candidates in a simple APA-oriented style."
        case .chicago:
            "Export publication candidates in a simple Chicago notes/bibliography-oriented style."
        case .tenkJufo:
            "Export publication candidates with TENK category, JUFO check field, role, peer-review, and DOI hints."
        }
    }
}

