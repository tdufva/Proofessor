import Foundation

struct CVHealthMetric: Identifiable, Hashable {
    var id: String { title }
    var title: String
    var score: Int
    var note: String
}

struct CVHealthReport: Hashable {
    var metrics: [CVHealthMetric]

    var overall: Int {
        guard !metrics.isEmpty else { return 0 }
        return metrics.map(\.score).reduce(0, +) / metrics.count
    }
}

