import Foundation

enum CVExportFormat: String, CaseIterable, Identifiable {
    case markdown = "Markdown"
    case rtf = "RTF"
    case word = "Word"
    case pdf = "PDF"
    case pages = "Pages"

    var id: String { rawValue }

    var fileExtension: String {
        switch self {
        case .markdown:
            "md"
        case .rtf:
            "rtf"
        case .word:
            "docx"
        case .pdf:
            "pdf"
        case .pages:
            "pages"
        }
    }

    var systemImage: String {
        switch self {
        case .markdown:
            "text.alignleft"
        case .rtf:
            "doc.richtext"
        case .word:
            "doc.text"
        case .pdf:
            "doc.viewfinder"
        case .pages:
            "doc.badge.gearshape"
        }
    }

    var helpText: String {
        switch self {
        case .markdown:
            "Export an editable Markdown draft."
        case .rtf:
            "Export rich text that opens in TextEdit, Word, and Pages."
        case .word:
            "Export a Word .docx file."
        case .pdf:
            "Export a styled PDF."
        case .pages:
            "Ask Apple Pages to create a .pages document from the styled draft."
        }
    }
}
