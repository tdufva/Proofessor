import Foundation

enum AppTab: String, Identifiable {
    case collection = "Collect"
    case evidence = "Verify & File"
    case cv = "Build CV"
    case bios = "Bios"
    case export = "Export"

    var id: String { rawValue }
}
