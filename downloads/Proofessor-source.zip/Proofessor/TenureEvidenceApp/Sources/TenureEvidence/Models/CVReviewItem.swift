import Foundation

struct CVReviewItem: Identifiable, Hashable {
    let id: String
    let section: String
    let line: String
    let reason: String
    let sourceHint: String
}

