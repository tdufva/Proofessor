import Foundation

enum EvidenceCaptureTemplate: String, CaseIterable, Identifiable {
    case talk = "Talk"
    case keynote = "Keynote"
    case course = "Course"
    case supervision = "Supervision"
    case service = "Service"
    case grant = "Grant"
    case publication = "Publication"
    case artisticWork = "Artistic work"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .talk: "person.wave.2"
        case .keynote: "megaphone"
        case .course: "graduationcap"
        case .supervision: "person.2"
        case .service: "building.columns"
        case .grant: "eurosign.circle"
        case .publication: "doc.text"
        case .artisticWork: "paintpalette"
        }
    }

    var prompt: String {
        switch self {
        case .talk:
            "Capture conference talks, invited talks, seminars, panels, and public lectures."
        case .keynote:
            "Capture keynote invitations, plenary talks, featured lectures, and major invited appearances."
        case .course:
            "Capture teaching, course responsibility, pedagogical development, and student feedback."
        case .supervision:
            "Capture thesis supervision, thesis examination, tutoring, and doctoral support."
        case .service:
            "Capture committees, programme leadership, academic hosting, reviewing, and university service."
        case .grant:
            "Capture grant applications, awarded funding, consortium work, and project roles."
        case .publication:
            "Capture publications, proceedings, chapters, edited work, and research outputs."
        case .artisticWork:
            "Capture exhibitions, artistic research, works, screenings, public projects, and documentation."
        }
    }

    var suggestedProof: String {
        switch self {
        case .talk, .keynote:
            "Programme, invitation email, event page, slides, recording, or confirmation."
        case .course:
            "Course page, syllabus, MyCourses export, evaluation, feedback, or certificate."
        case .supervision:
            "Thesis record, supervision list, examination invitation, statement, or official confirmation."
        case .service:
            "Appointment email, committee page, minutes, hosting programme, or review confirmation."
        case .grant:
            "Application PDF, decision letter, portal receipt, budget page, or consortium confirmation."
        case .publication:
            "Publication page, DOI, PDF, publisher record, ORCID/institutional repository entry, or acceptance email."
        case .artisticWork:
            "Exhibition page, catalogue, installation images, programme, review, or archive link."
        }
    }

    func makeEntry(date: String = EvidenceCaptureTemplate.todayString) -> EvidenceEntry {
        var entry = EvidenceEntry()
        entry.date = date
        entry.title = ""
        entry.status = "Needs confirmation"
        entry.source = ""
        entry.notes = ""

        switch self {
        case .talk:
            entry.category = "Talk"
            entry.eventType = "Conference or invited presentation"
            entry.role = "Presenter"
            entry.tenureDimension = "Research/artistic work"
        case .keynote:
            entry.category = "Talk"
            entry.eventType = "Keynote lecture"
            entry.role = "Keynote speaker"
            entry.tenureDimension = "Research/artistic work"
        case .course:
            entry.category = "Teaching"
            entry.eventType = "Course"
            entry.role = "Teacher"
            entry.tenureDimension = "Teaching"
        case .supervision:
            entry.category = "Supervision"
            entry.eventType = "Thesis supervision or examination"
            entry.role = "Supervisor"
            entry.tenureDimension = "Teaching"
        case .service:
            entry.category = "Service"
            entry.eventType = "Academic service"
            entry.role = "Member"
            entry.tenureDimension = "Impact and service"
        case .grant:
            entry.category = "Funding"
            entry.eventType = "Grant application or funded project"
            entry.role = "Applicant"
            entry.tenureDimension = "Research/artistic work"
        case .publication:
            entry.category = "Publication"
            entry.eventType = "Publication"
            entry.role = "Author"
            entry.tenureDimension = "Research/artistic work"
        case .artisticWork:
            entry.category = "Artistic Output"
            entry.eventType = "Artistic work"
            entry.role = "Artist"
            entry.tenureDimension = "Research/artistic work"
        }

        return entry
    }

    private static var todayString: String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
}
