import Foundation

struct CVDiffReport: Hashable {
    var added: [String]
    var removed: [String]
    var editedHint: [String]
    var oldWordCount: Int
    var newWordCount: Int
    var oldPageCount: Int
    var newPageCount: Int
}

