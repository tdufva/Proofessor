import Foundation

struct CVBuildOptions: Hashable {
    var includeAppEvidence: Bool = true
    var onlyCVReadyEvidence: Bool = false
    var includeSourceNotes: Bool = false
    var includeDraftNote: Bool = true
    var compactBullets: Bool = false
    var includeSourceConfidence: Bool = true
    var finalCleanMode: Bool = false
}
