import Foundation

struct ConnectorSettings: Codable, Hashable {
    var allowCalendar: Bool = true
    var allowEmail: Bool = true
    var allowPublicWeb: Bool = true
    var allowLocalFiles: Bool = true
    var allowProfilePages: Bool = true
    var documentScanFolders: [String] = []
    var publicDisplayName: String = ""
    var profileTitle: String = ""
    var affiliation: String = ""
    var researchThemes: String = ""
    var artisticThemes: String = ""
    var teachingThemes: String = ""
    var acrisProfileURL: String = ""
    var googleScholarURL: String = ""
    var orcidURL: String = ""
    var aaltoPeopleURL: String = ""
    var linkedInURL: String = ""
    var socialMediaURL: String = ""
    var websiteURL: String = ""
    var profilePicturePath: String = ""
    var selectedPublications: String = ""
    var selectedExhibitions: String = ""
    var earliestYear: Int = 2025
    var reviewPeriodStartDate: String = "2025-01-01"
    var reviewPeriodEndDate: String = ""
    var notes: String = "Automation should write suggestions to 00_Inbox/Suggested_Evidence and should not edit tenure_app_entries.json directly."

    var allowedSourceLabels: [String] {
        [
            allowCalendar ? "Calendar" : nil,
            allowEmail ? "Email" : nil,
            allowPublicWeb ? "Public web" : nil,
            allowLocalFiles ? "Local Tenure folder" : nil,
            allowProfilePages ? "Profile pages" : nil,
            documentScanFolders.isEmpty ? nil : "\(documentScanFolders.count) document folder(s)"
        ]
        .compactMap { $0 }
    }

    var configuredProfileCount: Int {
        [
            acrisProfileURL,
            googleScholarURL,
            orcidURL,
            aaltoPeopleURL,
            linkedInURL,
            socialMediaURL,
            websiteURL
        ]
        .filter { !$0.trimmed.isEmpty }
        .count
    }

    var profileCompletenessCount: Int {
        [
            publicDisplayName,
            profileTitle,
            affiliation,
            researchThemes,
            artisticThemes,
            teachingThemes,
            orcidURL,
            googleScholarURL,
            aaltoPeopleURL.isEmpty ? acrisProfileURL : aaltoPeopleURL,
            selectedPublications,
            selectedExhibitions
        ]
        .filter { !$0.trimmed.isEmpty }
        .count
    }

    var profileSourceText: String {
        var sections: [String] = []

        let personalDetails = [
            publicDisplayName,
            profileTitle,
            affiliation,
            orcidURL.trimmed.isEmpty ? "" : "ORCID: \(orcidURL.trimmed)",
            googleScholarURL.trimmed.isEmpty ? "" : "Google Scholar: \(googleScholarURL.trimmed)",
            aaltoPeopleURL.trimmed.isEmpty ? "" : "Aalto profile: \(aaltoPeopleURL.trimmed)",
            acrisProfileURL.trimmed.isEmpty ? "" : "Research portal: \(acrisProfileURL.trimmed)",
            websiteURL.trimmed.isEmpty ? "" : "Website: \(websiteURL.trimmed)"
        ]
        .map(\.trimmed)
        .filter { !$0.isEmpty }

        if !personalDetails.isEmpty {
            sections.append("## Personal Details\n\n" + personalDetails.joined(separator: "\n"))
        }

        let profileLines = [
            profileTitle.trimmed.isEmpty ? "" : "Title: \(profileTitle.trimmed)",
            affiliation.trimmed.isEmpty ? "" : "Affiliation: \(affiliation.trimmed)",
            researchThemes.trimmed.isEmpty ? "" : "Research themes: \(researchThemes.trimmed)",
            artisticThemes.trimmed.isEmpty ? "" : "Artistic themes: \(artisticThemes.trimmed)",
            teachingThemes.trimmed.isEmpty ? "" : "Teaching themes: \(teachingThemes.trimmed)"
        ]
        .filter { !$0.trimmed.isEmpty }

        if !profileLines.isEmpty {
            sections.append("## Profile\n\n" + profileLines.joined(separator: "\n"))
        }

        if !researchThemes.trimmed.isEmpty {
            sections.append("## Research Framing\n\n\(researchThemes.trimmed)")
        }

        if !selectedPublications.trimmed.isEmpty {
            sections.append("## Research output (selected)\n\n\(selectedPublications.trimmed)")
        }

        if !selectedExhibitions.trimmed.isEmpty {
            sections.append("## Artistic Work (selected)\n\n\(selectedExhibitions.trimmed)")
        }

        if !teachingThemes.trimmed.isEmpty {
            sections.append("## Teaching merits\n\n\(teachingThemes.trimmed)")
        }

        return sections.joined(separator: "\n\n")
    }

    init() {}

    enum CodingKeys: String, CodingKey {
        case allowCalendar
        case allowEmail
        case allowPublicWeb
        case allowLocalFiles
        case allowProfilePages
        case documentScanFolders
        case publicDisplayName
        case profileTitle
        case affiliation
        case researchThemes
        case artisticThemes
        case teachingThemes
        case acrisProfileURL
        case googleScholarURL
        case orcidURL
        case aaltoPeopleURL
        case linkedInURL
        case socialMediaURL
        case websiteURL
        case profilePicturePath
        case selectedPublications
        case selectedExhibitions
        case earliestYear
        case reviewPeriodStartDate
        case reviewPeriodEndDate
        case notes
    }

    init(from decoder: Decoder) throws {
        let defaults = ConnectorSettings()
        let container = try decoder.container(keyedBy: CodingKeys.self)

        allowCalendar = try container.decodeIfPresent(Bool.self, forKey: .allowCalendar) ?? defaults.allowCalendar
        allowEmail = try container.decodeIfPresent(Bool.self, forKey: .allowEmail) ?? defaults.allowEmail
        allowPublicWeb = try container.decodeIfPresent(Bool.self, forKey: .allowPublicWeb) ?? defaults.allowPublicWeb
        allowLocalFiles = try container.decodeIfPresent(Bool.self, forKey: .allowLocalFiles) ?? defaults.allowLocalFiles
        allowProfilePages = try container.decodeIfPresent(Bool.self, forKey: .allowProfilePages) ?? defaults.allowProfilePages
        documentScanFolders = try container.decodeIfPresent([String].self, forKey: .documentScanFolders) ?? defaults.documentScanFolders
        publicDisplayName = try container.decodeIfPresent(String.self, forKey: .publicDisplayName) ?? defaults.publicDisplayName
        profileTitle = try container.decodeIfPresent(String.self, forKey: .profileTitle) ?? defaults.profileTitle
        affiliation = try container.decodeIfPresent(String.self, forKey: .affiliation) ?? defaults.affiliation
        researchThemes = try container.decodeIfPresent(String.self, forKey: .researchThemes) ?? defaults.researchThemes
        artisticThemes = try container.decodeIfPresent(String.self, forKey: .artisticThemes) ?? defaults.artisticThemes
        teachingThemes = try container.decodeIfPresent(String.self, forKey: .teachingThemes) ?? defaults.teachingThemes
        acrisProfileURL = try container.decodeIfPresent(String.self, forKey: .acrisProfileURL) ?? defaults.acrisProfileURL
        googleScholarURL = try container.decodeIfPresent(String.self, forKey: .googleScholarURL) ?? defaults.googleScholarURL
        orcidURL = try container.decodeIfPresent(String.self, forKey: .orcidURL) ?? defaults.orcidURL
        aaltoPeopleURL = try container.decodeIfPresent(String.self, forKey: .aaltoPeopleURL) ?? defaults.aaltoPeopleURL
        linkedInURL = try container.decodeIfPresent(String.self, forKey: .linkedInURL) ?? defaults.linkedInURL
        socialMediaURL = try container.decodeIfPresent(String.self, forKey: .socialMediaURL) ?? defaults.socialMediaURL
        websiteURL = try container.decodeIfPresent(String.self, forKey: .websiteURL) ?? defaults.websiteURL
        profilePicturePath = try container.decodeIfPresent(String.self, forKey: .profilePicturePath) ?? defaults.profilePicturePath
        selectedPublications = try container.decodeIfPresent(String.self, forKey: .selectedPublications) ?? defaults.selectedPublications
        selectedExhibitions = try container.decodeIfPresent(String.self, forKey: .selectedExhibitions) ?? defaults.selectedExhibitions
        earliestYear = try container.decodeIfPresent(Int.self, forKey: .earliestYear) ?? defaults.earliestYear
        reviewPeriodStartDate = try container.decodeIfPresent(String.self, forKey: .reviewPeriodStartDate) ?? defaults.reviewPeriodStartDate
        reviewPeriodEndDate = try container.decodeIfPresent(String.self, forKey: .reviewPeriodEndDate) ?? defaults.reviewPeriodEndDate
        notes = try container.decodeIfPresent(String.self, forKey: .notes) ?? defaults.notes
    }
}
