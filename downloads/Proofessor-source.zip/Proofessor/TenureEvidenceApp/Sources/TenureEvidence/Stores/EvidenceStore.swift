import AppKit
import Foundation

@MainActor
final class EvidenceStore: ObservableObject {
    @Published var entries: [EvidenceEntry] = []
    @Published var cvItems: [CVStructuredItem] = []
    @Published var cvVersions: [CVVersionSnapshot] = []
    @Published var connectorSettings = ConnectorSettings()
    @Published var lastMessage: String = ""

    let workspaceURL: URL
    private let dataURL: URL
    private let attachmentsRootURL: URL
    private let exportURL: URL
    private let cvExportURL: URL
    private let dossierExportURL: URL
    private let sourceArchiveRootURL: URL
    private let profileSnapshotRootURL: URL
    private let currentCVSourceURL: URL
    private let importedCVSourceURL: URL
    private let cv2025SourceURL: URL
    private let cv2025SummaryURL: URL
    private let connectorSettingsURL: URL
    private let cvItemsURL: URL
    private let cvLastExportSnapshotURL: URL
    private let cvVersionHistoryURL: URL
    private let cvVersionHistoryRootURL: URL

    init(workspaceURL overrideWorkspaceURL: URL? = nil) {
        workspaceURL = overrideWorkspaceURL ?? TenureWorkspace.locate()
        dataURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("tenure_app_entries.json")
        attachmentsRootURL = workspaceURL
            .appendingPathComponent("00_Inbox")
            .appendingPathComponent("Proofessor_Attachments")
        exportURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("Proofessor_Evidence_Export.csv")
        cvExportURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("CV_Export_From_App.md")
        dossierExportURL = workspaceURL
            .appendingPathComponent("09_Tenure_Application_Dossier")
            .appendingPathComponent("Dossier_Builder_From_App.md")
        sourceArchiveRootURL = workspaceURL
            .appendingPathComponent("00_Inbox")
            .appendingPathComponent("Source_URL_Archive")
        profileSnapshotRootURL = workspaceURL
            .appendingPathComponent("00_Inbox")
            .appendingPathComponent("Profile_Snapshots")
        currentCVSourceURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("CV_Master_Source.md")
        importedCVSourceURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("Imported_CV_Combined_Source.md")
        cv2025SourceURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("CV2025_pages_extracted_text.txt")
        cv2025SummaryURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("CV2025_Pages_Essential_Material.md")
        connectorSettingsURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("automation_connector_settings.json")
        cvItemsURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("cv_structured_items.json")
        cvLastExportSnapshotURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("CV_Last_Export_Snapshot.md")
        cvVersionHistoryURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("cv_version_history.json")
        cvVersionHistoryRootURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("CV_Version_History")
        load()
        loadConnectorSettings()
        loadCVVersions()
        let hasStructuredCVFile = FileManager.default.fileExists(atPath: cvItemsURL.path)
        loadStructuredCVItems()
        if !hasStructuredCVFile {
            cvItems = CVStructuredItemBuilder.build(sourceText: currentCVSourceText(), entries: entries)
            saveStructuredCVItems(showMessage: false)
        } else {
            let merged = CVStructuredItemBuilder.mergeMissingImportedCVItems(
                into: cvItems,
                sourceText: currentCVSourceText(),
                entries: entries
            )
            let deduplicated = CVStructuredItemBuilder.deduplicated(merged.items)
            if merged.addedCount > 0 || deduplicated.removedCount > 0 {
                cvItems = deduplicated.items
                saveStructuredCVItems(showMessage: false)
            }
        }
    }

    func load() {
        do {
            let data = try Data(contentsOf: dataURL)
            entries = try JSONDecoder().decode([EvidenceEntry].self, from: data)
            sanitizeLoadedEntries()
            lastMessage = "Loaded \(entries.count) entries."
        } catch {
            entries = []
            lastMessage = "Started empty. Could not load entries: \(error.localizedDescription)"
        }
    }

    func save() {
        do {
            try FileManager.default.createDirectory(
                at: dataURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(entries)
            try data.write(to: dataURL, options: .atomic)
            lastMessage = "Saved \(entries.count) entries."
        } catch {
            lastMessage = "Save failed: \(error.localizedDescription)"
        }
    }

    func loadConnectorSettings() {
        do {
            let data = try Data(contentsOf: connectorSettingsURL)
            connectorSettings = try JSONDecoder().decode(ConnectorSettings.self, from: data)
        } catch {
            connectorSettings = ConnectorSettings()
        }
    }

    func saveConnectorSettings(_ settings: ConnectorSettings) {
        do {
            var normalizedSettings = settings
            normalizedSettings.reviewPeriodStartDate = normalizedDateKey(from: settings.reviewPeriodStartDate) ?? settings.reviewPeriodStartDate.trimmed
            normalizedSettings.reviewPeriodEndDate = normalizedDateKey(from: settings.reviewPeriodEndDate) ?? settings.reviewPeriodEndDate.trimmed
            connectorSettings = normalizedSettings
            try FileManager.default.createDirectory(
                at: connectorSettingsURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(normalizedSettings)
            try data.write(to: connectorSettingsURL, options: .atomic)
            lastMessage = "Saved automation connector settings."
        } catch {
            lastMessage = "Connector settings save failed: \(error.localizedDescription)"
        }
    }

    func revealConnectorSettings() {
        if FileManager.default.fileExists(atPath: connectorSettingsURL.path) {
            NSWorkspace.shared.activateFileViewerSelecting([connectorSettingsURL])
        } else {
            NSWorkspace.shared.open(connectorSettingsURL.deletingLastPathComponent())
        }
    }

    func loadCVVersions() {
        do {
            let data = try Data(contentsOf: cvVersionHistoryURL)
            cvVersions = try JSONDecoder().decode([CVVersionSnapshot].self, from: data)
                .sorted { $0.createdAt > $1.createdAt }
        } catch {
            cvVersions = []
        }
    }

    func saveCVVersions() {
        do {
            try FileManager.default.createDirectory(
                at: cvVersionHistoryURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(cvVersions.sorted { $0.createdAt > $1.createdAt })
            try data.write(to: cvVersionHistoryURL, options: .atomic)
        } catch {
            lastMessage = "CV version history save failed: \(error.localizedDescription)"
        }
    }

    func revealCVVersion(_ version: CVVersionSnapshot) {
        let url = workspaceURL.appendingPathComponent(version.draftPath)
        if FileManager.default.fileExists(atPath: url.path) {
            NSWorkspace.shared.activateFileViewerSelecting([url])
            lastMessage = "Revealed CV version snapshot."
        } else {
            NSWorkspace.shared.open(cvVersionHistoryRootURL)
            lastMessage = "Version file was not found; opened version history folder."
        }
    }

    func revealCVVersionHistoryFolder() {
        do {
            try FileManager.default.createDirectory(at: cvVersionHistoryRootURL, withIntermediateDirectories: true)
            NSWorkspace.shared.open(cvVersionHistoryRootURL)
            lastMessage = "Opened CV version history folder."
        } catch {
            lastMessage = "Could not open CV version history folder: \(error.localizedDescription)"
        }
    }

    func cvVersionText(_ version: CVVersionSnapshot) -> String {
        let url = workspaceURL.appendingPathComponent(version.draftPath)
        return (try? String(contentsOf: url, encoding: .utf8)) ?? ""
    }

    func loadStructuredCVItems() {
        do {
            let data = try Data(contentsOf: cvItemsURL)
            cvItems = try JSONDecoder().decode([CVStructuredItem].self, from: data)
        } catch {
            cvItems = []
        }
    }

    func saveStructuredCVItems(showMessage: Bool = true) {
        do {
            try FileManager.default.createDirectory(
                at: cvItemsURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(cvItems.sorted { $0.order < $1.order })
            try data.write(to: cvItemsURL, options: .atomic)
            if showMessage {
                lastMessage = "Saved \(cvItems.count) structured CV item(s)."
            }
        } catch {
            lastMessage = "Structured CV save failed: \(error.localizedDescription)"
        }
    }

    func rebuildStructuredCVItems() {
        cvItems = CVStructuredItemBuilder.build(sourceText: currentCVSourceText(), entries: entries)
        saveStructuredCVItems()
        lastMessage = "Rebuilt structured CV database from app entries and CV master source."
    }

    func refreshStructuredCVItemsFromImportedSources() {
        let merged = CVStructuredItemBuilder.mergeMissingImportedCVItems(
            into: cvItems,
            sourceText: currentCVSourceText(),
            entries: entries
        )
        let deduplicated = CVStructuredItemBuilder.deduplicated(merged.items)
        cvItems = deduplicated.items
        saveStructuredCVItems(showMessage: false)
        if merged.addedCount == 0 && deduplicated.removedCount == 0 {
            lastMessage = "Imported CV material is already represented in the structured CV database."
        } else {
            lastMessage = "Added \(merged.addedCount) missing imported CV row(s) and cleaned \(deduplicated.removedCount) duplicate row(s)."
        }
    }

    func importCVSourcesAndRefresh() {
        do {
            let report = try CVSourceImporter.importSources(workspaceURL: workspaceURL, outputURL: importedCVSourceURL)
            let merged = CVStructuredItemBuilder.mergeMissingImportedCVItems(
                into: cvItems,
                sourceText: currentCVSourceText(),
                entries: entries
            )
            let deduplicated = CVStructuredItemBuilder.deduplicated(merged.items)
            cvItems = deduplicated.items
            saveStructuredCVItems(showMessage: false)
            lastMessage = "Scanned \(report.scannedFileCount) CV source file(s), imported \(report.importedFileCount), added \(merged.addedCount) CV row(s), and cleaned \(deduplicated.removedCount) duplicate row(s)."
        } catch {
            lastMessage = "CV source import failed: \(error.localizedDescription)"
        }
    }

    @discardableResult
    func addStructuredCVItem(section: CVStructuredSection = .other) -> UUID {
        var item = CVStructuredItem()
        item.section = section
        item.title = "Untitled CV item"
        item.sourceConfidence = "review"
        item.includeInTemplates = [CVDraftVariant.currentPages.rawValue, CVDraftVariant.tenure.rawValue]
        item.order = (cvItems.map(\.order).max() ?? -1) + 1
        cvItems.insert(item, at: 0)
        saveStructuredCVItems()
        return item.id
    }

    @discardableResult
    func createCVLineFromEvidence(_ entryID: EvidenceEntry.ID) -> UUID? {
        guard let entry = entries.first(where: { $0.id == entryID }) else { return nil }

        if let existing = cvItems.first(where: { ($0.linkedEvidenceIDs ?? []).contains(entryID) }) {
            lastMessage = "This evidence already has a linked CV line."
            return existing.id
        }

        var item = CVStructuredItem()
        item.section = section(for: entry)
        item.year = String(entry.date.prefix(4))
        item.title = entry.title.trimmed.isEmpty ? "Untitled CV item" : entry.title
        item.role = entry.role
        item.venue = entry.venue
        item.doi = PublicationFormatter.doi(in: [entry.title, entry.source, entry.notes].joined(separator: " ")) ?? ""
        item.peerReview = peerReview(from: [entry.eventType, entry.notes, entry.source].joined(separator: " "))
        item.tenkClass = item.section == .publication ? PublicationFormatter.tenkCategory(for: [entry.title, entry.venue, entry.notes].joined(separator: " ")) : ""
        item.jufoLevel = item.section == .publication ? "check" : ""
        item.sourceConfidence = confidenceValue(from: SourceConfidenceEvaluator.badge(for: entry))
        item.visibility = entry.category == "Visibility" ? "public" : "academic"
        item.verified = entry.cvReady || entry.completeness.score >= 90
        item.includeInTemplates = defaultTemplates(for: item.section)
        item.linkedEvidenceIDs = [entryID]
        item.source = entry.source.trimmed.isEmpty ? "Evidence record: \(entry.title)" : entry.source
        item.notes = entry.notes
        item.order = (cvItems.map(\.order).max() ?? -1) + 1

        cvItems.insert(item, at: 0)
        saveStructuredCVItems()
        lastMessage = "Created a structured CV line from evidence."
        return item.id
    }

    @discardableResult
    func createEvidenceFromCVItem(_ itemID: CVStructuredItem.ID) -> UUID? {
        guard let itemIndex = cvItems.firstIndex(where: { $0.id == itemID }) else { return nil }
        let item = cvItems[itemIndex]

        var entry = EvidenceEntry()
        entry.date = normalizedDate(from: item.year)
        entry.category = category(for: item.section)
        entry.eventType = item.section.rawValue
        entry.title = item.title.trimmed.isEmpty ? "Untitled evidence" : item.title
        entry.role = item.role
        entry.venue = item.venue
        entry.tenureDimension = dimension(for: item.section)
        entry.status = "Needs confirmation"
        entry.source = item.source.trimmed.isEmpty ? "Structured CV database" : item.source
        entry.notes = [
            item.notes,
            item.doi.trimmed.isEmpty ? "" : "DOI: \(item.doi)",
            item.peerReview.trimmed.isEmpty ? "" : "Peer review: \(item.peerReview)",
            item.tenkClass.trimmed.isEmpty ? "" : "TENK class: \(item.tenkClass)",
            item.jufoLevel.trimmed.isEmpty ? "" : "JUFO: \(item.jufoLevel)"
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n")

        entries.insert(entry, at: 0)
        var linked = cvItems[itemIndex].linkedEvidenceIDs ?? []
        linked.append(entry.id)
        cvItems[itemIndex].linkedEvidenceIDs = Array(Set(linked))
        save()
        saveStructuredCVItems(showMessage: false)
        lastMessage = "Created evidence from CV line and linked it back."
        return entry.id
    }

    func deleteStructuredCVItem(id: CVStructuredItem.ID) {
        cvItems.removeAll { $0.id == id }
        saveStructuredCVItems()
    }

    func linkedEvidence(for item: CVStructuredItem) -> [EvidenceEntry] {
        let ids = Set(item.linkedEvidenceIDs ?? [])
        guard !ids.isEmpty else { return [] }
        return entries
            .filter { ids.contains($0.id) }
            .sorted(by: sortEntries)
    }

    func suggestedEvidenceMatches(for item: CVStructuredItem, limit: Int = 3) -> [EvidenceEntry] {
        let title = normalized(item.title)
        guard !title.isEmpty else { return [] }
        let linked = Set(item.linkedEvidenceIDs ?? [])

        return entries
            .filter { !linked.contains($0.id) }
            .compactMap { entry -> (EvidenceEntry, Double)? in
                let entryTitle = normalized(entry.title)
                guard !entryTitle.isEmpty else { return nil }

                var score = titleSimilarity(title, entryTitle)
                if !item.year.trimmed.isEmpty, entry.date.hasPrefix(item.year.trimmed) {
                    score += 0.18
                }
                if item.section == section(for: entry) {
                    score += 0.12
                }
                if !item.venue.trimmed.isEmpty,
                   entry.venue.localizedCaseInsensitiveContains(item.venue.trimmed)
                    || item.venue.localizedCaseInsensitiveContains(entry.venue.trimmed) {
                    score += 0.1
                }

                return score >= 0.35 ? (entry, score) : nil
            }
            .sorted { lhs, rhs in
                if lhs.1 == rhs.1 { return sortEntries(lhs.0, rhs.0) }
                return lhs.1 > rhs.1
            }
            .prefix(limit)
            .map(\.0)
    }

    func linkEvidence(_ entryID: EvidenceEntry.ID, to itemID: CVStructuredItem.ID) {
        guard let index = cvItems.firstIndex(where: { $0.id == itemID }) else { return }
        var ids = cvItems[index].linkedEvidenceIDs ?? []
        guard !ids.contains(entryID) else { return }
        ids.append(entryID)
        cvItems[index].linkedEvidenceIDs = ids
        saveStructuredCVItems()
        lastMessage = "Linked evidence to CV item."
    }

    func unlinkEvidence(_ entryID: EvidenceEntry.ID, from itemID: CVStructuredItem.ID) {
        guard let index = cvItems.firstIndex(where: { $0.id == itemID }) else { return }
        var ids = cvItems[index].linkedEvidenceIDs ?? []
        ids.removeAll { $0 == entryID }
        cvItems[index].linkedEvidenceIDs = ids.isEmpty ? nil : ids
        saveStructuredCVItems()
        lastMessage = "Unlinked evidence from CV item."
    }

    func linkBestEvidence(to itemID: CVStructuredItem.ID) {
        guard let item = cvItems.first(where: { $0.id == itemID }),
              let match = suggestedEvidenceMatches(for: item, limit: 1).first else {
            lastMessage = "No likely evidence match found for this CV item."
            return
        }

        linkEvidence(match.id, to: itemID)
    }

    func linkBestEvidenceToAll() {
        var linkedCount = 0

        for index in cvItems.indices where (cvItems[index].linkedEvidenceIDs ?? []).isEmpty {
            guard let match = suggestedEvidenceMatches(for: cvItems[index], limit: 1).first else {
                continue
            }
            cvItems[index].linkedEvidenceIDs = [match.id]
            linkedCount += 1
        }

        saveStructuredCVItems(showMessage: false)
        lastMessage = linkedCount == 0
            ? "No new evidence links were found."
            : "Auto-linked \(linkedCount) CV item(s) to likely evidence."
    }

    func normalizePublicationMetadata() {
        var changedCount = 0

        for index in cvItems.indices where cvItems[index].section == .publication {
            let basis = [
                cvItems[index].authors,
                cvItems[index].title,
                cvItems[index].venue,
                cvItems[index].source,
                cvItems[index].notes
            ]
            .joined(separator: " ")

            if cvItems[index].doi.trimmed.isEmpty,
               let doi = PublicationFormatter.doi(in: basis) {
                cvItems[index].doi = doi
                changedCount += 1
            }

            if cvItems[index].tenkClass.trimmed.isEmpty {
                cvItems[index].tenkClass = PublicationFormatter.tenkCategory(for: basis)
                changedCount += 1
            }

            if cvItems[index].peerReview == "check" || cvItems[index].peerReview.trimmed.isEmpty {
                cvItems[index].peerReview = inferredPeerReview(from: basis)
                changedCount += 1
            }

            if cvItems[index].sourceConfidence.trimmed.isEmpty {
                cvItems[index].sourceConfidence = confidenceValue(from: SourceConfidenceEvaluator.badge(for: basis, section: "Publication"))
                changedCount += 1
            }

        }

        saveStructuredCVItems(showMessage: false)
        lastMessage = changedCount == 0
            ? "Publication metadata already looked up to date."
            : "Updated \(changedCount) publication metadata field(s)."
    }

    func lastCVDraftSnapshotText() -> String {
        (try? String(contentsOf: cvLastExportSnapshotURL, encoding: .utf8)) ?? ""
    }

    func addEntry() -> UUID {
        var entry = EvidenceEntry()
        entry.title = "Untitled evidence"
        entry.date = ISO8601DateFormatter.shortDate.string(from: Date())
        entries.insert(entry, at: 0)
        save()
        return entry.id
    }

    func addEntry(_ entry: EvidenceEntry) -> UUID {
        entries.insert(entry, at: 0)
        save()
        return entry.id
    }

    func deleteEntry(id: EvidenceEntry.ID) {
        entries.removeAll { $0.id == id }
        save()
    }

    func filteredEntries(searchText: String) -> [EvidenceEntry] {
        let term = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty else {
            return entries.sorted(by: sortEntries)
        }

        return entries
            .filter { entry in
                [
                    entry.title,
                    entry.date,
                    entry.category,
                    entry.eventType,
                    entry.role,
                    entry.venue,
                    entry.status,
                    entry.tenureDimension,
                    entry.source,
                    entry.notes,
                    entry.attachments.map { "\($0.name) \($0.path)" }.joined(separator: " ")
                ]
                .joined(separator: " ")
                .localizedCaseInsensitiveContains(term)
            }
            .sorted(by: sortEntries)
    }

    func attachFiles(_ urls: [URL], to entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }

        let entryFolder = attachmentsRootURL.appendingPathComponent(entryID.uuidString)

        do {
            try FileManager.default.createDirectory(at: entryFolder, withIntermediateDirectories: true)

            for url in urls {
                let hasAccess = url.startAccessingSecurityScopedResource()
                defer {
                    if hasAccess {
                        url.stopAccessingSecurityScopedResource()
                    }
                }

                let destination = uniqueDestination(for: url.lastPathComponent, in: entryFolder)
                try FileManager.default.copyItem(at: url, to: destination)
                entries[index].attachments.append(
                    EvidenceAttachment(
                        name: destination.lastPathComponent,
                        path: relativePath(for: destination)
                    )
                )
            }

            save()
        } catch {
            lastMessage = "Attach failed: \(error.localizedDescription)"
        }
    }

    func revealAttachment(_ attachment: EvidenceAttachment) {
        let state = attachmentState(for: attachment)
        guard state.exists else {
            lastMessage = "Attachment is missing: \(attachment.name)."
            return
        }

        let url = state.url
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }

    func openAttachment(_ attachment: EvidenceAttachment) {
        let state = attachmentState(for: attachment)
        guard state.exists else {
            lastMessage = "Attachment is missing: \(attachment.name)."
            return
        }

        let url = state.url
        NSWorkspace.shared.open(url)
    }

    func attachmentState(for attachment: EvidenceAttachment) -> EvidenceAttachmentState {
        let url = resolvedAttachmentURL(for: attachment)
        var isDirectory = ObjCBool(false)
        let exists = FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory)
        return EvidenceAttachmentState(
            url: url,
            exists: exists,
            isDirectory: isDirectory.boolValue,
            isSupportedPreview: supportedAttachmentExtensions.contains(url.pathExtension.lowercased())
        )
    }

    func removeAttachment(_ attachment: EvidenceAttachment, from entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }
        entries[index].attachments.removeAll { $0.id == attachment.id }
        save()
    }

    func markEntryAsProofReady(_ entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }
        entries[index].cvReady = true
        if entries[index].status != "Filed" {
            entries[index].status = "Ready for CV"
        }
        save()
        lastMessage = "Marked evidence as proof-ready for CV and dossier use."
    }

    func extractAttachmentMetadata(for entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }

        let urls = entries[index].attachments
            .map(attachmentState(for:))
            .filter { $0.exists && !$0.isDirectory && $0.isSupportedPreview }
            .map(\.url)

        guard !urls.isEmpty else {
            lastMessage = "No readable PDF, image, or text attachments found for metadata extraction."
            return
        }

        do {
            let result = try EvidenceMetadataExtractor.extract(from: urls)
            guard !result.text.trimmed.isEmpty else {
                lastMessage = "No readable text found in the selected attachments."
                return
            }

            let parsed = ImportParser.parse(result.text)
            applyExtractedMetadata(parsed, extractedText: result.text, to: index)
            save()
            lastMessage = "Extracted metadata from \(result.fileCount) attachment(s)."
        } catch {
            lastMessage = "Metadata extraction failed: \(error.localizedDescription)"
        }
    }

    func revealAttachmentFolder(for entryID: EvidenceEntry.ID) {
        let folder = attachmentsRootURL.appendingPathComponent(entryID.uuidString)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            NSWorkspace.shared.open(folder)
        } catch {
            lastMessage = "Could not open attachment folder: \(error.localizedDescription)"
        }
    }

    func revealSourceArchiveFolder(for entryID: EvidenceEntry.ID) {
        let folder = sourceArchiveRootURL.appendingPathComponent(entryID.uuidString)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            NSWorkspace.shared.open(folder)
            lastMessage = "Opened source archive folder."
        } catch {
            lastMessage = "Could not open source archive folder: \(error.localizedDescription)"
        }
    }

    func revealWorkspace() {
        NSWorkspace.shared.activateFileViewerSelecting([workspaceURL])
    }

    func revealCVDraftFolder() {
        let folder = workspaceURL
            .appendingPathComponent("09_Tenure_Application_Dossier")
            .appendingPathComponent("Draft_Materials")

        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            NSWorkspace.shared.open(folder)
            lastMessage = "Opened CV draft export folder."
        } catch {
            lastMessage = "Could not open CV draft folder: \(error.localizedDescription)"
        }
    }

    func revealCurrentCVSource() {
        if FileManager.default.fileExists(atPath: currentCVSourceURL.path) {
            NSWorkspace.shared.activateFileViewerSelecting([currentCVSourceURL])
            lastMessage = "Revealed CV master source."
        } else {
            NSWorkspace.shared.open(currentCVSourceURL.deletingLastPathComponent())
            lastMessage = "CV master source was not found; opened template folder."
        }
    }

    func revealImportedCVSource() {
        if FileManager.default.fileExists(atPath: importedCVSourceURL.path) {
            NSWorkspace.shared.activateFileViewerSelecting([importedCVSourceURL])
            lastMessage = "Revealed imported CV source scan."
        } else {
            NSWorkspace.shared.open(importedCVSourceURL.deletingLastPathComponent())
            lastMessage = "Imported CV source scan was not found; opened tracker folder."
        }
    }

    func exportCSV() {
        do {
            try FileManager.default.createDirectory(
                at: exportURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let csv = CSVExporter.export(entries: entries.sorted(by: sortEntries))
            try csv.write(to: exportURL, atomically: true, encoding: .utf8)
            lastMessage = "Exported CSV to \(exportURL.lastPathComponent)."
            NSWorkspace.shared.activateFileViewerSelecting([exportURL])
        } catch {
            lastMessage = "Export failed: \(error.localizedDescription)"
        }
    }

    func exportCVMarkdown() {
        exportCVMarkdown(style: .academic)
    }

    func exportCVMarkdown(style: CVExportStyle) {
        do {
            let fileURL = workspaceURL
                .appendingPathComponent("10_Trackers_and_Templates")
                .appendingPathComponent(style.fileName)
            try FileManager.default.createDirectory(
                at: fileURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let markdown = CVMarkdownExporter.export(entries: entries, style: style)
            try markdown.write(to: fileURL, atomically: true, encoding: .utf8)
            if style == .academic {
                try markdown.write(to: cvExportURL, atomically: true, encoding: .utf8)
            }
            lastMessage = "Exported \(style.rawValue) to \(fileURL.lastPathComponent)."
            NSWorkspace.shared.activateFileViewerSelecting([fileURL])
        } catch {
            lastMessage = "CV export failed: \(error.localizedDescription)"
        }
    }

    func exportCitationList(style: CitationExportStyle) {
        do {
            let folder = workspaceURL
                .appendingPathComponent("09_Tenure_Application_Dossier")
                .appendingPathComponent("Draft_Materials")
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let fileURL = folder.appendingPathComponent(style.fileName)
            let markdown = PublicationCitationExporter.export(
                entries: entries,
                sourceText: currentCVSourceText(),
                structuredItems: cvItems.isEmpty
                    ? CVStructuredItemBuilder.build(sourceText: currentCVSourceText(), entries: entries)
                    : cvItems,
                style: style
            )
            try markdown.write(to: fileURL, atomically: true, encoding: .utf8)
            lastMessage = "Exported \(style.rawValue) citation list."
            NSWorkspace.shared.activateFileViewerSelecting([fileURL])
        } catch {
            lastMessage = "\(style.rawValue) citation export failed: \(error.localizedDescription)"
        }
    }

    func exportDossier() {
        do {
            try FileManager.default.createDirectory(
                at: dossierExportURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let markdown = DossierExporter.export(entries: reviewPeriodEntries())
            try markdown.write(to: dossierExportURL, atomically: true, encoding: .utf8)
            lastMessage = "Exported dossier builder."
            NSWorkspace.shared.activateFileViewerSelecting([dossierExportURL])
        } catch {
            lastMessage = "Dossier export failed: \(error.localizedDescription)"
        }
    }

    func exportTenureReadinessReport() {
        do {
            let folder = workspaceURL
                .appendingPathComponent("09_Tenure_Application_Dossier")
                .appendingPathComponent("Draft_Materials")
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

            let markdown = TenureReadinessReportExporter.export(entries: reviewPeriodEntries())
            let markdownURL = folder.appendingPathComponent("Tenure_Readiness_Report.md")
            let pdfURL = folder.appendingPathComponent("Tenure_Readiness_Report.pdf")

            try markdown.write(to: markdownURL, atomically: true, encoding: .utf8)
            let pdfData = try CVDocumentExporter.pdfData(from: markdown, theme: .aaltoClean)
            try pdfData.write(to: pdfURL, options: .atomic)

            lastMessage = "Exported tenure readiness report as Markdown and PDF."
            NSWorkspace.shared.activateFileViewerSelecting([pdfURL])
        } catch {
            lastMessage = "Tenure readiness report export failed: \(error.localizedDescription)"
        }
    }

    func currentCVSourceText() -> String {
        let combined = CVSourceImporter.combinedSourceText(
            workspaceURL: workspaceURL,
            masterURL: currentCVSourceURL,
            importedURL: importedCVSourceURL
        )
        if !combined.trimmed.isEmpty { return combined }

        let fallbackURL = workspaceURL
            .appendingPathComponent("10_Trackers_and_Templates")
            .appendingPathComponent("CVart_pages_extracted_text.txt")
        return (try? String(contentsOf: fallbackURL, encoding: .utf8)) ?? ""
    }

    func profileAutofillSuggestion() -> ProfileAutofillSuggestion {
        ProfileAutofillExtractor.suggestion(
            settings: connectorSettings,
            entries: entries,
            cvItems: cvItems,
            sourceText: currentCVSourceText()
        )
    }

    func saveProfileAutofill(_ suggestion: ProfileAutofillSuggestion) {
        var settings = connectorSettings
        settings.publicDisplayName = suggestion.name
        settings.profileTitle = suggestion.title
        settings.affiliation = suggestion.affiliation
        settings.researchThemes = suggestion.researchThemes
        settings.artisticThemes = suggestion.artisticThemes
        settings.teachingThemes = suggestion.teachingThemes
        settings.orcidURL = suggestion.orcidURL
        settings.googleScholarURL = suggestion.googleScholarURL
        settings.aaltoPeopleURL = suggestion.aaltoProfileURL
        settings.selectedPublications = suggestion.selectedPublications
        settings.selectedExhibitions = suggestion.selectedExhibitions
        saveConnectorSettings(settings)
        lastMessage = "Saved profile details for CVs, bios, and dossier drafts."
    }

    func cv2025SourceText() -> String {
        (try? String(contentsOf: cv2025SourceURL, encoding: .utf8)) ?? ""
    }

    func cv2025SummaryText() -> String {
        (try? String(contentsOf: cv2025SummaryURL, encoding: .utf8)) ?? ""
    }

    func generateCurrentCVDraft(variant: CVDraftVariant, options: CVBuildOptions = CVBuildOptions()) -> String {
        let sourceText = [
            connectorSettings.profileSourceText,
            currentCVSourceText()
        ]
        .filter { !$0.trimmed.isEmpty }
        .joined(separator: "\n\n")

        return CurrentCVBuilder.generate(
            variant: variant,
            sourceText: sourceText,
            cv2025Text: cv2025SourceText(),
            cv2025SummaryText: cv2025SummaryText(),
            cvItems: cvItems,
            appEntries: reviewPeriodEntries(),
            options: options
        )
    }

    func exportEditableCVDraft(_ draft: String, variant: CVDraftVariant, asRTF: Bool = false) {
        do {
            let format: CVExportFormat = asRTF ? .rtf : .markdown
            let fileURL = try CVDocumentExporter.export(
                draft: draft,
                variant: variant,
                theme: .currentPages,
                format: format,
                workspaceURL: workspaceURL,
                profilePicturePath: connectorSettings.profilePicturePath
            )
            try? saveCVDraftSnapshot(
                draft,
                variant: variant,
                theme: .currentPages,
                format: format.rawValue,
                exportedURL: fileURL,
                profilePicturePath: connectorSettings.profilePicturePath
            )
            lastMessage = "Exported editable \(format.rawValue) draft."
            NSWorkspace.shared.activateFileViewerSelecting([fileURL])
        } catch {
            lastMessage = "Editable CV export failed: \(error.localizedDescription)"
        }
    }

    func exportEditableCVDraft(
        _ draft: String,
        variant: CVDraftVariant,
        theme: CVDraftTheme,
        format: CVExportFormat
    ) {
        do {
            let fileURL = try CVDocumentExporter.export(
                draft: draft,
                variant: variant,
                theme: theme,
                format: format,
                workspaceURL: workspaceURL,
                profilePicturePath: connectorSettings.profilePicturePath
            )
            try? saveCVDraftSnapshot(
                draft,
                variant: variant,
                theme: theme,
                format: format.rawValue,
                exportedURL: fileURL,
                profilePicturePath: connectorSettings.profilePicturePath
            )
            lastMessage = "Exported \(format.rawValue) draft with \(theme.rawValue) theme."
            NSWorkspace.shared.activateFileViewerSelecting([fileURL])
        } catch {
            lastMessage = "\(format.rawValue) export failed: \(error.localizedDescription)"
        }
    }

    func exportEditableCVDraftBundle(_ draft: String, variant: CVDraftVariant, theme: CVDraftTheme) {
        let formats: [CVExportFormat] = [.markdown, .rtf, .word, .pdf]

        do {
            let exported = try formats.map { format in
                try CVDocumentExporter.export(
                    draft: draft,
                    variant: variant,
                    theme: theme,
                    format: format,
                    workspaceURL: workspaceURL,
                    profilePicturePath: connectorSettings.profilePicturePath
                )
            }
            try? saveCVDraftSnapshot(
                draft,
                variant: variant,
                theme: theme,
                format: "Export set",
                exportedURL: exported.first,
                profilePicturePath: connectorSettings.profilePicturePath
            )

            lastMessage = "Exported CV bundle: \(formats.map(\.rawValue).joined(separator: ", "))."
            if let first = exported.first {
                NSWorkspace.shared.activateFileViewerSelecting([first])
            }
        } catch {
            lastMessage = "CV bundle export failed: \(error.localizedDescription)"
        }
    }

    func exportDossierPacket(cvDraft: String, variant: CVDraftVariant, theme: CVDraftTheme) {
        do {
            let folder = try DossierPacketExporter.export(
                entries: reviewPeriodEntries(),
                draft: cvDraft,
                variant: variant,
                theme: theme,
                workspaceURL: workspaceURL
            )
            try? saveCVDraftSnapshot(
                cvDraft,
                variant: variant,
                theme: theme,
                format: "Dossier packet",
                exportedURL: folder,
                profilePicturePath: connectorSettings.profilePicturePath
            )
            lastMessage = "Exported dossier packet."
            NSWorkspace.shared.activateFileViewerSelecting([folder])
        } catch {
            lastMessage = "Dossier packet export failed: \(error.localizedDescription)"
        }
    }

    private func saveCVDraftSnapshot(
        _ draft: String,
        variant: CVDraftVariant,
        theme: CVDraftTheme,
        format: String,
        exportedURL: URL?,
        profilePicturePath: String? = nil
    ) throws {
        try FileManager.default.createDirectory(
            at: cvLastExportSnapshotURL.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        try draft.write(to: cvLastExportSnapshotURL, atomically: true, encoding: .utf8)

        try FileManager.default.createDirectory(at: cvVersionHistoryRootURL, withIntermediateDirectories: true)
        let stamp = DateFormatter.fileStamp.string(from: Date())
        let safeVariant = variant.fileStem
        let fileURL = cvVersionHistoryRootURL
            .appendingPathComponent("\(stamp)_\(safeVariant)_snapshot.md")
        try draft.write(to: fileURL, atomically: true, encoding: .utf8)

        let layout = CVDocumentExporter.layoutReport(for: draft, theme: theme, profilePicturePath: profilePicturePath)
        let version = CVVersionSnapshot(
            createdAt: stamp,
            variant: variant.rawValue,
            theme: theme.rawValue,
            format: format,
            wordCount: draft.split(whereSeparator: \.isWhitespace).count,
            pageCount: layout.pageCount,
            draftPath: relativePath(for: fileURL),
            exportedPath: exportedURL.map(relativePath(for:)) ?? ""
        )

        cvVersions.insert(version, at: 0)
        cvVersions = Array(cvVersions.sorted { $0.createdAt > $1.createdAt }.prefix(120))
        saveCVVersions()
    }

    func copyToClipboard(_ text: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
        lastMessage = "Copied draft to clipboard."
    }

    func exportBioDraft(_ bio: String, useCase: BioUseCase, lengthPreset: BioLengthPreset) {
        do {
            let folder = workspaceURL
                .appendingPathComponent("09_Tenure_Application_Dossier")
                .appendingPathComponent("Draft_Materials")
                .appendingPathComponent("Bio_Drafts")
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let stamp = DateFormatter.fileStamp.string(from: Date())
            let fileURL = folder.appendingPathComponent("\(stamp)_Bio_\(useCase.fileStem)_\(lengthPreset.rawValue).md")
            let markdown = """
            # \(useCase.rawValue)

            \(bio)
            """
            try markdown.write(to: fileURL, atomically: true, encoding: .utf8)
            lastMessage = "Exported \(useCase.rawValue.lowercased()) to \(fileURL.lastPathComponent)."
            NSWorkspace.shared.activateFileViewerSelecting([fileURL])
        } catch {
            lastMessage = "Bio export failed: \(error.localizedDescription)"
        }
    }

    func exportDossierNarrative(_ sections: [DossierNarrativeSection]) {
        do {
            let folder = workspaceURL
                .appendingPathComponent("09_Tenure_Application_Dossier")
                .appendingPathComponent("Draft_Materials")
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let fileURL = folder.appendingPathComponent("Dossier_Narrative_Draft.md")
            let markdown = """
            # Dossier Narrative Draft

            \(DossierNarrativeBuilder.markdown(from: sections))
            """
            try markdown.write(to: fileURL, atomically: true, encoding: .utf8)
            lastMessage = "Exported dossier narrative draft."
            NSWorkspace.shared.activateFileViewerSelecting([fileURL])
        } catch {
            lastMessage = "Dossier narrative export failed: \(error.localizedDescription)"
        }
    }

    func exportMonthlyReview(month: String) {
        do {
            let fileURL = workspaceURL
                .appendingPathComponent("10_Trackers_and_Templates")
                .appendingPathComponent("Monthly_Review_\(month).md")
            try FileManager.default.createDirectory(
                at: fileURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let markdown = CVMarkdownExporter.monthlyReview(entries: entries, month: month)
            try markdown.write(to: fileURL, atomically: true, encoding: .utf8)
            lastMessage = "Exported monthly review for \(month)."
            NSWorkspace.shared.activateFileViewerSelecting([fileURL])
        } catch {
            lastMessage = "Monthly review export failed: \(error.localizedDescription)"
        }
    }

    func availableMonths() -> [String] {
        let months = entries
            .compactMap { entry -> String? in
                guard entry.date.count >= 7 else { return nil }
                return String(entry.date.prefix(7))
            }
        return Array(Set(months)).sorted(by: >)
    }

    func entries(forMonth month: String) -> [EvidenceEntry] {
        entries
            .filter { $0.date.hasPrefix(month) }
            .sorted(by: sortEntries)
    }

    func incompleteEntries() -> [EvidenceEntry] {
        entries
            .filter { !$0.completeness.missing.isEmpty }
            .sorted { lhs, rhs in
                lhs.completeness.score < rhs.completeness.score
            }
    }

    func reviewPeriodEntries() -> [EvidenceEntry] {
        entries
            .filter { isInReviewPeriod($0) }
            .sorted(by: sortEntries)
    }

    func backgroundContextEntries() -> [EvidenceEntry] {
        entries
            .filter { !isInReviewPeriod($0) }
            .sorted(by: sortEntries)
    }

    func reviewPeriodLabel() -> String {
        let start = connectorSettings.reviewPeriodStartDate.trimmed
        let end = connectorSettings.reviewPeriodEndDate.trimmed
        if start.isEmpty && end.isEmpty { return "All dates" }
        if end.isEmpty { return "Since \(start)" }
        if start.isEmpty { return "Until \(end)" }
        return "\(start) to \(end)"
    }

    func isInReviewPeriod(_ entry: EvidenceEntry) -> Bool {
        guard let entryDate = normalizedDateKey(from: entry.date) else {
            return true
        }

        if let start = normalizedDateKey(from: connectorSettings.reviewPeriodStartDate),
           entryDate < start {
            return false
        }

        if let end = normalizedDateKey(from: connectorSettings.reviewPeriodEndDate),
           entryDate > end {
            return false
        }

        return true
    }

    func scannedDraftEntriesForReview() -> [EvidenceEntry] {
        entries
            .filter { entry in
                (entry.status == "Needs confirmation" || entry.status == "Needs review")
                    && !entry.cvReady
                    && (entry.source.localizedCaseInsensitiveContains("Imported from")
                        || entry.source.localizedCaseInsensitiveContains("configured document folder")
                        || entry.source.localizedCaseInsensitiveContains("workspace evidence folder")
                        || entry.source.localizedCaseInsensitiveContains("00_Inbox")
                        || entry.notes.localizedCaseInsensitiveContains("Pre-filled fields"))
            }
            .sorted { $0.date > $1.date }
    }

    func acceptScannedDraft(_ entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }
        let hasProof = TenureGapAnalyzer.hasProof(entries[index])
        if hasProof && entries[index].completeness.score >= 70 {
            entries[index].status = "Ready for CV"
            entries[index].cvReady = true
            appendReviewNote("Scan reviewed and accepted for CV/dossier use.", to: index)
        } else {
            entries[index].status = "Evidence missing"
            entries[index].cvReady = false
            appendReviewNote("Scan reviewed. Keep it, but add missing proof or details before using it in the dossier.", to: index)
        }
        save()
        lastMessage = "Reviewed scanned draft."
    }

    func ignoreScannedDraft(_ entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }
        entries[index].status = "Ignored"
        entries[index].cvReady = false
        appendReviewNote("Ignored during scan review. Kept only to avoid re-importing the same file.", to: index)
        save()
        lastMessage = "Ignored scanned draft."
    }

    func markScannedDraftProofMissing(_ entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }
        entries[index].status = "Evidence missing"
        entries[index].cvReady = false
        appendReviewNote("Scan reviewed. This looks relevant, but proof is missing or weak; attach a source file or source URL before using it.", to: index)
        save()
        lastMessage = "Marked scanned draft as proof missing."
    }

    func cvReviewQueueItems() -> [CVReviewItem] {
        CVReviewQueueBuilder.items(from: currentCVSourceText())
    }

    func addReviewQueueItemAsEvidence(_ item: CVReviewItem) -> UUID {
        var entry = ImportParser.parse(item.line)
        entry.status = "Needs confirmation"
        entry.source = "CV review queue: \(item.sourceHint)"
        entry.notes = """
        Review reason: \(item.reason)
        CV section: \(item.section)

        Original line:
        \(item.line)
        """
        if entry.title == "Imported evidence" || entry.title.trimmed.isEmpty {
            entry.title = String(item.line.prefix(120))
        }
        return addEntry(entry)
    }

    func suggestedEvidenceItems() -> [SuggestedEvidenceItem] {
        SuggestedEvidenceScanner.scan(workspaceURL: workspaceURL, existingEntries: entries)
    }

    func revealSuggestedEvidenceFolder() {
        let folder = workspaceURL.appendingPathComponent(SuggestedEvidenceScanner.folderPath)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            NSWorkspace.shared.open(folder)
            lastMessage = "Opened suggested evidence folder."
        } catch {
            lastMessage = "Could not open suggested evidence folder: \(error.localizedDescription)"
        }
    }

    @discardableResult
    func createDemoSuggestions() -> Int {
        let folder = workspaceURL.appendingPathComponent(SuggestedEvidenceScanner.folderPath)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let pendingDemoTitles = Set(suggestedEvidenceItems().map(\.entry.title).filter {
                $0.localizedCaseInsensitiveContains("Demo:")
            })
            var writtenCount = 0

            for sample in demoSuggestionSamples {
                let demoTitle = ImportParser.parse(sample.text).title
                if pendingDemoTitles.contains(demoTitle) {
                    continue
                }
                let destination = uniqueDestination(for: sample.fileName, in: folder)
                try sample.text.write(to: destination, atomically: true, encoding: .utf8)
                writtenCount += 1
            }

            lastMessage = writtenCount == 0
                ? "The three demo suggestions are already waiting in the review inbox."
                : "Added \(writtenCount) demo suggestion(s) to the review inbox."
            return writtenCount
        } catch {
            lastMessage = "Could not add demo suggestions: \(error.localizedDescription)"
            return 0
        }
    }

    func exportTinyDemoCV() {
        do {
            let fileURL = workspaceURL
                .appendingPathComponent("10_Trackers_and_Templates")
                .appendingPathComponent("Proofessor_Demo_CV.md")
            try FileManager.default.createDirectory(
                at: fileURL.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let entries = demoCVEntries()
            let markdown = CVMarkdownExporter.export(entries: entries, style: .academic)
            try markdown.write(to: fileURL, atomically: true, encoding: .utf8)
            lastMessage = "Exported a tiny demo CV to \(fileURL.lastPathComponent)."
            NSWorkspace.shared.activateFileViewerSelecting([fileURL])
        } catch {
            lastMessage = "Demo CV export failed: \(error.localizedDescription)"
        }
    }

    func acceptSuggestedEvidence(_ item: SuggestedEvidenceItem) -> UUID {
        var entry = item.entry
        entry.status = item.hasDuplicates ? "Needs confirmation" : "Needs review"
        entry.notes = entry.notes.trimmed.isEmpty ? item.rawText.trimmed : entry.notes
        let id = addEntry(entry)
        moveSuggestionFile(item.sourceURL, to: "Accepted")
        lastMessage = item.hasDuplicates
            ? "Imported suggested evidence with possible duplicates to review."
            : "Imported suggested evidence."
        return id
    }

    func acceptSuggestedEvidence(_ item: SuggestedEvidenceItem, mergeInto keeperID: EvidenceEntry.ID) -> UUID {
        let importedID = acceptSuggestedEvidence(item)
        mergeDuplicateEntry(importedID, into: keeperID)
        lastMessage = "Imported suggested evidence and merged it into the existing record."
        return keeperID
    }

    func dismissSuggestedEvidence(_ item: SuggestedEvidenceItem) {
        moveSuggestionFile(item.sourceURL, to: "Dismissed")
        lastMessage = "Dismissed suggested evidence."
    }

    @discardableResult
    func markSuggestedEvidenceProofMissing(_ item: SuggestedEvidenceItem) -> UUID {
        var entry = item.entry
        entry.status = "Evidence missing"
        entry.cvReady = false
        entry.notes = mergedText(
            entry.notes.trimmed.isEmpty ? item.rawText.trimmed : entry.notes,
            "Review queue marked this as useful, but proof is missing. Add an attachment, source URL, programme page, official confirmation, or other verifiable source before using it in the dossier.",
            separator: "\n\n"
        )
        let id = addEntry(entry)
        moveSuggestionFile(item.sourceURL, to: "Proof_Missing")
        lastMessage = "Kept suggested evidence and marked proof as missing."
        return id
    }

    func open(_ url: URL) {
        NSWorkspace.shared.open(url)
    }

    func profileLinks() -> [ProfileLink] {
        ProfileLink.links(from: connectorSettings)
    }

    func sortedEntries() -> [EvidenceEntry] {
        entries.sorted(by: sortEntries)
    }

    @discardableResult
    func scanInbox() -> Int {
        let result = InboxScanner.scan(workspaceURL: workspaceURL, existingEntries: entries)
        guard !result.entries.isEmpty else {
            lastMessage = result.skippedCount > 0
                ? "Inbox scan found no new files. Skipped \(result.skippedCount) already imported file(s)."
                : "Inbox scan found no importable files."
            return 0
        }

        entries.insert(contentsOf: result.entries, at: 0)
        save()
        lastMessage = "Inbox scan imported \(result.entries.count) file(s); skipped \(result.skippedCount)."
        return result.entries.count
    }

    @discardableResult
    func scanDocumentSources() -> Int {
        let inboxResult = InboxScanner.scan(workspaceURL: workspaceURL, existingEntries: entries)
        let workspaceResult = InboxScanner.scanWorkspaceEvidenceFolders(
            workspaceURL: workspaceURL,
            existingEntries: entries + inboxResult.entries
        )
        let folderURLs = connectorSettings.documentScanFolders
            .map { URL(fileURLWithPath: NSString(string: $0).expandingTildeInPath) }
            .filter { FileManager.default.fileExists(atPath: $0.path) }
        let folderResult = InboxScanner.scanFolders(
            folderURLs,
            workspaceURL: workspaceURL,
            existingEntries: entries + inboxResult.entries + workspaceResult.entries,
            sourceLabel: "configured document folder"
        )

        let imported = inboxResult.entries + workspaceResult.entries + folderResult.entries
        let skipped = inboxResult.skippedCount + workspaceResult.skippedCount + folderResult.skippedCount
        guard !imported.isEmpty else {
            lastMessage = skipped > 0
                ? "Deep document scan found no new files. Skipped \(skipped) already imported file(s)."
                : "Deep document scan found no importable files in 00_Inbox, tenure workspace folders, or configured document folders."
            return 0
        }

        entries.insert(contentsOf: imported, at: 0)
        save()
        lastMessage = "Deep document scan imported \(imported.count) file(s) from inbox, workspace folders, and configured folders; skipped \(skipped)."
        return imported.count
    }

    @discardableResult
    func scanConfiguredDocumentFolders() -> Int {
        let folderURLs = connectorSettings.documentScanFolders
            .map { URL(fileURLWithPath: NSString(string: $0).expandingTildeInPath) }
            .filter { FileManager.default.fileExists(atPath: $0.path) }

        guard !folderURLs.isEmpty else {
            lastMessage = "No document scan folder has been configured yet."
            return 0
        }

        let result = InboxScanner.scanFolders(
            folderURLs,
            workspaceURL: workspaceURL,
            existingEntries: entries,
            sourceLabel: "configured document folder"
        )

        guard !result.entries.isEmpty else {
            lastMessage = result.skippedCount > 0
                ? "Document folder scan found no new files. Skipped \(result.skippedCount) already imported file(s)."
                : "Document folder scan found no importable files."
            return 0
        }

        entries.insert(contentsOf: result.entries, at: 0)
        save()
        lastMessage = "Document folder scan imported \(result.entries.count) file(s); skipped \(result.skippedCount)."
        return result.entries.count
    }

    func fileAttachments(for entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }
        let destinationFolder = filingFolder(for: entries[index])

        do {
            try FileManager.default.createDirectory(at: destinationFolder, withIntermediateDirectories: true)
            var copiedCount = 0
            var missingCount = 0

            for attachmentIndex in entries[index].attachments.indices {
                let attachment = entries[index].attachments[attachmentIndex]
                let state = attachmentState(for: attachment)
                guard state.exists else {
                    missingCount += 1
                    continue
                }

                let destinationURL = uniqueDestination(for: attachment.name, in: destinationFolder)
                try FileManager.default.copyItem(at: state.url, to: destinationURL)
                entries[index].attachments[attachmentIndex].path = relativePath(for: destinationURL)
                entries[index].attachments[attachmentIndex].name = destinationURL.lastPathComponent
                copiedCount += 1
            }

            if copiedCount > 0 {
                entries[index].status = "Filed"
            }
            save()
            lastMessage = missingCount == 0
                ? "Copied evidence to \(relativePath(for: destinationFolder))."
                : "Copied \(copiedCount) file(s); \(missingCount) attachment(s) were missing."
        } catch {
            lastMessage = "Filing failed: \(error.localizedDescription)"
        }
    }

    func archiveSources(for entryID: EvidenceEntry.ID) {
        guard let index = entries.firstIndex(where: { $0.id == entryID }) else { return }
        let entry = entries[index]
        let urls = URLTools.extractURLs(from: entry.source + "\n" + entry.notes)

        guard !urls.isEmpty else {
            lastMessage = "No source URLs found in Source or Notes."
            return
        }

        Task {
            await archive(urls: urls, for: entryID, title: entry.title)
        }
    }

    func snapshotProfiles() {
        let links = profileLinks().filter(\.snapshotEligible)

        Task {
            let stamp = DateFormatter.fileStamp.string(from: Date())
            let folder = profileSnapshotRootURL.appendingPathComponent(stamp)
            var attachments: [EvidenceAttachment] = []
            var sourceLines: [String] = []

            do {
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

                for link in links {
                    sourceLines.append("\(link.title): \(link.url.absoluteString)")
                    do {
                        let saved = try await downloadSnapshot(from: link.url, into: folder, stem: link.title)
                        attachments.append(EvidenceAttachment(name: saved.lastPathComponent, path: relativePath(for: saved)))
                    } catch {
                        sourceLines.append("\(link.title) snapshot failed: \(error.localizedDescription)")
                    }
                }

                let noteURL = folder.appendingPathComponent("profile_snapshot_metadata.md")
                let note = """
                # Public Profile Snapshot

                Date: \(stamp)

                \(sourceLines.map { "- \($0)" }.joined(separator: "\n"))
                """
                try note.write(to: noteURL, atomically: true, encoding: .utf8)
                attachments.append(EvidenceAttachment(name: noteURL.lastPathComponent, path: relativePath(for: noteURL)))

                var entry = EvidenceEntry()
                entry.date = String(stamp.prefix(10))
                entry.category = "Visibility"
                entry.eventType = "Public profile snapshot"
                entry.title = "Public profile snapshots"
                entry.role = "Profile owner"
                entry.venue = links.map(\.title).joined(separator: ", ")
                entry.tenureDimension = "Impact and service"
                entry.status = "Filed"
                entry.source = sourceLines.joined(separator: "\n")
                entry.notes = "Snapshot of public profile pages for tenure evidence."
                entry.cvReady = false
                entry.attachments = attachments

                entries.insert(entry, at: 0)
                save()
                lastMessage = "Saved profile snapshots."
            } catch {
                lastMessage = "Profile snapshot failed: \(error.localizedDescription)"
            }
        }
    }

    func duplicateCandidates(for entry: EvidenceEntry) -> [EvidenceEntry] {
        let title = normalized(entry.title)
        guard !title.isEmpty else { return [] }

        return entries.filter { candidate in
            guard candidate.id != entry.id else { return false }
            let candidateTitle = normalized(candidate.title)
            guard !candidateTitle.isEmpty else { return false }

            if candidateTitle == title {
                return true
            }

            if !entry.date.trimmed.isEmpty,
               entry.date == candidate.date,
               titleSimilarity(title, candidateTitle) > 0.62 {
                return true
            }

            return titleSimilarity(title, candidateTitle) > 0.82
        }
    }

    func mergeDuplicateEntry(_ duplicateID: EvidenceEntry.ID, into keeperID: EvidenceEntry.ID) {
        guard duplicateID != keeperID,
              let keeperIndex = entries.firstIndex(where: { $0.id == keeperID }),
              let duplicateIndex = entries.firstIndex(where: { $0.id == duplicateID }) else {
            return
        }

        let duplicate = entries[duplicateIndex]

        entries[keeperIndex].date = preferred(entries[keeperIndex].date, duplicate.date)
        entries[keeperIndex].category = preferred(entries[keeperIndex].category, duplicate.category)
        entries[keeperIndex].eventType = preferred(entries[keeperIndex].eventType, duplicate.eventType)
        entries[keeperIndex].title = preferred(entries[keeperIndex].title, duplicate.title)
        entries[keeperIndex].role = preferred(entries[keeperIndex].role, duplicate.role)
        entries[keeperIndex].venue = preferred(entries[keeperIndex].venue, duplicate.venue)
        entries[keeperIndex].tenureDimension = preferred(entries[keeperIndex].tenureDimension, duplicate.tenureDimension)
        entries[keeperIndex].status = mergedStatus(entries[keeperIndex].status, duplicate.status)
        entries[keeperIndex].source = mergedText(entries[keeperIndex].source, duplicate.source, separator: "\n")
        entries[keeperIndex].notes = mergedText(
            entries[keeperIndex].notes,
            duplicate.notes.trimmed.isEmpty ? "Merged duplicate record: \(duplicate.title)" : duplicate.notes,
            separator: "\n\n"
        )
        entries[keeperIndex].cvReady = entries[keeperIndex].cvReady || duplicate.cvReady

        let existingAttachmentPaths = Set(entries[keeperIndex].attachments.map(\.path))
        let newAttachments = duplicate.attachments.filter { !existingAttachmentPaths.contains($0.path) }
        entries[keeperIndex].attachments.append(contentsOf: newAttachments)

        let mergedTitle = entries[keeperIndex].title
        entries.removeAll { $0.id == duplicateID }
        replaceLinkedEvidenceID(duplicateID, with: keeperID)
        save()
        saveStructuredCVItems(showMessage: false)
        lastMessage = "Merged duplicate evidence into \(mergedTitle)."
    }

    private func section(for entry: EvidenceEntry) -> CVStructuredSection {
        switch entry.category {
        case "Publication":
            return .publication
        case "Talk":
            return .talk
        case "Teaching":
            return .teaching
        case "Service":
            return .service
        case "Funding":
            return .grant
        case "Artistic Output":
            return .artisticWork
        case "Supervision":
            return .supervision
        case "Visibility":
            return .visibility
        default:
            return .other
        }
    }

    private func category(for section: CVStructuredSection) -> String {
        switch section {
        case .publication:
            return "Publication"
        case .talk:
            return "Talk"
        case .teaching:
            return "Teaching"
        case .service:
            return "Service"
        case .grant:
            return "Funding"
        case .artisticWork:
            return "Artistic Output"
        case .supervision:
            return "Supervision"
        case .visibility:
            return "Visibility"
        default:
            return "Other"
        }
    }

    private func dimension(for section: CVStructuredSection) -> String {
        switch section {
        case .teaching, .supervision:
            return "Teaching"
        case .service, .visibility:
            return "Impact and service"
        default:
            return "Research/artistic work"
        }
    }

    private func defaultTemplates(for section: CVStructuredSection) -> [String] {
        switch section {
        case .teaching, .supervision:
            return [CVDraftVariant.currentPages.rawValue, CVDraftVariant.teachingFocused.rawValue, CVDraftVariant.tenure.rawValue]
        case .artisticWork:
            return [CVDraftVariant.currentPages.rawValue, CVDraftVariant.artFocused.rawValue, CVDraftVariant.tenure.rawValue, CVDraftVariant.publicProfile.rawValue]
        case .publication, .grant:
            return [CVDraftVariant.currentPages.rawValue, CVDraftVariant.researchFocused.rawValue, CVDraftVariant.tenure.rawValue, CVDraftVariant.tenk.rawValue]
        case .talk, .visibility:
            return [CVDraftVariant.currentPages.rawValue, CVDraftVariant.researchFocused.rawValue, CVDraftVariant.tenure.rawValue, CVDraftVariant.publicProfile.rawValue]
        default:
            return [CVDraftVariant.currentPages.rawValue, CVDraftVariant.generalAcademic.rawValue, CVDraftVariant.tenure.rawValue]
        }
    }

    private func normalizedDate(from value: String) -> String {
        let trimmed = value.trimmed
        if trimmed.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil {
            return trimmed
        }
        if trimmed.range(of: #"^\d{4}$"#, options: .regularExpression) != nil {
            return "\(trimmed)-01-01"
        }
        return ISO8601DateFormatter.shortDate.string(from: Date())
    }

    private func normalizedDateKey(from value: String) -> String? {
        let trimmed = value.trimmed
        if trimmed.isEmpty { return nil }
        if trimmed.range(of: #"^\d{4}-\d{2}-\d{2}$"#, options: .regularExpression) != nil {
            return trimmed
        }
        if trimmed.range(of: #"^\d{4}-\d{2}$"#, options: .regularExpression) != nil {
            return "\(trimmed)-01"
        }
        if trimmed.range(of: #"^\d{4}$"#, options: .regularExpression) != nil {
            return "\(trimmed)-01-01"
        }
        return nil
    }

    private func appendReviewNote(_ note: String, to index: Int) {
        guard !entries[index].notes.localizedCaseInsensitiveContains(note) else { return }
        entries[index].notes = entries[index].notes.trimmed.isEmpty
            ? note
            : entries[index].notes + "\n\(note)"
    }

    private func applyExtractedMetadata(_ parsed: EvidenceEntry, extractedText: String, to index: Int) {
        let parsedDate = parsed.date.trimmed
        let currentDate = entries[index].date.trimmed
        if !parsedDate.isEmpty && (currentDate.isEmpty || currentDate == ISO8601DateFormatter.shortDate.string(from: Date())) {
            entries[index].date = parsedDate
        }
        entries[index].title = preferred(entries[index].title, parsed.title, replacing: ["Imported evidence"])
        entries[index].eventType = preferred(entries[index].eventType, parsed.eventType)
        entries[index].role = preferred(entries[index].role, parsed.role)
        entries[index].venue = preferred(entries[index].venue, parsed.venue)

        if entries[index].category == "Other" || entries[index].category.trimmed.isEmpty {
            entries[index].category = parsed.category
        }

        if entries[index].tenureDimension == "All" || entries[index].tenureDimension.trimmed.isEmpty {
            entries[index].tenureDimension = parsed.tenureDimension
        }

        if entries[index].source.trimmed.isEmpty {
            entries[index].source = "Attachment metadata extraction"
        } else if !parsed.source.trimmed.isEmpty,
                  parsed.source.localizedCaseInsensitiveContains("source url"),
                  !entries[index].source.localizedCaseInsensitiveContains(parsed.source.trimmed) {
            entries[index].source += "\n\(parsed.source.trimmed)"
        }

        let excerpt = extractedText
            .components(separatedBy: .newlines)
            .map(\.trimmed)
            .filter { !$0.isEmpty }
            .prefix(14)
            .joined(separator: "\n")

        guard !excerpt.trimmed.isEmpty,
              !entries[index].notes.localizedCaseInsensitiveContains("Extracted attachment text") else {
            return
        }

        let addition = """

        Extracted attachment text:
        \(excerpt)
        """
        entries[index].notes = entries[index].notes.trimmed.isEmpty
            ? addition.trimmed
            : entries[index].notes + addition
    }

    private func preferred(_ current: String, _ candidate: String) -> String {
        preferred(current, candidate, replacing: [])
    }

    private func preferred(_ current: String, _ candidate: String, replacing placeholders: [String]) -> String {
        let currentText = current.trimmed
        let candidateText = candidate.trimmed

        guard !candidateText.isEmpty else { return current }
        if currentText.isEmpty || currentText == "Untitled evidence" || currentText == "Imported evidence" || placeholders.contains(currentText) {
            return candidate
        }
        return current
    }

    private func mergedStatus(_ lhs: String, _ rhs: String) -> String {
        let rank = [
            "Evidence missing": 0,
            "Needs confirmation": 1,
            "Needs review": 2,
            "Ready for CV": 3,
            "Filed": 4
        ]
        return (rank[lhs, default: 0] >= rank[rhs, default: 0]) ? lhs : rhs
    }

    private func mergedText(_ lhs: String, _ rhs: String, separator: String) -> String {
        let left = lhs.trimmed
        let right = rhs.trimmed

        guard !left.isEmpty else { return right }
        guard !right.isEmpty else { return left }

        let normalizedLeft = normalized(left)
        let normalizedRight = normalized(right)
        if normalizedLeft.contains(normalizedRight) {
            return left
        }
        if normalizedRight.contains(normalizedLeft) {
            return right
        }

        return [left, right].joined(separator: separator)
    }

    private func replaceLinkedEvidenceID(_ oldID: EvidenceEntry.ID, with newID: EvidenceEntry.ID) {
        for index in cvItems.indices {
            var ids = cvItems[index].linkedEvidenceIDs ?? []
            guard ids.contains(oldID) else { continue }
            ids = ids.map { $0 == oldID ? newID : $0 }

            var seen = Set<EvidenceEntry.ID>()
            let deduped = ids.filter { seen.insert($0).inserted }
            cvItems[index].linkedEvidenceIDs = deduped.isEmpty ? nil : deduped
        }
    }

    private struct DemoSuggestionSample {
        var fileName: String
        var text: String
    }

    private var demoSuggestionSamples: [DemoSuggestionSample] {
        [
            DemoSuggestionSample(
                fileName: "demo_invited_keynote.md",
                text: """
                Title: Demo: Invited keynote on digital learning
                Date: 2026-04-15
                Venue: Nordic Learning Futures Symposium
                Role: Keynote speaker
                Source: https://example.org/demo/keynote

                The public programme confirms an invited keynote, host, date, and international audience.
                Aalto dimension: Impact and service
                Proof found: public programme URL and invitation text.
                What is missing: upload the real invitation email or event PDF if this were your record.
                """
            ),
            DemoSuggestionSample(
                fileName: "demo_course_feedback.md",
                text: """
                Title: Demo: Course feedback and curriculum revision
                Date: 2026-03-20
                Course: Creative AI Studio
                Venue: Aalto University
                Role: Responsible teacher
                Source: https://example.org/demo/course-feedback

                Course feedback was analysed and used to revise assignments, learning outcomes, and assessment rubrics.
                Aalto dimension: Teaching
                Proof found: feedback summary and course development note.
                What is missing: attach the official feedback export or MyCourses summary.
                """
            ),
            DemoSuggestionSample(
                fileName: "demo_research_grant.md",
                text: """
                Title: Demo: Research Council of Finland project grant
                Date: 2026-05-01
                Funder: Research Council of Finland
                Amount: EUR 250000
                Role: Principal investigator
                Source: https://example.org/demo/grant

                Funding decision confirms competitive research funding, role, funder, budget, and project title.
                Aalto dimension: Research/artistic work
                Proof found: decision letter URL.
                What is missing: attach the official decision letter before dossier use.
                """
            )
        ]
    }

    private func demoCVEntries() -> [EvidenceEntry] {
        let acceptedDemoEntries = entries
            .filter { $0.title.localizedCaseInsensitiveContains("Demo:") }
            .sorted(by: sortEntries)

        if !acceptedDemoEntries.isEmpty {
            return acceptedDemoEntries
        }

        return demoSuggestionSamples.map { sample in
            var entry = ImportParser.parse(sample.text)
            entry.status = "Ready for CV"
            entry.cvReady = true
            entry.source = "Demo source generated by Proofessor"
            return entry
        }
    }

    private var supportedAttachmentExtensions: Set<String> {
        ["pdf", "docx", "doc", "pages", "pptx", "key", "xlsx", "csv", "txt", "rtf", "jpg", "jpeg", "png", "heic", "md", "bib", "bibtex", "ris"]
    }

    private func resolvedAttachmentURL(for attachment: EvidenceAttachment) -> URL {
        if attachment.path.hasPrefix("/") {
            return URL(fileURLWithPath: attachment.path)
        }

        return workspaceURL.appendingPathComponent(attachment.path)
    }

    private func sanitizeLoadedEntries() {
        for index in entries.indices {
            if !EvidenceOptions.categories.contains(entries[index].category) {
                entries[index].category = "Other"
            }

            if !EvidenceOptions.statuses.contains(entries[index].status) {
                entries[index].status = "Needs review"
            }

            if !EvidenceOptions.dimensions.contains(entries[index].tenureDimension) {
                entries[index].tenureDimension = "All"
            }

            if entries[index].title.trimmed.isEmpty {
                entries[index].title = "Untitled evidence"
            }

            entries[index].attachments = sanitizedAttachments(entries[index].attachments)
        }
    }

    private func sanitizedAttachments(_ attachments: [EvidenceAttachment]) -> [EvidenceAttachment] {
        var seenIDs = Set<UUID>()
        var seenPaths = Set<String>()
        var sanitized: [EvidenceAttachment] = []

        for attachment in attachments {
            let path = attachment.path.trimmed
            guard !path.isEmpty else { continue }

            let normalizedPath = path
                .replacingOccurrences(of: "\\", with: "/")
                .replacingOccurrences(of: "//", with: "/")
            guard seenPaths.insert(normalizedPath).inserted else { continue }

            let id = seenIDs.insert(attachment.id).inserted ? attachment.id : UUID()
            let name = attachment.name.trimmed.isEmpty
                ? URL(fileURLWithPath: normalizedPath).lastPathComponent
                : attachment.name

            sanitized.append(EvidenceAttachment(id: id, name: name, path: normalizedPath))
        }

        return sanitized
    }

    private func archive(urls: [URL], for entryID: EvidenceEntry.ID, title: String) async {
        let stamp = DateFormatter.fileStamp.string(from: Date())
        let folder = sourceArchiveRootURL
            .appendingPathComponent(entryID.uuidString)
            .appendingPathComponent(stamp)

        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            var attachments: [EvidenceAttachment] = []
            var notes: [String] = ["# Source URL Archive", "", "Entry: \(title)", "Date: \(stamp)", ""]

            for url in urls {
                do {
                    let saved = try await downloadSnapshot(from: url, into: folder, stem: URLTools.safeFileStem(for: url))
                    attachments.append(EvidenceAttachment(name: saved.lastPathComponent, path: relativePath(for: saved)))
                    notes.append("- Saved \(url.absoluteString) as \(saved.lastPathComponent)")
                } catch {
                    notes.append("- Failed \(url.absoluteString): \(error.localizedDescription)")
                }
            }

            let metadataURL = folder.appendingPathComponent("archive_metadata.md")
            try notes.joined(separator: "\n").write(to: metadataURL, atomically: true, encoding: .utf8)
            attachments.append(EvidenceAttachment(name: metadataURL.lastPathComponent, path: relativePath(for: metadataURL)))

            if let index = entries.firstIndex(where: { $0.id == entryID }) {
                entries[index].attachments.append(contentsOf: attachments)
                save()
                lastMessage = "Archived \(attachments.count) source files."
            }
        } catch {
            lastMessage = "Source archive failed: \(error.localizedDescription)"
        }
    }

    private func inferredPeerReview(from text: String) -> String {
        let lower = text.lowercased()
        if lower.contains("peer-reviewed") || lower.contains("peer reviewed") || lower.contains("refereed") {
            return "yes"
        }

        if lower.contains("journal") || lower.contains("proceedings") {
            return "check"
        }

        return "not stated"
    }

    private func confidenceValue(from badge: String) -> String {
        if badge.localizedCaseInsensitiveContains("high") { return "high" }
        if badge.localizedCaseInsensitiveContains("profile") { return "profile" }
        if badge.localizedCaseInsensitiveContains("review") { return "review" }
        return "medium"
    }

    private func peerReview(from text: String) -> String {
        let lower = text.lowercased()
        if lower.contains("peer-reviewed") || lower.contains("peer reviewed") || lower.contains("refereed") {
            return "yes"
        }
        if lower.contains("journal") || lower.contains("proceedings") {
            return "check"
        }
        return "not stated"
    }

    private func downloadSnapshot(from url: URL, into folder: URL, stem: String) async throws -> URL {
        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue("Mozilla/5.0 Proofessor", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await URLSession.shared.data(for: request)
        let mimeType = (response as? HTTPURLResponse)?.mimeType ?? "text/html"
        let fileExtension = mimeType.contains("pdf") ? "pdf" : "html"
        let destination = uniqueDestination(for: "\(stem).\(fileExtension)", in: folder)
        try data.write(to: destination, options: .atomic)
        return destination
    }

    private func filingFolder(for entry: EvidenceEntry) -> URL {
        let base: String

        switch entry.category {
        case "Talk":
            if entry.eventType.localizedCaseInsensitiveContains("conference") {
                base = "08_Talks_Visibility_and_Recognition/Conference_Talks"
            } else if entry.eventType.localizedCaseInsensitiveContains("invited") || entry.role.localizedCaseInsensitiveContains("invited") {
                base = "08_Talks_Visibility_and_Recognition/Invited_Talks"
            } else {
                base = "08_Talks_Visibility_and_Recognition/External_Visibility"
            }
        case "Artistic Output", "Publication":
            base = entry.category == "Publication" ? "03_Research_Artistic_Work/Publications" : "03_Research_Artistic_Work/Exhibitions"
        case "Funding":
            base = "05_Funding_and_Grants/Applications_Submitted"
        case "Teaching":
            base = "04_Teaching_and_Pedagogy/Teaching_Portfolio"
        case "Supervision":
            base = "07_Supervision_and_Examination/Theses_Supervised"
        case "Service":
            base = "06_Impact_Service_and_Leadership/Committee_and_Service"
        case "Visibility":
            base = "08_Talks_Visibility_and_Recognition/External_Visibility"
        default:
            base = "00_Inbox"
        }

        return workspaceURL.appendingPathComponent(base)
    }

    private func normalized(_ value: String) -> String {
        value
            .lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }

    private func titleSimilarity(_ lhs: String, _ rhs: String) -> Double {
        let left = Set(lhs.split(separator: " ").map(String.init))
        let right = Set(rhs.split(separator: " ").map(String.init))
        guard !left.isEmpty, !right.isEmpty else { return 0 }
        let intersection = left.intersection(right).count
        let union = left.union(right).count
        return Double(intersection) / Double(union)
    }

    private func sortEntries(_ lhs: EvidenceEntry, _ rhs: EvidenceEntry) -> Bool {
        if lhs.date == rhs.date {
            return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
        }
        return lhs.date > rhs.date
    }

    private func uniqueDestination(for fileName: String, in folder: URL) -> URL {
        let base = URL(fileURLWithPath: fileName).deletingPathExtension().lastPathComponent
        let ext = URL(fileURLWithPath: fileName).pathExtension
        var candidate = folder.appendingPathComponent(fileName)
        var counter = 2

        while FileManager.default.fileExists(atPath: candidate.path) {
            let nextName = ext.isEmpty ? "\(base)-\(counter)" : "\(base)-\(counter).\(ext)"
            candidate = folder.appendingPathComponent(nextName)
            counter += 1
        }

        return candidate
    }

    private func moveSuggestionFile(_ url: URL, to folderName: String) {
        let destinationFolder = workspaceURL
            .appendingPathComponent(SuggestedEvidenceScanner.folderPath)
            .appendingPathComponent(folderName)

        do {
            try FileManager.default.createDirectory(at: destinationFolder, withIntermediateDirectories: true)
            let destination = uniqueDestination(for: url.lastPathComponent, in: destinationFolder)
            try FileManager.default.moveItem(at: url, to: destination)
        } catch {
            lastMessage = "Could not move suggestion file: \(error.localizedDescription)"
        }
    }

    private func relativePath(for url: URL) -> String {
        let workspacePath = workspaceURL.standardizedFileURL.path
        let filePath = url.standardizedFileURL.path
        guard filePath.hasPrefix(workspacePath + "/") else { return filePath }
        return String(filePath.dropFirst(workspacePath.count + 1))
    }
}

enum TenureWorkspace {
    static let defaultWorkspaceFolderName = "ProofessorWorkspace"

    static func locate(
        environment: [String: String] = ProcessInfo.processInfo.environment,
        bundle: Bundle = .main,
        currentDirectoryPath: String = FileManager.default.currentDirectoryPath,
        fileManager: FileManager = .default
    ) -> URL {
        if let overrideURL = workspaceURL(from: environment["PROOFESSOR_WORKSPACE"], fileManager: fileManager)
            ?? workspaceURL(from: environment["TENURE_WORKSPACE"], fileManager: fileManager) {
            return overrideURL
        }

        if let path = bundle.object(forInfoDictionaryKey: "ProofessorWorkspacePath") as? String,
           let bundledURL = workspaceURL(from: path, fileManager: fileManager) {
            return bundledURL
        }

        if let path = bundle.object(forInfoDictionaryKey: "TenureWorkspacePath") as? String,
           let bundledURL = workspaceURL(from: path, fileManager: fileManager) {
            return bundledURL
        }

        let current = URL(fileURLWithPath: currentDirectoryPath)
        if current.lastPathComponent == "TenureEvidenceApp" || current.lastPathComponent == "ProofessorApp" {
            let sharedRoot = current.deletingLastPathComponent()
            let sourceTemplate = sharedRoot.appendingPathComponent("EmptyWorkspaceTemplate", isDirectory: true)
            return directoryExists(sourceTemplate, fileManager: fileManager) ? sourceTemplate : sharedRoot
        }

        if isWorkspace(current, fileManager: fileManager) {
            return current
        }

        let sourceTemplate = current.appendingPathComponent("EmptyWorkspaceTemplate", isDirectory: true)
        if directoryExists(sourceTemplate, fileManager: fileManager) {
            return sourceTemplate
        }

        return preparedUserWorkspace(bundle: bundle, fileManager: fileManager)
    }

    static func preparedUserWorkspace(bundle: Bundle = .main, fileManager: FileManager = .default) -> URL {
        let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? fileManager.homeDirectoryForCurrentUser.appendingPathComponent("Documents", isDirectory: true)
        return preparedUserWorkspace(
            documentsURL: documentsURL,
            templateURL: bundle.url(forResource: "EmptyWorkspaceTemplate", withExtension: nil),
            fileManager: fileManager
        )
    }

    static func preparedUserWorkspace(
        documentsURL: URL,
        templateURL: URL?,
        fileManager: FileManager = .default
    ) -> URL {
        let workspaceURL = documentsURL.appendingPathComponent(defaultWorkspaceFolderName, isDirectory: true)

        if !directoryExists(workspaceURL, fileManager: fileManager),
           let templateURL {
            try? fileManager.copyItem(at: templateURL, to: workspaceURL)
        }

        ensureMinimumWorkspace(at: workspaceURL, fileManager: fileManager)
        return workspaceURL
    }

    private static func workspaceURL(from path: String?, fileManager: FileManager) -> URL? {
        guard let path = path?.trimmingCharacters(in: .whitespacesAndNewlines), !path.isEmpty else {
            return nil
        }

        let url = URL(fileURLWithPath: path, isDirectory: true)
        return directoryExists(url, fileManager: fileManager) ? url : nil
    }

    private static func isWorkspace(_ url: URL, fileManager: FileManager) -> Bool {
        directoryExists(url.appendingPathComponent("10_Trackers_and_Templates", isDirectory: true), fileManager: fileManager)
    }

    private static func directoryExists(_ url: URL, fileManager: FileManager) -> Bool {
        var isDirectory: ObjCBool = false
        return fileManager.fileExists(atPath: url.path, isDirectory: &isDirectory) && isDirectory.boolValue
    }

    private static func ensureMinimumWorkspace(at workspaceURL: URL, fileManager: FileManager) {
        let directories = [
            "00_Inbox/Suggested_Evidence",
            "00_Inbox/Proofessor_Attachments",
            "00_Inbox/Source_URL_Archive",
            "00_Inbox/Profile_Snapshots",
            "01_Process_and_Criteria/Tenure_Criteria",
            "02_Profile_CV_and_Portfolios/CV_Source_Files",
            "02_Profile_CV_and_Portfolios/Profile_Photos",
            "03_Research_Artistic_Work/Publications",
            "03_Research_Artistic_Work/Projects",
            "03_Research_Artistic_Work/Artistic_Work",
            "04_Teaching_and_Pedagogy/Course_Materials",
            "04_Teaching_and_Pedagogy/Teaching_Evaluations",
            "04_Teaching_and_Pedagogy/Pedagogical_Training",
            "05_Funding_and_Grants/Calls_and_Opportunities",
            "05_Funding_and_Grants/Applications_Submitted",
            "06_Impact_Service_and_Leadership/Committee_and_Service",
            "06_Impact_Service_and_Leadership/Leadership",
            "07_Supervision_and_Examination/Theses_Supervised",
            "07_Supervision_and_Examination/Theses_Examined",
            "08_Talks_Visibility_and_Recognition/Invited_Talks",
            "08_Talks_Visibility_and_Recognition/Conference_Talks",
            "08_Talks_Visibility_and_Recognition/Media_and_Public_Engagement",
            "09_Tenure_Application_Dossier/Draft_Materials",
            "09_Tenure_Application_Dossier/Packet_Exports",
            "10_Trackers_and_Templates/CV_Source_Extractions",
            "10_Trackers_and_Templates/CV_Version_History"
        ]

        for directory in directories {
            try? fileManager.createDirectory(
                at: workspaceURL.appendingPathComponent(directory, isDirectory: true),
                withIntermediateDirectories: true
            )
        }

        writeDefaultFileIfMissing(
            workspaceURL.appendingPathComponent("10_Trackers_and_Templates/tenure_app_entries.json"),
            contents: "[]\n",
            fileManager: fileManager
        )
        writeDefaultFileIfMissing(
            workspaceURL.appendingPathComponent("10_Trackers_and_Templates/cv_structured_items.json"),
            contents: "[]\n",
            fileManager: fileManager
        )
        writeDefaultFileIfMissing(
            workspaceURL.appendingPathComponent("10_Trackers_and_Templates/automation_connector_settings.json"),
            contents: "{}\n",
            fileManager: fileManager
        )
        writeDefaultFileIfMissing(
            workspaceURL.appendingPathComponent("10_Trackers_and_Templates/CV_Master_Source.md"),
            contents: "# CV Master Source\n\nAdd CV source material here or import it through the app.\n",
            fileManager: fileManager
        )
    }

    private static func writeDefaultFileIfMissing(_ url: URL, contents: String, fileManager: FileManager) {
        guard !fileManager.fileExists(atPath: url.path) else { return }
        try? contents.write(to: url, atomically: true, encoding: .utf8)
    }
}

private extension ISO8601DateFormatter {
    static let shortDate: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
}

private extension DateFormatter {
    static let fileStamp: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd_HHmmss"
        return formatter
    }()
}
