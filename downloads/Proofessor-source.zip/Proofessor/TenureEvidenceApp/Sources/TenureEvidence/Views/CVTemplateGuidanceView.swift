import SwiftUI

struct CVTemplateGuidanceView: View {
    let template: CVDraftVariant
    let selectedTheme: CVDraftTheme
    let applyTheme: (CVDraftTheme) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Label("Template Guidance", systemImage: "lightbulb")
                    .font(.headline)
                Spacer()
                Text(selectedTheme.rawValue)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 6))
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 230), alignment: .top)], alignment: .leading, spacing: 10) {
                guidanceCard("Optimizes for", image: "target", text: template.optimizesFor)
                guidanceCard("Cut first", image: "scissors", text: template.cutAdvice)
                guidanceCard("Design posture", image: "paintbrush", text: template.designAdvice)
            }

            VStack(alignment: .leading, spacing: 7) {
                Text(template == .tenk ? "Allowed Design" : "Graphical Design Options")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)

                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(template.allowedThemes) { theme in
                            Button {
                                applyTheme(theme)
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: theme.systemImage)
                                    Text(theme.rawValue)
                                }
                                .font(.caption)
                                .padding(.horizontal, 9)
                                .padding(.vertical, 6)
                                .background(
                                    theme == selectedTheme ? Color.accentColor.opacity(0.16) : Color.secondary.opacity(0.1),
                                    in: RoundedRectangle(cornerRadius: 6)
                                )
                            }
                            .buttonStyle(.plain)
                            .help(theme.description)
                        }
                    }
                }

                Text(selectedTheme.designUse)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Text(selectedTheme.personalizationHint)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private func guidanceCard(_ title: String, image: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Label(title, systemImage: image)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            Text(text)
                .font(.caption)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(9)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: 6))
    }
}
