import SwiftUI

struct CVLineEditorView: View {
    @Binding var items: [CVDraftLineItem]
    let template: CVDraftVariant
    let onApply: () -> Void
    @State private var expandedReasonIDs: Set<CVDraftLineItem.ID> = []

    private let confidenceValues = ["high", "medium", "profile", "review"]
    private let relevanceValues = ["essential", "keep", "optional", "omit"]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Line-Level Editing", systemImage: "list.bullet.rectangle")
                    .font(.headline)
                Text("\(items.filter(\.included).count) included · \(items.filter(\.verified).count) verified")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button {
                    markIncludedVerified()
                } label: {
                    Label("Verify Included", systemImage: "checkmark.seal")
                }
                .help("Mark every included CV line as verified")

                Button(action: onApply) {
                    Label("Apply Lines", systemImage: "arrow.down.doc")
                }
                .keyboardShortcut("l", modifiers: [.command])
                .help("Rebuild the editable draft from these line rows")
            }

            Text("Edit each line calmly: include, verify, set confidence, rank template relevance, move it up or down, and use the info button to see why it appears.")
                .font(.caption)
                .foregroundStyle(.secondary)

            List {
                ForEach($items) { item in
                    lineRow(item)
                }
            }
            .listStyle(.inset)
            .frame(minHeight: 500)
        }
    }

    private func lineRow(_ item: Binding<CVDraftLineItem>) -> some View {
        let id = item.wrappedValue.id
        let isReasonExpanded = expandedReasonIDs.contains(id)
        let reason = item.wrappedValue.inclusionReason

        return VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 8) {
                Toggle("", isOn: item.included)
                    .labelsHidden()
                    .help("Include or exclude this line from the CV draft")

                TextField("CV line", text: item.text, axis: .vertical)
                    .font(item.wrappedValue.isStructural ? .headline : .body)
                    .textFieldStyle(.plain)

                Toggle("", isOn: item.verified)
                    .labelsHidden()
                    .help("Mark this CV line as verified")

                Picker("Confidence", selection: item.sourceConfidence) {
                    ForEach(confidenceValues, id: \.self) { value in
                        Text(value.capitalized).tag(value)
                    }
                }
                .labelsHidden()
                .frame(width: 112)
                .help("Source confidence for this CV line")

                Picker("Relevance", selection: item.templateRelevance) {
                    ForEach(relevanceValues, id: \.self) { value in
                        Text(value.capitalized).tag(value)
                    }
                }
                .labelsHidden()
                .frame(width: 112)
                .help("How important this line is for the selected \(template.rawValue) template")

                Button {
                    toggleReason(id)
                } label: {
                    Image(systemName: isReasonExpanded ? "info.circle.fill" : "info.circle")
                }
                .buttonStyle(.borderless)
                .help(reason.isEmpty ? "Show why this line appears in the draft" : reason)

                VStack(spacing: 4) {
                    Button {
                        move(id, by: -1)
                    } label: {
                        Image(systemName: "chevron.up")
                    }
                    .buttonStyle(.borderless)
                    .help("Move this CV line up")

                    Button {
                        move(id, by: 1)
                    } label: {
                        Image(systemName: "chevron.down")
                    }
                    .buttonStyle(.borderless)
                    .help("Move this CV line down")
                }
            }

            Text(item.wrappedValue.section)
                .font(.caption)
                .foregroundStyle(.secondary)

            if isReasonExpanded {
                Text(reason.isEmpty ? "No inclusion note recorded for this line yet." : reason)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.quaternary.opacity(0.22), in: RoundedRectangle(cornerRadius: 6))
            }
        }
        .padding(.vertical, 5)
    }

    private func markIncludedVerified() {
        for index in items.indices where items[index].included {
            items[index].verified = true
        }
    }

    private func move(_ id: UUID, by offset: Int) {
        guard let index = items.firstIndex(where: { $0.id == id }) else { return }
        let target = index + offset
        guard items.indices.contains(target) else { return }
        items.swapAt(index, target)
        normalizeOrders()
    }

    private func toggleReason(_ id: CVDraftLineItem.ID) {
        if expandedReasonIDs.contains(id) {
            expandedReasonIDs.remove(id)
        } else {
            expandedReasonIDs.insert(id)
        }
    }

    private func normalizeOrders() {
        for index in items.indices {
            items[index].order = index
        }
    }
}
