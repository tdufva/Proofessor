import SwiftUI

struct CVReviewQueueView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @State private var items: [CVReviewItem] = []

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("CV Review Queue", systemImage: "checklist")
                    .font(.title2.weight(.semibold))
                Spacer()
                Text("\(items.count) items")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Button {
                    reload()
                } label: {
                    Label("Refresh", systemImage: "arrow.triangle.2.circlepath")
                }
                .help("Refresh uncertain lines from the CV master source")
                Button {
                    store.revealCurrentCVSource()
                } label: {
                    Label("Master Source", systemImage: "doc.text.magnifyingglass")
                }
                .help("Reveal the CV master source in Finder")
                Button("Close") {
                    dismiss()
                }
            }

            if items.isEmpty {
                ContentUnavailableView(
                    "No Review Items",
                    systemImage: "checkmark.seal",
                    description: Text("No uncertain CV source lines were found.")
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List(items) { item in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(item.section)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.secondary)
                            Spacer()
                            Text(item.sourceHint)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }

                        Text(item.line)
                            .font(.body)
                            .textSelection(.enabled)

                        HStack {
                            Label(item.reason, systemImage: "exclamationmark.magnifyingglass")
                                .font(.caption)
                                .foregroundStyle(.orange)
                            Spacer()
                            Button {
                                store.copyToClipboard(item.line)
                            } label: {
                                Label("Copy", systemImage: "doc.on.doc")
                            }
                            .help("Copy this source line")

                            Button {
                                _ = store.addReviewQueueItemAsEvidence(item)
                            } label: {
                                Label("Make Evidence", systemImage: "plus.circle")
                            }
                            .help("Create a reviewable evidence record from this source line")
                        }
                    }
                    .padding(.vertical, 6)
                }
            }

            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(18)
        .frame(minWidth: 820, minHeight: 620)
        .onAppear(perform: reload)
    }

    private func reload() {
        items = store.cvReviewQueueItems()
    }
}
