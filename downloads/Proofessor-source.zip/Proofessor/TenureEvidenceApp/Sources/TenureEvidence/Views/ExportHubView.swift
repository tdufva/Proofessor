import SwiftUI

struct ExportHubView: View {
    @ObservedObject var store: EvidenceStore
    let openCV: () -> Void
    let openVerify: () -> Void
    let openDossier: () -> Void
    let openMonthlyReview: () -> Void
    let openProfiles: () -> Void
    let openGuide: () -> Void

    private var missingProofCount: Int {
        store.entries.filter { entry in
            entry.attachments.isEmpty && !entry.source.localizedCaseInsensitiveContains("http")
        }.count
    }

    private var reviewCount: Int {
        store.entries.filter { $0.status == "Needs review" || $0.status == "Needs confirmation" }.count
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                PageHeader(
                    title: "Export",
                    subtitle: "Prepare sendable material: CV drafts, dossier packets, evidence indexes, monthly reviews, and source folders.",
                    systemImage: "square.and.arrow.up"
                )

                StatusStrip(items: [
                    StatusStripItem(text: "\(store.entries.count) evidence records", systemImage: "folder", tone: .neutral),
                    StatusStripItem(text: "\(store.entries.filter(\.cvReady).count) ready to use", systemImage: "checkmark.circle", tone: .success),
                    StatusStripItem(text: "\(reviewCount) to review", systemImage: "checklist", tone: reviewCount == 0 ? .success : .warning),
                    StatusStripItem(text: "\(missingProofCount) proof needed", systemImage: "paperclip", tone: missingProofCount == 0 ? .success : .warning)
                ])

                ActionPanel(
                    title: "Main Exports",
                    subtitle: "Start here when you need something to send, file, or review.",
                    systemImage: "doc.on.doc"
                ) {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 320), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.md) {
                        exportCard(
                            title: "Build CV",
                            text: "Open the CV builder, choose purpose and style, preview, then export Pages, Word, PDF, or Markdown.",
                            image: "doc.text.magnifyingglass",
                            primary: true,
                            action: openCV
                        )

                        exportCard(
                            title: "Dossier Builder",
                            text: "Prepare a tenure packet with CV, evidence index, attachments, and a cover checklist.",
                            image: "shippingbox",
                            primary: false,
                            action: openDossier
                        )

                        exportCard(
                            title: "Evidence CSV",
                            text: "Export the whole evidence register for spreadsheet review or backup.",
                            image: "tablecells",
                            primary: false,
                            action: store.exportCSV
                        )

                        exportCard(
                            title: "Readiness Report",
                            text: "Export a printable tenure gap report with strong evidence, weak evidence, proof needed, and next actions.",
                            image: "doc.text.magnifyingglass",
                            primary: false,
                            action: store.exportTenureReadinessReport
                        )

                        exportCard(
                            title: "Monthly Review",
                            text: "Review a month of activity before updating evidence and CV material.",
                            image: "calendar",
                            primary: false,
                            action: openMonthlyReview
                        )
                    }
                }

                ActionPanel(
                    title: "Before Sending",
                    subtitle: "These checks catch the usual dossier problems before export.",
                    systemImage: "checkmark.seal"
                ) {
                    VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                        checklistRow(
                            title: "Evidence has proof",
                            value: missingProofCount == 0 ? "OK" : "\(missingProofCount) need attachment or source URL",
                            tone: missingProofCount == 0 ? .success : .warning,
                            actionTitle: "Open Verify & File",
                            action: openVerify
                        )

                        checklistRow(
                            title: "Imported items are reviewed",
                            value: reviewCount == 0 ? "OK" : "\(reviewCount) still needs review",
                            tone: reviewCount == 0 ? .success : .warning,
                            actionTitle: "Open Verify & File",
                            action: openVerify
                        )

                        checklistRow(
                            title: "Profile snapshots",
                            value: "Refresh public links when visibility matters",
                            tone: .neutral,
                            actionTitle: "Open Profiles",
                            action: openProfiles
                        )
                    }
                }

                ActionPanel(
                    title: "More",
                    subtitle: "Less frequent export and orientation tools.",
                    systemImage: "ellipsis.circle"
                ) {
                    HStack(spacing: AppDesign.Spacing.sm) {
                        Button(action: openGuide) {
                            Label("Guide", systemImage: "questionmark.circle")
                        }
                        .help("Open the app guide")

                        Button(action: store.revealCVDraftFolder) {
                            Label("Draft Folder", systemImage: "folder")
                        }
                        .help("Open the CV draft export folder")

                        Button(action: store.revealWorkspace) {
                            Label("Tenure Folder", systemImage: "folder.badge.gearshape")
                        }
                        .help("Reveal the main Tenure folder")

                        Spacer()
                    }
                }
            }
            .padding(AppDesign.Spacing.xl)
            .frame(maxWidth: 1180, alignment: .leading)
        }
    }

    private func exportCard(title: String, text: String, image: String, primary: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                Image(systemName: image)
                    .font(.title2)
                    .foregroundStyle(primary ? .white : .secondary)

                Text(title)
                    .font(.headline)

                Text(text)
                    .font(.caption)
                    .foregroundStyle(primary ? .white.opacity(0.86) : .secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(AppDesign.Spacing.md)
            .frame(maxWidth: .infinity, minHeight: 132, alignment: .topLeading)
            .background(primary ? Color.accentColor : Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
            .foregroundStyle(primary ? .white : .primary)
        }
        .buttonStyle(.plain)
        .help(title)
    }

    private func checklistRow(
        title: String,
        value: String,
        tone: StatusChip.Tone,
        actionTitle: String,
        action: @escaping () -> Void
    ) -> some View {
        HStack(spacing: AppDesign.Spacing.md) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.headline)
                Text(value)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()
            StatusChip(text: tone == .success ? "Ready" : "Check", systemImage: tone == .success ? "checkmark.circle" : "exclamationmark.circle", tone: tone)

            Button(action: action) {
                Text(actionTitle)
            }
            .help(actionTitle)
        }
        .padding(AppDesign.Spacing.sm)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
    }
}
