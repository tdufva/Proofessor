import SwiftUI

enum AppDesign {
    static let academyGold = Color(red: 0.78, green: 0.65, blue: 0.35)
    static let academyGreen = Color(red: 0.12, green: 0.23, blue: 0.19)
    static let academyInk = Color(red: 0.96, green: 0.94, blue: 0.89)
    static let academyBlack = Color(red: 0.05, green: 0.06, blue: 0.06)

    enum Spacing {
        static let xs: CGFloat = 4
        static let sm: CGFloat = 8
        static let md: CGFloat = 12
        static let lg: CGFloat = 18
        static let xl: CGFloat = 24
    }

    enum Radius {
        static let sm: CGFloat = 6
        static let md: CGFloat = 8
    }

    static var appBackground: some ShapeStyle {
        LinearGradient(
            colors: [
                academyGreen.opacity(0.52),
                academyBlack,
                Color.black.opacity(0.95)
            ],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }

    static var cardFill: some ShapeStyle {
        academyInk.opacity(0.075)
    }

    static var quietFill: some ShapeStyle {
        academyInk.opacity(0.052)
    }

    static var warningFill: some ShapeStyle {
        Color.orange.opacity(0.10)
    }

    static var successFill: some ShapeStyle {
        Color.green.opacity(0.10)
    }
}

struct PageHeader: View {
    var title: String
    var subtitle: String?
    var systemImage: String
    var trailing: AnyView?

    init(title: String, subtitle: String? = nil, systemImage: String, trailing: AnyView? = nil) {
        self.title = title
        self.subtitle = subtitle
        self.systemImage = systemImage
        self.trailing = trailing
    }

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .top, spacing: AppDesign.Spacing.md) {
                headerText
                Spacer(minLength: AppDesign.Spacing.lg)
                trailing
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                headerText
                trailing
            }
        }
        .accessibilityElement(children: .combine)
    }

    private var headerText: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
            Label(title, systemImage: systemImage)
                .font(.system(.largeTitle, design: .serif).weight(.semibold))
                .labelStyle(.titleAndIcon)

            if let subtitle {
                Text(subtitle)
                    .font(.callout)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

struct ActionPanel<Content: View>: View {
    var title: String
    var subtitle: String?
    var systemImage: String
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(title: title, subtitle: subtitle, systemImage: systemImage)
            content
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }
}

struct StatusStrip: View {
    var items: [StatusStripItem]

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: AppDesign.Spacing.sm) {
                ForEach(items) { item in
                    StatusChip(text: item.text, systemImage: item.systemImage, tone: item.tone)
                }
                Spacer(minLength: 0)
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 132), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                ForEach(items) { item in
                    StatusChip(text: item.text, systemImage: item.systemImage, tone: item.tone)
                }
            }
        }
        .accessibilityElement(children: .combine)
    }
}

struct StatusStripItem: Identifiable, Hashable {
    var id: String { text + (systemImage ?? "") }
    var text: String
    var systemImage: String?
    var tone: StatusChip.Tone = .neutral
}

struct AppEmptyState: View {
    var title: String
    var message: String
    var systemImage: String
    var actionTitle: String?
    var actionImage: String?
    var action: (() -> Void)?

    var body: some View {
        ContentUnavailableView {
            Label(title, systemImage: systemImage)
        } description: {
            Text(message)
        } actions: {
            if let actionTitle, let action {
                Button(action: action) {
                    Label(actionTitle, systemImage: actionImage ?? "arrow.right")
                }
                .buttonStyle(.borderedProminent)
                .keyboardShortcut(.defaultAction)
                .help(actionTitle)
            }
        }
        .padding(AppDesign.Spacing.xl)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .accessibilityElement(children: .contain)
    }
}

struct AppSectionHeader: View {
    var title: String
    var subtitle: String?
    var systemImage: String
    var trailing: AnyView?

    init(title: String, subtitle: String? = nil, systemImage: String, trailing: AnyView? = nil) {
        self.title = title
        self.subtitle = subtitle
        self.systemImage = systemImage
        self.trailing = trailing
    }

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: AppDesign.Spacing.sm) {
                sectionText
                Spacer()
                trailing
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                sectionText
                trailing
            }
        }
        .accessibilityElement(children: .combine)
    }

    private var sectionText: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
            Label(title, systemImage: systemImage)
                .font(.system(.title3, design: .serif).weight(.semibold))
            if let subtitle {
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

struct StatusChip: View {
    enum Tone {
        case neutral
        case success
        case warning
        case danger
        case accent

        var foreground: Color {
            switch self {
            case .neutral:
                .secondary
            case .success:
                .green
            case .warning:
                .orange
            case .danger:
                .red
            case .accent:
                AppDesign.academyGold
            }
        }

        var fill: Color {
            switch self {
            case .neutral:
                Color.secondary.opacity(0.10)
            case .success:
                Color.green.opacity(0.14)
            case .warning:
                Color.orange.opacity(0.16)
            case .danger:
                Color.red.opacity(0.14)
            case .accent:
                AppDesign.academyGold.opacity(0.18)
            }
        }
    }

    var text: String
    var systemImage: String?
    var tone: Tone = .neutral

    var body: some View {
        Label {
            Text(text)
                .lineLimit(1)
                .minimumScaleFactor(0.85)
        } icon: {
            if let systemImage {
                Image(systemName: systemImage)
            }
        }
        .font(.caption.weight(.medium))
        .foregroundStyle(tone.foreground)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(tone.fill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
        .accessibilityLabel(text)
    }
}

struct PrimaryEmptyState: View {
    var title: String
    var message: String
    var systemImage: String
    var actionTitle: String
    var actionImage: String
    var action: () -> Void

    var body: some View {
        AppEmptyState(
            title: title,
            message: message,
            systemImage: systemImage,
            actionTitle: actionTitle,
            actionImage: actionImage,
            action: action
        )
    }
}
