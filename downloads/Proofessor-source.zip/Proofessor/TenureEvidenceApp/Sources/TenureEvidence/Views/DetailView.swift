import SwiftUI
import UniformTypeIdentifiers

struct DetailView: View {
    @Binding var entry: EvidenceEntry
    @ObservedObject var store: EvidenceStore
    @State private var importingFiles = false
    @State private var dropIsTargeted = false
    @State private var selectedPreviewAttachmentID: EvidenceAttachment.ID?
    @State private var showSourceDetails = false
    @State private var showNotesEditor = false
    @FocusState private var titleIsFocused: Bool

    private var selectedPreviewAttachment: EvidenceAttachment? {
        guard let selectedPreviewAttachmentID else { return entry.attachments.first }
        return entry.attachments.first { $0.id == selectedPreviewAttachmentID } ?? entry.attachments.first
    }

    var body: some View {
        ScrollView {
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .top, spacing: AppDesign.Spacing.lg) {
                    recordColumn
                        .frame(minWidth: 560, maxWidth: 780, alignment: .topLeading)
                    evidencePreviewPane
                        .frame(width: 390, alignment: .topLeading)
                }

                VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                    recordColumn
                    evidencePreviewPane
                }
            }
            .padding(24)
            .frame(maxWidth: 1200, alignment: .leading)
        }
        .background(AppDesign.appBackground)
        .fileImporter(
            isPresented: $importingFiles,
            allowedContentTypes: [.item],
            allowsMultipleSelection: true
        ) { result in
            switch result {
            case .success(let urls):
                store.attachFiles(urls, to: entry.id)
            case .failure(let error):
                store.lastMessage = "Import failed: \(error.localizedDescription)"
            }
        }
        .onChange(of: entry) { _, _ in
            store.save()
        }
        .onDrop(of: [.fileURL], isTargeted: $dropIsTargeted) { providers in
            handleDrop(providers)
        }
        .onAppear(perform: keepPreviewSelectionValid)
        .onChange(of: entry.attachments) { _, _ in
            keepPreviewSelectionValid()
        }
    }

    private var recordColumn: some View {
        VStack(alignment: .leading, spacing: 18) {
            header
            completenessSection
            autofillReviewSection
            duplicateSection
            checklistSection
            coreFields
            notesSection
            attachmentsSection
            footer
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            TextField("Title", text: $entry.title)
                .font(.title2.weight(.semibold))
                .textFieldStyle(.plain)
                .focused($titleIsFocused)
                .accessibilityLabel("Evidence title")

            HStack(spacing: 10) {
                StatusChip(text: entry.category, systemImage: "tag", tone: .neutral)
                StatusChip(text: entry.displayStatus, systemImage: "circle.dashed", tone: statusTone(entry.status))
                Toggle("Ready to use", isOn: $entry.cvReady)
                    .toggleStyle(.checkbox)
                    .help("Mark this record as ready to include in CV exports")

                Picker("Status", selection: $entry.status) {
                    ForEach(EvidenceOptions.statuses, id: \.self) { status in
                        Text(EvidenceOptions.displayStatus(for: status)).tag(status)
                    }
                }
                .labelsHidden()
                .frame(width: 190)
                .help("Set the review or filing status for this record")

                Spacer()

                Button {
                    store.fileAttachments(for: entry.id)
                } label: {
                    Label("File Evidence", systemImage: "folder.badge.gearshape")
                }
                .disabled(entry.attachments.isEmpty || !entry.attachments.contains { store.attachmentState(for: $0).exists })
                .keyboardShortcut("f", modifiers: [.command, .shift])
                .help("Copy existing attachments into the best permanent tenure evidence folder")

                Button {
                    store.archiveSources(for: entry.id)
                } label: {
                    Label("Archive URLs", systemImage: "archivebox")
                }
                .help("Save snapshots of URLs found in Source or Notes")
            }
        }
        .accessibilityElement(children: .contain)
    }

    private var completenessSection: some View {
        let report = entry.completeness

        return VStack(alignment: .leading, spacing: 8) {
            AppSectionHeader(
                title: report.displayLabel,
                subtitle: "Completeness check for this evidence record.",
                systemImage: "checklist",
                trailing: AnyView(StatusChip(text: "\(report.score)% complete", systemImage: "gauge", tone: report.score >= 90 ? .success : .warning))
            )

            ProgressView(value: Double(report.score), total: 100)

            if !report.missing.isEmpty {
                Text("Missing: \(report.missing.joined(separator: ", "))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(12)
        .background(.quaternary.opacity(0.3), in: RoundedRectangle(cornerRadius: 8))
    }

    private var duplicateSection: some View {
        let duplicates = store.duplicateCandidates(for: entry)

        return Group {
            if !duplicates.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Possible duplicate", systemImage: "exclamationmark.triangle")
                        .font(.headline)
                        .foregroundStyle(.orange)
                        .help("This record looks similar to another evidence entry")

                    ForEach(duplicates.prefix(3)) { candidate in
                        HStack(spacing: 8) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(candidate.title)
                                    .font(.caption.weight(.medium))
                                    .lineLimit(1)
                                Text(candidate.displaySubtitle)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            Spacer()
                            Button {
                                store.mergeDuplicateEntry(candidate.id, into: entry.id)
                            } label: {
                                Label("Merge Into This", systemImage: "arrow.triangle.merge")
                            }
                            .font(.caption)
                            .help("Merge this duplicate record into the current evidence record")
                        }
                    }
                }
                .padding(12)
                .background(.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }

    private var autofillReviewSection: some View {
        let report = entry.completeness
        let readableAttachmentCount = entry.attachments
            .map(store.attachmentState(for:))
            .filter { $0.exists && !$0.isDirectory && $0.isSupportedPreview }
            .count

        return VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            AppSectionHeader(
                title: "Autofill Review",
                subtitle: "The scan has prefilled what it could find. Edit any field below before marking it ready to use.",
                systemImage: "wand.and.sparkles"
            )

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 165), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                reviewStatus("Date", value: entry.date, image: "calendar")
                reviewStatus("Category", value: entry.category, image: "tag")
                reviewStatus("Type", value: entry.eventType, image: "text.badge.checkmark")
                reviewStatus("Role", value: entry.role, image: "person.crop.circle")
                reviewStatus("Host", value: entry.venue, image: "building.2")
                reviewStatus("Dimension", value: entry.tenureDimension, image: "scope")
            }

            HStack(spacing: AppDesign.Spacing.sm) {
                Button {
                    store.extractAttachmentMetadata(for: entry.id)
                } label: {
                    Label("Extract More Fields", systemImage: "text.viewfinder")
                }
                .disabled(readableAttachmentCount == 0)
                .help(readableAttachmentCount == 0 ? "Attach a readable PDF, image, text, Markdown, CSV, or RTF file first" : "Read attachment text and fill any still-empty fields")

                Button {
                    store.markEntryAsProofReady(entry.id)
                } label: {
                    Label("Mark Ready", systemImage: "checkmark.seal")
                }
                .disabled(entry.attachments.isEmpty && sourceURLs.isEmpty)
                .help("Use after reviewing the prefilled fields and proof")

                Spacer()

                Text(report.missing.isEmpty ? "Ready for human confirmation." : "Check: \(report.missing.joined(separator: ", "))")
                    .font(.caption)
                    .foregroundStyle(report.missing.isEmpty ? .green : .secondary)
                    .lineLimit(2)
                    .truncationMode(.tail)
            }
        }
        .padding(12)
        .background(Color.accentColor.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private func reviewStatus(_ title: String, value: String, image: String) -> some View {
        let isFilled = !value.trimmed.isEmpty && value != "All"

        return Label {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption.weight(.semibold))
                Text(isFilled ? value : "Check this")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        } icon: {
            Image(systemName: isFilled ? "checkmark.circle.fill" : image)
                .foregroundStyle(isFilled ? .green : .orange)
        }
        .padding(AppDesign.Spacing.sm)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
    }

    private var checklistSection: some View {
        let items = EvidenceChecklist.items(for: entry)

        return VStack(alignment: .leading, spacing: 8) {
            AppSectionHeader(
                title: "Evidence Checklist",
                subtitle: "Expected proof and metadata for this type of activity.",
                systemImage: "checklist"
            )

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), alignment: .leading)], alignment: .leading, spacing: 8) {
                ForEach(items) { item in
                    Label(item.label, systemImage: item.isSatisfied ? "checkmark.circle.fill" : "circle")
                        .font(.caption)
                        .foregroundStyle(item.isSatisfied ? .green : .secondary)
                        .lineLimit(2)
                        .help(item.isSatisfied ? "Checklist item complete" : "Checklist item still needs attention")
                }
            }
        }
        .padding(12)
        .background(.quaternary.opacity(0.22), in: RoundedRectangle(cornerRadius: 8))
    }

    private var coreFields: some View {
        ActionPanel(
            title: "Editable Fields",
            subtitle: "The scan has filled what it could. Adjust only what needs correction.",
            systemImage: "slider.horizontal.3"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                Grid(alignment: .leading, horizontalSpacing: 14, verticalSpacing: 12) {
                    GridRow {
                        Text("Date").foregroundStyle(.secondary)
                        TextField("YYYY-MM-DD", text: $entry.date)
                            .textFieldStyle(.roundedBorder)
                    }

                    GridRow {
                        Text("Category").foregroundStyle(.secondary)
                        Picker("Category", selection: $entry.category) {
                            ForEach(EvidenceOptions.categories, id: \.self) { category in
                                Text(category).tag(category)
                            }
                        }
                        .labelsHidden()
                    }

                    GridRow {
                        Text("Type").foregroundStyle(.secondary)
                        TextField("Invited talk, conference presentation, exhibition...", text: $entry.eventType)
                            .textFieldStyle(.roundedBorder)
                    }

                    GridRow {
                        Text("Role").foregroundStyle(.secondary)
                        TextField("Speaker, co-presenter, artist, reviewer...", text: $entry.role)
                            .textFieldStyle(.roundedBorder)
                    }

                    GridRow {
                        Text("Venue / host").foregroundStyle(.secondary)
                        TextField("Event, institution, city, country", text: $entry.venue)
                            .textFieldStyle(.roundedBorder)
                    }

                    GridRow {
                        Text("Dimension").foregroundStyle(.secondary)
                        Picker("Tenure dimension", selection: $entry.tenureDimension) {
                            ForEach(EvidenceOptions.dimensions, id: \.self) { dimension in
                                Text(dimension).tag(dimension)
                            }
                        }
                        .labelsHidden()
                    }
                }

                DisclosureGroup(isExpanded: $showSourceDetails) {
                    TextField("URL, email, calendar, file, institutional portal...", text: $entry.source)
                        .textFieldStyle(.roundedBorder)
                        .padding(.top, AppDesign.Spacing.xs)
                } label: {
                    HStack {
                        Label("Source details", systemImage: "link")
                        Spacer()
                        Text(entry.source.trimmed.isEmpty ? "No source yet" : "Source saved")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
            }
        }
    }

    private var notesSection: some View {
        DisclosureGroup(isExpanded: $showNotesEditor) {
            TextEditor(text: $entry.notes)
                .font(.body)
                .frame(minHeight: 130)
                .scrollContentBackground(.hidden)
                .padding(8)
                .background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 8))
                .padding(.top, AppDesign.Spacing.sm)
        } label: {
            HStack(alignment: .firstTextBaseline, spacing: AppDesign.Spacing.sm) {
                Label("Notes for CV / dossier", systemImage: "note.text")
                    .font(.title3.weight(.semibold))
                Spacer()
                Text(noteSummary)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.tail)
            }
        }
        .padding(12)
        .background(.quaternary.opacity(0.22), in: RoundedRectangle(cornerRadius: 8))
    }

    private var attachmentsSection: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Attachments",
                subtitle: "Select a file here; the preview and proof actions stay beside the record.",
                systemImage: "paperclip",
                trailing: AnyView(
                    HStack {
                        Button {
                            importingFiles = true
                        } label: {
                            Label("Attach Files", systemImage: "paperclip")
                        }
                        .help("Attach files to this evidence record")
                        Button {
                            store.revealAttachmentFolder(for: entry.id)
                        } label: {
                            Label("Folder", systemImage: "folder")
                        }
                        .help("Open the attachment folder for this evidence record")
                    }
                )
            )

            attachmentList
        }
        .padding(12)
        .overlay {
            RoundedRectangle(cornerRadius: 8)
                .strokeBorder(dropIsTargeted ? Color.accentColor : Color.secondary.opacity(0.18), lineWidth: dropIsTargeted ? 2 : 1)
        }
    }

    private var evidencePreviewPane: some View {
        let selectedState = selectedPreviewAttachment.map { store.attachmentState(for: $0) }
        let hasProof = !entry.attachments.isEmpty || !sourceURLs.isEmpty

        return VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Evidence Preview",
                subtitle: selectedPreviewAttachment?.name ?? "Select or attach a proof file.",
                systemImage: "doc.viewfinder"
            )

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                HStack {
                    StatusChip(
                        text: hasProof ? "Proof present" : "Proof needed",
                        systemImage: hasProof ? "checkmark.circle" : "paperclip",
                        tone: hasProof ? .success : .warning
                    )
                    StatusChip(
                        text: entry.cvReady ? "Ready to use" : "Not ready yet",
                        systemImage: entry.cvReady ? "checkmark.seal" : "circle",
                        tone: entry.cvReady ? .success : .neutral
                    )
                }

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                    Button {
                        importingFiles = true
                    } label: {
                        Label("Attach", systemImage: "paperclip")
                    }
                    .help("Attach PDF, image, text, slide, or other proof files")

                    Button {
                        store.archiveSources(for: entry.id)
                    } label: {
                        Label("Archive URLs", systemImage: "archivebox")
                    }
                    .disabled(sourceURLs.isEmpty)
                    .help("Archive source URLs found in Source or Notes")

                    Button {
                        store.extractAttachmentMetadata(for: entry.id)
                    } label: {
                        Label("Extract Fields", systemImage: "text.viewfinder")
                    }
                    .disabled(entry.attachments.isEmpty)
                    .help("Read PDF text or image OCR from attachments and fill empty evidence fields")

                    Button {
                        store.markEntryAsProofReady(entry.id)
                    } label: {
                        Label("Mark as Proof", systemImage: "checkmark.seal")
                    }
                    .disabled(!hasProof)
                    .help("Mark this record as ready proof for CV and dossier use")

                    Button {
                        store.fileAttachments(for: entry.id)
                    } label: {
                        Label("File", systemImage: "folder.badge.gearshape")
                    }
                    .disabled(entry.attachments.isEmpty || !entry.attachments.contains { store.attachmentState(for: $0).exists })
                    .help("Copy attachments into the permanent tenure evidence folders")

                    Button {
                        _ = store.createCVLineFromEvidence(entry.id)
                    } label: {
                        Label("CV Line", systemImage: "text.badge.plus")
                    }
                    .help("Create a structured CV line from this evidence record and link it back")
                }
                .buttonStyle(.bordered)
            }

            EvidenceAttachmentPreviewView(
                attachment: selectedPreviewAttachment,
                state: selectedState,
                showsHeader: false
            )

            if sourceURLs.isEmpty {
                Text("No source URL detected in Source or Notes.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    Text("Source URLs")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    ForEach(sourceURLs.prefix(3), id: \.self) { url in
                        Link(url.absoluteString, destination: url)
                            .font(.caption)
                            .lineLimit(1)
                            .truncationMode(.middle)
                    }
                }
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .accessibilityElement(children: .contain)
    }

    private var attachmentList: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            if entry.attachments.isEmpty {
                PrimaryEmptyState(
                    title: "No Attachments",
                    message: dropIsTargeted ? "Drop files to attach them." : "Attach a file or drag one here so this evidence has proof.",
                    systemImage: "paperclip",
                    actionTitle: "Attach Files",
                    actionImage: "paperclip",
                    action: { importingFiles = true }
                )
                .frame(minHeight: 220)
            } else {
                ForEach(entry.attachments, id: \.id) { attachment in
                    attachmentRow(attachment)
                }
            }
        }
    }

    private var footer: some View {
        VStack(alignment: .leading, spacing: 6) {
            Divider()
            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func attachmentRow(_ attachment: EvidenceAttachment) -> some View {
        let state = store.attachmentState(for: attachment)

        return HStack {
            Image(systemName: state.systemImage)
                .foregroundStyle(state.exists ? Color.secondary : Color.orange)
                .help(state.label)
            VStack(alignment: .leading) {
                HStack(spacing: 6) {
                    Text(attachment.name)
                    Text(state.label)
                        .font(.caption2.weight(.medium))
                        .foregroundStyle(state.exists ? Color.secondary : Color.orange)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 5))
                }
                Text(attachment.path)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer()
            Button {
                selectedPreviewAttachmentID = attachment.id
            } label: {
                Label("Preview", systemImage: "doc.viewfinder")
            }
            .disabled(!state.exists || state.isDirectory)
            .help("Preview this attachment in the evidence pane")
            Button {
                store.openAttachment(attachment)
            } label: {
                Label("Open", systemImage: "arrow.up.right.square")
            }
            .disabled(!state.exists)
            .help("Open this attachment")
            Button {
                store.revealAttachment(attachment)
            } label: {
                Label("Reveal", systemImage: "magnifyingglass")
            }
            .disabled(!state.exists)
            .help("Reveal this attachment in Finder")
            Button(role: .destructive) {
                store.removeAttachment(attachment, from: entry.id)
            } label: {
                Label("Remove", systemImage: "xmark.circle")
            }
            .help("Remove this attachment from the record")
        }
        .padding(.vertical, 4)
        .padding(.horizontal, AppDesign.Spacing.sm)
        .background(
            selectedPreviewAttachment?.id == attachment.id ? Color.accentColor.opacity(0.10) : Color.clear,
            in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm)
        )
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(attachment.name), \(state.label)")
    }

    private func keepPreviewSelectionValid() {
        guard !entry.attachments.isEmpty else {
            selectedPreviewAttachmentID = nil
            return
        }

        if selectedPreviewAttachmentID == nil
            || !entry.attachments.contains(where: { $0.id == selectedPreviewAttachmentID }) {
            selectedPreviewAttachmentID = entry.attachments.first?.id
        }
    }

    private var sourceURLs: [URL] {
        URLTools.extractURLs(from: [entry.source, entry.notes].joined(separator: "\n"))
    }

    private var noteSummary: String {
        let trimmedNotes = entry.notes.trimmed
        guard !trimmedNotes.isEmpty else { return "No notes yet" }
        let firstLine = trimmedNotes
            .components(separatedBy: .newlines)
            .first?
            .trimmed
        if let firstLine, !firstLine.isEmpty {
            return firstLine
        }
        return "Notes saved"
    }

    private func statusTone(_ status: String) -> StatusChip.Tone {
        switch status {
        case "Filed", "Ready for CV":
            return .success
        case "Evidence missing", "Needs confirmation":
            return .warning
        default:
            return .neutral
        }
    }

    private func handleDrop(_ providers: [NSItemProvider]) -> Bool {
        let entryID = entry.id
        var accepted = false

        for provider in providers where provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
            accepted = true
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                let url: URL?

                if let itemURL = item as? URL {
                    url = itemURL
                } else if let data = item as? Data {
                    url = URL(dataRepresentation: data, relativeTo: nil)
                } else {
                    url = nil
                }

                guard let url else { return }

                Task { @MainActor in
                    store.attachFiles([url], to: entryID)
                }
            }
        }

        return accepted
    }
}
