import SwiftUI

struct CVVersionHistoryView: View {
    @ObservedObject var store: EvidenceStore
    let currentDraft: String
    let theme: CVDraftTheme
    let restoreVersion: (String) -> Void
    @State private var selectedVersionID: CVVersionSnapshot.ID?

    private var selectedVersion: CVVersionSnapshot? {
        if let selectedVersionID,
           let version = store.cvVersions.first(where: { $0.id == selectedVersionID }) {
            return version
        }
        return store.cvVersions.first
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Label("CV Version History", systemImage: "clock.arrow.circlepath")
                        .font(.headline)
                    Spacer()
                    Button {
                        store.revealCVVersionHistoryFolder()
                    } label: {
                        Label("Folder", systemImage: "folder")
                    }
                    .help("Open the saved CV version history folder")
                }

                if store.cvVersions.isEmpty {
                    ContentUnavailableView(
                        "No CV Versions",
                        systemImage: "clock.arrow.circlepath",
                        description: Text("Export a CV once to create the first saved version.")
                    )
                    .frame(minHeight: 420)
                } else {
                    List(selection: $selectedVersionID) {
                        ForEach(store.cvVersions) { version in
                            VStack(alignment: .leading, spacing: 3) {
                                Text(version.displayTitle)
                                    .lineLimit(1)
                                Text(version.displaySubtitle)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            .tag(Optional(version.id))
                            .help("Saved CV version from \(version.createdAt)")
                        }
                    }
                    .frame(minWidth: 280, minHeight: 500)
                }
            }
            .frame(width: 330)

            if let selectedVersion {
                versionDetail(selectedVersion)
            } else {
                Spacer()
            }
        }
        .onAppear {
            selectedVersionID = selectedVersionID ?? store.cvVersions.first?.id
        }
    }

    private func versionDetail(_ version: CVVersionSnapshot) -> some View {
        let versionText = store.cvVersionText(version)
        let diff = CVDiffEngine.compare(current: currentDraft, previous: versionText, theme: theme)

        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(version.displayTitle)
                        .font(.title3.weight(.semibold))
                    Text(version.displaySubtitle)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    store.revealCVVersion(version)
                } label: {
                    Label("Reveal", systemImage: "folder")
                }
                .help("Reveal this saved Markdown snapshot")

                Button {
                    store.copyToClipboard(versionText)
                } label: {
                    Label("Copy", systemImage: "doc.on.doc")
                }
                .disabled(versionText.trimmed.isEmpty)
                .help("Copy this saved CV version")

                Button {
                    restoreVersion(versionText)
                } label: {
                    Label("Use Version", systemImage: "arrow.uturn.backward")
                }
                .disabled(versionText.trimmed.isEmpty)
                .help("Load this saved version into the current draft editor")
            }

            HStack(spacing: 8) {
                diffMetric("Words", old: diff.oldWordCount, new: diff.newWordCount)
                diffMetric("Pages", old: diff.oldPageCount, new: diff.newPageCount)
                diffMetric("Added", old: 0, new: diff.added.count)
                diffMetric("Removed", old: 0, new: diff.removed.count)
                Spacer()
            }

            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    diffBlock("New in current draft", lines: diff.added, color: .green)
                    diffBlock("Only in saved version", lines: diff.removed, color: .red)
                    diffBlock("Likely edited", lines: diff.editedHint, color: .orange)
                }
            }
            .frame(minHeight: 430)
        }
        .frame(maxWidth: .infinity, alignment: .topLeading)
    }

    private func diffMetric(_ title: String, old: Int, new: Int) -> some View {
        HStack(spacing: 4) {
            Text(title)
                .foregroundStyle(.secondary)
            if title == "Words" || title == "Pages" {
                Text("\(old) -> \(new)")
                    .fontWeight(.semibold)
            } else {
                Text("\(new)")
                    .fontWeight(.semibold)
            }
        }
        .font(.caption)
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 6))
    }

    private func diffBlock(_ title: String, lines: [String], color: Color) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("\(title) (\(lines.count))")
                .font(.headline)
                .foregroundStyle(color)

            if lines.isEmpty {
                Text("No lines in this group.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(lines, id: \.self) { line in
                    Text(line)
                        .font(.caption)
                        .textSelection(.enabled)
                        .padding(8)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(color.opacity(0.08), in: RoundedRectangle(cornerRadius: 6))
                }
            }
        }
    }
}
