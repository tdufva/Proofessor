import SwiftUI

struct ProfileLinksView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @State private var settings = ConnectorSettings()
    @State private var showProfileEditor = false
    @State private var showGuidedSetup = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                PageHeader(
                    title: "Academic Profiles",
                    subtitle: "Open, edit, and snapshot the public profiles you choose to track.",
                    systemImage: "person.text.rectangle",
                    trailing: AnyView(
                        HStack {
                            Button {
                                showGuidedSetup = true
                            } label: {
                                Label("Autofill", systemImage: "wand.and.sparkles")
                            }
                            .help("Autofill profile details from CV and evidence material")

                            Button {
                                store.snapshotProfiles()
                            } label: {
                                Label("Snapshot", systemImage: "camera")
                            }
                            .help("Save dated snapshots of your configured public profile pages")

                            Button {
                                save()
                            } label: {
                                Label("Save", systemImage: "checkmark")
                            }
                            .buttonStyle(.borderedProminent)
                            .keyboardShortcut(.defaultAction)

                            Button("Close") {
                                dismiss()
                            }
                            .keyboardShortcut(.cancelAction)
                        }
                    )
                )

                ActionPanel(
                    title: "Profile URLs",
                    subtitle: "Keep the list short. Add only the profiles you want reused in review and export.",
                    systemImage: "link"
                ) {
                    VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                        StatusStrip(items: [
                            StatusStripItem(
                                text: settings.configuredProfileCount == 0 ? "No links" : "\(settings.configuredProfileCount) link(s)",
                                systemImage: "link",
                                tone: settings.configuredProfileCount == 0 ? .neutral : .success
                            ),
                            StatusStripItem(
                                text: settings.profilePicturePath.trimmed.isEmpty ? "Picture optional" : "Picture ready",
                                systemImage: "person.crop.square",
                                tone: settings.profilePicturePath.trimmed.isEmpty ? .neutral : .success
                            )
                        ])

                        DisclosureGroup(isExpanded: $showProfileEditor) {
                            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                                settingsRow("Display name", text: $settings.publicDisplayName, prompt: "Name for public web search")
                                settingsRow("Title", text: $settings.profileTitle, prompt: "Assistant Professor, Lecturer, Artist-researcher...")
                                settingsRow("Affiliation", text: $settings.affiliation, prompt: "Aalto University, school, department, group...")
                                settingsRow("Research themes", text: $settings.researchThemes, prompt: "Short phrases separated by commas")
                                settingsRow("Artistic themes", text: $settings.artisticThemes, prompt: "Short phrases separated by commas")
                                settingsRow("Teaching themes", text: $settings.teachingThemes, prompt: "Short phrases separated by commas")
                                settingsRow("Institutional profile", text: $settings.acrisProfileURL, prompt: "https://research.aalto.fi/en/persons/...")
                                settingsRow("Google Scholar", text: $settings.googleScholarURL, prompt: "https://scholar.google.com/citations?user=...")
                                settingsRow("ORCID", text: $settings.orcidURL, prompt: "https://orcid.org/0000-0000-0000-0000")
                                settingsRow("People page", text: $settings.aaltoPeopleURL, prompt: "https://www.aalto.fi/en/people/...")
                                settingsRow("LinkedIn", text: $settings.linkedInURL, prompt: "https://linkedin.com/in/...")
                                settingsRow("Social media", text: $settings.socialMediaURL, prompt: "https://mastodon.social/@name or https://bsky.app/profile/...")
                                settingsRow("Website", text: $settings.websiteURL, prompt: "https://...")
                                ProfilePicturePickerView(path: $settings.profilePicturePath)
                                    .padding(.top, AppDesign.Spacing.sm)
                            }
                            .padding(.top, AppDesign.Spacing.sm)
                        } label: {
                            Label("Edit profile details", systemImage: "pencil")
                        }
                    }
                }

                ActionPanel(
                    title: "Open Links",
                    subtitle: "Use these to check profile content before snapshotting or exporting public-facing CVs.",
                    systemImage: "arrow.up.right.square"
                ) {
                    VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                        let links = ProfileLink.links(from: settings)

                        if links.isEmpty {
                            Text("No profile links saved yet.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }

                        ForEach(links) { link in
                            Button {
                                store.open(link.url)
                            } label: {
                                HStack {
                                    Image(systemName: link.systemImage)
                                        .frame(width: 20)
                                        .help(link.title)
                                    VStack(alignment: .leading) {
                                        Text(link.title)
                                        Text(link.url.absoluteString)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                            .lineLimit(1)
                                            .truncationMode(.middle)
                                    }
                                    Spacer()
                                    Image(systemName: "arrow.up.right")
                                        .foregroundStyle(.secondary)
                                        .help("Open this profile link")
                                }
                            }
                            .buttonStyle(.plain)
                            .help("Open \(link.title)")
                            Divider()
                        }
                    }
                }

                Text(store.lastMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(AppDesign.Spacing.xl)
            .frame(maxWidth: 760, alignment: .leading)
        }
        .frame(minWidth: 520, idealWidth: 720, minHeight: 560, idealHeight: 620)
        .onAppear {
            settings = store.connectorSettings
        }
        .sheet(isPresented: $showGuidedSetup) {
            GuidedProfileSetupView(store: store) {
                settings = store.connectorSettings
            }
        }
    }

    private func settingsRow(_ title: String, text: Binding<String>, prompt: String) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: AppDesign.Spacing.md) {
                settingsLabel(title)
                    .frame(width: 150, alignment: .leading)
                TextField(prompt, text: text)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: .infinity)
            }
            VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                settingsLabel(title)
                TextField(prompt, text: text)
                    .textFieldStyle(.roundedBorder)
            }
        }
    }

    private func settingsLabel(_ title: String) -> some View {
        Text(title)
            .font(.caption.weight(.semibold))
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)
    }

    private func save() {
        store.saveConnectorSettings(settings)
    }
}
