import PDFKit
import SwiftUI

struct CVLayoutPreviewView: View {
    let draft: String
    let theme: CVDraftTheme
    let variant: CVDraftVariant
    var targetPageLimit: Int? = nil
    var profilePicturePath: String? = nil

    private var pdfData: Data? {
        try? CVDocumentExporter.pdfData(from: draft, theme: theme, profilePicturePath: profilePicturePath)
    }

    private var report: CVLayoutReport {
        CVDocumentExporter.layoutReport(for: draft, theme: theme, profilePicturePath: profilePicturePath)
    }

    private var wordCount: Int {
        draft.split(whereSeparator: \.isWhitespace).count
    }

    private var sectionOrder: [String] {
        draft.components(separatedBy: .newlines)
            .map(\.trimmed)
            .filter { $0.hasPrefix("## ") }
            .map { String($0.dropFirst(3)).trimmed }
            .prefix(10)
            .map { $0 }
    }

    private var densityLabel: String {
        if theme.pageMargin <= 46 || theme.lineSpacing <= 1.6 { return "Compact" }
        if theme.pageMargin >= 60 || theme.lineSpacing >= 4 { return "Generous" }
        return "Balanced"
    }

    private var warnings: [String] {
        var output: [String] = []
        if let targetPageLimit, report.pageCount > targetPageLimit {
            output.append("Too long for the chosen purpose. Aim for \(targetPageLimit) page(s).")
        } else if report.pageCount > 5 {
            output.append("Long CV. Consider a compact or selected version before sharing.")
        }

        if wordCount < 220 || sectionOrder.count < 3 {
            output.append("Too sparse. Add profile basics, selected work, and at least a few verified items.")
        }

        if warningsNeedProfile {
            output.append("Profile details look light. Autofill name, title, affiliation, themes, and profile links.")
        }

        return output
    }

    private var warningsNeedProfile: Bool {
        !draft.localizedCaseInsensitiveContains("orcid")
            && !draft.localizedCaseInsensitiveContains("google scholar")
            && !draft.localizedCaseInsensitiveContains("aalto")
            && variant == .publicProfile
    }

    var body: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            header

            ViewThatFits(in: .horizontal) {
                HStack(alignment: .top, spacing: AppDesign.Spacing.md) {
                    previewPane
                    exportSummary
                        .frame(width: 300, alignment: .topLeading)
                }

                VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                    previewPane
                    exportSummary
                }
            }
        }
        .padding(18)
        .frame(minWidth: 860, minHeight: 720)
    }

    private var header: some View {
        HStack {
            Label("Export Preview", systemImage: "doc.richtext")
                .font(.title2.weight(.semibold))
            Spacer()
            StatusChip(text: "\(report.pageCount) page(s)", systemImage: "doc.on.doc", tone: pageTone)
            StatusChip(text: densityLabel, systemImage: "text.line.first.and.arrowtriangle.forward", tone: .neutral)
        }
    }

    private var pageTone: StatusChip.Tone {
        if let targetPageLimit, report.pageCount > targetPageLimit { return .warning }
        return report.pageCount <= 3 ? .success : .accent
    }

    @ViewBuilder
    private var previewPane: some View {
        if let pdfData {
            PDFPreview(data: pdfData)
                .frame(minWidth: 620, minHeight: 620)
                .clipShape(RoundedRectangle(cornerRadius: 8))
        } else {
            ContentUnavailableView(
                "No Preview",
                systemImage: "doc.text.magnifyingglass",
                description: Text("The current draft could not be rendered.")
            )
            .frame(minWidth: 620, minHeight: 620)
        }
    }

    private var exportSummary: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            summaryGroup("Typography", systemImage: "textformat", rows: [
                ("Title", "\(Int(theme.titleFont.pointSize)) pt"),
                ("Headings", "\(Int(theme.headingFont.pointSize)) pt"),
                ("Body", "\(Int(theme.bodyFont.pointSize)) pt")
            ])

            summaryGroup("Spacing", systemImage: "ruler", rows: [
                ("Density", densityLabel),
                ("Line spacing", String(format: "%.1f", theme.lineSpacing)),
                ("Margins", "\(Int(theme.pageMargin)) pt")
            ])

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                Label("Section Order", systemImage: "list.number")
                    .font(.headline)
                if sectionOrder.isEmpty {
                    Text("No sections detected yet.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(Array(sectionOrder.enumerated()), id: \.offset) { index, section in
                        Text("\(index + 1). \(section)")
                            .font(.caption)
                            .lineLimit(1)
                    }
                }
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                Label("Warnings", systemImage: "exclamationmark.triangle")
                    .font(.headline)
                if warnings.isEmpty {
                    StatusChip(text: "Looks ready", systemImage: "checkmark.circle", tone: .success)
                } else {
                    ForEach(warnings, id: \.self) { warning in
                        Label(warning, systemImage: "exclamationmark.circle")
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }

            Spacer(minLength: 0)
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func summaryGroup(_ title: String, systemImage: String, rows: [(String, String)]) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            Label(title, systemImage: systemImage)
                .font(.headline)
            ForEach(rows, id: \.0) { row in
                HStack {
                    Text(row.0)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text(row.1)
                        .fontWeight(.medium)
                }
                .font(.caption)
            }
        }
    }
}

private struct PDFPreview: NSViewRepresentable {
    let data: Data

    func makeNSView(context: Context) -> PDFView {
        let view = PDFView()
        view.autoScales = true
        view.displayMode = .singlePageContinuous
        view.displaysPageBreaks = true
        view.backgroundColor = .textBackgroundColor
        view.document = PDFDocument(data: data)
        return view
    }

    func updateNSView(_ view: PDFView, context: Context) {
        view.document = PDFDocument(data: data)
        view.autoScales = true
    }
}
