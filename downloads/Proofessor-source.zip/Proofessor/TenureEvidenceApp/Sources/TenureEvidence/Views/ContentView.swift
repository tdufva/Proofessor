import SwiftUI

struct ContentView: View {
    @AppStorage("hasSeenTenureOnboarding") private var hasSeenTenureOnboarding = false
    @StateObject private var store = EvidenceStore()
    @State private var selectedTab: AppTab = .collection
    @State private var selection: EvidenceEntry.ID?
    @State private var searchText = ""
    @State private var showingGuidedCapture = false
    @State private var showingImportAssistant = false
    @State private var showingSuggestedEvidence = false
    @State private var showingConnectorSettings = false
    @State private var showingMonthlyReview = false
    @State private var showingProfileLinks = false
    @State private var showingDossierBuilder = false
    @State private var showingReviewScans = false
    @State private var showingOnboarding = false
    @State private var showingStartHere = false
    @State private var didScanInboxOnLaunch = false

    var body: some View {
        TabView(selection: $selectedTab) {
            TenureCollectionView(
                store: store,
                addEvidence: addEntry,
                openGuidedCapture: { showingGuidedCapture = true },
                scanInbox: scanInbox,
                openImport: { showingImportAssistant = true },
                openSuggestions: { showingSuggestedEvidence = true },
                openSources: { showingConnectorSettings = true },
                openReviewScans: { showingReviewScans = true },
                openEvidence: { id in
                    selection = id
                    selectedTab = .evidence
                },
                openCV: { selectedTab = .cv },
                openStartHere: { showingStartHere = true }
            )
            .tabItem {
                Label("Collect", systemImage: "tray.full")
            }
            .tag(AppTab.collection)

            evidenceWorkspace
                .tabItem {
                    Label("Verify & File", systemImage: "checkmark.folder")
                }
                .tag(AppTab.evidence)

            CVCreationView(
                store: store,
                openEvidence: { id in
                    selection = id
                    selectedTab = .evidence
                }
            )
            .tabItem {
                Label("Build CV", systemImage: "doc.text.magnifyingglass")
            }
            .tag(AppTab.cv)

            BioBuilderView(store: store)
                .tabItem {
                    Label("Bios", systemImage: "person.text.rectangle")
                }
                .tag(AppTab.bios)

            ExportHubView(
                store: store,
                openCV: { selectedTab = .cv },
                openVerify: { selectedTab = .evidence },
                openDossier: { showingDossierBuilder = true },
                openMonthlyReview: { showingMonthlyReview = true },
                openProfiles: { showingProfileLinks = true },
                openGuide: { showingOnboarding = true }
            )
            .tabItem {
                Label("Export", systemImage: "square.and.arrow.up")
            }
            .tag(AppTab.export)
        }
        .onAppear {
            if !didScanInboxOnLaunch {
                didScanInboxOnLaunch = true
                scanInbox()
            }

            if selection == nil {
                selection = store.entries.first?.id
            }

            if !hasSeenTenureOnboarding {
                showingStartHere = true
                hasSeenTenureOnboarding = true
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .exportEvidenceRequested)) { _ in
            store.exportCSV()
        }
        .sheet(isPresented: $showingImportAssistant) {
            ImportAssistantView(store: store, selection: $selection)
                .frame(minWidth: 680, minHeight: 560)
        }
        .sheet(isPresented: $showingGuidedCapture) {
            GuidedCaptureView(
                store: store,
                selection: $selection,
                onCreate: { selectedTab = .evidence }
            )
        }
        .sheet(isPresented: $showingSuggestedEvidence) {
            SuggestedEvidenceView(
                store: store,
                selection: $selection,
                openEvidenceAfterImport: { selectedTab = .evidence }
            )
                .frame(minWidth: 720, idealWidth: 920, minHeight: 620, idealHeight: 680)
        }
        .sheet(isPresented: $showingConnectorSettings) {
            ConnectorSettingsView(store: store)
                .frame(minWidth: 620, idealWidth: 760, minHeight: 560, idealHeight: 680)
        }
        .sheet(isPresented: $showingMonthlyReview) {
            MonthlyReviewView(store: store)
                .frame(minWidth: 760, minHeight: 560)
        }
        .sheet(isPresented: $showingProfileLinks) {
            ProfileLinksView(store: store)
                .frame(minWidth: 620, idealWidth: 760, minHeight: 560, idealHeight: 620)
        }
        .sheet(isPresented: $showingDossierBuilder) {
            DossierBuilderView(store: store)
                .frame(minWidth: 820, minHeight: 620)
        }
        .sheet(isPresented: $showingReviewScans) {
            ReviewScansWizardView(
                store: store,
                selection: $selection,
                openEvidence: { selectedTab = .evidence }
            )
        }
        .sheet(isPresented: $showingStartHere) {
            StartHereView(
                store: store,
                openSuggestions: { showingSuggestedEvidence = true },
                openCV: { selectedTab = .cv },
                openSources: { showingConnectorSettings = true }
            )
        }
        .sheet(isPresented: $showingOnboarding) {
            OnboardingView(store: store)
        }
        .onChange(of: store.entries) { _, _ in
            if selection == nil || !store.entries.contains(where: { $0.id == selection }) {
                selection = store.entries.first?.id
            }
        }
    }

    private var evidenceWorkspace: some View {
        NavigationSplitView {
            Group {
                if store.entries.isEmpty {
                    PrimaryEmptyState(
                        title: "No Evidence Yet",
                        message: "Start by scanning 00_Inbox or creating one evidence record.",
                        systemImage: "tray.badge.plus",
                        actionTitle: "New Evidence",
                        actionImage: "plus",
                        action: addEntry
                    )
                } else {
                    SidebarView(
                        entries: store.filteredEntries(searchText: searchText),
                        selection: $selection,
                        addAction: addEntry,
                        deleteAction: deleteSelection
                    )
                }
            }
            .navigationSplitViewColumnWidth(min: 260, ideal: 320, max: 420)
        } detail: {
            if let binding = selectedEntryBinding {
                DetailView(entry: binding, store: store)
            } else {
                EmptyStateView(addAction: addEntry)
            }
        }
        .searchable(text: $searchText, placement: .sidebar, prompt: "Search evidence")
        .toolbar {
            ToolbarItemGroup {
                Button(action: addEntry) {
                    Label("New", systemImage: "plus")
                }
                .keyboardShortcut("n", modifiers: [.command])
                .help("Create a new blank evidence record")
                Button(action: scanInbox) {
                    Label("Scan", systemImage: "arrow.triangle.2.circlepath")
                }
                .keyboardShortcut("r", modifiers: [.command, .shift])
                .help("Scan 00_Inbox and configured document folders for new evidence files")

                Menu {
                    Button {
                        showingStartHere = true
                    } label: {
                        Label("Start Here", systemImage: "sparkles")
                    }

                    Divider()

                    Button {
                        showingGuidedCapture = true
                    } label: {
                        Label("Guided Capture", systemImage: "square.and.pencil")
                    }

                    Button {
                        showingImportAssistant = true
                    } label: {
                        Label("Import Text", systemImage: "tray.and.arrow.down")
                    }

                    Button {
                        showingSuggestedEvidence = true
                    } label: {
                        Label("Review Suggestions", systemImage: "sparkles")
                    }

                    Button {
                        showingReviewScans = true
                    } label: {
                        Label("Review Scans", systemImage: "text.viewfinder")
                    }

                    Button {
                        showingConnectorSettings = true
                    } label: {
                        Label("Source Settings", systemImage: "switch.2")
                    }

                    Divider()

                    Button {
                        showingMonthlyReview = true
                    } label: {
                        Label("Monthly Review", systemImage: "calendar")
                    }

                    Button {
                        showingProfileLinks = true
                    } label: {
                        Label("Profile Snapshots", systemImage: "person.text.rectangle")
                    }

                    Divider()

                    Button(action: store.exportCSV) {
                        Label("Export Evidence CSV", systemImage: "square.and.arrow.up")
                    }

                    Button {
                        showingDossierBuilder = true
                    } label: {
                        Label("Dossier Builder", systemImage: "rectangle.3.group")
                    }

                    Button(action: store.revealWorkspace) {
                        Label("Reveal Tenure Folder", systemImage: "folder")
                    }

                    Button {
                        showingOnboarding = true
                    } label: {
                        Label("Guide", systemImage: "questionmark.circle")
                    }
                } label: {
                    Label("More", systemImage: "ellipsis.circle")
                }
                .help("More evidence, review, source, and export actions")
            }
        }
    }

    private var selectedEntryBinding: Binding<EvidenceEntry>? {
        guard let selection,
              let index = store.entries.firstIndex(where: { $0.id == selection }) else {
            return nil
        }

        return $store.entries[index]
    }

    private func addEntry() {
        selection = store.addEntry()
        selectedTab = .evidence
    }

    private func scanInbox() {
        let importedCount = store.scanDocumentSources()
        if importedCount > 0 {
            selection = store.entries.first?.id
        }
    }

    private func deleteSelection() {
        guard let selection else { return }
        store.deleteEntry(id: selection)
        self.selection = store.entries.first?.id
    }
}
