import SwiftUI

struct CVCreationView: View {
    @ObservedObject var store: EvidenceStore
    let openEvidence: (EvidenceEntry.ID) -> Void
    @State private var selectedDesignPurpose: CVDesignPurpose = .elegantAcademic
    @State private var selectedTemplate: CVDraftVariant? = CVDesignPurpose.elegantAcademic.variant
    @State private var selectedTheme: CVDraftTheme = .aaltoClean
    @State private var selectedFormat: CVExportFormat = .pdf
    @State private var buildOptions = CVBuildOptions()
    @State private var baseDraft = ""
    @State private var draft = ""
    @State private var includedSectionIDs: Set<String> = []
    @State private var sectionOrder: [String] = []
    @State private var selectedWorkflow: CVWorkflowStep = .choose
    @State private var selectedEditorPane: CVEditorPane = .draft
    @State private var selectedCheckPane: CVCheckPane = .preview
    @State private var lineItems: [CVDraftLineItem] = []
    @State private var showingLayoutPreview = false
    @State private var showingReviewQueue = false
    @State private var showingAdvancedOptions = false
    @State private var showingCleanupHelpers = false
    @State private var showingSectionControls = false
    @State private var showingQualityChecks = false
    @State private var showingProfileSetup = false

    private var template: CVDraftVariant {
        selectedTemplate ?? .currentPages
    }

    private var templateRule: CVTemplateRule {
        CVTemplateRule.rule(for: template, base: buildOptions)
    }

    private var effectiveDraftForExport: String {
        guard buildOptions.finalCleanMode else { return draft }
        let items = lineItems.isEmpty ? CVDraftLineBuilder.items(from: draft, template: template) : lineItems
        let clean = CVDraftLineBuilder.markdown(from: items, cleanOnly: true)
        return clean.trimmed.isEmpty ? draft : clean
    }

    private var draftSections: [CVDraftSection] {
        let sections = CVDraftSectionFilter.sections(in: baseDraft)
        guard !sectionOrder.isEmpty else { return sections }

        var remaining = sections
        var ordered: [CVDraftSection] = []

        for id in sectionOrder {
            guard let index = remaining.firstIndex(where: { $0.id == id }) else { continue }
            ordered.append(remaining.remove(at: index))
        }

        return ordered + remaining
    }

    var body: some View {
        ScrollView {
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .top, spacing: AppDesign.Spacing.lg) {
                    mainBuilderColumn
                        .frame(minWidth: 560, maxWidth: .infinity, alignment: .topLeading)

                    livePreviewRail
                        .frame(width: 390, alignment: .topLeading)
                }

                VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                    mainBuilderColumn
                    livePreviewRail
                }
            }
            .padding(22)
            .frame(maxWidth: 1320, alignment: .topLeading)
        }
        .frame(minWidth: 640, maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .onAppear(perform: regenerateDraft)
        .onChange(of: selectedTemplate) { _, _ in
            ensureThemeAllowed()
            regenerateDraft()
        }
        .onChange(of: buildOptions) { _, _ in
            regenerateDraft()
        }
        .sheet(isPresented: $showingLayoutPreview) {
            CVLayoutPreviewView(
                draft: effectiveDraftForExport,
                theme: selectedTheme,
                variant: template,
                targetPageLimit: selectedDesignPurpose.targetPageLimit,
                profilePicturePath: profilePicturePathForExport
            )
        }
        .sheet(isPresented: $showingReviewQueue) {
            CVReviewQueueView(store: store)
        }
        .sheet(isPresented: $showingProfileSetup) {
            GuidedProfileSetupView(store: store) {
                regenerateDraft()
            }
        }
    }

    private var mainBuilderColumn: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
            header
            CVDesignStudioView(
                selectedPurpose: selectedDesignPurpose,
                profileCompleteness: store.connectorSettings.profileCompletenessCount,
                applyPurpose: applyDesignPurpose,
                openProfileSetup: { showingProfileSetup = true }
            )
            actionBar
            CVFlowStatusView(
                step: selectedWorkflow,
                draftIsEmpty: effectiveDraftForExport.trimmed.isEmpty,
                structuredItemCount: store.cvItems.count,
                cvReadyCount: store.entries.filter(\.cvReady).count,
                unverifiedLineCount: lineItems.filter { $0.included && !$0.verified && !$0.isStructural }.count,
                finalCleanMode: buildOptions.finalCleanMode
            )
            stepNavigation
            workflowContent

            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var stepNavigation: some View {
        ActionPanel(
            title: "Build Flow",
            subtitle: selectedWorkflow.guidance,
            systemImage: "point.3.connected.trianglepath.dotted"
        ) {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                ForEach(CVWorkflowStep.allCases) { step in
                    Button {
                        selectedWorkflow = step
                    } label: {
                        workflowStepCard(step)
                    }
                    .buttonStyle(.plain)
                    .help(step.guidance)
                }
            }
        }
    }

    private func workflowStepCard(_ step: CVWorkflowStep) -> some View {
        let isSelected = step == selectedWorkflow

        return VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            HStack {
                Image(systemName: step.systemImage)
                    .foregroundStyle(isSelected ? Color.accentColor : Color.secondary)
                Spacer()
                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                }
            }
            Text(step.rawValue)
                .font(.headline)
                .foregroundStyle(.primary)
            Text(step.shortHint)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(AppDesign.Spacing.md)
        .frame(maxWidth: .infinity, minHeight: 126, alignment: .topLeading)
        .background(
            isSelected ? Color.accentColor.opacity(0.12) : Color.secondary.opacity(0.07),
            in: RoundedRectangle(cornerRadius: AppDesign.Radius.md)
        )
    }

    private var livePreviewRail: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            CVLivePreviewView(draft: effectiveDraftForExport, theme: selectedTheme, profilePicturePath: profilePicturePathForExport)

            ActionPanel(
                title: "Profile Picture",
                subtitle: selectedTheme.supportsProfilePicture
                    ? "Optional for this style. It appears in the builder now and can be used for public-facing CV designs."
                    : "Saved for public-facing styles. The selected theme keeps the CV text-only.",
                systemImage: "person.crop.square"
            ) {
                ProfilePicturePickerView(path: profilePictureBinding, compact: true)
            }

            ActionPanel(
                title: "Next Action",
                subtitle: selectedWorkflow.guidance,
                systemImage: "arrow.forward.circle"
            ) {
                Button {
                    advanceWorkflow()
                } label: {
                    Label(nextActionTitle, systemImage: nextActionImage)
                }
                .buttonStyle(.borderedProminent)
                .disabled(selectedWorkflow == .export && effectiveDraftForExport.trimmed.isEmpty)
                .help(nextActionHelp)
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            PageHeader(
                title: "Build CV",
                subtitle: "Choose the CV purpose, confirm the source material, edit the draft, then preview and export a sendable version.",
                systemImage: "doc.text.magnifyingglass"
            )

            StatusStrip(items: [
                StatusStripItem(text: template.rawValue, systemImage: template.systemImage, tone: .accent),
                StatusStripItem(text: selectedTheme.rawValue, systemImage: selectedTheme.systemImage, tone: .neutral),
                StatusStripItem(text: "\(store.cvItems.count) source rows", systemImage: "tablecells", tone: store.cvItems.isEmpty ? .warning : .neutral),
                StatusStripItem(text: "\(importedCVSourceLineCount) imported lines", systemImage: "doc.text", tone: importedCVSourceLineCount == 0 ? .warning : .neutral),
                StatusStripItem(text: "\(store.entries.filter(\.cvReady).count) ready to use", systemImage: "checkmark.circle", tone: store.entries.filter(\.cvReady).isEmpty ? .warning : .success)
            ])
        }
        .accessibilityElement(children: .combine)
    }

    private var actionBar: some View {
        ActionPanel(
            title: "Export Choices",
            subtitle: selectedDesignPurpose.whySuggested,
            systemImage: "slider.horizontal.3"
        ) {
            VStack(alignment: .leading, spacing: 10) {
                ViewThatFits(in: .horizontal) {
                    HStack(alignment: .firstTextBaseline, spacing: 10) {
                        StatusChip(text: selectedDesignPurpose.rawValue, systemImage: selectedDesignPurpose.systemImage, tone: .accent)
                        formatPicker
                        Spacer(minLength: 0)
                    }

                    VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                        StatusChip(text: selectedDesignPurpose.rawValue, systemImage: selectedDesignPurpose.systemImage, tone: .accent)
                        formatPicker
                    }
                }

                HStack(spacing: 8) {
                    Button {
                        showingLayoutPreview = true
                    } label: {
                        Label("Preview", systemImage: "doc.richtext")
                    }
                    .disabled(effectiveDraftForExport.trimmed.isEmpty)
                    .keyboardShortcut("p", modifiers: [.command, .option])
                    .help("Preview the rendered A4 layout and page count")

                    Button {
                        export(selectedFormat)
                    } label: {
                        Label("Export", systemImage: selectedFormat.systemImage)
                    }
                    .disabled(effectiveDraftForExport.trimmed.isEmpty)
                    .keyboardShortcut("e", modifiers: [.command])
                    .buttonStyle(.borderedProminent)
                    .help(selectedFormat.helpText)

                    cvMoreMenu

                    Spacer(minLength: 0)
                }

                sourceStatusStrip

                DisclosureGroup("Fine-tune layout and build options", isExpanded: $showingAdvancedOptions) {
                    VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                        setupPickers
                        optionsBar
                    }
                        .padding(.top, 6)
                }
                .font(.caption)
                .help("Open template, visual style, source notes, confidence badges, final clean mode, and evidence inclusion settings")
                preflightBar
            }
        }
    }

    private var setupPickers: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                templatePicker
                themePicker
                formatPicker
                Spacer(minLength: 0)
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                templatePicker
                themePicker
                formatPicker
            }
        }
    }

    private var templatePicker: some View {
        Picker("Purpose detail", selection: $selectedTemplate) {
            ForEach(CVDraftVariant.allCases) { option in
                Label(option.rawValue, systemImage: option.systemImage).tag(Optional(option))
            }
        }
        .frame(minWidth: 230, idealWidth: 250, maxWidth: 280)
        .help("Fine-tune the structure after choosing the main purpose")
    }

    private var themePicker: some View {
        Picker("Visual style", selection: $selectedTheme) {
            ForEach(template.allowedThemes) { theme in
                Label(theme.rawValue, systemImage: theme.systemImage).tag(theme)
            }
        }
        .frame(minWidth: 190, idealWidth: 210, maxWidth: 240)
        .help(template == .tenk ? "TENK CV is restricted to formal styling" : "Choose the visual style used for Word, PDF, RTF, and Pages exports")
    }

    private var formatPicker: some View {
        Picker("Format", selection: $selectedFormat) {
            ForEach(CVExportFormat.allCases) { format in
                Label(format.rawValue, systemImage: format.systemImage).tag(format)
            }
        }
        .frame(width: 135)
        .help(selectedFormat.helpText)
    }

    private var cvMoreMenu: some View {
        Menu {
            Button {
                regenerateDraft()
            } label: {
                Label("Regenerate Draft", systemImage: "arrow.clockwise")
            }

            Button {
                refreshImportedCVMaterial()
            } label: {
                Label("Scan CV Files", systemImage: "doc.text.magnifyingglass")
            }

            Button {
                store.copyToClipboard(effectiveDraftForExport)
            } label: {
                Label("Copy Draft", systemImage: "doc.on.doc")
            }
            .disabled(effectiveDraftForExport.trimmed.isEmpty)

            Button {
                store.revealCVDraftFolder()
            } label: {
                Label("Draft Folder", systemImage: "folder")
            }

            Divider()

            Button {
                store.exportEditableCVDraftBundle(effectiveDraftForExport, variant: template, theme: selectedTheme)
            } label: {
                Label("Export Set", systemImage: "square.stack.3d.up")
            }
            .disabled(effectiveDraftForExport.trimmed.isEmpty)

            Button {
                store.exportDossierPacket(cvDraft: effectiveDraftForExport, variant: template, theme: selectedTheme)
            } label: {
                Label("Dossier Packet", systemImage: "shippingbox")
            }
            .disabled(effectiveDraftForExport.trimmed.isEmpty)

            Menu {
                Button {
                    export(.pages)
                } label: {
                    Label("Pages", systemImage: CVExportFormat.pages.systemImage)
                }

                Button {
                    export(.word)
                } label: {
                    Label("Word", systemImage: CVExportFormat.word.systemImage)
                }

                Button {
                    export(.pdf)
                } label: {
                    Label("PDF", systemImage: CVExportFormat.pdf.systemImage)
                }
            } label: {
                Label("Quick Formats", systemImage: "doc.on.doc")
            }

            Divider()

            Menu {
                ForEach(CitationExportStyle.allCases) { style in
                    Button {
                        store.exportCitationList(style: style)
                    } label: {
                        Label(style.rawValue, systemImage: style.systemImage)
                    }
                }
            } label: {
                Label("Citation Lists", systemImage: "text.book.closed")
            }

            Button {
                showingReviewQueue = true
            } label: {
                Label("Review Queue", systemImage: "checklist")
            }
        } label: {
            Label("More", systemImage: "ellipsis.circle")
        }
        .help("More CV actions")
    }

    private var sourceStatusStrip: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) {
                sourceStatusText
                Spacer()
                sourceStatusActions
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                sourceStatusText
                sourceStatusActions
            }
        }
        .padding(10)
        .background(
            importedCVSourceLineCount == 0 ? Color.orange.opacity(0.10) : Color.secondary.opacity(0.06),
            in: RoundedRectangle(cornerRadius: AppDesign.Radius.md)
        )
    }

    private var sourceStatusText: some View {
        VStack(alignment: .leading, spacing: 2) {
            Label("Imported CV source", systemImage: "doc.text")
                .font(.caption.weight(.semibold))

            Text(importedCVSourceLineCount == 0
                 ? "No old CV source text found."
                 : "\(importedCVSourceLineCount) non-empty lines are available from the imported/master CV files.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var sourceStatusActions: some View {
        HStack(spacing: AppDesign.Spacing.sm) {
            Button {
                refreshImportedCVMaterial()
            } label: {
                Label("Scan CV Files", systemImage: "doc.text.magnifyingglass")
            }
            .help("Scan old CV files and add missing rows into the structured CV database without deleting existing edits")

            Button {
                store.revealCurrentCVSource()
            } label: {
                Label("Show Source", systemImage: "doc.text")
            }
            .help("Reveal the consolidated CV master source used by the CV builder")
        }
    }

    private var optionsBar: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Build Options")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 170), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                Toggle(isOn: $buildOptions.includeAppEvidence) {
                    Label("App evidence", systemImage: "list.bullet.rectangle")
                }
                .toggleStyle(.checkbox)
                .help("Include recent ready-to-use and high-completeness evidence records from the app")

                Toggle(isOn: $buildOptions.onlyCVReadyEvidence) {
                    Label("Ready to use only", systemImage: "checkmark.seal")
                }
                .toggleStyle(.checkbox)
                .disabled(!buildOptions.includeAppEvidence)
                .help("Limit app-captured additions to records explicitly marked ready to use")

                Toggle(isOn: $buildOptions.compactBullets) {
                    Label("Compact bullets", systemImage: "text.justify.left")
                }
                .toggleStyle(.checkbox)
                .help("Shorten app-captured evidence bullets by leaving out event type labels")

                Toggle(isOn: $buildOptions.includeDraftNote) {
                    Label("Draft note", systemImage: "note.text")
                }
                .toggleStyle(.checkbox)
                .disabled(buildOptions.finalCleanMode)
                .help("Include a short review note at the top of generated CV drafts")

                Toggle(isOn: $buildOptions.includeSourceNotes) {
                    Label("Source notes", systemImage: "link")
                }
                .toggleStyle(.checkbox)
                .disabled(buildOptions.finalCleanMode)
                .help("Include source notes in the header and app-captured CV lines")

                Toggle(isOn: $buildOptions.includeSourceConfidence) {
                    Label("Confidence", systemImage: "gauge.with.dots.needle.bottom.50percent")
                }
                .toggleStyle(.checkbox)
                .disabled(buildOptions.finalCleanMode)
                .help("Add source-confidence badges to generated CV lines")
            }
            .font(.caption)

            HStack(spacing: 10) {
                Toggle(isOn: $buildOptions.finalCleanMode) {
                    Label("Final clean export", systemImage: "checkmark.rectangle.stack")
                }
                .toggleStyle(.checkbox)
                .help("Remove scaffolding, source badges, source notes, draft notes, and uncertain lines from exports")

                Text("Final clean mode exports only verified or manually approved content and suppresses source scaffolding.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var preflightBar: some View {
        let report = CVDraftPreflightReport(
            draft: effectiveDraftForExport,
            theme: selectedTheme,
            profilePicturePath: profilePicturePathForExport,
            appEntryCount: appEntryCountForCurrentOptions,
            cvReadyCount: store.entries.filter(\.cvReady).count
        )

        return ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) {
                preflightMetricsRow(report)
                Spacer()
                preflightHint(report)
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                preflightMetricsGrid(report)
                preflightHint(report)
            }
        }
        .help("Quick export preflight: word count, section count, bullet count, included app records, and likely cleanup status")
    }

    private func preflightMetricsRow(_ report: CVDraftPreflightReport) -> some View {
        HStack(spacing: 8) {
            preflightMetric("Words", value: "\(report.wordCount)", systemImage: "text.word.spacing")
            preflightMetric("Sections", value: "\(report.sectionCount)", systemImage: "list.bullet.indent")
            preflightMetric("Bullets", value: "\(report.bulletCount)", systemImage: "list.bullet")
            preflightMetric("Pages", value: "\(report.pageCount)", systemImage: "doc.richtext")
            preflightMetric("App Items", value: "\(report.appEntryCount)", systemImage: "tray.full")
            preflightMetric("Ready", value: "\(report.cvReadyCount)", systemImage: "checkmark.circle")
        }
    }

    private func preflightMetricsGrid(_ report: CVDraftPreflightReport) -> some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 96), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
            preflightMetric("Words", value: "\(report.wordCount)", systemImage: "text.word.spacing")
            preflightMetric("Sections", value: "\(report.sectionCount)", systemImage: "list.bullet.indent")
            preflightMetric("Bullets", value: "\(report.bulletCount)", systemImage: "list.bullet")
            preflightMetric("Pages", value: "\(report.pageCount)", systemImage: "doc.richtext")
            preflightMetric("App Items", value: "\(report.appEntryCount)", systemImage: "tray.full")
            preflightMetric("Ready", value: "\(report.cvReadyCount)", systemImage: "checkmark.circle")
        }
    }

    private func preflightHint(_ report: CVDraftPreflightReport) -> some View {
        Text(report.readinessHint)
            .font(.caption)
            .foregroundStyle(report.readinessColor)
            .fixedSize(horizontal: false, vertical: true)
    }

    @ViewBuilder
    private var workflowContent: some View {
        switch selectedWorkflow {
        case .choose:
            CVStartWizardView(
                selectedTemplate: template,
                selectedTheme: selectedTheme,
                allowedThemes: template.allowedThemes,
                databaseCount: store.cvItems.count,
                publicationCount: store.cvItems.filter { $0.section == .publication }.count,
                verifiedCount: store.cvItems.filter(\.verified).count,
                importedSourceLineCount: importedCVSourceLineCount,
                applyPreset: applyPreset,
                applyTheme: applyTheme,
                refreshImportedCV: refreshImportedCVMaterial
            )
        case .check:
            sourceStep
        case .edit:
            editStep
        case .export:
            exportStep
        }
    }

    private var sourceStep: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            ActionPanel(
                title: "Source Material",
                subtitle: "Make sure the old CV, structured source rows, publications, and app evidence are present before editing.",
                systemImage: "doc.text.magnifyingglass"
            ) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 180), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.md) {
                    sourceMetric("Imported CV", "\(importedCVSourceLineCount)", "non-empty lines", "doc.text", importedCVSourceLineCount == 0 ? .warning : .success)
                    sourceMetric("Source Rows", "\(store.cvItems.count)", "editable CV rows", "tablecells", store.cvItems.isEmpty ? .warning : .success)
                    sourceMetric("Publications", "\(store.cvItems.filter { $0.section == .publication }.count)", "publication rows", "text.book.closed", .neutral)
                    sourceMetric("Ready Evidence", "\(store.entries.filter(\.cvReady).count)", "app evidence items", "checkmark.circle", store.entries.filter(\.cvReady).isEmpty ? .warning : .success)
                }

                HStack(spacing: AppDesign.Spacing.sm) {
                    Button {
                        refreshImportedCVMaterial()
                    } label: {
                        Label("Scan CV Files", systemImage: "doc.text.magnifyingglass")
                    }
                    .buttonStyle(.borderedProminent)
                    .help("Scan the CV/profile folders, extract readable CV text, and merge missing rows into the structured CV database")

                    Button {
                        store.revealCurrentCVSource()
                    } label: {
                        Label("Master Source", systemImage: "doc.text")
                    }

                    Button {
                        store.revealImportedCVSource()
                    } label: {
                        Label("Imported Source", systemImage: "doc.text.magnifyingglass")
                    }

                    Button {
                        selectedEditorPane = .database
                        selectedWorkflow = .edit
                    } label: {
                        Label("Edit Source Rows", systemImage: "tablecells")
                    }

                    Button {
                        selectedEditorPane = .publications
                        selectedWorkflow = .edit
                    } label: {
                        Label("Edit Publications", systemImage: "text.book.closed")
                    }

                    Spacer()
                }
            }

            DisclosureGroup("Template and style guidance") {
                CVTemplateGuidanceView(template: template, selectedTheme: selectedTheme, applyTheme: applyTheme)
                    .padding(.top, AppDesign.Spacing.sm)
            }
            .help("Show what this CV template optimizes for and which styles are allowed")
        }
    }

    private var editStep: some View {
        VStack(alignment: .leading, spacing: 12) {
            DisclosureGroup("Cleanup helpers", isExpanded: $showingCleanupHelpers) {
                CVCleanupActionsView(
                    hideUncertain: hideUncertainLines,
                    shortenToThreePages: shortenToThreePages,
                    fixPublications: store.normalizePublicationMetadata,
                    useTenureOrder: useTenureOrder,
                    makeSendable: makeSendable
                )
                .padding(.top, AppDesign.Spacing.sm)
            }
            .help("Open optional cleanup actions for shortening, publication metadata, and sendable mode")

            HStack {
                Picker("Edit pane", selection: $selectedEditorPane) {
                    ForEach(CVEditorPane.allCases) { pane in
                        Text(pane.rawValue).tag(pane)
                    }
                }
                .pickerStyle(.segmented)
                .frame(maxWidth: 520)
                .help("Choose what to edit: draft text, line rows, structured database, or publication metadata")
                Spacer()
            }

            DisclosureGroup("Advanced section ordering", isExpanded: $showingSectionControls) {
                sectionControls
                    .padding(.top, AppDesign.Spacing.sm)
            }
            .help("Include, exclude, and reorder exported CV sections")

            if store.cvItems.isEmpty {
                PrimaryEmptyState(
                    title: "No Structured CV Rows",
                    message: "Create a usable CV source by importing rows from your old CV files and evidence records.",
                    systemImage: "tablecells.badge.ellipsis",
                    actionTitle: "Scan CV Files",
                    actionImage: "doc.text.magnifyingglass",
                    action: refreshImportedCVMaterial
                )
                .frame(minHeight: 220)
            }

            editorContent
                .frame(maxWidth: .infinity, minHeight: 560, alignment: .topLeading)
        }
    }

    private var exportStep: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            CVExportStepView(
                draft: effectiveDraftForExport,
                theme: selectedTheme,
                variant: template,
                profilePicturePath: profilePicturePathForExport,
                selectedFormat: $selectedFormat,
                export: export,
                exportSet: { store.exportEditableCVDraftBundle(effectiveDraftForExport, variant: template, theme: selectedTheme) },
                exportPacket: { store.exportDossierPacket(cvDraft: effectiveDraftForExport, variant: template, theme: selectedTheme) },
                copy: { store.copyToClipboard(effectiveDraftForExport) },
                revealFolder: store.revealCVDraftFolder
            )

            DisclosureGroup("Quality checks, versions, and reviewer view", isExpanded: $showingQualityChecks) {
                checkStep
                    .padding(.top, AppDesign.Spacing.sm)
            }
            .help("Open diff, version history, reviewer view, and health scores")
        }
    }

    private func sourceMetric(_ title: String, _ value: String, _ subtitle: String, _ image: String, _ tone: StatusChip.Tone) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
            Label(title, systemImage: image)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title2.weight(.semibold))
            Text(subtitle)
                .font(.caption2)
                .foregroundStyle(.secondary)
            StatusChip(
                text: tone == .warning ? "Check" : (tone == .success ? "Ready" : "Info"),
                systemImage: tone == .warning ? "exclamationmark.circle" : (tone == .success ? "checkmark.circle" : "info.circle"),
                tone: tone
            )
        }
        .padding(AppDesign.Spacing.md)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .accessibilityElement(children: .combine)
    }

    private var profilePictureBinding: Binding<String> {
        Binding {
            store.connectorSettings.profilePicturePath
        } set: { newValue in
            var settings = store.connectorSettings
            settings.profilePicturePath = newValue
            store.saveConnectorSettings(settings)
        }
    }

    private var profilePicturePathForExport: String? {
        let path = store.connectorSettings.profilePicturePath.trimmed
        guard template != .tenk,
              selectedTheme.rendersProfilePictureMasthead,
              !path.isEmpty else {
            return nil
        }

        return path
    }

    private var nextActionTitle: String {
        switch selectedWorkflow {
        case .choose:
            "Check Source Material"
        case .check:
            "Edit Draft"
        case .edit:
            "Preview & Export"
        case .export:
            "Export \(selectedFormat.rawValue)"
        }
    }

    private var nextActionImage: String {
        switch selectedWorkflow {
        case .choose:
            "doc.text.magnifyingglass"
        case .check:
            "square.and.pencil"
        case .edit:
            "doc.richtext"
        case .export:
            selectedFormat.systemImage
        }
    }

    private var nextActionHelp: String {
        switch selectedWorkflow {
        case .choose:
            "Move to source checking before editing the CV text"
        case .check:
            "Move to the editor once the old CV and structured rows look present"
        case .edit:
            "Move to preview and export tools"
        case .export:
            selectedFormat.helpText
        }
    }

    private func advanceWorkflow() {
        switch selectedWorkflow {
        case .choose:
            selectedWorkflow = .check
        case .check:
            selectedWorkflow = .edit
            selectedEditorPane = .draft
        case .edit:
            selectedWorkflow = .export
            selectedCheckPane = .preview
        case .export:
            export(selectedFormat)
        }
    }

    private var sectionControls: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            if draftSections.isEmpty {
                Text("Generate a draft first.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                HStack {
                    Text("Choose which sections appear in export and drag rows to reorder them.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Button {
                        includeAllSections()
                    } label: {
                        Label("Include All", systemImage: "checklist.checked")
                    }
                    .help("Include every section in the current CV draft")
                }

                LazyVStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    ForEach(draftSections) { section in
                        HStack(spacing: AppDesign.Spacing.sm) {
                            Image(systemName: "line.3.horizontal")
                                .foregroundStyle(.secondary)
                                .help("Drag to reorder this section")

                            Toggle(isOn: binding(for: section)) {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(section.title)
                                        .lineLimit(1)
                                    Text("\(section.wordCount) words, \(section.bulletCount) bullets")
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            .toggleStyle(.checkbox)
                        }
                        .padding(.vertical, 3)
                        .draggable(section.id)
                        .dropDestination(for: String.self) { ids, _ in
                            guard let sourceID = ids.first else { return false }
                            moveSection(sourceID: sourceID, before: section.id)
                            return true
                        }
                    }
                }
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    @ViewBuilder
    private var editorContent: some View {
        switch selectedEditorPane {
        case .draft:
            draftEditor
        case .lines:
            CVLineEditorView(items: $lineItems, template: template) {
                syncDraftFromLines()
            }
        case .database:
            CVStructuredDatabaseView(store: store, template: template, openEvidence: openEvidence)
        case .publications:
            CVPublicationTableView(store: store)
        }
    }

    private var checkStep: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Picker("Check pane", selection: $selectedCheckPane) {
                    ForEach(CVCheckPane.allCases) { pane in
                        Text(pane.rawValue).tag(pane)
                    }
                }
                .pickerStyle(.segmented)
                .frame(maxWidth: 460)
                .help("Check layout, changes, reviewer view, or health scores")
                Spacer()
            }

            checkContent
        }
    }

    @ViewBuilder
    private var checkContent: some View {
        switch selectedCheckPane {
        case .preview:
            CVLivePreviewView(draft: effectiveDraftForExport, theme: selectedTheme, profilePicturePath: profilePicturePathForExport)
        case .diff:
            CVDiffView(
                report: CVDiffEngine.compare(
                    current: effectiveDraftForExport,
                    previous: store.lastCVDraftSnapshotText(),
                    theme: selectedTheme
                ),
                hasSnapshot: !store.lastCVDraftSnapshotText().trimmed.isEmpty
            )
        case .versions:
            CVVersionHistoryView(
                store: store,
                currentDraft: effectiveDraftForExport,
                theme: selectedTheme,
                restoreVersion: restoreVersion
            )
        case .reviewer:
            CVReviewerView(
                summary: CVReviewerSummaryBuilder.summary(
                    draft: effectiveDraftForExport,
                    entries: store.entries,
                    cvItems: store.cvItems
                )
            )
        case .health:
            CVHealthView(
                report: CVHealthReportBuilder.report(
                    draft: effectiveDraftForExport,
                    entries: store.entries,
                    cvItems: store.cvItems,
                    theme: selectedTheme,
                    variant: template
                )
            )
        }
    }

    private var draftEditor: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                AppSectionHeader(
                    title: "Editable Draft",
                    subtitle: "Edit the generated text directly, then refresh line rows if you want line-level control.",
                    systemImage: "doc.text"
                )
                Spacer()
                Button {
                    rebuildLineItemsFromDraft()
                } label: {
                    Label("Refresh Lines", systemImage: "arrow.triangle.2.circlepath")
                }
                .help("Rebuild the line editor rows from the current text draft")
            }

            TextEditor(text: $draft)
                .font(.system(.body, design: .serif))
                .frame(minHeight: 500)
                .scrollContentBackground(.hidden)
                .padding(10)
                .background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: 8))
                .accessibilityLabel("Editable CV draft text")
        }
    }

    private func preflightMetric(_ title: String, value: String, systemImage: String) -> some View {
        HStack(spacing: 5) {
            Image(systemName: systemImage)
                .foregroundStyle(.secondary)
            Text(value)
                .fontWeight(.semibold)
            Text(title)
                .foregroundStyle(.secondary)
        }
        .font(.caption)
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: 6))
        .help("\(title): \(value)")
    }

    private func templateRow(_ option: CVDraftVariant) -> some View {
        HStack(spacing: 10) {
            Image(systemName: option.systemImage)
                .foregroundStyle(.secondary)
                .frame(width: 18)

            VStack(alignment: .leading, spacing: 2) {
                Text(option.rawValue)
                    .lineLimit(1)
                Text(option.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .help(option.description)
    }

    private func applyPreset(_ preset: CVWizardPreset) {
        selectedTemplate = preset.variant
        selectedTheme = preset.theme
        ensureThemeAllowed()
        buildOptions = preset.options
        selectedWorkflow = .check
        selectedEditorPane = .draft
        regenerateDraft()
    }

    private func applyTheme(_ theme: CVDraftTheme) {
        guard template.allowedThemes.contains(theme) else { return }
        selectedTheme = theme
    }

    private func applyDesignPurpose(_ purpose: CVDesignPurpose) {
        selectedDesignPurpose = purpose
        selectedTemplate = purpose.variant
        selectedTheme = purpose.theme
        buildOptions = purpose.options
        ensureThemeAllowed()
        selectedWorkflow = .check
        selectedEditorPane = .draft
        regenerateDraft()
    }

    private func ensureThemeAllowed() {
        guard !template.allowedThemes.contains(selectedTheme) else { return }
        selectedTheme = template.allowedThemes.first ?? .aaltoClean
    }

    private func hideUncertainLines() {
        if lineItems.isEmpty {
            rebuildLineItemsFromDraft()
        }

        for index in lineItems.indices {
            let line = lineItems[index].text.lowercased()
            if lineItems[index].sourceConfidence == "review"
                || line.contains("[source: review]")
                || line.contains("review before")
                || line.contains("role to check")
                || line.contains("missing")
                || line.contains(" jufo: check")
                || line.contains("peer review: check") {
                lineItems[index].included = false
            }
        }

        syncDraftFromLines()
        store.lastMessage = "Hidden uncertain CV lines from the working draft."
    }

    private func shortenToThreePages() {
        selectedTemplate = .threePage
        selectedTheme = .compact
        buildOptions.onlyCVReadyEvidence = true
        buildOptions.compactBullets = true
        buildOptions.includeDraftNote = false
        buildOptions.includeSourceNotes = false
        buildOptions.includeSourceConfidence = false
        buildOptions.finalCleanMode = true
        selectedWorkflow = .edit
        selectedEditorPane = .lines
        regenerateDraft()
    }

    private func useTenureOrder() {
        selectedTemplate = .tenure
        selectedTheme = .aaltoClean
        buildOptions.includeAppEvidence = true
        buildOptions.finalCleanMode = false
        selectedWorkflow = .edit
        selectedEditorPane = .draft
        regenerateDraft()
    }

    private func makeSendable() {
        buildOptions.onlyCVReadyEvidence = true
        buildOptions.includeDraftNote = false
        buildOptions.includeSourceNotes = false
        buildOptions.includeSourceConfidence = false
        buildOptions.compactBullets = true
        buildOptions.finalCleanMode = true
        selectedWorkflow = .export
        selectedCheckPane = .preview
        regenerateDraft()
    }

    private func refreshImportedCVMaterial() {
        store.importCVSourcesAndRefresh()
        regenerateDraft()
    }

    private func regenerateDraft() {
        baseDraft = store.generateCurrentCVDraft(variant: template, options: buildOptions)
        sectionOrder = CVDraftSectionFilter.sections(in: baseDraft).map(\.id)
        includeAllSections()
        rebuildLineItemsFromDraft()
    }

    private func includeAllSections() {
        let sections = CVDraftSectionFilter.sections(in: baseDraft)
        if sectionOrder.isEmpty {
            sectionOrder = sections.map(\.id)
        }
        includedSectionIDs = Set(sections.map(\.id))
        applySectionFilter()
    }

    private func applySectionFilter() {
        draft = CVDraftSectionFilter.orderedMarkdown(
            baseDraft,
            includedSectionIDs: includedSectionIDs,
            orderedSectionIDs: sectionOrder
        )
        rebuildLineItemsFromDraft()
    }

    private func rebuildLineItemsFromDraft() {
        lineItems = CVDraftLineBuilder.items(from: draft, template: template)
    }

    private func syncDraftFromLines() {
        draft = CVDraftLineBuilder.markdown(from: lineItems)
    }

    private func restoreVersion(_ versionText: String) {
        draft = versionText
        baseDraft = versionText
        sectionOrder = CVDraftSectionFilter.sections(in: baseDraft).map(\.id)
        includedSectionIDs = Set(sectionOrder)
        rebuildLineItemsFromDraft()
        selectedWorkflow = .edit
        selectedEditorPane = .draft
        store.lastMessage = "Loaded saved CV version into the current draft."
    }

    private func moveSection(sourceID: String, before targetID: String) {
        guard sourceID != targetID else { return }

        var ordered = draftSections.map(\.id)
        guard let sourceIndex = ordered.firstIndex(of: sourceID),
              let targetIndex = ordered.firstIndex(of: targetID) else {
            return
        }

        let item = ordered.remove(at: sourceIndex)
        let adjustedTarget = sourceIndex < targetIndex ? targetIndex - 1 : targetIndex
        ordered.insert(item, at: adjustedTarget)
        sectionOrder = ordered
        applySectionFilter()
    }

    private func binding(for section: CVDraftSection) -> Binding<Bool> {
        Binding {
            includedSectionIDs.contains(section.id)
        } set: { isIncluded in
            if isIncluded {
                includedSectionIDs.insert(section.id)
            } else {
                includedSectionIDs.remove(section.id)
            }
            applySectionFilter()
        }
    }

    private func export(_ format: CVExportFormat) {
        store.exportEditableCVDraft(effectiveDraftForExport, variant: template, theme: selectedTheme, format: format)
    }

    private var appEntryCountForCurrentOptions: Int {
        let options = templateRule.options
        guard options.includeAppEvidence else { return 0 }

        return store.entries.filter { entry in
            options.onlyCVReadyEvidence ? entry.cvReady : (entry.cvReady || entry.completeness.score >= 75)
        }
        .count
    }

    private var importedCVSourceLineCount: Int {
        store.currentCVSourceText()
            .components(separatedBy: .newlines)
            .map(\.trimmed)
            .filter { line in
                !line.isEmpty
                    && !line.hasPrefix("--- Page")
                    && !line.localizedCaseInsensitiveContains("source files consulted")
            }
            .count
    }
}

private struct CVDraftPreflightReport {
    let wordCount: Int
    let sectionCount: Int
    let bulletCount: Int
    let pageCount: Int
    let layoutStatus: String
    let appEntryCount: Int
    let cvReadyCount: Int

    init(draft: String, theme: CVDraftTheme, profilePicturePath: String?, appEntryCount: Int, cvReadyCount: Int) {
        let layout = CVDocumentExporter.layoutReport(for: draft, theme: theme, profilePicturePath: profilePicturePath)
        self.wordCount = draft.split(whereSeparator: \.isWhitespace).count
        self.sectionCount = draft.components(separatedBy: "\n## ").count - 1
        self.bulletCount = draft.components(separatedBy: "\n- ").count - 1 + (draft.hasPrefix("- ") ? 1 : 0)
        self.pageCount = layout.pageCount
        self.layoutStatus = layout.threePageStatus
        self.appEntryCount = appEntryCount
        self.cvReadyCount = cvReadyCount
    }

    var readinessHint: String {
        if wordCount == 0 {
            return "No draft generated"
        }

        if wordCount > 2_400 {
            return "Long draft: shorten before sending"
        }

        if pageCount > 3 {
            return layoutStatus
        }

        if sectionCount < 5 {
            return "Thin draft: review missing sections"
        }

        return "Ready for editing and export"
    }

    var readinessColor: Color {
        if wordCount == 0 || sectionCount < 5 {
            return .orange
        }

        if pageCount > 3 {
            return .orange
        }

        if wordCount > 2_400 {
            return .secondary
        }

        return .green
    }
}
