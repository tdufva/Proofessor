import SwiftUI

struct TenureCriteriaMatrixView: View {
    let entries: [EvidenceEntry]
    var periodLabel: String = "All dates"
    var backgroundCount: Int = 0
    let openEvidence: (EvidenceEntry.ID) -> Void

    private var rows: [TenureDimensionCoverage] {
        TenureGapAnalyzer.coverage(entries: entries)
    }

    private var gapMessages: [String] {
        TenureGapAnalyzer.gapMessages(entries: entries)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Aalto Criteria Matrix",
                subtitle: "Current review period: \(periodLabel). \(backgroundCount) older/background record(s) kept out of the main dossier view.",
                systemImage: "square.grid.3x3"
            )

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 300), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.md) {
                ForEach(rows) { row in
                    matrixCard(row)
                }
            }

            gapFinder
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func matrixCard(_ row: TenureDimensionCoverage) -> some View {
        let status = status(for: row)

        return VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            HStack(alignment: .top) {
                Label(row.dimension.title, systemImage: row.dimension.systemImage)
                    .font(.headline)
                    .lineLimit(2)
                Spacer()
                StatusChip(text: status.label, systemImage: status.image, tone: status.tone)
            }

            Text(row.dimension.description)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: AppDesign.Spacing.sm) {
                metric("\(row.entries.count)", "total")
                metric("\(row.proofCount)", "proof")
                metric("\(row.readyCount)", "ready")
            }

            if row.gapNotes.isEmpty {
                Text("No obvious gaps in this area right now.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(row.gapNotes.prefix(2), id: \.self) { note in
                    gapText(note)
                }
            }

            if !row.entries.isEmpty {
                Text("Strongest records")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)

                ForEach(row.entries.prefix(3)) { entry in
                    Button {
                        openEvidence(entry.id)
                    } label: {
                        HStack(alignment: .top, spacing: AppDesign.Spacing.sm) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(entry.title.trimmed.isEmpty ? "Untitled evidence" : entry.title)
                                    .font(.caption.weight(.semibold))
                                    .lineLimit(1)
                                Text(entry.displaySubtitle.isEmpty ? entry.category : entry.displaySubtitle)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            Spacer()
                            Image(systemName: TenureGapAnalyzer.hasProof(entry) ? "paperclip.circle.fill" : "paperclip")
                                .font(.caption)
                                .foregroundStyle(TenureGapAnalyzer.hasProof(entry) ? .green : .orange)
                                .help(TenureGapAnalyzer.hasProof(entry) ? "Has proof" : "Proof needed")
                        }
                    }
                    .buttonStyle(.plain)
                    .help("Open this evidence record")
                }
            }
        }
        .padding(AppDesign.Spacing.md)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(status.tone.fill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .overlay {
            RoundedRectangle(cornerRadius: AppDesign.Radius.md)
                .strokeBorder(status.tone.foreground.opacity(0.22))
        }
    }

    private var gapFinder: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            Label("Gap Finder", systemImage: "magnifyingglass")
                .font(.headline)

            if gapMessages.isEmpty {
                Text("No major dossier gaps detected in the current review period.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(gapMessages, id: \.self) { message in
                    Label(message, systemImage: "exclamationmark.triangle")
                        .font(.caption)
                        .foregroundStyle(.orange)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding(AppDesign.Spacing.md)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func metric(_ value: String, _ label: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value)
                .font(.headline)
            Text(label)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.background.opacity(0.45), in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
    }

    private func gapText(_ text: String) -> some View {
        Label(text, systemImage: "exclamationmark.triangle")
            .font(.caption.weight(.medium))
            .foregroundStyle(.orange)
            .fixedSize(horizontal: false, vertical: true)
    }

    private func status(for row: TenureDimensionCoverage) -> (label: String, image: String, tone: StatusChip.Tone) {
        if row.entries.isEmpty {
            return ("Gap", "exclamationmark.triangle", .warning)
        }
        if row.proofCount == 0 {
            return ("Proof needed", "paperclip", .warning)
        }
        if row.readyCount == 0 {
            return ("Review", "checklist", .accent)
        }
        return ("Covered", "checkmark.circle", .success)
    }
}
