import SwiftUI

struct CVHealthView: View {
    let report: CVHealthReport

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("CV Health Scores", systemImage: "gauge.with.dots.needle.bottom.50percent")
                    .font(.headline)
                Spacer()
                Text("\(report.overall)% overall")
                    .font(.headline)
                    .foregroundStyle(color(for: report.overall))
            }

            Text("These scores are editing signals, not judgement. They point to where the CV needs evidence, metadata cleanup, shortening, or verification.")
                .font(.caption)
                .foregroundStyle(.secondary)

            VStack(alignment: .leading, spacing: 12) {
                ForEach(report.metrics) { metric in
                    metricRow(metric)
                }
            }
            .frame(maxWidth: 760, alignment: .leading)

            Spacer()
        }
    }

    private func metricRow(_ metric: CVHealthMetric) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(metric.title)
                    .font(.headline)
                Spacer()
                Text("\(metric.score)%")
                    .font(.headline)
                    .foregroundStyle(color(for: metric.score))
            }
            ProgressView(value: Double(metric.score), total: 100)
                .tint(color(for: metric.score))
            Text(metric.note)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(12)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private func color(for score: Int) -> Color {
        if score >= 75 { return .green }
        if score >= 50 { return .orange }
        return .red
    }
}
