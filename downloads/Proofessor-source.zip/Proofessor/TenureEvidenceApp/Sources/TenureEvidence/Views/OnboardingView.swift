import AppKit
import SwiftUI
import UniformTypeIdentifiers

struct OnboardingView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @State private var settings = ConnectorSettings()
    @State private var showProfileFields = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                header
                setupSummary
                folderSetup
                sourceSetup
                profileSetup
                footer
            }
            .padding(AppDesign.Spacing.xl)
            .frame(maxWidth: 880, alignment: .leading)
        }
        .background(AppDesign.appBackground)
        .frame(minWidth: 560, idealWidth: 840, minHeight: 620, idealHeight: 700)
        .onAppear {
            settings = store.connectorSettings
        }
    }

    private var header: some View {
        PageHeader(
            title: "Set Up Proofessor",
            subtitle: "Choose where the app may look. It will create suggestions first; you decide what becomes evidence.",
            systemImage: "point.3.connected.trianglepath.dotted",
            trailing: AnyView(
                Button("Close") {
                    dismiss()
                }
                .keyboardShortcut(.cancelAction)
            )
        )
    }

    private var setupSummary: some View {
        ActionPanel(
            title: "First Run",
            subtitle: "Add a folder, keep the sources you trust, then start a deep scan.",
            systemImage: "checklist"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                StatusStrip(items: [
                    StatusStripItem(
                        text: settings.allowedSourceLabels.isEmpty ? "No sources yet" : "\(settings.allowedSourceLabels.count) source type(s)",
                        systemImage: "lock.open",
                        tone: settings.allowedSourceLabels.isEmpty ? .warning : .success
                    ),
                    StatusStripItem(
                        text: settings.documentScanFolders.isEmpty ? "Folder needed" : "\(settings.documentScanFolders.count) folder(s)",
                        systemImage: "folder",
                        tone: settings.documentScanFolders.isEmpty ? .warning : .success
                    ),
                    StatusStripItem(
                        text: settings.configuredProfileCount == 0 ? "Profiles optional" : "\(settings.configuredProfileCount) profile link(s)",
                        systemImage: "graduationcap",
                        tone: settings.configuredProfileCount == 0 ? .neutral : .success
                    ),
                    StatusStripItem(
                        text: settings.profilePicturePath.trimmed.isEmpty ? "Picture optional" : "Picture ready",
                        systemImage: "person.crop.square",
                        tone: settings.profilePicturePath.trimmed.isEmpty ? .neutral : .success
                    )
                ])
            }
        }
    }

    private var sourceSetup: some View {
        ActionPanel(
            title: "2. Sources",
            subtitle: "Leave on what the app may use for suggested evidence.",
            systemImage: "lock.open"
        ) {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 210), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                Toggle("Calendar", isOn: $settings.allowCalendar)
                    .help("Allow calendar-derived suggestions for lectures, meetings, seminars, and reviews")
                Toggle("Mail", isOn: $settings.allowEmail)
                    .help("Allow email-derived suggestions for invitations, confirmations, feedback, and certificates")
                Toggle("Public web", isOn: $settings.allowPublicWeb)
                    .help("Allow public web/profile checks for visibility evidence")
                Toggle("Folders", isOn: $settings.allowLocalFiles)
                    .help("Allow local document folders to be scanned for evidence files")
                Toggle("Profiles", isOn: $settings.allowProfilePages)
                    .help("Allow institutional repository, Scholar, ORCID, and other public profile links")
            }
            .toggleStyle(.checkbox)
        }
    }

    private var folderSetup: some View {
        ActionPanel(
            title: "1. Evidence Folder",
            subtitle: "Drop or choose the place where your tenure material already lives.",
            systemImage: "folder.badge.plus"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    Label("App workspace", systemImage: "externaldrive")
                        .font(.caption.weight(.semibold))
                    Text(store.workspaceURL.path)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                        .textSelection(.enabled)
                }
                .padding(AppDesign.Spacing.sm)
                .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))

                dropFolderTarget

                if settings.documentScanFolders.isEmpty {
                    Text("No folder selected yet.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(settings.documentScanFolders, id: \.self) { folder in
                        HStack {
                            Image(systemName: "folder")
                                .foregroundStyle(.secondary)
                            Text(folder)
                                .lineLimit(1)
                                .truncationMode(.middle)
                                .textSelection(.enabled)
                            Spacer()
                            Button {
                                settings.documentScanFolders.removeAll { $0 == folder }
                            } label: {
                                Label("Remove", systemImage: "minus.circle")
                            }
                        }
                        .padding(AppDesign.Spacing.sm)
                        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
                    }
                }

                Button(action: chooseFolder) {
                    Label("Choose Folder to Scan", systemImage: "folder.badge.plus")
                }
                .help("Pick a local folder the app can scan for tenure documents")
            }
        }
    }

    private var dropFolderTarget: some View {
        VStack(alignment: .center, spacing: AppDesign.Spacing.sm) {
            Image(systemName: "tray.and.arrow.down")
                .font(.title2)
                .foregroundStyle(.secondary)
            Text("Drop an evidence folder here")
                .font(.headline)
            Text("If you drop a file, the app adds its containing folder.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, minHeight: 120)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .overlay(
            RoundedRectangle(cornerRadius: AppDesign.Radius.md)
                .strokeBorder(style: StrokeStyle(lineWidth: 1, dash: [6, 4]))
                .foregroundStyle(.secondary.opacity(0.35))
        )
        .onDrop(of: [UTType.fileURL.identifier], isTargeted: nil) { providers in
            handleDroppedFolders(providers)
        }
        .help("Drop a folder containing documents to add it as a scan source")
    }

    private var profileSetup: some View {
        ActionPanel(
            title: "3. Profile Details",
            subtitle: "Optional links help with profile snapshots and visibility checks.",
            systemImage: "person.text.rectangle"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                StatusStrip(items: [
                    StatusStripItem(
                        text: settings.configuredProfileCount == 0 ? "No profile links" : "\(settings.configuredProfileCount) profile link(s)",
                        systemImage: "link",
                        tone: settings.configuredProfileCount == 0 ? .neutral : .success
                    ),
                    StatusStripItem(
                        text: settings.publicDisplayName.trimmed.isEmpty ? "Name optional" : "Name set",
                        systemImage: "person",
                        tone: settings.publicDisplayName.trimmed.isEmpty ? .neutral : .success
                    )
                ])

                DisclosureGroup(isExpanded: $showProfileFields) {
                    VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                        settingsRow("Name", text: $settings.publicDisplayName, prompt: "Your public display name")
                        settingsRow("Institutional profile", text: $settings.acrisProfileURL, prompt: "https://research.example.edu/profile/...")
                        settingsRow("Google Scholar", text: $settings.googleScholarURL, prompt: "https://scholar.google.com/citations?user=...")
                        settingsRow("ORCID", text: $settings.orcidURL, prompt: "https://orcid.org/0000-0000-0000-0000")
                        settingsRow("Website", text: $settings.websiteURL, prompt: "https://...")
                        ProfilePicturePickerView(path: $settings.profilePicturePath)
                            .padding(.top, AppDesign.Spacing.sm)
                    }
                    .padding(.top, AppDesign.Spacing.sm)
                } label: {
                    Label("Edit optional profile details", systemImage: "pencil")
                }
            }
        }
    }

    private func settingsRow(_ title: String, text: Binding<String>, prompt: String) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: AppDesign.Spacing.md) {
                settingsLabel(title)
                    .frame(width: 150, alignment: .leading)
                TextField(prompt, text: text)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: .infinity)
            }
            VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                settingsLabel(title)
                TextField(prompt, text: text)
                    .textFieldStyle(.roundedBorder)
            }
        }
    }

    private func settingsLabel(_ title: String) -> some View {
        Text(title)
            .font(.caption.weight(.semibold))
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)
    }

    private var footer: some View {
        ViewThatFits(in: .horizontal) {
            footerContent(axis: .horizontal)
            footerContent(axis: .vertical)
        }
    }

    private func footerContent(axis: Axis.Set) -> some View {
        let text = VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
            Text("Allowed now: \(settings.allowedSourceLabels.isEmpty ? "No sources enabled" : settings.allowedSourceLabels.joined(separator: ", "))")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }

        let buttons = HStack {
            Button {
                save(startScan: false)
            } label: {
                Label("Save Setup", systemImage: "checkmark")
            }
            Button {
                save(startScan: true)
            } label: {
                Label("Save and Deep Scan", systemImage: "arrow.triangle.2.circlepath")
            }
            .disabled(settings.documentScanFolders.isEmpty || !settings.allowLocalFiles)
            .buttonStyle(.borderedProminent)
            .keyboardShortcut(.defaultAction)
        }

        if axis == .horizontal {
            return AnyView(HStack { text; Spacer(); buttons })
        }

        return AnyView(VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) { text; buttons })
    }

    private func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.prompt = "Use Folder"

        guard panel.runModal() == .OK, let url = panel.url else { return }
        addScanFolder(url)
    }

    private func addScanFolder(_ url: URL) {
        var isDirectory = ObjCBool(false)
        FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory)
        let folderURL = isDirectory.boolValue ? url : url.deletingLastPathComponent()
        let path = folderURL.standardizedFileURL.path
        if !settings.documentScanFolders.contains(path) {
            settings.documentScanFolders.append(path)
        }
    }

    private func handleDroppedFolders(_ providers: [NSItemProvider]) -> Bool {
        for provider in providers {
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                let url: URL?

                if let data = item as? Data {
                    url = URL(dataRepresentation: data, relativeTo: nil)
                } else if let droppedURL = item as? URL {
                    url = droppedURL
                } else {
                    url = nil
                }

                guard let url else { return }
                Task { @MainActor in
                    addScanFolder(url)
                }
            }
        }

        return true
    }

    private func save(startScan: Bool) {
        store.saveConnectorSettings(settings)
        if startScan {
            _ = store.scanDocumentSources()
        }
        dismiss()
    }
}
