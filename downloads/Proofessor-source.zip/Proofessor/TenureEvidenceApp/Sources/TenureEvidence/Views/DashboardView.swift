import SwiftUI

struct DashboardView: View {
    @ObservedObject var store: EvidenceStore
    let newEvidence: () -> Void
    let scanInbox: () -> Void
    let openEvidence: () -> Void
    let openCV: () -> Void
    let openImport: () -> Void
    let openSuggestions: () -> Void
    let openMonthlyReview: () -> Void
    let openDossier: () -> Void
    let openReviewScans: () -> Void
    let selectEvidence: (EvidenceEntry.ID) -> Void

    private var incompleteEntries: [EvidenceEntry] {
        store.incompleteEntries()
    }

    private var recentEntries: [EvidenceEntry] {
        Array(store.sortedEntries().prefix(6))
    }

    private var unverifiedCVItems: [CVStructuredItem] {
        store.cvItems
            .filter { !$0.verified || $0.sourceConfidence == "review" }
            .sorted {
                if $0.sourceConfidence == $1.sourceConfidence { return $0.order < $1.order }
                return $0.sourceConfidence == "review"
            }
    }

    private var publicationsNeedingMetadata: [CVStructuredItem] {
        store.cvItems
            .filter {
                $0.section == .publication
                    && ($0.doi.trimmed.isEmpty
                        || $0.peerReview == "check"
                        || $0.jufoLevel == "check"
                        || $0.tenkClass.trimmed.isEmpty)
            }
            .sorted { $0.year > $1.year }
    }

    private var cvClaimsWithoutEvidence: [CVStructuredItem] {
        store.cvItems
            .filter { item in
                item.title.trimmed.isEmpty == false
                    && (item.linkedEvidenceIDs ?? []).isEmpty
                    && item.section != .education
                    && item.section != .employment
            }
            .sorted {
                if $0.sourceConfidence == $1.sourceConfidence { return $0.order < $1.order }
                return $0.sourceConfidence == "review"
            }
    }

    private var evidenceWithoutAttachment: [EvidenceEntry] {
        store.entries
            .filter { entry in
                entry.attachments.isEmpty
                    && !entry.source.localizedCaseInsensitiveContains("http")
                    && (entry.cvReady || entry.completeness.score >= 60)
            }
            .sorted { lhs, rhs in
                if lhs.cvReady == rhs.cvReady { return lhs.date > rhs.date }
                return lhs.cvReady && !rhs.cvReady
            }
    }

    private var uncertainSourceLines: [CVReviewItem] {
        store.cvReviewQueueItems()
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                header
                if store.entries.isEmpty {
                    PrimaryEmptyState(
                        title: "Start Your Proofessor Evidence Base",
                        message: "Capture the first record, then the dashboard will start showing proof gaps, CV readiness, and filing work.",
                        systemImage: "tray.badge.plus",
                        actionTitle: "New Evidence",
                        actionImage: "plus",
                        action: newEvidence
                    )
                }
                pipeline
                TenureCriteriaGuidanceView()
                TenureCriteriaMatrixView(
                    entries: store.reviewPeriodEntries(),
                    periodLabel: store.reviewPeriodLabel(),
                    backgroundCount: store.backgroundContextEntries().count,
                    openEvidence: { id in
                        selectEvidence(id)
                        openEvidence()
                    }
                )
                nextActions
                metricGrid
                FixThisQueueView(
                    store: store,
                    openEvidence: { id in
                        selectEvidence(id)
                        openEvidence()
                    },
                    openCV: openCV,
                    openReviewScans: openReviewScans
                )
                missingProofDashboard
                attentionGrid
                recentAndVersions
            }
            .padding(AppDesign.Spacing.xl)
            .frame(maxWidth: 1180, alignment: .leading)
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Label("Tenure Overview", systemImage: "rectangle.3.group")
                .font(.largeTitle.weight(.semibold))
            Text("Capture evidence, verify the claims, file proof, build the CV, and export the dossier from one calm place.")
                .foregroundStyle(.secondary)
        }
    }

    private var pipeline: some View {
        HStack(spacing: 8) {
            pipelineStep("Capture", "Evidence records", "tray.and.arrow.down", isActive: true)
            pipelineArrow
            pipelineStep("Verify", "Completeness + sources", "checkmark.seal", isActive: !incompleteEntries.isEmpty)
            pipelineArrow
            pipelineStep("File", "Attachments + URLs", "folder", isActive: store.entries.contains { !$0.attachments.isEmpty })
            pipelineArrow
            pipelineStep("Build CV", "Structured database", "doc.text.magnifyingglass", isActive: !store.cvItems.isEmpty)
            pipelineArrow
            pipelineStep("Export", "CV + dossier", "square.and.arrow.up", isActive: !store.cvVersions.isEmpty)
        }
    }

    private var pipelineArrow: some View {
        Image(systemName: "chevron.right")
            .font(.caption)
            .foregroundStyle(.secondary)
    }

    private func pipelineStep(_ title: String, _ subtitle: String, _ image: String, isActive: Bool) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Label(title, systemImage: image)
                .font(.headline)
            Text(subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(isActive ? Color.green.opacity(0.08) : Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
        .help("\(title): \(subtitle)")
    }

    private var nextActions: some View {
        VStack(alignment: .leading, spacing: 10) {
            AppSectionHeader(
                title: "Next Best Actions",
                subtitle: "Fast routes into the work you are most likely to do now.",
                systemImage: "sparkles"
            )

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 210), alignment: .leading)], alignment: .leading, spacing: 10) {
                actionButton("Scan Documents", "Find files in Inbox, tenure folders, and configured folders", "arrow.triangle.2.circlepath", scanInbox)
                actionButton("Review Scans", "\(store.scannedDraftEntriesForReview().count) scanned draft(s)", "text.viewfinder", openReviewScans)
                actionButton("Import Text", "Paste calendar or email text", "tray.and.arrow.down", openImport)
                actionButton("Review Suggestions", "Check scheduled evidence inbox", "tray.full", openSuggestions)
                actionButton("Fix CV Metadata", "\(publicationsNeedingMetadata.count) publication item(s)", "text.book.closed", {
                    store.normalizePublicationMetadata()
                    openCV()
                })
                actionButton("Open CV Builder", "Purpose, source, edit, export", "doc.text.magnifyingglass", openCV)
                actionButton("Monthly Review", "Clean one month of activity", "calendar", openMonthlyReview)
                actionButton("Dossier", "Build tenure packet", "rectangle.3.group", openDossier)
            }
        }
    }

    private func actionButton(_ title: String, _ subtitle: String, _ image: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 6) {
                Label(title, systemImage: image)
                    .font(.headline)
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(10)
        }
        .buttonStyle(.bordered)
        .help(subtitle)
    }

    private var metricGrid: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), alignment: .leading)], alignment: .leading, spacing: 10) {
            metric("Evidence", "\(store.entries.count)", "tray.full", "Total evidence records")
            metric("Ready to use", "\(store.entries.filter(\.cvReady).count)", "checkmark.circle", "Evidence records marked ready for CV")
            metric("Needs attention", "\(incompleteEntries.count)", "exclamationmark.triangle", "Evidence records missing fields or proof")
            metric("CV items", "\(store.cvItems.count)", "tablecells", "Structured CV database rows")
            metric("Unverified CV", "\(unverifiedCVItems.count)", "questionmark.circle", "Structured CV rows that need verification")
            metric("Proof needed", "\(cvClaimsWithoutEvidence.count + evidenceWithoutAttachment.count)", "link.badge.plus", "CV claims and evidence records that need supporting proof")
            metric("CV versions", "\(store.cvVersions.count)", "clock.arrow.circlepath", "Saved CV export snapshots")
        }
    }

    private func metric(_ title: String, _ value: String, _ image: String, _ help: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Label(title, systemImage: image)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title2.weight(.semibold))
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
        .help(help)
    }

    private var missingProofDashboard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                AppSectionHeader(
                    title: "Proof Needed Dashboard",
                    subtitle: "A quick audit of claims, files, metadata, and uncertain source lines.",
                    systemImage: "doc.text.magnifyingglass"
                )
                Button {
                    openCV()
                } label: {
                    Label("Open CV Claims", systemImage: "tablecells")
                }
                .help("Open Build CV to link evidence and clean uncertain claims")
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 250), alignment: .top)], alignment: .leading, spacing: 10) {
                proofColumn(
                    "CV claims without evidence",
                    count: cvClaimsWithoutEvidence.count,
                    image: "link.badge.plus"
                ) {
                    if cvClaimsWithoutEvidence.isEmpty {
                        secondaryText("All main structured CV claims have linked evidence.")
                    } else {
                        ForEach(cvClaimsWithoutEvidence.prefix(4)) { item in
                            cvItemLine(item)
                        }
                    }
                }

                proofColumn(
                    "Evidence without attachment",
                    count: evidenceWithoutAttachment.count,
                    image: "paperclip"
                ) {
                    if evidenceWithoutAttachment.isEmpty {
                        secondaryText("No CV-facing evidence needs proof files or URLs.")
                    } else {
                        ForEach(evidenceWithoutAttachment.prefix(4)) { entry in
                            evidenceButton(entry)
                        }
                    }
                }

                proofColumn(
                    "Publication metadata incomplete",
                    count: publicationsNeedingMetadata.count,
                    image: "text.book.closed"
                ) {
                    if publicationsNeedingMetadata.isEmpty {
                        secondaryText("Publication DOI, TENK, JUFO, and peer-review fields look clean.")
                    } else {
                        ForEach(publicationsNeedingMetadata.prefix(4)) { item in
                            cvItemLine(item)
                        }
                    }
                }

                proofColumn(
                    "Uncertain source lines",
                    count: uncertainSourceLines.count,
                    image: "questionmark.circle"
                ) {
                    if uncertainSourceLines.isEmpty {
                        secondaryText("No uncertain old-CV or web-source lines found.")
                    } else {
                        ForEach(uncertainSourceLines.prefix(4)) { item in
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.line)
                                    .font(.caption.weight(.semibold))
                                    .lineLimit(2)
                                Text(item.reason)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            .help("Open Build CV > Review Queue to accept or clean this line")
                        }
                    }
                }
            }
        }
        .padding(12)
        .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private func proofColumn<Content: View>(
        _ title: String,
        count: Int,
        image: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label(title, systemImage: image)
                    .font(.headline)
                Spacer()
                Text("\(count)")
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 7)
                    .padding(.vertical, 3)
                    .background(count == 0 ? Color.green.opacity(0.14) : Color.orange.opacity(0.16), in: Capsule())
            }
            content()
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private var attentionGrid: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 330), alignment: .top)], alignment: .leading, spacing: 12) {
            attentionSection("Evidence Needs Attention", image: "exclamationmark.triangle") {
                if incompleteEntries.isEmpty {
                    secondaryText("No incomplete evidence records.")
                } else {
                    ForEach(incompleteEntries.prefix(5)) { entry in
                        evidenceButton(entry)
                    }
                }
            }

            attentionSection("Unverified CV Items", image: "questionmark.circle") {
                if unverifiedCVItems.isEmpty {
                    secondaryText("No unverified structured CV items.")
                } else {
                    ForEach(unverifiedCVItems.prefix(5)) { item in
                        cvItemLine(item)
                    }
                }
            }

            attentionSection("Publication Metadata", image: "text.book.closed") {
                if publicationsNeedingMetadata.isEmpty {
                    secondaryText("Publication metadata looks clean.")
                } else {
                    ForEach(publicationsNeedingMetadata.prefix(5)) { item in
                        cvItemLine(item)
                    }
                    Button {
                        store.normalizePublicationMetadata()
                    } label: {
                        Label("Fix What Can Be Inferred", systemImage: "wand.and.stars")
                    }
                    .help("Fill missing DOI, TENK, peer-review, and author hints when the app can infer them")
                }
            }
        }
    }

    private var recentAndVersions: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 430), alignment: .top)], alignment: .leading, spacing: 12) {
            attentionSection("Recent Evidence", image: "clock") {
                if recentEntries.isEmpty {
                    secondaryText("No evidence records yet.")
                } else {
                    ForEach(recentEntries) { entry in
                        evidenceButton(entry)
                    }
                }
            }

            attentionSection("CV Version History", image: "clock.arrow.circlepath") {
                if store.cvVersions.isEmpty {
                    secondaryText("No CV exports saved yet. Export once from Build CV to create a version.")
                } else {
                    ForEach(store.cvVersions.prefix(5)) { version in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(version.displayTitle)
                                    .font(.caption.weight(.semibold))
                                    .lineLimit(1)
                                Text(version.displaySubtitle)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            Spacer()
                            Button {
                                store.revealCVVersion(version)
                            } label: {
                                Image(systemName: "folder")
                            }
                            .buttonStyle(.borderless)
                            .help("Reveal this CV version snapshot")
                        }
                    }
                    Button {
                        openCV()
                    } label: {
                        Label("Open Version History", systemImage: "doc.text.magnifyingglass")
                    }
                }
            }
        }
    }

    private func attentionSection<Content: View>(
        _ title: String,
        image: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Label(title, systemImage: image)
                .font(.headline)
            content()
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private func evidenceButton(_ entry: EvidenceEntry) -> some View {
        Button {
            selectEvidence(entry.id)
            openEvidence()
        } label: {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(entry.title.trimmed.isEmpty ? "Untitled evidence" : entry.title)
                        .font(.caption.weight(.semibold))
                        .lineLimit(1)
                    Text(entry.displaySubtitle.isEmpty ? entry.category : entry.displaySubtitle)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                Text("\(entry.completeness.score)%")
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(entry.completeness.score >= 90 ? .green : .orange)
            }
        }
        .buttonStyle(.plain)
        .help("Open evidence record")
    }

    private func cvItemLine(_ item: CVStructuredItem) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(item.title.trimmed.isEmpty ? "Untitled CV item" : item.title)
                .font(.caption.weight(.semibold))
                .lineLimit(1)
            Text("\(item.section.rawValue) · \(item.sourceConfidence) · \(item.verified ? "verified" : "not verified")")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
    }

    private func secondaryText(_ value: String) -> some View {
        Text(value)
            .font(.caption)
            .foregroundStyle(.secondary)
    }
}
