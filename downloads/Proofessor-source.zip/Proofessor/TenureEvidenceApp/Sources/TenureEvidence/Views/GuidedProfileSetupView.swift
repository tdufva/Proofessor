import SwiftUI

struct GuidedProfileSetupView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    var onSave: (() -> Void)? = nil

    @State private var suggestion = ProfileAutofillSuggestion()
    @State private var showLinks = false
    @State private var showSelectedWork = true

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                header
                overview
                identityFields
                themeFields
                selectedWorkFields
                linkFields

                Text(store.lastMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(AppDesign.Spacing.xl)
            .frame(maxWidth: 920, alignment: .leading)
        }
        .frame(minWidth: 720, minHeight: 620)
        .onAppear(perform: refresh)
    }

    private var header: some View {
        PageHeader(
            title: "Autofill My Profile",
            subtitle: "The app looks through your CV source, profile links, structured CV rows, and evidence records. Check the result once; CVs, bios, and dossier text use it after that.",
            systemImage: "wand.and.sparkles",
            trailing: AnyView(
                HStack {
                    Button(action: refresh) {
                        Label("Autofill", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .help("Refill the fields from current CV and evidence material")

                    Button(action: save) {
                        Label("Save Profile", systemImage: "checkmark")
                    }
                    .buttonStyle(.borderedProminent)
                    .keyboardShortcut(.defaultAction)

                    Button("Close") {
                        dismiss()
                    }
                    .keyboardShortcut(.cancelAction)
                }
            )
        )
    }

    private var overview: some View {
        StatusStrip(items: [
            StatusStripItem(text: "\(suggestion.filledCount)/11 found", systemImage: "checklist", tone: suggestion.filledCount >= 7 ? .success : .warning),
            StatusStripItem(text: store.connectorSettings.profileCompletenessCount == 0 ? "New setup" : "Saved profile exists", systemImage: "person.crop.circle", tone: store.connectorSettings.profileCompletenessCount == 0 ? .neutral : .accent),
            StatusStripItem(text: "\(store.cvItems.count) CV rows", systemImage: "list.bullet.rectangle", tone: store.cvItems.isEmpty ? .neutral : .success),
            StatusStripItem(text: "\(store.entries.count) evidence records", systemImage: "tray.full", tone: store.entries.isEmpty ? .neutral : .success)
        ])
    }

    private var identityFields: some View {
        ActionPanel(
            title: "Identity",
            subtitle: "These lines appear first in CVs, bios, and public profile drafts.",
            systemImage: "person.text.rectangle"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                profileRow("Name", text: $suggestion.name, prompt: "Full name")
                profileRow("Title", text: $suggestion.title, prompt: "Assistant Professor, Lecturer, Artist-researcher...")
                profileRow("Affiliation", text: $suggestion.affiliation, prompt: "Aalto University, school, department, group...")
            }
        }
    }

    private var themeFields: some View {
        ActionPanel(
            title: "Themes",
            subtitle: "Short phrases work best. These steer CV order, bios, and dossier paragraphs.",
            systemImage: "text.magnifyingglass"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                profileRow("Research", text: $suggestion.researchThemes, prompt: "AI, art education, postdigital culture...")
                profileRow("Artistic", text: $suggestion.artisticThemes, prompt: "Exhibitions, media art, practice-based research...")
                profileRow("Teaching", text: $suggestion.teachingThemes, prompt: "Pedagogy, supervision, curriculum, creative coding...")
            }
        }
    }

    private var selectedWorkFields: some View {
        DisclosureGroup(isExpanded: $showSelectedWork) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                multilineField("Selected publications", text: $suggestion.selectedPublications, prompt: "One selected publication per line")
                multilineField("Selected exhibitions/projects", text: $suggestion.selectedExhibitions, prompt: "One selected exhibition or project per line")
            }
            .padding(.top, AppDesign.Spacing.sm)
        } label: {
            Label("Selected Work", systemImage: "star.square")
                .font(.headline)
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var linkFields: some View {
        DisclosureGroup(isExpanded: $showLinks) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                profileRow("ORCID", text: $suggestion.orcidURL, prompt: "https://orcid.org/...")
                profileRow("Google Scholar", text: $suggestion.googleScholarURL, prompt: "https://scholar.google.com/...")
                profileRow("Aalto profile", text: $suggestion.aaltoProfileURL, prompt: "https://www.aalto.fi/... or research.aalto.fi/...")
            }
            .padding(.top, AppDesign.Spacing.sm)
        } label: {
            Label("Profile Links", systemImage: "link")
                .font(.headline)
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func profileRow(_ title: String, text: Binding<String>, prompt: String) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: AppDesign.Spacing.md) {
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .frame(width: 120, alignment: .leading)
                TextField(prompt, text: text)
                    .textFieldStyle(.roundedBorder)
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                TextField(prompt, text: text)
                    .textFieldStyle(.roundedBorder)
            }
        }
    }

    private func multilineField(_ title: String, text: Binding<String>, prompt: String) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            TextEditor(text: text)
                .font(.body)
                .frame(minHeight: 92)
                .scrollContentBackground(.hidden)
                .padding(8)
                .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
                .overlay(alignment: .topLeading) {
                    if text.wrappedValue.trimmed.isEmpty {
                        Text(prompt)
                            .font(.caption)
                            .foregroundStyle(.secondary.opacity(0.75))
                            .padding(.horizontal, 14)
                            .padding(.vertical, 14)
                            .allowsHitTesting(false)
                    }
                }
        }
    }

    private func refresh() {
        suggestion = store.profileAutofillSuggestion()
    }

    private func save() {
        store.saveProfileAutofill(suggestion)
        onSave?()
    }
}
