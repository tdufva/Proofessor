import SwiftUI

struct SidebarView: View {
    let entries: [EvidenceEntry]
    @Binding var selection: EvidenceEntry.ID?
    let addAction: () -> Void
    let deleteAction: () -> Void

    var body: some View {
        List(selection: $selection) {
            Section("Evidence") {
                ForEach(entries) { entry in
                    HStack(spacing: 10) {
                        Image(systemName: iconName(for: entry))
                            .foregroundStyle(.secondary)
                            .frame(width: 18)
                            .help("\(entry.category) evidence")

                        VStack(alignment: .leading, spacing: 3) {
                            Text(entry.title.isEmpty ? "Untitled evidence" : entry.title)
                                .lineLimit(1)

                            Text(entry.displaySubtitle.isEmpty ? entry.category : entry.displaySubtitle)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                        }

                        Spacer(minLength: 8)

                        Text("\(entry.completeness.score)%")
                            .font(.caption2.weight(.medium))
                            .foregroundStyle(entry.completeness.score >= 90 ? .green : .secondary)
                            .help("Completeness score: \(entry.completeness.score)%")
                    }
                    .accessibilityElement(children: .combine)
                    .accessibilityLabel("\(entry.title.isEmpty ? "Untitled evidence" : entry.title), \(entry.category), \(entry.completeness.score) percent complete")
                    .tag(entry.id)
                    .contextMenu {
                        Button("Delete", role: .destructive, action: deleteAction)
                    }
                }
            }
        }
        .listStyle(.sidebar)
        .safeAreaInset(edge: .bottom) {
            HStack {
                Button(action: addAction) {
                    Label("Add", systemImage: "plus")
                }
                .help("Create a new blank evidence record")
                Spacer()
                Button(role: .destructive, action: deleteAction) {
                    Label("Delete", systemImage: "trash")
                }
                .disabled(selection == nil)
                .help("Delete the selected evidence record")
            }
            .padding(10)
            .background(.bar)
        }
    }

    private func iconName(for entry: EvidenceEntry) -> String {
        switch entry.category {
        case "Talk": "person.wave.2"
        case "Artistic Output": "paintpalette"
        case "Publication": "doc.text"
        case "Funding": "eurosign.circle"
        case "Teaching": "graduationcap"
        case "Supervision": "person.2"
        case "Service": "building.columns"
        case "Visibility": "megaphone"
        default: "tray.full"
        }
    }
}
