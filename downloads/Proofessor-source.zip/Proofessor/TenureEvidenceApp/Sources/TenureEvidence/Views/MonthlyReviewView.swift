import SwiftUI

struct MonthlyReviewView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @State private var selectedMonth: String

    init(store: EvidenceStore) {
        self.store = store
        _selectedMonth = State(initialValue: store.availableMonths().first ?? Self.currentMonth())
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Label("Monthly Review", systemImage: "calendar")
                    .font(.title2.weight(.semibold))
                Spacer()
                Picker("Month", selection: $selectedMonth) {
                    ForEach(monthOptions, id: \.self) { month in
                        Text(month).tag(month)
                    }
                }
                .frame(width: 160)
                .help("Choose the month to review")

                Button {
                    store.exportMonthlyReview(month: selectedMonth)
                } label: {
                    Label("Export Review", systemImage: "square.and.arrow.up")
                }
                .help("Export a Markdown review for the selected month")

                Button("Close") {
                    dismiss()
                }
            }

            HStack(spacing: 14) {
                metricCard("Entries", value: "\(monthEntries.count)")
                metricCard("CV Ready", value: "\(monthEntries.filter { $0.cvReady }.count)")
                metricCard("Needs Evidence", value: "\(store.incompleteEntries().filter { $0.attachments.isEmpty }.count)")
                metricCard("Average", value: "\(averageScore)%")
            }

            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    reviewSection("Entries in \(selectedMonth)", entries: monthEntries)
                    reviewSection("Lowest Completeness", entries: Array(store.incompleteEntries().prefix(10)))
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(22)
    }

    private var monthOptions: [String] {
        let months = store.availableMonths()
        return months.isEmpty ? [Self.currentMonth()] : months
    }

    private var monthEntries: [EvidenceEntry] {
        store.entries(forMonth: selectedMonth)
    }

    private var averageScore: Int {
        guard !monthEntries.isEmpty else { return 0 }
        let total = monthEntries.map { $0.completeness.score }.reduce(0, +)
        return total / monthEntries.count
    }

    private func metricCard(_ title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title3.weight(.semibold))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 8))
    }

    private func reviewSection(_ title: String, entries: [EvidenceEntry]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.headline)

            if entries.isEmpty {
                Text("No entries.")
                    .foregroundStyle(.secondary)
            } else {
                ForEach(entries) { entry in
                    HStack(alignment: .firstTextBaseline) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(entry.title)
                                .font(.body.weight(.medium))
                            Text(entry.displaySubtitle)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            if !entry.completeness.missing.isEmpty {
                                Text("Missing: \(entry.completeness.missing.joined(separator: ", "))")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        Text("\(entry.completeness.score)%")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(entry.completeness.score >= 90 ? .green : .secondary)
                            .help("Completeness score: \(entry.completeness.score)%")
                    }
                    Divider()
                }
            }
        }
    }

    private static func currentMonth() -> String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM"
        return formatter.string(from: Date())
    }
}
