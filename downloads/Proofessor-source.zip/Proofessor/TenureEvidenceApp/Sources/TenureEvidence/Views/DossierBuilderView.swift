import SwiftUI

struct DossierBuilderView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @State private var narrativeSections: [DossierNarrativeSection] = []

    private let dimensions = [
        "Research/artistic work",
        "Teaching",
        "Impact and service"
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Label("Dossier Builder", systemImage: "rectangle.3.group")
                    .font(.title2.weight(.semibold))
                Spacer()
                Button {
                    store.exportDossierNarrative(narrativeSections)
                } label: {
                    Label("Export Narrative", systemImage: "text.quote")
                }
                .help("Export the editable dossier narrative paragraphs")
                Button {
                    store.exportDossier()
                } label: {
                    Label("Export Dossier", systemImage: "square.and.arrow.up")
                }
                .help("Export the dossier planning view as Markdown")
                Button("Close") {
                    dismiss()
                }
            }

            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    narrativeBuilder
                    ForEach(dimensions, id: \.self) { dimension in
                        dimensionSection(dimension)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(22)
        .onAppear(perform: regenerateNarrative)
    }

    private var narrativeBuilder: some View {
        ActionPanel(
            title: "Narrative Builder",
            subtitle: "Short, editable paragraphs for tenure materials. Each paragraph names the evidence base and warns when proof is thin.",
            systemImage: "text.quote"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                HStack {
                    Button(action: regenerateNarrative) {
                        Label("Regenerate", systemImage: "arrow.triangle.2.circlepath")
                    }
                    Button {
                        store.copyToClipboard(DossierNarrativeBuilder.markdown(from: narrativeSections))
                    } label: {
                        Label("Copy", systemImage: "doc.on.doc")
                    }
                    Spacer()
                    Button {
                        store.exportDossierNarrative(narrativeSections)
                    } label: {
                        Label("Export", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(.borderedProminent)
                }

                LazyVStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                    ForEach(narrativeSections) { section in
                        narrativeSectionEditor(section)
                    }
                }
            }
        }
    }

    private func narrativeSectionEditor(_ section: DossierNarrativeSection) -> some View {
        let binding = Binding<String> {
            narrativeSections.first(where: { $0.id == section.id })?.paragraph ?? section.paragraph
        } set: { newValue in
            guard let index = narrativeSections.firstIndex(where: { $0.id == section.id }) else { return }
            narrativeSections[index].paragraph = newValue
        }

        return VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            HStack {
                Label(section.title, systemImage: section.systemImage)
                    .font(.headline)
                Spacer()
                StatusChip(
                    text: section.evidenceTitles.isEmpty ? "Proof needed" : "\(section.evidenceTitles.count) evidence item(s)",
                    systemImage: section.evidenceTitles.isEmpty ? "paperclip" : "checkmark.circle",
                    tone: section.evidenceTitles.isEmpty ? .warning : .success
                )
            }

            TextEditor(text: binding)
                .font(.body)
                .frame(minHeight: 94)
                .scrollContentBackground(.hidden)
                .padding(8)
                .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))

            if !section.missingNote.trimmed.isEmpty {
                Text(section.missingNote)
                    .font(.caption)
                    .foregroundStyle(section.missingNote.localizedCaseInsensitiveContains("need") ? .orange : .secondary)
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func dimensionSection(_ dimension: String) -> some View {
        let entries = store.sortedEntries()
            .filter { $0.tenureDimension == dimension || $0.tenureDimension == "All" || inferredDimension($0) == dimension }
            .sorted { lhs, rhs in
                if lhs.cvReady != rhs.cvReady { return lhs.cvReady && !rhs.cvReady }
                return lhs.completeness.score > rhs.completeness.score
            }

        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(dimension)
                    .font(.headline)
                Spacer()
                Text("\(entries.count) entries")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if entries.isEmpty {
                Text("No evidence filed yet.")
                    .foregroundStyle(.secondary)
            } else {
                ForEach(entries.prefix(8)) { entry in
                    HStack(alignment: .firstTextBaseline, spacing: 12) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(entry.title)
                                .font(.body.weight(.medium))
                            Text(entry.displaySubtitle)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if entry.cvReady {
                            Image(systemName: "checkmark.seal.fill")
                                .foregroundStyle(.green)
                                .help("Ready to use")
                        }
                        Text("\(entry.completeness.score)%")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(entry.completeness.score >= 90 ? .green : .secondary)
                            .help("Completeness score: \(entry.completeness.score)%")
                    }
                    Divider()
                }
            }
        }
        .padding(14)
        .background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: 8))
    }

    private func inferredDimension(_ entry: EvidenceEntry) -> String {
        switch entry.category {
        case "Teaching", "Supervision":
            "Teaching"
        case "Service", "Visibility":
            "Impact and service"
        default:
            "Research/artistic work"
        }
    }

    private func regenerateNarrative() {
        narrativeSections = DossierNarrativeBuilder.build(
            entries: store.reviewPeriodEntries(),
            cvItems: store.cvItems,
            settings: store.connectorSettings
        )
    }
}
