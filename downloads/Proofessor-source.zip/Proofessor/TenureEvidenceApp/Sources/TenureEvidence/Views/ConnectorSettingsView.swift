import AppKit
import SwiftUI

struct ConnectorSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @State private var settings = ConnectorSettings()
    @State private var showProfileLinkFields = false
    @State private var showAutomationNote = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                header
                sourcePermissions
                documentFolders
                profileLinks
                automationRules
                footer
            }
            .padding(AppDesign.Spacing.xl)
            .frame(maxWidth: 760, alignment: .leading)
        }
        .frame(minWidth: 520, idealWidth: 720, minHeight: 560, idealHeight: 680)
        .onAppear {
            settings = store.connectorSettings
        }
    }

    private var header: some View {
        PageHeader(
            title: "Source Settings",
            subtitle: "Choose what the app may use when suggesting evidence.",
            systemImage: "switch.2",
            trailing: AnyView(
                HStack {
                    Button {
                        store.revealConnectorSettings()
                    } label: {
                        Label("Config File", systemImage: "doc.text.magnifyingglass")
                    }
                    .help("Reveal the JSON settings file used by the suggested evidence scan")

                    Button {
                        save()
                    } label: {
                        Label("Save", systemImage: "checkmark")
                    }
                    .buttonStyle(.borderedProminent)
                    .keyboardShortcut(.defaultAction)

                    Button("Close") {
                        dismiss()
                    }
                    .keyboardShortcut(.cancelAction)
                }
            )
        )
    }

    private var sourcePermissions: some View {
        ActionPanel(
            title: "Allowed Sources",
            subtitle: "These switches control the suggestion scan.",
            systemImage: "lock.open"
        ) {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                Toggle("Calendar events", isOn: $settings.allowCalendar)
                    .help("Allow tenure suggestions from calendar titles, hosts, dates, and locations")
                Toggle("Email messages", isOn: $settings.allowEmail)
                    .help("Allow tenure suggestions from email invitations, confirmations, certificates, and event details")
                Toggle("Public web", isOn: $settings.allowPublicWeb)
                    .help("Allow public web searches for profile, lectures, keynotes, talks, and presentations")
                Toggle("Document folders", isOn: $settings.allowLocalFiles)
                    .help("Allow local document folders to be scanned for CVs, PDFs, slides, certificates, and notes")
                Toggle("Profile pages", isOn: $settings.allowProfilePages)
                    .help("Allow Institutional research profile, Google Scholar, ORCID, and other profile pages")
            }
            .toggleStyle(.checkbox)
        }
    }

    private var documentFolders: some View {
        ActionPanel(
            title: "Document Folders to Scan",
            subtitle: "Add folders with CVs, certificates, slides, teaching evidence, or old tenure material.",
            systemImage: "folder.badge.plus"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                if settings.documentScanFolders.isEmpty {
                    AppEmptyState(
                        title: "No Folder Added",
                        message: "Choose one folder to scan for documents when collecting tenure evidence.",
                        systemImage: "folder",
                        actionTitle: "Choose Folder",
                        actionImage: "folder.badge.plus",
                        action: chooseFolder
                    )
                    .frame(minHeight: 180)
                } else {
                    ForEach(settings.documentScanFolders, id: \.self) { folder in
                        HStack {
                            Image(systemName: "folder")
                                .foregroundStyle(.secondary)
                            Text(folder)
                                .lineLimit(1)
                                .truncationMode(.middle)
                                .textSelection(.enabled)
                            Spacer()
                            Button {
                                settings.documentScanFolders.removeAll { $0 == folder }
                            } label: {
                                Label("Remove", systemImage: "minus.circle")
                            }
                            .help("Remove this folder from future scans")
                        }
                        .padding(AppDesign.Spacing.sm)
                        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
                    }
                }

                HStack {
                    Button(action: chooseFolder) {
                        Label("Choose Folder", systemImage: "folder.badge.plus")
                    }
                    .help("Add a local folder to scan for evidence documents")

                    Button {
                        save()
                        _ = store.scanDocumentSources()
                    } label: {
                        Label("Deep Scan Now", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .disabled(settings.documentScanFolders.isEmpty || !settings.allowLocalFiles)
                    .help("Save settings and scan inbox, workspace, and configured folders")

                    Spacer()
                }
            }
        }
    }

    private var profileLinks: some View {
        ActionPanel(
            title: "Profile Links",
            subtitle: "Optional links for snapshots, public visibility checks, and CV variants.",
            systemImage: "person.text.rectangle"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                StatusStrip(items: [
                    StatusStripItem(
                        text: settings.configuredProfileCount == 0 ? "No links" : "\(settings.configuredProfileCount) link(s)",
                        systemImage: "link",
                        tone: settings.configuredProfileCount == 0 ? .neutral : .success
                    ),
                    StatusStripItem(
                        text: settings.publicDisplayName.trimmed.isEmpty ? "Name optional" : "Name set",
                        systemImage: "person",
                        tone: settings.publicDisplayName.trimmed.isEmpty ? .neutral : .success
                    )
                ])

                DisclosureGroup(isExpanded: $showProfileLinkFields) {
                    VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                        settingsRow("Display name", text: $settings.publicDisplayName, prompt: "Name used for public web searches")
                        settingsRow("Institutional profile", text: $settings.acrisProfileURL, prompt: "https://research.example.edu/profile/...")
                        settingsRow("Google Scholar", text: $settings.googleScholarURL, prompt: "https://scholar.google.com/citations?user=...")
                        settingsRow("ORCID", text: $settings.orcidURL, prompt: "https://orcid.org/0000-0000-0000-0000")
                        settingsRow("People page", text: $settings.aaltoPeopleURL, prompt: "https://www.example.edu/people/...")
                        settingsRow("LinkedIn", text: $settings.linkedInURL, prompt: "https://linkedin.com/in/...")
                        settingsRow("Social media", text: $settings.socialMediaURL, prompt: "https://mastodon.social/@name or https://bsky.app/profile/...")
                        settingsRow("Website", text: $settings.websiteURL, prompt: "https://...")
                    }
                    .padding(.top, AppDesign.Spacing.sm)
                } label: {
                    Label("Edit optional profile links", systemImage: "pencil")
                }
            }
        }
    }

    private func settingsRow(_ title: String, text: Binding<String>, prompt: String) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: AppDesign.Spacing.md) {
                settingsLabel(title)
                    .frame(width: 150, alignment: .leading)
                TextField(prompt, text: text)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: .infinity)
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                settingsLabel(title)
                TextField(prompt, text: text)
                    .textFieldStyle(.roundedBorder)
            }
        }
    }

    private func settingsLabel(_ title: String) -> some View {
        Text(title)
            .font(.caption.weight(.semibold))
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)
    }

    private var automationRules: some View {
        ActionPanel(
            title: "Scan Rules",
            subtitle: "Keep suggestions focused on current tenure evidence.",
            systemImage: "slider.horizontal.3"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                HStack {
                    Text("Earliest year")
                    Stepper(value: $settings.earliestYear, in: 2000...2035) {
                        Text("\(settings.earliestYear)")
                            .frame(width: 52, alignment: .leading)
                    }
                    .help("Ignore suggestions before this year unless they are clearly tenure-relevant")
                    Spacer()
                }

                VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    DisclosureGroup(isExpanded: $showAutomationNote) {
                        TextEditor(text: $settings.notes)
                            .frame(minHeight: 100)
                            .scrollContentBackground(.hidden)
                            .padding(AppDesign.Spacing.sm)
                            .background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
                            .padding(.top, AppDesign.Spacing.xs)
                    } label: {
                        Label("Advanced automation note", systemImage: "note.text")
                    }
                }
            }
        }
    }

    private var footer: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            Text("Allowed now: \(settings.allowedSourceLabels.isEmpty ? "No sources enabled" : settings.allowedSourceLabels.joined(separator: ", "))")
                .font(.caption)
                .foregroundStyle(.secondary)
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)

            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.prompt = "Use Folder"

        guard panel.runModal() == .OK, let url = panel.url else { return }
        let path = url.standardizedFileURL.path
        if !settings.documentScanFolders.contains(path) {
            settings.documentScanFolders.append(path)
        }
    }

    private func save() {
        store.saveConnectorSettings(settings)
    }
}
