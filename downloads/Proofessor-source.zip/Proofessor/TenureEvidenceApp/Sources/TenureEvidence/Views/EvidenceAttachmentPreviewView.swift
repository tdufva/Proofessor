import PDFKit
import SwiftUI

struct EvidenceAttachmentPreviewView: View {
    let attachment: EvidenceAttachment?
    let state: EvidenceAttachmentState?
    var showsHeader = true

    var body: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            if showsHeader {
                AppSectionHeader(
                    title: "Preview",
                    subtitle: attachment?.name ?? "Select an attachment to preview it here.",
                    systemImage: "doc.viewfinder"
                )
            }

            Group {
                if let attachment, let state {
                    previewContent(attachment: attachment, state: state)
                } else {
                    ContentUnavailableView(
                        "No Attachment Selected",
                        systemImage: "doc.viewfinder",
                        description: Text("Choose Preview on a PDF, image, or text file.")
                    )
                }
            }
            .frame(maxWidth: .infinity, minHeight: 260, maxHeight: 420)
            .background(.quaternary.opacity(0.18), in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .accessibilityElement(children: .contain)
    }

    @ViewBuilder
    private func previewContent(attachment: EvidenceAttachment, state: EvidenceAttachmentState) -> some View {
        if !state.exists {
            ContentUnavailableView(
                "Missing File",
                systemImage: "exclamationmark.triangle",
                description: Text("The stored path no longer points to a file. Reattach it or remove the attachment.")
            )
        } else if state.isDirectory {
            ContentUnavailableView(
                "Folder Attachment",
                systemImage: "folder",
                description: Text("Open the folder from the attachment actions.")
            )
        } else {
            switch previewKind(for: state.url) {
            case .pdf:
                EvidencePDFPreview(url: state.url)
            case .image:
                if let image = NSImage(contentsOf: state.url) {
                    Image(nsImage: image)
                        .resizable()
                        .scaledToFit()
                        .padding(AppDesign.Spacing.sm)
                        .accessibilityLabel("Image preview for \(attachment.name)")
                } else {
                    unavailable("Image Could Not Load", image: "photo", detail: "The file exists, but macOS could not decode it as an image.")
                }
            case .text:
                ScrollView {
                    Text(readText(from: state.url))
                        .font(.system(.caption, design: .monospaced))
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(AppDesign.Spacing.md)
                }
                .accessibilityLabel("Text preview for \(attachment.name)")
            case .unsupported:
                unavailable(
                    "No Inline Preview",
                    image: "doc",
                    detail: "This file type can still be opened in its original app."
                )
            }
        }
    }

    private func unavailable(_ title: String, image: String, detail: String) -> some View {
        ContentUnavailableView(
            title,
            systemImage: image,
            description: Text(detail)
        )
    }

    private func readText(from url: URL) -> String {
        if url.pathExtension.lowercased() == "rtf",
           let data = try? Data(contentsOf: url),
           let attributed = try? NSAttributedString(
                data: data,
                options: [.documentType: NSAttributedString.DocumentType.rtf],
                documentAttributes: nil
           ) {
            return attributed.string
        }

        return (try? String(contentsOf: url, encoding: .utf8)) ?? "Could not read this text file."
    }

    private func previewKind(for url: URL) -> PreviewKind {
        switch url.pathExtension.lowercased() {
        case "pdf":
            return .pdf
        case "png", "jpg", "jpeg", "heic", "tiff", "gif":
            return .image
        case "txt", "md", "csv", "rtf":
            return .text
        default:
            return .unsupported
        }
    }
}

private enum PreviewKind {
    case pdf
    case image
    case text
    case unsupported
}

private struct EvidencePDFPreview: NSViewRepresentable {
    let url: URL

    func makeNSView(context: Context) -> PDFView {
        let view = PDFView()
        view.autoScales = true
        view.displayMode = .singlePageContinuous
        view.displaysPageBreaks = true
        view.backgroundColor = .textBackgroundColor
        view.document = PDFDocument(url: url)
        return view
    }

    func updateNSView(_ view: PDFView, context: Context) {
        view.document = PDFDocument(url: url)
        view.autoScales = true
    }
}
