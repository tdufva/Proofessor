import SwiftUI

struct FixThisQueueView: View {
    @ObservedObject var store: EvidenceStore
    let openEvidence: (EvidenceEntry.ID) -> Void
    let openCV: () -> Void
    let openReviewScans: () -> Void

    private var cvClaimsWithoutEvidence: [CVStructuredItem] {
        store.cvItems
            .filter {
                !$0.title.trimmed.isEmpty
                    && ($0.linkedEvidenceIDs ?? []).isEmpty
                    && $0.section != .education
                    && $0.section != .employment
            }
            .sorted { $0.order < $1.order }
    }

    private var missingAttachmentEntries: [EvidenceEntry] {
        store.entries
            .filter { entry in
                entry.attachments.contains { !store.attachmentState(for: $0).exists }
                    || (entry.attachments.isEmpty && !entry.source.localizedCaseInsensitiveContains("http") && (entry.cvReady || entry.completeness.score >= 60))
            }
            .sorted { $0.date > $1.date }
    }

    private var unverifiedCVItems: [CVStructuredItem] {
        store.cvItems
            .filter { !$0.verified || $0.sourceConfidence == "review" }
            .sorted {
                if $0.sourceConfidence == $1.sourceConfidence { return $0.order < $1.order }
                return $0.sourceConfidence == "review"
            }
    }

    private var scannedDraftEntries: [EvidenceEntry] {
        store.scannedDraftEntriesForReview()
    }

    private var totalCount: Int {
        cvClaimsWithoutEvidence.count + missingAttachmentEntries.count + unverifiedCVItems.count + scannedDraftEntries.count
    }

    var body: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Fix This Queue",
                subtitle: "A short guided list of dossier problems that have a clear next action.",
                systemImage: "wrench.and.screwdriver",
                trailing: AnyView(StatusChip(text: "\(totalCount)", systemImage: "exclamationmark.circle", tone: totalCount == 0 ? .success : .warning))
            )

            if totalCount == 0 {
                Text("No urgent proof, attachment, or CV verification fixes right now.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(AppDesign.Spacing.md)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(AppDesign.successFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 280), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                    fixColumn(
                        "Link CV Claims",
                        count: cvClaimsWithoutEvidence.count,
                        image: "link.badge.plus",
                        actionTitle: "Open CV Database",
                        action: openCV
                    ) {
                        ForEach(cvClaimsWithoutEvidence.prefix(3)) { item in
                            queueLine(title: item.title, detail: item.section.rawValue)
                        }
                    }

                    fixColumn(
                        "Review Scans",
                        count: scannedDraftEntries.count,
                        image: "text.viewfinder",
                        actionTitle: "Open Review Wizard",
                        action: openReviewScans
                    ) {
                        ForEach(scannedDraftEntries.prefix(3)) { entry in
                            queueLine(title: entry.title, detail: entry.displaySubtitle.isEmpty ? entry.category : entry.displaySubtitle)
                        }
                    }

                    fixColumn(
                        "Repair Attachments",
                        count: missingAttachmentEntries.count,
                        image: "paperclip",
                        actionTitle: "Open First Evidence",
                        action: {
                            if let first = missingAttachmentEntries.first {
                                openEvidence(first.id)
                            }
                        }
                    ) {
                        ForEach(missingAttachmentEntries.prefix(3)) { entry in
                            queueLine(title: entry.title, detail: entry.displaySubtitle.isEmpty ? entry.category : entry.displaySubtitle)
                        }
                    }

                    fixColumn(
                        "Verify CV Rows",
                        count: unverifiedCVItems.count,
                        image: "checkmark.seal",
                        actionTitle: "Open CV Builder",
                        action: openCV
                    ) {
                        ForEach(unverifiedCVItems.prefix(3)) { item in
                            queueLine(title: item.title, detail: "\(item.section.rawValue) · \(item.sourceConfidence)")
                        }
                    }
                }
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .accessibilityElement(children: .contain)
    }

    private func fixColumn<Content: View>(
        _ title: String,
        count: Int,
        image: String,
        actionTitle: String,
        action: @escaping () -> Void,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            HStack {
                Label(title, systemImage: image)
                    .font(.headline)
                Spacer()
                StatusChip(text: "\(count)", tone: count == 0 ? .success : .warning)
            }

            if count == 0 {
                Text("Nothing to fix here.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                content()
                Button(action: action) {
                    Label(actionTitle, systemImage: "arrow.right.circle")
                }
                .buttonStyle(.bordered)
                .help(actionTitle)
            }
        }
        .padding(AppDesign.Spacing.md)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func queueLine(title: String, detail: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title.trimmed.isEmpty ? "Untitled item" : title)
                .font(.caption.weight(.semibold))
                .lineLimit(1)
            Text(detail.trimmed.isEmpty ? "Needs detail" : detail)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .accessibilityElement(children: .combine)
    }
}
