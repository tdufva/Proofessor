import SwiftUI

struct TenureCollectionView: View {
    @ObservedObject var store: EvidenceStore
    let addEvidence: () -> Void
    let openGuidedCapture: () -> Void
    let scanInbox: () -> Void
    let openImport: () -> Void
    let openSuggestions: () -> Void
    let openSources: () -> Void
    let openReviewScans: () -> Void
    let openEvidence: (EvidenceEntry.ID) -> Void
    let openCV: () -> Void
    let openStartHere: () -> Void

    private var recentEntries: [EvidenceEntry] {
        Array(store.sortedEntries().prefix(6))
    }

    private var suggestedCount: Int {
        store.suggestedEvidenceItems().count
    }

    private var needsReviewCount: Int {
        store.entries.filter { $0.status == "Needs review" || $0.status == "Needs confirmation" }.count
    }

    private var scanDraftCount: Int {
        store.scannedDraftEntriesForReview().count
    }

    private var missingProofCount: Int {
        store.entries.filter { entry in
            entry.attachments.isEmpty && !entry.source.localizedCaseInsensitiveContains("http")
        }.count
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                header
                startHerePanel
                addImportSection
                automationSection
                collectionStatus
                TenureCriteriaMatrixView(
                    entries: store.reviewPeriodEntries(),
                    periodLabel: store.reviewPeriodLabel(),
                    backgroundCount: store.backgroundContextEntries().count,
                    openEvidence: openEvidence
                )
                recentCollection
            }
            .padding(AppDesign.Spacing.xl)
            .frame(maxWidth: 1180, alignment: .leading)
        }
        .accessibilityElement(children: .contain)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            PageHeader(
                title: "Collect",
                subtitle: "A calm review desk for evidence: scan first, review suggestions, then keep only what belongs in the dossier.",
                systemImage: "tray.full"
            )

            StatusStrip(items: [
                StatusStripItem(text: "\(store.entries.count) collected", systemImage: "tray.full", tone: .accent),
                StatusStripItem(text: "\(suggestedCount) suggested", systemImage: "sparkles", tone: suggestedCount == 0 ? .neutral : .warning),
                StatusStripItem(text: "\(needsReviewCount) to review", systemImage: "checklist", tone: needsReviewCount == 0 ? .success : .warning),
                StatusStripItem(text: "\(missingProofCount) proof needed", systemImage: "paperclip", tone: missingProofCount == 0 ? .success : .warning)
            ])
        }
    }

    private var startHerePanel: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            HStack(alignment: .top, spacing: AppDesign.Spacing.md) {
                Image(systemName: "sparkles")
                    .font(.title2)
                    .foregroundStyle(AppDesign.academyGold)
                    .frame(width: 28)

                VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    Text("First 10 Minutes")
                        .font(.system(.title2, design: .serif).weight(.semibold))
                    Text("Choose a folder, scan subfolders, review three sample suggestions, and export a tiny demo CV.")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer()

                Button(action: openStartHere) {
                    Label("Start Here", systemImage: "arrow.right.circle")
                }
                .buttonStyle(.borderedProminent)
                .keyboardShortcut("1", modifiers: [.command])
                .help("Open the guided first-run flow")
            }

            DisclosureGroup("Show workflow map") {
                collectionPipeline
                    .padding(.top, AppDesign.Spacing.sm)
            }
            .font(.caption.weight(.medium))
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var collectionPipeline: some View {
        HStack(spacing: AppDesign.Spacing.sm) {
            collectionStep("Add", "Manual records", "plus.circle")
            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
            collectionStep("Import", "Text, email, calendar", "tray.and.arrow.down")
            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
            collectionStep("Automate", "Calendar, email, files", "clock.arrow.2.circlepath")
            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
            collectionStep("Review", "Approve suggestions", "checkmark.seal")
            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
            collectionStep("File", "Attach proof", "folder")
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Collection workflow: add, import, automate, review, file")
    }

    private func collectionStep(_ title: String, _ subtitle: String, _ image: String) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
            Label(title, systemImage: image)
                .font(.headline)
            Text(subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(AppDesign.Spacing.md)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var addImportSection: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Next Best Actions",
                subtitle: "Use these when you have new material or need to review what the app found.",
                systemImage: "square.and.pencil"
            )

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 230), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.md) {
                actionCard(
                    "Guided Capture",
                    "Add a known talk, course, supervision, grant, service role, publication, or artistic work.",
                    "square.and.pencil",
                    primary: true,
                    action: openGuidedCapture
                )
                actionCard(
                    "New Evidence",
                    "Create a blank record.",
                    "plus.circle",
                    primary: false,
                    action: addEvidence
                )
                actionCard(
                    "Scan Documents",
                    "Find PDFs, CVs, BibTeX, feedback, images, and notes inside subfolders.",
                    "arrow.triangle.2.circlepath",
                    primary: false,
                    action: scanInbox
                )
                actionCard(
                    "Import Text",
                    "Paste email, calendar, DOI, BibTeX, profile, or event-page text.",
                    "tray.and.arrow.down",
                    primary: false,
                    action: openImport
                )
                actionCard(
                    "Review Suggestions",
                    "Accept, edit, dismiss, merge, or mark proof missing.",
                    "tray.full",
                    primary: suggestedCount > 0,
                    action: openSuggestions
                )
                actionCard(
                    "Review Scans",
                    "Confirm scanned drafts before dossier use.",
                    "text.viewfinder",
                    primary: scanDraftCount > 0,
                    action: openReviewScans
                )
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var automationSection: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Automation: Search for Tenure Information",
                subtitle: "Allowed sources save candidates to the inbox and wait for your approval.",
                systemImage: "clock.arrow.2.circlepath",
                trailing: AnyView(
                    Button(action: openSources) {
                        Label("Source Settings", systemImage: "switch.2")
                    }
                    .help("Choose which calendar, email, web, file, and profile sources the automation may inspect")
                )
            )

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 260), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.md) {
                automationSourceCard(
                    "Calendar",
                    enabled: store.connectorSettings.allowCalendar,
                    image: "calendar",
                    text: "Looks for talks, guest lectures, committees, supervision, seminars, reviews, and tenure-relevant meetings."
                )
                automationSourceCard(
                    "Email",
                    enabled: store.connectorSettings.allowEmail,
                    image: "envelope",
                    text: "Looks for invitations, confirmations, certificates, feedback, funding messages, and event details."
                )
                automationSourceCard(
                    "Files",
                    enabled: store.connectorSettings.allowLocalFiles,
                    image: "folder",
                    text: store.connectorSettings.documentScanFolders.isEmpty
                        ? "Looks in 00_Inbox and the tenure workspace subfolders for PDFs, slides, documents, notes, and exports."
                        : "Looks in 00_Inbox, tenure workspace subfolders, and \(store.connectorSettings.documentScanFolders.count) configured folder(s)."
                )
                automationSourceCard(
                    "Profiles",
                    enabled: store.connectorSettings.allowProfilePages,
                    image: "person.text.rectangle",
                    text: "Tracks \(store.connectorSettings.configuredProfileCount) configured profile link(s), including ACRIS, Google Scholar, and ORCID when present."
                )
            }

            HStack(spacing: AppDesign.Spacing.sm) {
                Button(action: openSuggestions) {
                    Label("Open Suggested Evidence", systemImage: "sparkles")
                }
                .buttonStyle(.borderedProminent)
                .help("Review candidates found by the automation")

                Button(action: openReviewScans) {
                    Label("Review Scans", systemImage: "text.viewfinder")
                }
                .help("Review scanned document drafts")

                Button(action: scanInbox) {
                    Label("Run Document Scan Now", systemImage: "arrow.triangle.2.circlepath")
                }
                .help("Scan 00_Inbox, tenure workspace subfolders, and configured folders for new files")

                Button(action: store.revealSuggestedEvidenceFolder) {
                    Label("Suggested Folder", systemImage: "folder")
                }
                .help("Open 00_Inbox/Suggested_Evidence")

                Spacer()
            }

            Text("Calendar and email search only runs for sources you explicitly allow in Source Settings. Suggested items stay out of the official evidence list until you review them.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(AppDesign.Spacing.md)
        .background(Color.blue.opacity(0.07), in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var collectionStatus: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.md) {
            metricCard("Collected", "\(store.entries.count)", "tray.full", "All evidence records in the app")
            metricCard("Ready to use", "\(store.entries.filter(\.cvReady).count)", "checkmark.circle", "Records ready for CV use")
            metricCard("Check this", "\(needsReviewCount)", "checklist", "Imported or uncertain records to clean")
            metricCard("Proof needed", "\(missingProofCount)", "paperclip", "Records without attachment or source URL")
        }
    }

    private var recentCollection: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Recently Collected",
                subtitle: "The newest collected items, so you can quickly continue cleaning and filing.",
                systemImage: "clock"
            )

            if recentEntries.isEmpty {
                PrimaryEmptyState(
                    title: "Nothing Collected Yet",
                    message: "Create the first evidence record or scan the inbox for existing files.",
                    systemImage: "tray.badge.plus",
                    actionTitle: "New Evidence",
                    actionImage: "plus",
                    action: addEvidence
                )
                .frame(minHeight: 260)
            } else {
                LazyVStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                    ForEach(recentEntries) { entry in
                        Button {
                            openEvidence(entry.id)
                        } label: {
                            HStack(alignment: .top, spacing: AppDesign.Spacing.sm) {
                                Image(systemName: iconName(for: entry))
                                    .foregroundStyle(.secondary)
                                    .frame(width: 18)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(entry.title.trimmed.isEmpty ? "Untitled evidence" : entry.title)
                                        .font(.caption.weight(.semibold))
                                        .lineLimit(1)
                                    Text(entry.displaySubtitle.isEmpty ? entry.category : entry.displaySubtitle)
                                        .font(.caption2)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(1)
                                }
                                Spacer()
                                StatusChip(text: entry.displayStatus, tone: statusTone(entry.status))
                                StatusChip(text: "\(entry.completeness.score)%", tone: entry.completeness.score >= 90 ? .success : .warning)
                            }
                            .padding(AppDesign.Spacing.sm)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
                        }
                        .buttonStyle(.plain)
                        .help("Open evidence record")
                    }
                }
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func actionCard(_ title: String, _ text: String, _ image: String, primary: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                Image(systemName: image)
                    .font(.title2)
                    .foregroundStyle(primary ? .white : .secondary)
                Text(title)
                    .font(.headline)
                Text(text)
                    .font(.caption)
                    .foregroundStyle(primary ? .white.opacity(0.86) : .secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(AppDesign.Spacing.md)
            .frame(maxWidth: .infinity, minHeight: 145, alignment: .topLeading)
            .background(primary ? Color.accentColor : Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
            .foregroundStyle(primary ? .white : .primary)
        }
        .buttonStyle(.plain)
        .help(title)
        .accessibilityElement(children: .combine)
    }

    private func automationSourceCard(_ title: String, enabled: Bool, image: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            HStack {
                Label(title, systemImage: image)
                    .font(.headline)
                Spacer()
                StatusChip(text: enabled ? "Allowed" : "Off", systemImage: enabled ? "checkmark.circle" : "pause.circle", tone: enabled ? .success : .neutral)
            }
            Text(text)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(AppDesign.Spacing.md)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func metricCard(_ title: String, _ value: String, _ image: String, _ help: String) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            Label(title, systemImage: image)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.title2.weight(.semibold))
        }
        .padding(AppDesign.Spacing.md)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .help(help)
    }

    private func statusTone(_ status: String) -> StatusChip.Tone {
        switch status {
        case "Filed", "Ready for CV":
            return .success
        case "Needs confirmation", "Evidence missing":
            return .warning
        default:
            return .neutral
        }
    }

    private func iconName(for entry: EvidenceEntry) -> String {
        switch entry.category {
        case "Talk": "person.wave.2"
        case "Artistic Output": "paintpalette"
        case "Publication": "doc.text"
        case "Funding": "eurosign.circle"
        case "Teaching": "graduationcap"
        case "Supervision": "person.2"
        case "Service": "building.columns"
        case "Visibility": "megaphone"
        default: "tray.full"
        }
    }
}
