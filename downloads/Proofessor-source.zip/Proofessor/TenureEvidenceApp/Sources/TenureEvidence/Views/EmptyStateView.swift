import SwiftUI

struct EmptyStateView: View {
    let addAction: () -> Void

    var body: some View {
        PrimaryEmptyState(
            title: "No Evidence Selected",
            message: "Select a record from the sidebar or create one new evidence item.",
            systemImage: "folder.badge.plus",
            actionTitle: "New Evidence",
            actionImage: "plus",
            action: addAction
        )
    }
}
