import SwiftUI

struct TenureCriteriaGuidanceView: View {
    @State private var selectedSchool: AaltoSchoolPreset = .aaltoWide
    @State private var selectedStage: AaltoCareerStage = .tenure

    private let criteria = [
        ("Research/artistic work", "Independent work, quality and impact, team building with doctoral/postdoctoral or artistic professionals, and competitive funding."),
        ("Teaching", "Teaching experience, thesis supervision, course development, pedagogical studies, feedback quality, and evidence of improvement."),
        ("Impact and service", "Field development, academic service and leadership, societal contribution, and nurturing the next generation.")
    ]

    private let teachingChecks = [
        "Explain teaching philosophy and choices",
        "Show implementation in practice",
        "Evidence impact on student learning",
        "Document broad teaching and supervision",
        "Show curriculum or programme leadership",
        "Show systematic development as a teacher",
        "Analyse feedback and show improvements",
        "Design teaching demonstration as a teaching situation"
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                Label("Aalto Criteria Presets", systemImage: "building.columns")
                    .font(.title3.weight(.semibold))
                Spacer()
                Text("\(selectedSchool.shortName) · \(selectedStage.shortName)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            ViewThatFits(in: .horizontal) {
                HStack {
                    presetPickers
                    Spacer()
                }
                VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                    presetPickers
                }
            }

            Text(AaltoCriteriaMatcher.guidance(school: selectedSchool, stage: selectedStage))
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 240), alignment: .top)], alignment: .leading, spacing: 10) {
                ForEach(criteria, id: \.0) { item in
                    VStack(alignment: .leading, spacing: 5) {
                        Text(item.0)
                            .font(.caption.weight(.semibold))
                        Text(item.1)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(9)
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                    .background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: 6))
                }
            }

            VStack(alignment: .leading, spacing: 7) {
                Label("Teaching Portfolio Reminders", systemImage: "graduationcap")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 210), alignment: .leading)], alignment: .leading, spacing: 6) {
                    ForEach(teachingChecks, id: \.self) { check in
                        Label(check, systemImage: "checkmark.circle")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                }
            }

            HStack(spacing: 10) {
                Link("Tenure track", destination: URL(string: "https://www.aalto.fi/en/tenure-track")!)
                Link("Evaluation criteria", destination: URL(string: "https://www.aalto.fi/en/services/tenure-track-evaluation-criteria")!)
                Link("FAQ", destination: URL(string: "https://www.aalto.fi/en/tenure-track/tenure-track-frequently-asked-questions-and-answers")!)
            }
            .font(.caption)
        }
        .padding(12)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: 8))
    }

    private var presetPickers: some View {
        Group {
            Picker("School", selection: $selectedSchool) {
                ForEach(AaltoSchoolPreset.allCases) { school in
                    Text(school.rawValue).tag(school)
                }
            }
            .frame(maxWidth: 260)

            Picker("Stage", selection: $selectedStage) {
                ForEach(AaltoCareerStage.allCases) { stage in
                    Text(stage.rawValue).tag(stage)
                }
            }
            .frame(maxWidth: 300)
        }
    }
}
