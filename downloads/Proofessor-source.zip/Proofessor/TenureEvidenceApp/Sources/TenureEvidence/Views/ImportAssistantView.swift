import SwiftUI

struct ImportAssistantView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @Binding var selection: EvidenceEntry.ID?
    @State private var pastedText = ""
    @State private var preview = EvidenceEntry()

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Label("Calendar / Email Import", systemImage: "tray.and.arrow.down")
                    .font(.title2.weight(.semibold))
                Spacer()
                Button("Close") {
                    dismiss()
                }
            }

            HStack(alignment: .top, spacing: 18) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Paste an email, calendar invite, or event programme text")
                        .font(.headline)

                    TextEditor(text: $pastedText)
                        .font(.body)
                        .frame(minWidth: 300, minHeight: 360)
                        .scrollContentBackground(.hidden)
                        .padding(8)
                        .background(.quaternary.opacity(0.35), in: RoundedRectangle(cornerRadius: 8))

                    Button {
                        preview = ImportParser.parse(pastedText)
                    } label: {
                        Label("Extract Fields", systemImage: "sparkles")
                    }
                    .disabled(pastedText.trimmed.isEmpty)
                    .help("Extract a draft evidence record from the pasted text")
                }

                VStack(alignment: .leading, spacing: 10) {
                    Text("Preview")
                        .font(.headline)

                    Grid(alignment: .leading, horizontalSpacing: 12, verticalSpacing: 10) {
                        GridRow {
                            Text("Date").foregroundStyle(.secondary)
                            TextField("YYYY-MM-DD", text: $preview.date)
                        }
                        GridRow {
                            Text("Title").foregroundStyle(.secondary)
                            TextField("Title", text: $preview.title)
                        }
                        GridRow {
                            Text("Category").foregroundStyle(.secondary)
                            Picker("Category", selection: $preview.category) {
                                ForEach(EvidenceOptions.categories, id: \.self) { category in
                                    Text(category).tag(category)
                                }
                            }
                            .labelsHidden()
                        }
                        GridRow {
                            Text("Type").foregroundStyle(.secondary)
                            TextField("Type", text: $preview.eventType)
                        }
                        GridRow {
                            Text("Role").foregroundStyle(.secondary)
                            TextField("Role", text: $preview.role)
                        }
                        GridRow {
                            Text("Venue").foregroundStyle(.secondary)
                            TextField("Venue / host", text: $preview.venue)
                        }
                    }

                    Text("Completeness after import: \(preview.completeness.score)%")
                        .font(.caption)
                        .foregroundStyle(.secondary)

                    let duplicates = store.duplicateCandidates(for: preview)
                    if !duplicates.isEmpty {
                        VStack(alignment: .leading, spacing: 4) {
                            Label("Possible duplicate", systemImage: "exclamationmark.triangle")
                                .foregroundStyle(.orange)
                                .help("The preview looks similar to an existing evidence record")
                            ForEach(duplicates.prefix(3)) { duplicate in
                                Text("\(duplicate.date) · \(duplicate.title)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(8)
                        .background(.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
                    }

                    Spacer()

                    HStack {
                        Button {
                            let newID = store.addEntry(preview)
                            selection = newID
                            dismiss()
                        } label: {
                            Label("Create Entry", systemImage: "plus.circle")
                        }
                        .disabled(preview.title.trimmed.isEmpty)
                        .help("Create an evidence record from the preview")

                        Button("Reset") {
                            pastedText = ""
                            preview = EvidenceEntry()
                        }
                        .help("Clear the pasted text and preview")
                    }
                }
                .frame(minWidth: 300)
            }
        }
        .padding(22)
        .onChange(of: pastedText) { _, newValue in
            guard preview.title.trimmed.isEmpty, !newValue.trimmed.isEmpty else { return }
            preview = ImportParser.parse(newValue)
        }
    }
}
