import PDFKit
import SwiftUI

struct CVLivePreviewView: View {
    let draft: String
    let theme: CVDraftTheme
    var profilePicturePath: String? = nil

    private var report: CVLayoutReport {
        CVDocumentExporter.layoutReport(for: draft, theme: theme, profilePicturePath: profilePicturePath)
    }

    private var pdfData: Data? {
        try? CVDocumentExporter.pdfData(from: draft, theme: theme, profilePicturePath: profilePicturePath)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("Live Preview", systemImage: "doc.richtext")
                    .font(.headline)
                Spacer()
                Text("\(report.pageCount) page(s)")
                    .font(.caption.weight(.semibold))
                Text(report.threePageStatus)
                    .font(.caption)
                    .foregroundStyle(report.pageCount <= 3 ? .green : .orange)
            }

            if let pdfData {
                CVPDFPreview(data: pdfData)
                    .frame(minWidth: 320, idealWidth: 380, maxWidth: .infinity, minHeight: 500)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                ContentUnavailableView(
                    "No Preview",
                    systemImage: "doc.text.magnifyingglass",
                    description: Text("Generate or edit the CV draft to see the rendered layout.")
                )
                .frame(minWidth: 320, idealWidth: 380, maxWidth: .infinity, minHeight: 500)
            }
        }
    }
}

struct CVPDFPreview: NSViewRepresentable {
    let data: Data

    func makeNSView(context: Context) -> PDFView {
        let view = PDFView()
        view.autoScales = true
        view.displayMode = .singlePageContinuous
        view.displaysPageBreaks = true
        view.backgroundColor = .textBackgroundColor
        view.document = PDFDocument(data: data)
        return view
    }

    func updateNSView(_ view: PDFView, context: Context) {
        view.document = PDFDocument(data: data)
        view.autoScales = true
    }
}
