import AppKit
import SwiftUI

struct CVStartWizardView: View {
    let selectedTemplate: CVDraftVariant
    let selectedTheme: CVDraftTheme
    let allowedThemes: [CVDraftTheme]
    let databaseCount: Int
    let publicationCount: Int
    let verifiedCount: Int
    let importedSourceLineCount: Int
    let applyPreset: (CVWizardPreset) -> Void
    let applyTheme: (CVDraftTheme) -> Void
    let refreshImportedCV: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            ViewThatFits(in: .horizontal) {
                HStack {
                    startHeader
                    Spacer()
                    statusPills
                }

                VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                    startHeader
                    statusPills
                }
            }

            Text("Pick the job the CV needs to do. The app will choose the template, style, export cleanliness, and length posture for you.")
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 240), alignment: .top)], alignment: .leading, spacing: 12) {
                ForEach(CVWizardPreset.all) { preset in
                    Button {
                        applyPreset(preset)
                    } label: {
                        presetCard(preset)
                    }
                    .buttonStyle(.plain)
                    .help("Use \(preset.title)")
                }
            }

            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Label("Style For This Template", systemImage: "paintbrush")
                        .font(.headline)
                    Spacer()
                    Text(selectedTheme.rawValue)
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                }

                LazyVGrid(columns: [GridItem(.adaptive(minimum: 210), alignment: .top)], alignment: .leading, spacing: 10) {
                    ForEach(allowedThemes) { theme in
                        Button {
                            applyTheme(theme)
                        } label: {
                            themeCard(theme)
                        }
                        .buttonStyle(.plain)
                        .help(theme.description)
                    }
                }
            }
            .padding(12)
            .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))

            VStack(alignment: .leading, spacing: 8) {
                Label("Current setup", systemImage: "slider.horizontal.3")
                    .font(.headline)
                Text("\(selectedTemplate.rawValue) · \(selectedTheme.rawValue)")
                    .font(.title3.weight(.medium))
                Text("The draft uses the structured CV database plus the imported/master CV source. If old CV material seems missing, scan the CV folders before editing.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Button {
                    refreshImportedCV()
                } label: {
                    Label("Scan CV Files", systemImage: "doc.text.magnifyingglass")
                }
                .help("Scan old CV files and merge missing rows into the structured database")
            }
            .padding(12)
            .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var startHeader: some View {
        Label("CV Variant Builder", systemImage: "wand.and.stars")
            .font(.title3.weight(.semibold))
    }

    private var statusPills: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: AppDesign.Spacing.sm) {
                statusPill("\(databaseCount) CV rows", image: "tablecells")
                statusPill("\(publicationCount) publications", image: "text.book.closed")
                statusPill("\(verifiedCount) verified", image: "checkmark.seal")
                statusPill("\(importedSourceLineCount) imported lines", image: "doc.text")
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 128), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                statusPill("\(databaseCount) CV rows", image: "tablecells")
                statusPill("\(publicationCount) publications", image: "text.book.closed")
                statusPill("\(verifiedCount) verified", image: "checkmark.seal")
                statusPill("\(importedSourceLineCount) imported lines", image: "doc.text")
            }
        }
    }

    private func themeCard(_ theme: CVDraftTheme) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Circle()
                    .fill(Color(nsColor: theme.accentColor))
                    .frame(width: 12, height: 12)
                    .help("Theme accent color")
                Image(systemName: theme.systemImage)
                    .foregroundStyle(.secondary)
                Spacer()
                if theme == selectedTheme {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                }
            }

            Text(theme.rawValue)
                .font(.headline)
                .foregroundStyle(.primary)

            Text(theme.description)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Text(theme.designUse)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(2)
        }
        .padding(11)
        .frame(maxWidth: .infinity, minHeight: 136, alignment: .topLeading)
        .background(
            theme == selectedTheme ? Color.accentColor.opacity(0.12) : Color.secondary.opacity(0.08),
            in: RoundedRectangle(cornerRadius: 8)
        )
    }

    private func presetCard(_ preset: CVWizardPreset) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                Image(systemName: preset.systemImage)
                    .font(.title3)
                    .foregroundStyle(.secondary)
                    .frame(width: 24)
                Spacer()
                if preset.variant == selectedTemplate {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                }
            }

            Text(preset.title)
                .font(.headline)
                .foregroundStyle(.primary)

            Text(preset.subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Text("\(preset.variant.rawValue) · \(preset.theme.rawValue)")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding(12)
        .frame(maxWidth: .infinity, minHeight: 150, alignment: .topLeading)
        .background(
            preset.variant == selectedTemplate ? Color.green.opacity(0.1) : Color.secondary.opacity(0.08),
            in: RoundedRectangle(cornerRadius: 8)
        )
    }

    private func statusPill(_ text: String, image: String) -> some View {
        Label(text, systemImage: image)
            .font(.caption)
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 6))
            .help(text)
    }
}
