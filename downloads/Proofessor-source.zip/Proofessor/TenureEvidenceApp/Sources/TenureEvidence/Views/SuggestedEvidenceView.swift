import SwiftUI

struct SuggestedEvidenceView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @Binding var selection: EvidenceEntry.ID?
    var openEvidenceAfterImport: (() -> Void)? = nil

    @State private var suggestions: [SuggestedEvidenceItem] = []
    @State private var selectedFilter: InboxFilter = .all
    @State private var selectedIDs: Set<SuggestedEvidenceItem.ID> = []
    @State private var expandedIDs: Set<SuggestedEvidenceItem.ID> = []
    @State private var schoolPreset: AaltoSchoolPreset = .aaltoWide
    @State private var careerStage: AaltoCareerStage = .tenure

    private enum InboxFilter: String, CaseIterable, Identifiable {
        case all = "All"
        case duplicates = "Duplicates"
        case missingProof = "Proof Needed"
        case nearlyReady = "Nearly Ready"

        var id: String { rawValue }
    }

    private var filteredSuggestions: [SuggestedEvidenceItem] {
        suggestions.filter { item in
            switch selectedFilter {
            case .all:
                return true
            case .duplicates:
                return item.hasDuplicates
            case .missingProof:
                return item.sourceURLs.isEmpty && item.entry.attachments.isEmpty
            case .nearlyReady:
                return item.entry.completeness.score >= 70 && !item.hasDuplicates
            }
        }
    }

    private var selectedItems: [SuggestedEvidenceItem] {
        suggestions.filter { selectedIDs.contains($0.id) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
            header

            if suggestions.isEmpty {
                emptyState
            } else {
                controls
                if !selectedIDs.isEmpty {
                    batchToolbar
                }
                inboxList
            }

            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)
        }
        .padding(AppDesign.Spacing.lg)
        .frame(minWidth: 760, idealWidth: 1040, minHeight: 640, idealHeight: 760)
        .onAppear(perform: reload)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            PageHeader(
                title: "Evidence Review Inbox",
                subtitle: "Review what the app found. Each item shows the Aalto dimension, confidence, proof, missing pieces, and why the app found it before import.",
                systemImage: "tray.full",
                trailing: AnyView(
                    HStack {
                        Button {
                            reload()
                        } label: {
                            Label("Refresh", systemImage: "arrow.triangle.2.circlepath")
                        }
                        .keyboardShortcut("r", modifiers: [.command])
                        .help("Rescan the suggested evidence inbox")

                        Button {
                            store.revealSuggestedEvidenceFolder()
                        } label: {
                            Label("Folder", systemImage: "folder")
                        }
                        .help("Open the folder where suggestions are saved")

                        Button("Close") {
                            dismiss()
                        }
                        .keyboardShortcut(.cancelAction)
                    }
                )
            )

            StatusStrip(items: [
                StatusStripItem(text: "\(suggestions.count) pending", systemImage: "tray.full", tone: suggestions.isEmpty ? .neutral : .accent),
                StatusStripItem(text: "\(suggestions.filter(\.hasDuplicates).count) duplicates", systemImage: "arrow.triangle.merge", tone: suggestions.contains(where: \.hasDuplicates) ? .warning : .success),
                StatusStripItem(text: "\(suggestions.filter { $0.sourceURLs.isEmpty && $0.entry.attachments.isEmpty }.count) proof weak", systemImage: "paperclip", tone: suggestions.contains { $0.sourceURLs.isEmpty && $0.entry.attachments.isEmpty } ? .warning : .success),
                StatusStripItem(text: "\(suggestions.filter { $0.entry.completeness.score >= 70 }.count) nearly ready", systemImage: "checkmark.circle", tone: .neutral)
            ])
        }
    }

    private var emptyState: some View {
        AppEmptyState(
            title: "Evidence Inbox Empty",
            message: "No suggested evidence files are waiting. Run a document scan, add profile/source settings, or drop files into 00_Inbox/Suggested_Evidence.",
            systemImage: "tray",
            actionTitle: "Refresh Inbox",
            actionImage: "arrow.triangle.2.circlepath",
            action: reload
        )
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var controls: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: AppDesign.Spacing.md) {
                filterPicker
                presetPickers
                Spacer()
                Button {
                    toggleSelectFiltered()
                } label: {
                    Label(allFilteredSelected ? "Clear Selection" : "Select Visible", systemImage: allFilteredSelected ? "checkmark.circle.badge.xmark" : "checkmark.circle")
                }
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                filterPicker
                presetPickers
                Button {
                    toggleSelectFiltered()
                } label: {
                    Label(allFilteredSelected ? "Clear Selection" : "Select Visible", systemImage: allFilteredSelected ? "checkmark.circle.badge.xmark" : "checkmark.circle")
                }
            }
        }
    }

    private var filterPicker: some View {
        Picker("Inbox filter", selection: $selectedFilter) {
            ForEach(InboxFilter.allCases) { filter in
                Text(filter.rawValue).tag(filter)
            }
        }
        .pickerStyle(.segmented)
        .frame(maxWidth: 480)
        .help("Filter evidence inbox cards")
    }

    private var presetPickers: some View {
        HStack(spacing: AppDesign.Spacing.sm) {
            Picker("School", selection: $schoolPreset) {
                ForEach(AaltoSchoolPreset.allCases) { preset in
                    Text(preset.shortName).tag(preset)
                }
            }
            .frame(width: 150)
            .help("Choose the Aalto school lens for confidence notes")

            Picker("Stage", selection: $careerStage) {
                ForEach(AaltoCareerStage.allCases) { stage in
                    Text(stage.shortName).tag(stage)
                }
            }
            .frame(width: 170)
            .help("Choose the career stage lens for confidence notes")
        }
    }

    private var batchToolbar: some View {
        HStack(spacing: AppDesign.Spacing.sm) {
            StatusChip(text: "\(selectedIDs.count) selected", systemImage: "checkmark.circle", tone: .accent)

            Button {
                acceptSelected()
            } label: {
                Label("Accept", systemImage: "checkmark.circle")
            }
            .keyboardShortcut(.return, modifiers: [.command])
            .help("Accept selected suggestions")

            Button {
                importSelectedForEditing()
            } label: {
                Label("Edit", systemImage: "square.and.pencil")
            }
            .help("Import selected suggestions, then open the last one for editing")

            Button {
                markSelectedProofMissing()
            } label: {
                Label("Proof Needed", systemImage: "paperclip.badge.ellipsis")
            }
            .keyboardShortcut("m", modifiers: [.command])
            .help("Keep selected suggestions but mark them as needing proof")

            Button(role: .destructive) {
                dismissSelected()
            } label: {
                Label("Dismiss", systemImage: "xmark")
            }
            .keyboardShortcut(KeyEquivalent.delete, modifiers: [])
            .help("Dismiss selected suggestions")

            Spacer()

            Button {
                selectedIDs.removeAll()
            } label: {
                Label("Clear", systemImage: "xmark.circle")
            }
        }
        .padding(AppDesign.Spacing.sm)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var inboxList: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                ForEach(filteredSuggestions) { item in
                    inboxCard(item)
                }
            }
            .padding(.vertical, 2)
        }
    }

    private func inboxCard(_ item: SuggestedEvidenceItem) -> some View {
        let recommendation = AaltoCriteriaMatcher.recommendation(
            for: item.entry,
            school: schoolPreset,
            stage: careerStage
        )
        let trace = EvidenceSourceTrace.suggestion(item)

        return VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            HStack(alignment: .top, spacing: AppDesign.Spacing.md) {
                Toggle(isOn: selectionBinding(for: item)) {
                    EmptyView()
                }
                .toggleStyle(.checkbox)
                .labelsHidden()
                .help("Select this suggestion for batch actions")

                VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    HStack(spacing: AppDesign.Spacing.sm) {
                        StatusChip(text: item.entry.date.trimmed.isEmpty ? "No date" : item.entry.date, systemImage: "calendar", tone: item.entry.date.trimmed.isEmpty ? .warning : .neutral)
                        StatusChip(text: recommendation.dimension, systemImage: "target", tone: .accent)
                        StatusChip(text: recommendation.confidence.rawValue, systemImage: "gauge", tone: confidenceTone(recommendation.confidence))
                        StatusChip(text: proofLabel(for: item), systemImage: proofIcon(for: item), tone: proofTone(for: item))
                        if item.hasDuplicates {
                            StatusChip(text: "duplicate?", systemImage: "arrow.triangle.merge", tone: .warning)
                        }
                    }

                    Text(item.entry.title.trimmed.isEmpty ? "Untitled suggested evidence" : item.entry.title)
                        .font(.title3.weight(.semibold))
                        .lineLimit(2)

                    Text([item.entry.eventType, item.entry.role, item.entry.venue].filter { !$0.trimmed.isEmpty }.joined(separator: " - "))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }

                Spacer()

                Text("\(item.entry.completeness.score)%")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(item.entry.completeness.score >= 80 ? .green : .orange)
                    .help("Completeness score if imported as an evidence record")
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 230), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                evidenceField("Aalto Dimension", image: "target", value: "\(recommendation.dimension)\n\(recommendation.title)")
                evidenceField("Confidence", image: "gauge", value: recommendation.confidenceNote)
                evidenceField("Why Suggested", image: "lightbulb", value: recommendation.reason)
                evidenceField("Proof Found", image: "checkmark.seal", value: proofSummary(for: item))
                evidenceField("What Is Missing", image: "exclamationmark.circle", value: missingSummary(for: item))
                evidenceField("Source Trace", image: "text.magnifyingglass", value: sourceTraceSummary(trace))
            }

            DisclosureGroup(isExpanded: expansionBinding(for: item)) {
                VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                    if !trace.snippet.trimmed.isEmpty {
                        traceSnippet(trace.snippet)
                    }

                    if !trace.links.isEmpty {
                        ForEach(Array(trace.links.prefix(3)), id: \.absoluteString) { url in
                            Button {
                                store.open(url)
                            } label: {
                                Label(url.absoluteString, systemImage: "link")
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                            }
                            .buttonStyle(.link)
                        }
                    }
                }
                .padding(.top, AppDesign.Spacing.xs)
            } label: {
                Label("Source details", systemImage: "doc.text.magnifyingglass")
                    .font(.caption.weight(.semibold))
            }

            if item.hasDuplicates {
                duplicatePanel(item)
            }

            HStack(spacing: AppDesign.Spacing.sm) {
                Button(role: .destructive) {
                    store.dismissSuggestedEvidence(item)
                    reload()
                } label: {
                    Label("Dismiss", systemImage: "xmark")
                }
                .help("Move this suggestion to Dismissed")

                Button {
                    selection = store.markSuggestedEvidenceProofMissing(item)
                    reload()
                } label: {
                    Label("Proof Needed", systemImage: "paperclip.badge.ellipsis")
                }
                .help("Keep this suggestion as evidence, but mark proof as missing")

                Spacer()

                Button {
                    selection = store.acceptSuggestedEvidence(item)
                    reload()
                    openEvidenceAfterImport?()
                    dismiss()
                } label: {
                    Label("Edit", systemImage: "square.and.pencil")
                }
                .help("Import this suggestion and open it for editing")

                Button {
                    selection = store.acceptSuggestedEvidence(item)
                    reload()
                } label: {
                    Label(item.hasDuplicates ? "Accept as New" : "Accept", systemImage: "checkmark.circle")
                }
                .buttonStyle(.borderedProminent)
                .help(item.hasDuplicates ? "Import this suggestion as a separate record" : "Import this suggestion as a reviewable evidence record")
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .accessibilityElement(children: .contain)
    }

    private func evidenceField(_ title: String, image: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
            Label(title, systemImage: image)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            Text(value.trimmed.isEmpty ? "Check this." : value)
                .font(.caption)
                .fixedSize(horizontal: false, vertical: true)
                .textSelection(.enabled)
        }
        .padding(AppDesign.Spacing.sm)
        .frame(maxWidth: .infinity, minHeight: 96, alignment: .topLeading)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
    }

    private func traceSnippet(_ snippet: String) -> some View {
        Text(snippet)
            .font(.caption)
            .textSelection(.enabled)
            .padding(AppDesign.Spacing.sm)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.black.opacity(0.18), in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
    }

    private func duplicatePanel(_ item: SuggestedEvidenceItem) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            Label("Possible duplicate records", systemImage: "arrow.triangle.merge")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.orange)

            ForEach(item.duplicateCandidates) { duplicate in
                HStack(spacing: AppDesign.Spacing.sm) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(duplicate.title)
                            .font(.caption.weight(.medium))
                            .lineLimit(1)
                        Text(duplicate.displaySubtitle)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    Spacer()
                    Button {
                        selection = duplicate.id
                    } label: {
                        Label("Open", systemImage: "arrow.right.circle")
                    }
                    .help("Open the possible duplicate record after closing the inbox")

                    Button {
                        selection = store.acceptSuggestedEvidence(item, mergeInto: duplicate.id)
                        reload()
                    } label: {
                        Label("Merge Duplicate", systemImage: "arrow.triangle.merge")
                    }
                    .buttonStyle(.borderedProminent)
                    .help("Import the suggestion, merge it into this existing record, and move the suggestion to Accepted")
                }
            }
        }
        .padding(AppDesign.Spacing.sm)
        .background(Color.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
    }

    private var allFilteredSelected: Bool {
        !filteredSuggestions.isEmpty && filteredSuggestions.allSatisfy { selectedIDs.contains($0.id) }
    }

    private func selectionBinding(for item: SuggestedEvidenceItem) -> Binding<Bool> {
        Binding {
            selectedIDs.contains(item.id)
        } set: { isSelected in
            if isSelected {
                selectedIDs.insert(item.id)
            } else {
                selectedIDs.remove(item.id)
            }
        }
    }

    private func expansionBinding(for item: SuggestedEvidenceItem) -> Binding<Bool> {
        Binding {
            expandedIDs.contains(item.id)
        } set: { isExpanded in
            if isExpanded {
                expandedIDs.insert(item.id)
            } else {
                expandedIDs.remove(item.id)
            }
        }
    }

    private func toggleSelectFiltered() {
        if allFilteredSelected {
            selectedIDs.subtract(filteredSuggestions.map(\.id))
        } else {
            selectedIDs.formUnion(filteredSuggestions.map(\.id))
        }
    }

    private func acceptSelected() {
        for item in selectedItems {
            selection = store.acceptSuggestedEvidence(item)
        }
        reload()
    }

    private func importSelectedForEditing() {
        var lastID: EvidenceEntry.ID?
        for item in selectedItems {
            lastID = store.acceptSuggestedEvidence(item)
        }
        selection = lastID ?? selection
        reload()
        if lastID != nil {
            openEvidenceAfterImport?()
            dismiss()
        }
    }

    private func dismissSelected() {
        for item in selectedItems {
            store.dismissSuggestedEvidence(item)
        }
        reload()
    }

    private func markSelectedProofMissing() {
        for item in selectedItems {
            selection = store.markSuggestedEvidenceProofMissing(item)
        }
        reload()
    }

    private func proofLabel(for item: SuggestedEvidenceItem) -> String {
        if !item.sourceURLs.isEmpty { return "\(item.sourceURLs.count) link(s)" }
        if !item.entry.attachments.isEmpty { return "\(item.entry.attachments.count) file(s)" }
        return "proof missing"
    }

    private func proofIcon(for item: SuggestedEvidenceItem) -> String {
        if !item.sourceURLs.isEmpty { return "link" }
        if !item.entry.attachments.isEmpty { return "paperclip.circle" }
        return "paperclip"
    }

    private func proofTone(for item: SuggestedEvidenceItem) -> StatusChip.Tone {
        item.sourceURLs.isEmpty && item.entry.attachments.isEmpty ? .warning : .success
    }

    private func confidenceTone(_ confidence: AaltoCriteriaRecommendation.Confidence) -> StatusChip.Tone {
        switch confidence {
        case .high:
            return .success
        case .medium:
            return .accent
        case .review:
            return .warning
        }
    }

    private func proofSummary(for item: SuggestedEvidenceItem) -> String {
        var parts: [String] = []
        if !item.relativePath.trimmed.isEmpty {
            parts.append("Suggestion file: \(item.relativePath)")
        }
        if !item.sourceURLs.isEmpty {
            parts.append("Source link: \(item.sourceURLs.map(\.absoluteString).prefix(2).joined(separator: ", "))")
        }
        if !item.entry.attachments.isEmpty {
            parts.append("Attachment: \(item.entry.attachments.map(\.name).joined(separator: ", "))")
        }
        if item.sourceURLs.isEmpty && item.entry.attachments.isEmpty {
            parts.append("No source URL or attachment detected yet.")
        }
        return parts.joined(separator: "\n")
    }

    private func missingSummary(for item: SuggestedEvidenceItem) -> String {
        item.missingFields.isEmpty ? "Nothing obvious before import." : item.missingFields.joined(separator: ", ")
    }

    private func sourceTraceSummary(_ trace: EvidenceSourceTrace) -> String {
        var parts = [
            "File: \(trace.fileName)",
            "Folder: \(trace.folder.trimmed.isEmpty ? "Suggested evidence inbox" : trace.folder)"
        ]
        if !trace.date.trimmed.isEmpty {
            parts.append("Date: \(trace.date)")
        }
        if !trace.snippet.trimmed.isEmpty {
            parts.append("Snippet: \(trace.snippet)")
        }
        if let link = trace.links.first {
            parts.append("Source link: \(link.absoluteString)")
        }
        return parts.joined(separator: "\n")
    }

    private func reload() {
        suggestions = store.suggestedEvidenceItems()
        let currentIDs = Set(suggestions.map(\.id))
        selectedIDs.formIntersection(currentIDs)
        expandedIDs.formIntersection(currentIDs)
    }
}
