import SwiftUI

struct CVDiffView: View {
    let report: CVDiffReport
    let hasSnapshot: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("CV Diff Since Last Export", systemImage: "arrow.left.arrow.right")
                    .font(.headline)
                Spacer()
                metric("Words", old: report.oldWordCount, new: report.newWordCount)
                metric("Pages", old: report.oldPageCount, new: report.newPageCount)
            }

            if !hasSnapshot {
                ContentUnavailableView(
                    "No Previous Export Snapshot",
                    systemImage: "clock.arrow.circlepath",
                    description: Text("Export a CV once, then this view will show added, removed, and likely edited lines.")
                )
                .frame(minHeight: 440)
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        diffSection("New items added", lines: report.added, color: .green, systemImage: "plus.circle")
                        diffSection("Removed items", lines: report.removed, color: .red, systemImage: "minus.circle")
                        diffSection("Likely edited wording", lines: report.editedHint, color: .orange, systemImage: "pencil")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .frame(minHeight: 500)
            }
        }
    }

    private func metric(_ title: String, old: Int, new: Int) -> some View {
        HStack(spacing: 4) {
            Text(title)
                .foregroundStyle(.secondary)
            Text("\(old) -> \(new)")
                .fontWeight(.semibold)
        }
        .font(.caption)
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 6))
        .help("\(title) changed from \(old) to \(new)")
    }

    private func diffSection(_ title: String, lines: [String], color: Color, systemImage: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("\(title) (\(lines.count))", systemImage: systemImage)
                .font(.headline)
                .foregroundStyle(color)

            if lines.isEmpty {
                Text("No changes in this group.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(lines, id: \.self) { line in
                    Text(line)
                        .font(.caption)
                        .textSelection(.enabled)
                        .padding(8)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(color.opacity(0.08), in: RoundedRectangle(cornerRadius: 6))
                }
            }
        }
    }
}
