import SwiftUI

struct CVStructuredDatabaseView: View {
    @ObservedObject var store: EvidenceStore
    let template: CVDraftVariant
    let openEvidence: (EvidenceEntry.ID) -> Void
    @State private var sectionFilter: CVStructuredSection?

    private let confidenceValues = ["high", "medium", "profile", "review"]
    private let peerReviewValues = ["yes", "no", "check", "not stated"]
    private let visibilityValues = ["academic", "public", "internal"]

    private var filteredItems: [CVStructuredItem] {
        store.cvItems
            .filter { item in
                sectionFilter.map { item.section == $0 } ?? true
            }
            .sorted { lhs, rhs in
                if lhs.section.rawValue == rhs.section.rawValue {
                    return lhs.order < rhs.order
                }
                return lhs.section.rawValue < rhs.section.rawValue
            }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Structured CV Database", systemImage: "tablecells")
                    .font(.headline)
                Text("\(store.cvItems.count) item(s)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Picker("Section", selection: $sectionFilter) {
                    Text("All sections").tag(Optional<CVStructuredSection>.none)
                    ForEach(CVStructuredSection.allCases) { section in
                        Text(section.rawValue).tag(Optional(section))
                    }
                }
                .frame(width: 210)
                .help("Filter structured CV items by section")

                Button {
                    _ = store.addStructuredCVItem(section: sectionFilter ?? .other)
                } label: {
                    Label("Add", systemImage: "plus")
                }
                .help("Add a new structured CV item")

                Button {
                    store.saveStructuredCVItems()
                } label: {
                    Label("Save", systemImage: "externaldrive")
                }
                .help("Save the structured CV database")

                Button {
                    store.linkBestEvidenceToAll()
                } label: {
                    Label("Auto Link", systemImage: "link.badge.plus")
                }
                .help("Link each unlinked CV item to its best likely evidence match")

                Button {
                    store.rebuildStructuredCVItems()
                } label: {
                    Label("Rebuild", systemImage: "arrow.triangle.2.circlepath")
                }
                .help("Rebuild the structured CV database from app evidence and the CV master source")
            }

            Text("This is the editable source of truth: year, title, role, venue, source confidence, visibility, and which CV templates each item belongs in.")
                .font(.caption)
                .foregroundStyle(.secondary)

            if filteredItems.isEmpty {
                ContentUnavailableView(
                    "No Structured Items",
                    systemImage: "tablecells.badge.ellipsis",
                    description: Text("Use Rebuild to seed this table from the current CV files and evidence records.")
                )
                .frame(minHeight: 440)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 10) {
                        ForEach(filteredItems) { item in
                            if let index = store.cvItems.firstIndex(where: { $0.id == item.id }) {
                                structuredRow($store.cvItems[index])
                            }
                        }
                    }
                    .padding(.vertical, 2)
                }
                .frame(minHeight: 500)
            }
        }
        .onChange(of: store.cvItems) { _, _ in
            store.saveStructuredCVItems(showMessage: false)
        }
    }

    private func structuredRow(_ item: Binding<CVStructuredItem>) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                Picker("Section", selection: item.section) {
                    ForEach(CVStructuredSection.allCases) { section in
                        Text(section.rawValue).tag(section)
                    }
                }
                .frame(width: 150)
                .help("Structured CV section")

                TextField("Year", text: item.year)
                    .frame(width: 70)
                    .help("Year or date range")

                TextField("Title", text: item.title, axis: .vertical)
                    .font(.body.weight(.medium))
                    .help("CV item title or full line")

                Toggle("Verified", isOn: item.verified)
                    .toggleStyle(.checkbox)
                    .help("Only verified items are included in final clean export decisions")

                Button {
                    store.deleteStructuredCVItem(id: item.wrappedValue.id)
                } label: {
                    Image(systemName: "trash")
                }
                .buttonStyle(.borderless)
                .foregroundStyle(.red)
                .help("Delete this structured CV item")
            }

            claimProofStatusStrip(for: item.wrappedValue)

            Grid(alignment: .leading, horizontalSpacing: 10, verticalSpacing: 8) {
                GridRow {
                    Text("Authors").foregroundStyle(.secondary)
                    TextField("Authors", text: item.authors)
                    Text("Role").foregroundStyle(.secondary)
                    TextField("Role", text: item.role)
                }
                GridRow {
                    Text("Venue").foregroundStyle(.secondary)
                    TextField("Venue", text: item.venue)
                    Text("DOI").foregroundStyle(.secondary)
                    TextField("DOI", text: item.doi)
                }
                GridRow {
                    Text("Peer").foregroundStyle(.secondary)
                    Picker("Peer review", selection: item.peerReview) {
                        ForEach(peerReviewValues, id: \.self) { value in
                            Text(value.capitalized).tag(value)
                        }
                    }
                    Text("TENK").foregroundStyle(.secondary)
                    TextField("TENK class", text: item.tenkClass)
                }
                GridRow {
                    Text("JUFO").foregroundStyle(.secondary)
                    TextField("JUFO level", text: item.jufoLevel)
                    Text("Confidence").foregroundStyle(.secondary)
                    Picker("Source confidence", selection: item.sourceConfidence) {
                        ForEach(confidenceValues, id: \.self) { value in
                            Text(value.capitalized).tag(value)
                        }
                    }
                }
                GridRow {
                    Text("Visibility").foregroundStyle(.secondary)
                    Picker("Visibility", selection: item.visibility) {
                        ForEach(visibilityValues, id: \.self) { value in
                            Text(value.capitalized).tag(value)
                        }
                    }
                    Text("Source").foregroundStyle(.secondary)
                    TextField("Source", text: item.source)
                }
            }
            .font(.caption)

            VStack(alignment: .leading, spacing: 6) {
                Text("Include In Templates")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)

                ScrollView(.horizontal) {
                    HStack(spacing: 10) {
                        ForEach(CVDraftVariant.allCases) { variant in
                            Toggle(variant.rawValue, isOn: templateBinding(item, variant: variant))
                                .toggleStyle(.checkbox)
                                .font(.caption)
                                .help("Include this item in \(variant.rawValue)")
                        }
                    }
                }
            }

            linkedEvidenceSection(item)

            TextField("Notes", text: item.notes, axis: .vertical)
                .font(.caption)
                .help("Private notes for CV editing and evidence checking")
        }
        .padding(12)
        .background(
            templateBinding(item, variant: template).wrappedValue ? Color.green.opacity(0.08) : Color.secondary.opacity(0.08),
            in: RoundedRectangle(cornerRadius: 8)
        )
    }

    private func linkedEvidenceSection(_ item: Binding<CVStructuredItem>) -> some View {
        let linked = store.linkedEvidence(for: item.wrappedValue)
        let suggestions = store.suggestedEvidenceMatches(for: item.wrappedValue, limit: 3)
        let status = claimProofStatus(for: item.wrappedValue)

        return VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text("Claim-to-Proof Links")
                    .font(.caption.weight(.semibold))

                Text("\(linked.count)")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(.secondary.opacity(0.12), in: Capsule())

                StatusChip(text: status.title, systemImage: status.systemImage, tone: status.tone)

                Spacer()

                Button {
                    store.linkBestEvidence(to: item.wrappedValue.id)
                } label: {
                    Label("Link Best", systemImage: "link.badge.plus")
                }
                .buttonStyle(.borderless)
                .font(.caption)
                .help("Link the best likely evidence record to this CV item")

                Button {
                    if let id = store.createEvidenceFromCVItem(item.wrappedValue.id) {
                        openEvidence(id)
                    }
                } label: {
                    Label("Make Evidence", systemImage: "tray.badge.plus")
                }
                .buttonStyle(.borderless)
                .font(.caption)
                .help("Create and link a new evidence record from this CV line")
            }

            if linked.isEmpty {
                Text("No proof is linked to this CV claim yet. Use Link Best or choose a suggested evidence match before final export.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            } else {
                ForEach(linked) { entry in
                    let hasProof = evidenceHasProof(entry)
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: hasProof ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                            .foregroundStyle(hasProof ? .green : .orange)
                            .help(hasProof ? "This linked record has attachment or URL proof" : "This linked record still needs proof")
                        VStack(alignment: .leading, spacing: 2) {
                            Text(entry.title)
                                .font(.caption)
                                .lineLimit(1)
                            Text(entry.displaySubtitle)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                            HStack(spacing: 6) {
                                StatusChip(
                                    text: hasProof ? "Proof" : "Proof needed",
                                    systemImage: hasProof ? "paperclip.circle" : "paperclip",
                                    tone: hasProof ? .success : .warning
                                )
                                StatusChip(
                                    text: "\(entry.completeness.score)%",
                                    systemImage: "gauge",
                                    tone: entry.completeness.score >= 80 ? .success : .warning
                                )
                                if entry.cvReady {
                                    StatusChip(text: "Ready to use", systemImage: "checkmark.seal", tone: .success)
                                }
                            }
                        }
                        Spacer()
                        Button {
                            openEvidence(entry.id)
                        } label: {
                            Image(systemName: "arrow.right.circle")
                        }
                        .buttonStyle(.borderless)
                        .help("Open this evidence record")

                        Button {
                            store.revealAttachmentFolder(for: entry.id)
                        } label: {
                            Image(systemName: "folder")
                        }
                        .buttonStyle(.borderless)
                        .help("Open the attachment folder for this evidence record")

                        Button {
                            store.revealSourceArchiveFolder(for: entry.id)
                        } label: {
                            Image(systemName: "archivebox")
                        }
                        .buttonStyle(.borderless)
                        .help("Open the source archive folder for this evidence record")

                        if !sourceURLs(for: entry).isEmpty {
                            Button {
                                store.archiveSources(for: entry.id)
                            } label: {
                                Image(systemName: "tray.and.arrow.down")
                            }
                            .buttonStyle(.borderless)
                            .help("Archive source URLs for this evidence record")
                        }

                        Button {
                            store.unlinkEvidence(entry.id, from: item.wrappedValue.id)
                        } label: {
                            Image(systemName: "link.badge.minus")
                        }
                        .buttonStyle(.borderless)
                        .help("Unlink this evidence record from the CV item")
                    }
                }
            }

            if !suggestions.isEmpty {
                Divider()
                Text("Suggested links")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.secondary)

                ForEach(suggestions) { entry in
                    HStack(spacing: 8) {
                        Image(systemName: "sparkle.magnifyingglass")
                            .foregroundStyle(.secondary)
                            .help("Suggested evidence match")
                        VStack(alignment: .leading, spacing: 2) {
                            Text(entry.title)
                                .font(.caption)
                                .lineLimit(1)
                            Text(entry.displaySubtitle)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                        }
                        Spacer()
                        Button {
                            store.linkEvidence(entry.id, to: item.wrappedValue.id)
                        } label: {
                            Label("Link", systemImage: "link")
                        }
                        .buttonStyle(.borderless)
                        .font(.caption)
                        .help("Link this suggested evidence record to the CV item")
                    }
                }
            }
        }
        .padding(8)
        .background(.quaternary.opacity(0.22), in: RoundedRectangle(cornerRadius: 6))
    }

    private func claimProofStatusStrip(for item: CVStructuredItem) -> some View {
        let status = claimProofStatus(for: item)

        return HStack(alignment: .top, spacing: 8) {
            StatusChip(text: status.title, systemImage: status.systemImage, tone: status.tone)
            Text(status.detail)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 8)
            if status.needsLink {
                Button {
                    store.linkBestEvidence(to: item.id)
                } label: {
                    Label("Link Best", systemImage: "link.badge.plus")
                }
                .buttonStyle(.borderless)
                .font(.caption)
                .help("Find and link the best likely evidence record for this claim")
            }
        }
        .padding(8)
        .background(status.tone.fill, in: RoundedRectangle(cornerRadius: 6))
    }

    private struct ClaimProofStatus {
        var title: String
        var detail: String
        var systemImage: String
        var tone: StatusChip.Tone
        var needsLink: Bool
    }

    private func claimProofStatus(for item: CVStructuredItem) -> ClaimProofStatus {
        let linked = store.linkedEvidence(for: item)

        guard !linked.isEmpty else {
            return ClaimProofStatus(
                title: "Missing proof",
                detail: "This CV claim has no linked evidence yet.",
                systemImage: "link.badge.plus",
                tone: .warning,
                needsLink: true
            )
        }

        let proofCount = linked.filter(evidenceHasProof).count
        guard proofCount > 0 else {
            return ClaimProofStatus(
                title: "Weak proof",
                detail: "Evidence is linked, but it still needs an attachment or source URL.",
                systemImage: "paperclip",
                tone: .warning,
                needsLink: false
            )
        }

        if item.verified {
            return ClaimProofStatus(
                title: "Verified proof",
                detail: "\(proofCount) linked evidence record(s) support this verified CV claim.",
                systemImage: "checkmark.seal",
                tone: .success,
                needsLink: false
            )
        }

        return ClaimProofStatus(
            title: "Proof linked",
            detail: "\(proofCount) linked evidence record(s) found. Verify the wording before final export.",
            systemImage: "link.circle",
            tone: .accent,
            needsLink: false
        )
    }

    private func evidenceHasProof(_ entry: EvidenceEntry) -> Bool {
        !entry.attachments.isEmpty || !sourceURLs(for: entry).isEmpty
    }

    private func sourceURLs(for entry: EvidenceEntry) -> [URL] {
        URLTools.extractURLs(from: [entry.source, entry.notes].joined(separator: "\n"))
    }

    private func templateBinding(_ item: Binding<CVStructuredItem>, variant: CVDraftVariant) -> Binding<Bool> {
        Binding {
            item.wrappedValue.includeInTemplates.contains(variant.rawValue)
        } set: { isIncluded in
            var templates = item.wrappedValue.includeInTemplates
            if isIncluded {
                if !templates.contains(variant.rawValue) {
                    templates.append(variant.rawValue)
                }
            } else {
                templates.removeAll { $0 == variant.rawValue }
            }
            item.wrappedValue.includeInTemplates = templates
        }
    }
}
