import SwiftUI

struct CVStylesView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Label("CV Export Styles", systemImage: "text.badge.star")
                    .font(.title2.weight(.semibold))
                Spacer()
                Button("Close") {
                    dismiss()
                }
            }

            Text("Export the same records in different voices and structures.")
                .foregroundStyle(.secondary)

            VStack(alignment: .leading, spacing: 10) {
                ForEach(CVExportStyle.allCases) { style in
                    Button {
                        store.exportCVMarkdown(style: style)
                    } label: {
                        HStack {
                            Image(systemName: icon(for: style))
                                .frame(width: 22)
                                .help(style.rawValue)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(style.rawValue)
                                Text(description(for: style))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "square.and.arrow.up")
                                .foregroundStyle(.secondary)
                                .help("Export this CV style")
                        }
                        .padding(.vertical, 4)
                    }
                    .buttonStyle(.plain)
                    .help("Export \(style.rawValue)")
                    Divider()
                }
            }
            .padding(12)
            .background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: 8))
        }
        .padding(22)
    }

    private func icon(for style: CVExportStyle) -> String {
        switch style {
        case .academic:
            "doc.text"
        case .tenk:
            "list.bullet.rectangle"
        case .tenureBullets:
            "checklist"
        case .publicBio:
            "person.text.rectangle"
        }
    }

    private func description(for style: CVExportStyle) -> String {
        switch style {
        case .academic:
            "Grouped academic CV sections for talks, exhibitions, service, teaching, funding, and visibility."
        case .tenk:
            "A compact structure aligned with Finnish academic CV categories."
        case .tenureBullets:
            "Evaluator-facing narrative bullets grouped by tenure dimensions."
        case .publicBio:
            "Short profile update text and selected recent highlights."
        }
    }
}
