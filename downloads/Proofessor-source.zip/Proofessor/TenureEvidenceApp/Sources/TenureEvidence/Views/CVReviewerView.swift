import SwiftUI

struct CVReviewerView: View {
    let summary: CVReviewerSummary

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Reviewer View", systemImage: "person.badge.key")
                .font(.headline)

            Text("A quick approximation of what a tenure evaluator might notice first: strongest evidence, thin evidence, and lines that still look provisional.")
                .font(.caption)
                .foregroundStyle(.secondary)

            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 300), alignment: .top)], alignment: .leading, spacing: 12) {
                    highlightSection("Top Research / Artistic Strengths", entries: summary.researchHighlights, image: "paintpalette")
                    highlightSection("Top Teaching Strengths", entries: summary.teachingHighlights, image: "graduationcap")
                    highlightSection("Top Impact / Service Strengths", entries: summary.impactHighlights, image: "person.3")
                    missingSection
                    weakLineSection
                }
                .padding(.vertical, 2)
            }
            .frame(minHeight: 500)
        }
    }

    private func highlightSection(_ title: String, entries: [EvidenceEntry], image: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: image)
                .font(.headline)

            if entries.isEmpty {
                Text("No strong ready-to-use evidence yet.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(entries) { entry in
                    entryLine(entry)
                }
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private var missingSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Proof / Records Needed", systemImage: "exclamationmark.triangle")
                .font(.headline)
                .foregroundStyle(.orange)

            if summary.missingEvidence.isEmpty {
                Text("No obvious missing evidence records.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(summary.missingEvidence) { entry in
                    VStack(alignment: .leading, spacing: 2) {
                        entryLine(entry)
                        if !entry.completeness.missing.isEmpty {
                            Text("Missing: \(entry.completeness.missing.joined(separator: ", "))")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .padding(12)
        .background(Color.orange.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private var weakLineSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Weak Or Vague Lines", systemImage: "line.3.horizontal.decrease.circle")
                .font(.headline)

            if summary.weakLines.isEmpty {
                Text("No obvious provisional lines found.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(summary.weakLines, id: \.self) { line in
                    Text(line)
                        .font(.caption)
                        .textSelection(.enabled)
                }
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private func entryLine(_ entry: EvidenceEntry) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(entry.title.trimmed.isEmpty ? "Untitled evidence" : entry.title)
                .font(.caption.weight(.semibold))
                .lineLimit(2)
            Text([entry.date, entry.role, entry.venue].filter { !$0.trimmed.isEmpty }.joined(separator: " · "))
                .font(.caption2)
                .foregroundStyle(.secondary)
                .lineLimit(2)
        }
    }
}
