import SwiftUI

struct CVCleanupActionsView: View {
    let hideUncertain: () -> Void
    let shortenToThreePages: () -> Void
    let fixPublications: () -> Void
    let useTenureOrder: () -> Void
    let makeSendable: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("One-Click Cleanup", systemImage: "sparkles")
                .font(.headline)

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 190), alignment: .leading)], alignment: .leading, spacing: 8) {
                cleanupButton("Hide uncertain lines", image: "eye.slash", action: hideUncertain)
                    .help("Exclude review-confidence, missing, check, or provisional lines from the draft")
                cleanupButton("Shorten to 3 pages", image: "rectangle.compress.vertical", action: shortenToThreePages)
                    .help("Switch to the three-page template, compact theme, ready-to-use evidence, and final clean mode")
                cleanupButton("Fix publications", image: "text.book.closed", action: fixPublications)
                    .help("Fill missing publication metadata where it can be inferred: DOI, TENK, peer review, and source confidence")
                cleanupButton("Tenure order", image: "checklist", action: useTenureOrder)
                    .help("Switch to the tenure template and Clean academic theme")
                cleanupButton("Make sendable", image: "checkmark.rectangle.stack", action: makeSendable)
                    .help("Turn on final clean mode and remove source scaffolding")
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }

    private func cleanupButton(_ title: String, image: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: image)
                .lineLimit(1)
        }
    }
}
