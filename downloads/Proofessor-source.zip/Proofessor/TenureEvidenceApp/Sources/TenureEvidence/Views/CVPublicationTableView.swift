import SwiftUI

struct CVPublicationTableView: View {
    @ObservedObject var store: EvidenceStore

    private let peerReviewValues = ["yes", "no", "check", "not stated"]
    private let confidenceValues = ["high", "medium", "profile", "review"]

    private var publications: [CVStructuredItem] {
        store.cvItems
            .filter { $0.section == .publication }
            .sorted {
                if $0.year == $1.year { return $0.title < $1.title }
                return $0.year > $1.year
            }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Publication Table", systemImage: "text.book.closed")
                    .font(.headline)
                Text("\(publications.count) structured publication(s)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Menu {
                    ForEach(CitationExportStyle.allCases) { style in
                        Button {
                            store.exportCitationList(style: style)
                        } label: {
                            Label(style.rawValue, systemImage: style.systemImage)
                        }
                    }
                } label: {
                    Label("Export Citations", systemImage: "square.and.arrow.up")
                }
                .help("Export this publication list as APA, Chicago, or TENK/JUFO-oriented citations")

                Button {
                    _ = store.addStructuredCVItem(section: .publication)
                } label: {
                    Label("Add Publication", systemImage: "plus")
                }
                .help("Add a structured publication record")
            }

            Text("Use this table for the academic part that needs the most care: authors, year, title, venue, DOI, peer-review status, TENK class, JUFO level, and your role.")
                .font(.caption)
                .foregroundStyle(.secondary)

            if publications.isEmpty {
                ContentUnavailableView(
                    "No Structured Publications",
                    systemImage: "text.book.closed",
                    description: Text("Add publications manually or rebuild the structured database from the master CV source.")
                )
                .frame(minHeight: 440)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 10) {
                        ForEach(publications) { publication in
                            if let index = store.cvItems.firstIndex(where: { $0.id == publication.id }) {
                                publicationRow($store.cvItems[index])
                            }
                        }
                    }
                    .padding(.vertical, 2)
                }
                .frame(minHeight: 500)
            }
        }
        .onChange(of: store.cvItems) { _, _ in
            store.saveStructuredCVItems(showMessage: false)
        }
    }

    private func publicationRow(_ item: Binding<CVStructuredItem>) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                TextField("Year", text: item.year)
                    .frame(width: 70)
                    .help("Publication year")
                TextField("Authors", text: item.authors)
                    .frame(minWidth: 160)
                    .help("Publication authors")
                TextField("Title", text: item.title, axis: .vertical)
                    .font(.body.weight(.medium))
                    .help("Publication title")
                Toggle("Verified", isOn: item.verified)
                    .toggleStyle(.checkbox)
                    .help("Mark this publication metadata as verified")
            }

            Grid(alignment: .leading, horizontalSpacing: 10, verticalSpacing: 8) {
                GridRow {
                    Text("Venue").foregroundStyle(.secondary)
                    TextField("Journal, book, conference, publisher", text: item.venue)
                    Text("DOI").foregroundStyle(.secondary)
                    TextField("10.xxxx/...", text: item.doi)
                }
                GridRow {
                    Text("Peer review").foregroundStyle(.secondary)
                    Picker("Peer review", selection: item.peerReview) {
                        ForEach(peerReviewValues, id: \.self) { value in
                            Text(value.capitalized).tag(value)
                        }
                    }
                    Text("Role").foregroundStyle(.secondary)
                    TextField("author, editor, contributor...", text: item.role)
                }
                GridRow {
                    Text("TENK").foregroundStyle(.secondary)
                    TextField("A/B/C/D/E/F/G", text: item.tenkClass)
                    Text("JUFO").foregroundStyle(.secondary)
                    TextField("0/1/2/3/check", text: item.jufoLevel)
                }
                GridRow {
                    Text("Confidence").foregroundStyle(.secondary)
                    Picker("Source confidence", selection: item.sourceConfidence) {
                        ForEach(confidenceValues, id: \.self) { value in
                            Text(value.capitalized).tag(value)
                        }
                    }
                    Text("Source").foregroundStyle(.secondary)
                    TextField("DOI, portal, CV, publisher page...", text: item.source)
                }
            }
            .font(.caption)

            HStack {
                TextField("Notes", text: item.notes, axis: .vertical)
                    .font(.caption)
                Button {
                    store.deleteStructuredCVItem(id: item.wrappedValue.id)
                } label: {
                    Label("Delete", systemImage: "trash")
                }
                .buttonStyle(.borderless)
                .foregroundStyle(.red)
                .help("Delete this publication record")
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }
}
