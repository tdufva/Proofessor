import AppKit
import SwiftUI

struct StartHereView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    let openSuggestions: () -> Void
    let openCV: () -> Void
    let openSources: () -> Void

    @State private var didChooseFolder = false
    @State private var didScan = false
    @State private var didCreateSamples = false
    @State private var didExportDemoCV = false
    @State private var scannedCount: Int?

    private var selectedFolderLabel: String {
        guard let path = store.connectorSettings.documentScanFolders.last else {
            return "No extra folder chosen yet"
        }
        return URL(fileURLWithPath: path).lastPathComponent
    }

    private var pendingSuggestionCount: Int {
        store.suggestedEvidenceItems().count
    }

    var body: some View {
        ZStack {
            Rectangle()
                .fill(AppDesign.appBackground)
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                    header
                    nextActionPanel
                    guidedSteps
                    footer
                }
                .padding(AppDesign.Spacing.xl)
                .frame(maxWidth: 920, alignment: .leading)
            }
        }
        .preferredColorScheme(.dark)
        .frame(minWidth: 780, idealWidth: 920, minHeight: 620, idealHeight: 720)
    }

    private var header: some View {
        PageHeader(
            title: "Start Here",
            subtitle: "A ten-minute walkthrough: choose a folder, scan it, review three sample suggestions, and export a tiny demo CV.",
            systemImage: "sparkles",
            trailing: AnyView(
                Button("Close") {
                    dismiss()
                }
                .keyboardShortcut(.cancelAction)
            )
        )
    }

    private var nextActionPanel: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            HStack(alignment: .top, spacing: AppDesign.Spacing.md) {
                Image(systemName: nextActionIcon)
                    .font(.title2)
                    .foregroundStyle(AppDesign.academyGold)
                    .frame(width: 28)

                VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    Text(nextActionTitle)
                        .font(.system(.title2, design: .serif).weight(.semibold))
                    Text(nextActionSubtitle)
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer()

                Button(action: runNextAction) {
                    Label(nextActionButtonTitle, systemImage: nextActionIcon)
                }
                .buttonStyle(.borderedProminent)
                .keyboardShortcut(.defaultAction)
                .help("Continue the guided setup")
            }

            StatusStrip(items: [
                StatusStripItem(text: selectedFolderLabel, systemImage: "folder", tone: didChooseFolder || !store.connectorSettings.documentScanFolders.isEmpty ? .success : .neutral),
                StatusStripItem(text: scanStatusText, systemImage: "text.viewfinder", tone: didScan ? .success : .neutral),
                StatusStripItem(text: "\(pendingSuggestionCount) in inbox", systemImage: "tray.full", tone: pendingSuggestionCount >= 3 ? .success : .accent),
                StatusStripItem(text: didExportDemoCV ? "demo CV exported" : "demo CV ready", systemImage: "doc.text", tone: didExportDemoCV ? .success : .neutral)
            ])
        }
        .padding(AppDesign.Spacing.lg)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var guidedSteps: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Guided Flow",
                subtitle: "Each step has one clear action. Everything it finds remains editable.",
                systemImage: "list.bullet.rectangle"
            )

            stepRow(
                number: "1",
                title: "Choose a folder",
                detail: selectedFolderLabel,
                complete: didChooseFolder || !store.connectorSettings.documentScanFolders.isEmpty,
                buttonTitle: "Choose",
                image: "folder.badge.plus",
                action: chooseFolder
            )

            stepRow(
                number: "2",
                title: "Scan for evidence",
                detail: "Looks inside the inbox, tenure folders, configured folders, and subfolders.",
                complete: didScan,
                buttonTitle: "Scan",
                image: "arrow.triangle.2.circlepath",
                action: runScan
            )

            stepRow(
                number: "3",
                title: "Review three sample suggestions",
                detail: "A keynote, teaching feedback, and a funding item show the whole review workflow.",
                complete: didCreateSamples,
                buttonTitle: "Open Inbox",
                image: "tray.full",
                action: reviewSamples
            )

            stepRow(
                number: "4",
                title: "Export a tiny demo CV",
                detail: "Creates a small CV export so the user sees the endpoint immediately.",
                complete: didExportDemoCV,
                buttonTitle: "Export",
                image: "doc.text",
                action: exportDemoCV
            )
        }
        .padding(AppDesign.Spacing.lg)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var footer: some View {
        HStack {
            Button {
                dismiss()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    openSources()
                }
            } label: {
                Label("Source Settings", systemImage: "switch.2")
            }
            .help("Choose profile links, review period, and folders")

            Button {
                dismiss()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    openCV()
                }
            } label: {
                Label("Build CV", systemImage: "doc.text.magnifyingglass")
            }
            .help("Open the CV builder")

            Spacer()

            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)
        }
    }

    private func stepRow(
        number: String,
        title: String,
        detail: String,
        complete: Bool,
        buttonTitle: String,
        image: String,
        action: @escaping () -> Void
    ) -> some View {
        HStack(alignment: .center, spacing: AppDesign.Spacing.md) {
            Text(number)
                .font(.headline.monospacedDigit())
                .foregroundStyle(complete ? .green : AppDesign.academyGold)
                .frame(width: 30, height: 30)
                .background((complete ? Color.green : AppDesign.academyGold).opacity(0.14), in: Circle())

            VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                HStack(spacing: AppDesign.Spacing.sm) {
                    Text(title)
                        .font(.headline)
                    if complete {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                    }
                }
                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer()

            Button(action: action) {
                Label(buttonTitle, systemImage: image)
            }
            .help(title)
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var scanStatusText: String {
        guard let scannedCount else { return "not scanned" }
        return scannedCount == 1 ? "1 item scanned" : "\(scannedCount) items scanned"
    }

    private var nextActionTitle: String {
        if store.connectorSettings.documentScanFolders.isEmpty && !didChooseFolder {
            return "Choose where your evidence lives"
        }
        if !didScan {
            return "Run a deep scan"
        }
        if pendingSuggestionCount < 3 && !didCreateSamples {
            return "Load three sample suggestions"
        }
        if !didExportDemoCV {
            return "Export the demo CV"
        }
        return "You have seen the full loop"
    }

    private var nextActionSubtitle: String {
        if store.connectorSettings.documentScanFolders.isEmpty && !didChooseFolder {
            return "Pick a folder with PDFs, CVs, BibTeX files, course feedback, or tenure materials. The scan will also look inside subfolders."
        }
        if !didScan {
            return "The app will prefill candidate records from files, folder names, text snippets, DOI/BibTeX metadata, and source links."
        }
        if pendingSuggestionCount < 3 && !didCreateSamples {
            return "The samples let a new user understand accept, edit, dismiss, merge, and proof-missing decisions without reading documentation."
        }
        if !didExportDemoCV {
            return "A tiny export makes the destination visible: evidence becomes a CV draft."
        }
        return "Continue with your real suggestions, or adjust sources and review period settings."
    }

    private var nextActionButtonTitle: String {
        if store.connectorSettings.documentScanFolders.isEmpty && !didChooseFolder {
            return "Choose Folder"
        }
        if !didScan { return "Scan Now" }
        if pendingSuggestionCount < 3 && !didCreateSamples { return "Add Samples" }
        if !didExportDemoCV { return "Export Demo CV" }
        return "Open Review Inbox"
    }

    private var nextActionIcon: String {
        if store.connectorSettings.documentScanFolders.isEmpty && !didChooseFolder {
            return "folder.badge.plus"
        }
        if !didScan { return "arrow.triangle.2.circlepath" }
        if pendingSuggestionCount < 3 && !didCreateSamples { return "sparkles" }
        if !didExportDemoCV { return "doc.text" }
        return "tray.full"
    }

    private func runNextAction() {
        if store.connectorSettings.documentScanFolders.isEmpty && !didChooseFolder {
            chooseFolder()
        } else if !didScan {
            runScan()
        } else if pendingSuggestionCount < 3 && !didCreateSamples {
            createSamples()
        } else if !didExportDemoCV {
            exportDemoCV()
        } else {
            reviewSamples()
        }
    }

    private func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.title = "Choose a folder to scan for tenure evidence"
        panel.prompt = "Choose Folder"

        guard panel.runModal() == .OK, let url = panel.url else { return }

        var settings = store.connectorSettings
        if !settings.documentScanFolders.contains(url.path) {
            settings.documentScanFolders.append(url.path)
        }
        settings.allowLocalFiles = true
        store.saveConnectorSettings(settings)
        didChooseFolder = true
    }

    private func runScan() {
        scannedCount = store.scanDocumentSources()
        didScan = true
    }

    private func createSamples() {
        _ = store.createDemoSuggestions()
        didCreateSamples = true
    }

    private func reviewSamples() {
        if pendingSuggestionCount < 3 {
            createSamples()
        }
        dismiss()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            openSuggestions()
        }
    }

    private func exportDemoCV() {
        store.exportTinyDemoCV()
        didExportDemoCV = true
    }
}
