import SwiftUI
import UniformTypeIdentifiers

struct GuidedCaptureView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @Binding var selection: EvidenceEntry.ID?
    var onCreate: () -> Void = {}
    @State private var selectedTemplate: EvidenceCaptureTemplate = .talk
    @State private var draft: EvidenceEntry = EvidenceCaptureTemplate.talk.makeEntry()
    @State private var pendingAttachments: [URL] = []
    @State private var importingFiles = false

    private var canCreate: Bool {
        !draft.title.trimmed.isEmpty && !draft.date.trimmed.isEmpty
    }

    var body: some View {
        HStack(spacing: 0) {
            templateList
                .frame(width: 210)
                .background(.bar)

            Divider()

            ScrollView {
                VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                    header
                    form
                    proofBox
                    actions
                }
                .padding(AppDesign.Spacing.xl)
                .frame(maxWidth: 720, alignment: .leading)
            }
        }
        .frame(minWidth: 760, idealWidth: 920, minHeight: 640, idealHeight: 680)
        .fileImporter(
            isPresented: $importingFiles,
            allowedContentTypes: [.item],
            allowsMultipleSelection: true
        ) { result in
            switch result {
            case .success(let urls):
                pendingAttachments.append(contentsOf: urls)
            case .failure(let error):
                store.lastMessage = "Attachment selection failed: \(error.localizedDescription)"
            }
        }
        .onChange(of: selectedTemplate) { _, newValue in
            draft = newValue.makeEntry(date: draft.date.trimmed.isEmpty ? EvidenceCaptureTemplate.talk.makeEntry().date : draft.date)
        }
    }

    private var templateList: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            PageHeader(
                title: "Guided Capture",
                subtitle: "Choose a tenure evidence type.",
                systemImage: "square.and.pencil"
            )
            .padding([.top, .horizontal], AppDesign.Spacing.md)

            List(selection: $selectedTemplate) {
                ForEach(EvidenceCaptureTemplate.allCases) { template in
                    Label(template.rawValue, systemImage: template.systemImage)
                        .tag(template)
                }
            }
            .listStyle(.sidebar)
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            HStack(alignment: .firstTextBaseline) {
                Label(selectedTemplate.rawValue, systemImage: selectedTemplate.systemImage)
                    .font(.title2.weight(.semibold))
                Spacer()
                Button("Close") {
                    dismiss()
                }
                .keyboardShortcut(.cancelAction)
            }

            Text(selectedTemplate.prompt)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            StatusStrip(items: [
                StatusStripItem(text: draft.title.trimmed.isEmpty ? "Needs title" : "Title ready", systemImage: "text.cursor", tone: draft.title.trimmed.isEmpty ? .warning : .success),
                StatusStripItem(text: draft.date.trimmed.isEmpty ? "Needs date" : draft.date, systemImage: "calendar", tone: draft.date.trimmed.isEmpty ? .warning : .success),
                StatusStripItem(text: "\(pendingAttachments.count) file(s)", systemImage: "paperclip", tone: pendingAttachments.isEmpty ? .neutral : .success)
            ])
        }
    }

    private var form: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Evidence Details",
                subtitle: "These fields become the evidence record and later feed the CV builder.",
                systemImage: "list.bullet.rectangle"
            )

            Grid(alignment: .leading, horizontalSpacing: 14, verticalSpacing: 12) {
                GridRow {
                    Text("Date").foregroundStyle(.secondary)
                    TextField("YYYY-MM-DD", text: $draft.date)
                }
                GridRow {
                    Text("Title").foregroundStyle(.secondary)
                    TextField("Title of event, work, course, grant, or publication", text: $draft.title)
                }
                GridRow {
                    Text("Category").foregroundStyle(.secondary)
                    Picker("Category", selection: $draft.category) {
                        ForEach(EvidenceOptions.categories, id: \.self) { category in
                            Text(category).tag(category)
                        }
                    }
                    .labelsHidden()
                }
                GridRow {
                    Text("Type").foregroundStyle(.secondary)
                    TextField("Evidence type", text: $draft.eventType)
                }
                GridRow {
                    Text("Role").foregroundStyle(.secondary)
                    TextField("Your role", text: $draft.role)
                }
                GridRow {
                    Text("Venue / host").foregroundStyle(.secondary)
                    TextField("Institution, event, publisher, or host", text: $draft.venue)
                }
                GridRow {
                    Text("Dimension").foregroundStyle(.secondary)
                    Picker("Tenure dimension", selection: $draft.tenureDimension) {
                        ForEach(EvidenceOptions.dimensions, id: \.self) { dimension in
                            Text(dimension).tag(dimension)
                        }
                    }
                    .labelsHidden()
                }
                GridRow {
                    Text("Source").foregroundStyle(.secondary)
                    TextField("URL, email, calendar item, file, institutional repository, Scholar, ORCID...", text: $draft.source)
                }
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                Text("Notes")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                TextEditor(text: $draft.notes)
                    .frame(minHeight: 120)
                    .scrollContentBackground(.hidden)
                    .padding(AppDesign.Spacing.sm)
                    .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var proofBox: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Proof to Attach",
                subtitle: selectedTemplate.suggestedProof,
                systemImage: "paperclip",
                trailing: AnyView(
                    Button {
                        importingFiles = true
                    } label: {
                        Label("Attach Files", systemImage: "paperclip")
                    }
                    .help("Choose files to attach when this record is created")
                )
            )

            if pendingAttachments.isEmpty {
                Text("No files selected yet. You can also attach files later in Verify & File.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                LazyVStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    ForEach(pendingAttachments, id: \.self) { url in
                        HStack {
                            Label(url.lastPathComponent, systemImage: "doc")
                                .font(.caption)
                                .lineLimit(1)
                            Spacer()
                            Button {
                                pendingAttachments.removeAll { $0 == url }
                            } label: {
                                Image(systemName: "xmark.circle")
                            }
                            .buttonStyle(.borderless)
                            .help("Remove this pending attachment")
                        }
                    }
                }
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var actions: some View {
        HStack {
            if !canCreate {
                Text("A title and date are required.")
                    .font(.caption)
                    .foregroundStyle(.orange)
            } else {
                Text("Ready to create.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button("Reset") {
                draft = selectedTemplate.makeEntry()
                pendingAttachments = []
            }
            .help("Reset this guided capture form")

            Button {
                createEntry()
            } label: {
                Label("Create Evidence", systemImage: "plus.circle")
            }
            .buttonStyle(.borderedProminent)
            .disabled(!canCreate)
            .keyboardShortcut(.defaultAction)
            .help("Create an evidence record from this guided form")
        }
    }

    private func createEntry() {
        let newID = store.addEntry(draft)
        if !pendingAttachments.isEmpty {
            store.attachFiles(pendingAttachments, to: newID)
        }
        selection = newID
        onCreate()
        dismiss()
    }
}
