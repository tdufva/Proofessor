import SwiftUI

struct CVDesignStudioView: View {
    let selectedPurpose: CVDesignPurpose
    let profileCompleteness: Int
    let applyPurpose: (CVDesignPurpose) -> Void
    let openProfileSetup: () -> Void

    var body: some View {
        ActionPanel(
            title: "CV Design Studio",
            subtitle: "Choose the purpose. The app picks the structure, typography, density, and export defaults.",
            systemImage: "wand.and.sparkles"
        ) {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 210), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                    ForEach(CVDesignPurpose.allCases) { purpose in
                        purposeCard(purpose)
                    }
                }

                ViewThatFits(in: .horizontal) {
                    HStack(spacing: AppDesign.Spacing.sm) {
                        profileStatus
                        Spacer()
                        Button(action: openProfileSetup) {
                            Label("Autofill My Profile", systemImage: "wand.and.sparkles")
                        }
                        .buttonStyle(.borderedProminent)
                    }

                    VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                        profileStatus
                        Button(action: openProfileSetup) {
                            Label("Autofill My Profile", systemImage: "wand.and.sparkles")
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
            }
        }
    }

    private func purposeCard(_ purpose: CVDesignPurpose) -> some View {
        let isSelected = selectedPurpose == purpose

        return Button {
            applyPurpose(purpose)
        } label: {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                HStack {
                    Image(systemName: purpose.systemImage)
                        .foregroundStyle(isSelected ? AppDesign.academyGold : .secondary)
                    Spacer()
                    if isSelected {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                    }
                }

                Text(purpose.rawValue)
                    .font(.headline)
                    .foregroundStyle(.primary)
                    .lineLimit(2)

                Text(purpose.shortHint)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)

                StatusChip(text: purpose.theme.rawValue, systemImage: purpose.theme.systemImage, tone: isSelected ? .accent : .neutral)
            }
            .padding(AppDesign.Spacing.md)
            .frame(maxWidth: .infinity, minHeight: 148, alignment: .topLeading)
            .background(
                isSelected ? AppDesign.academyGold.opacity(0.14) : AppDesign.academyInk.opacity(0.052),
                in: RoundedRectangle(cornerRadius: AppDesign.Radius.md)
            )
            .overlay {
                RoundedRectangle(cornerRadius: AppDesign.Radius.md)
                    .strokeBorder(isSelected ? AppDesign.academyGold.opacity(0.55) : Color.secondary.opacity(0.12))
            }
        }
        .buttonStyle(.plain)
        .help(purpose.whySuggested)
    }

    private var profileStatus: some View {
        HStack(spacing: AppDesign.Spacing.sm) {
            StatusChip(
                text: profileCompleteness >= 7 ? "Profile ready" : "Profile can improve",
                systemImage: profileCompleteness >= 7 ? "checkmark.circle" : "person.crop.circle.badge.questionmark",
                tone: profileCompleteness >= 7 ? .success : .warning
            )
            Text(profileCompleteness >= 7
                 ? "CVs, bios, and dossier text have enough profile context."
                 : "Add profile basics once to improve every draft.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}
