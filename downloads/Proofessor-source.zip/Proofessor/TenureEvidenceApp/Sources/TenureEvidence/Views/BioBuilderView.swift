import SwiftUI

struct BioBuilderView: View {
    @ObservedObject var store: EvidenceStore
    @State private var useCase: BioUseCase = .academic
    @State private var lengthPreset: BioLengthPreset = .short
    @State private var customCharacterLimit = 1_000
    @State private var cvReadyOnly = true
    @State private var draft = ""
    @State private var showingProfileSetup = false

    private var selectedEntries: [EvidenceEntry] {
        cvReadyOnly
            ? store.entries.filter { $0.cvReady || $0.status == "Ready for CV" || $0.status == "Filed" }
            : store.entries
    }

    private var wordCount: Int {
        BioDraftBuilder.wordCount(draft)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
                header
                sourceStatus
                controls
                editor
            }
            .padding(AppDesign.Spacing.xl)
            .frame(maxWidth: 1180, alignment: .leading)
        }
        .onAppear(perform: regenerate)
        .onChange(of: useCase) { _, _ in regenerate() }
        .onChange(of: lengthPreset) { _, _ in regenerate() }
        .onChange(of: customCharacterLimit) { _, _ in
            if lengthPreset == .custom { regenerate() }
        }
        .onChange(of: cvReadyOnly) { _, _ in regenerate() }
        .sheet(isPresented: $showingProfileSetup) {
            GuidedProfileSetupView(store: store) {
                regenerate()
            }
        }
    }

    private var header: some View {
        PageHeader(
            title: "Bios",
            subtitle: "Generate editable third-person biographies for academic, artistic, research, teaching, public, and speaker-introduction needs.",
            systemImage: "person.text.rectangle",
            trailing: AnyView(
                HStack {
                    Button(action: regenerate) {
                        Label("Regenerate", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .keyboardShortcut("b", modifiers: [.command])
                    .help("Regenerate the bio from current evidence")

                    Button {
                        store.copyToClipboard(draft)
                    } label: {
                        Label("Copy", systemImage: "doc.on.doc")
                    }
                    .help("Copy the bio text")

                    Button {
                        showingProfileSetup = true
                    } label: {
                        Label("Profile", systemImage: "person.text.rectangle")
                    }
                    .help("Autofill the profile details used by bios")

                    Button {
                        store.exportBioDraft(draft, useCase: useCase, lengthPreset: lengthPreset)
                    } label: {
                        Label("Export", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(.borderedProminent)
                    .help("Export the bio as Markdown")
                }
            )
        )
    }

    private var sourceStatus: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            StatusStrip(items: [
                StatusStripItem(text: "\(selectedEntries.count) evidence items", systemImage: "tray.full", tone: selectedEntries.isEmpty ? .warning : .accent),
                StatusStripItem(text: "\(store.cvItems.count) CV rows", systemImage: "list.bullet.rectangle", tone: store.cvItems.isEmpty ? .neutral : .success),
                StatusStripItem(text: store.connectorSettings.profileCompletenessCount >= 7 ? "Profile ready" : "Profile can improve", systemImage: "person.crop.circle", tone: store.connectorSettings.profileCompletenessCount >= 7 ? .success : .warning),
                StatusStripItem(text: "\(wordCount) words", systemImage: "text.word.spacing", tone: .neutral),
                StatusStripItem(text: "\(draft.count) characters", systemImage: "character.cursor.ibeam", tone: .neutral)
            ])

            HStack {
                Toggle("Use ready-to-use evidence only", isOn: $cvReadyOnly)
                    .toggleStyle(.checkbox)
                    .help("Use only evidence already marked ready or filed")
                Spacer()
                Text(store.lastMessage)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private var controls: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 320), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.md) {
            ActionPanel(title: "Bio Type", subtitle: useCase.guidance, systemImage: useCase.systemImage) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), alignment: .leading)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                    ForEach(BioUseCase.allCases) { option in
                        Button {
                            useCase = option
                        } label: {
                            Label(option.rawValue, systemImage: option.systemImage)
                                .lineLimit(1)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                        .tint(useCase == option ? AppDesign.academyGold : .secondary)
                    }
                }
            }

            ActionPanel(title: "Length", subtitle: lengthPreset.label, systemImage: "ruler") {
                Picker("Length", selection: $lengthPreset) {
                    ForEach(BioLengthPreset.allCases) { preset in
                        Text(preset.rawValue).tag(preset)
                    }
                }
                .pickerStyle(.segmented)

                if lengthPreset == .custom {
                    VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                        Stepper("Character limit: \(customCharacterLimit)", value: $customCharacterLimit, in: 160...4_000, step: 50)
                        Slider(value: Binding(
                            get: { Double(customCharacterLimit) },
                            set: { customCharacterLimit = Int($0.rounded()) }
                        ), in: 160...4_000, step: 50)
                        Text("Custom mode trims the generated bio at a sentence boundary whenever possible.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                } else {
                    Text(lengthPreset == .short ? "Good for websites, programme pages, and profile pages." : "Good for faculty pages, grant profiles, catalogues, and dossiers.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var editor: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            AppSectionHeader(
                title: "Editable Bio Draft",
                subtitle: "Written in third person, with role first, then focus, evidence-backed highlights, teaching, and impact.",
                systemImage: "square.and.pencil"
            )

            TextEditor(text: $draft)
                .font(.body)
                .scrollContentBackground(.hidden)
                .padding(AppDesign.Spacing.md)
                .frame(minHeight: 360)
                .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
                .overlay(
                    RoundedRectangle(cornerRadius: AppDesign.Radius.md)
                        .stroke(Color.secondary.opacity(0.18))
                )

            HStack {
                Button(action: regenerate) {
                    Label("Regenerate", systemImage: "arrow.triangle.2.circlepath")
                }
                Button {
                    store.copyToClipboard(draft)
                } label: {
                    Label("Copy", systemImage: "doc.on.doc")
                }
                Spacer()
                Button {
                    store.exportBioDraft(draft, useCase: useCase, lengthPreset: lengthPreset)
                } label: {
                    Label("Export Bio", systemImage: "square.and.arrow.up")
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func regenerate() {
        draft = BioDraftBuilder.build(
            useCase: useCase,
            lengthPreset: lengthPreset,
            customCharacterLimit: customCharacterLimit,
            entries: store.entries,
            cvItems: store.cvItems,
            sourceText: store.currentCVSourceText(),
            settings: store.connectorSettings,
            cvReadyOnly: cvReadyOnly
        )
    }
}
