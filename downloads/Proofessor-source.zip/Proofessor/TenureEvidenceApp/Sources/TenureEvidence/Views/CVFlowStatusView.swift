import SwiftUI

struct CVFlowStatusView: View {
    let step: CVWorkflowStep
    let draftIsEmpty: Bool
    let structuredItemCount: Int
    let cvReadyCount: Int
    let unverifiedLineCount: Int
    let finalCleanMode: Bool

    private var messages: [FlowMessage] {
        var output: [FlowMessage] = [
            FlowMessage(
                title: step.rawValue,
                detail: step.guidance,
                image: step.systemImage,
                level: .info
            )
        ]

        if structuredItemCount == 0 {
            output.append(
                FlowMessage(
                    title: "Structured CV database is empty",
                    detail: "Use Edit > Database > Rebuild before relying on CV exports.",
                    image: "tablecells.badge.ellipsis",
                    level: .warning
                )
            )
        }

        if draftIsEmpty {
            output.append(
                FlowMessage(
                    title: "No draft generated yet",
                    detail: "Choose a preset or click Regenerate Draft to create editable CV text.",
                    image: "doc.text.magnifyingglass",
                    level: .warning
                )
            )
        }

        if cvReadyCount == 0 {
            output.append(
                FlowMessage(
                    title: "No ready-to-use evidence",
                    detail: "Exports can still use CV source material, but app-captured evidence will be weak until records are marked ready to use.",
                    image: "checkmark.seal",
                    level: .warning
                )
            )
        }

        if finalCleanMode && unverifiedLineCount > 0 {
            output.append(
                FlowMessage(
                    title: "\(unverifiedLineCount) line(s) may be removed",
                    detail: "Final clean mode keeps verified or manually approved content and suppresses internal source notes.",
                    image: "line.3.horizontal.decrease.circle",
                    level: .info
                )
            )
        }

        return output
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label("CV Build Flow", systemImage: "point.3.connected.trianglepath.dotted")
                    .font(.headline)
                Spacer()
                Text(finalCleanMode ? "Final clean mode" : "Working draft mode")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(finalCleanMode ? .green : .secondary)
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), alignment: .top)], alignment: .leading, spacing: 8) {
                ForEach(messages) { message in
                    Label {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(message.title)
                                .font(.caption.weight(.semibold))
                            Text(message.detail)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    } icon: {
                        Image(systemName: message.image)
                            .foregroundStyle(message.level.color)
                    }
                    .padding(8)
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                    .background(.quaternary.opacity(0.22), in: RoundedRectangle(cornerRadius: 6))
                }
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
    }
}

private struct FlowMessage: Identifiable {
    enum Level {
        case info
        case warning

        var color: Color {
            switch self {
            case .info:
                .secondary
            case .warning:
                .orange
            }
        }
    }

    let id = UUID()
    var title: String
    var detail: String
    var image: String
    var level: Level
}
