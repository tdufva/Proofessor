import SwiftUI

struct CVExportStepView: View {
    let draft: String
    let theme: CVDraftTheme
    let variant: CVDraftVariant
    var profilePicturePath: String? = nil
    let selectedFormat: Binding<CVExportFormat>
    let export: (CVExportFormat) -> Void
    let exportSet: () -> Void
    let exportPacket: () -> Void
    let copy: () -> Void
    let revealFolder: () -> Void

    private var report: CVLayoutReport {
        CVDocumentExporter.layoutReport(for: draft, theme: theme, profilePicturePath: profilePicturePath)
    }

    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 14) {
                Label("Export", systemImage: "square.and.arrow.up")
                    .font(.title3.weight(.semibold))

                Text("\(variant.rawValue) · \(theme.rawValue) · \(report.pageCount) page(s)")
                    .foregroundStyle(.secondary)

                Picker("Format", selection: selectedFormat) {
                    ForEach(CVExportFormat.allCases) { format in
                        Label(format.rawValue, systemImage: format.systemImage).tag(format)
                    }
                }
                .pickerStyle(.radioGroup)
                .help("Choose the export format")

                HStack {
                    Button {
                        export(selectedFormat.wrappedValue)
                    } label: {
                        Label("Export Selected", systemImage: selectedFormat.wrappedValue.systemImage)
                    }
                    .disabled(draft.trimmed.isEmpty)
                    .help(selectedFormat.wrappedValue.helpText)

                    Button(action: exportSet) {
                        Label("Export Set", systemImage: "square.stack.3d.up")
                    }
                    .disabled(draft.trimmed.isEmpty)
                    .help("Export Markdown, RTF, Word, and PDF together")
                }

                HStack {
                    Button(action: exportPacket) {
                        Label("Dossier Packet", systemImage: "shippingbox")
                    }
                    .disabled(draft.trimmed.isEmpty)
                    .help("Export CV, evidence index, selected attachments, and checklist")

                    Button(action: copy) {
                        Label("Copy", systemImage: "doc.on.doc")
                    }
                    .disabled(draft.trimmed.isEmpty)
                    .help("Copy the current export draft")

                    Button(action: revealFolder) {
                        Label("Draft Folder", systemImage: "folder")
                    }
                    .help("Open the CV draft export folder")
                }

                Text(report.threePageStatus)
                    .font(.caption)
                    .foregroundStyle(report.pageCount <= 3 ? .green : .orange)

                Spacer()
            }
            .frame(minWidth: 320, maxWidth: 420, alignment: .topLeading)

            CVLivePreviewView(draft: draft, theme: theme, profilePicturePath: profilePicturePath)
        }
    }
}
