import SwiftUI

struct CurrentCVBuilderView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @State private var variant: CVDraftVariant = .generalAcademic
    @State private var draft = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Label("Editable Current CV Builder", systemImage: "doc.text.magnifyingglass")
                    .font(.title2.weight(.semibold))
                Spacer()
                Picker("Variant", selection: $variant) {
                    ForEach(CVDraftVariant.allCases) { option in
                        Text(option.rawValue).tag(option)
                    }
                }
                .frame(width: 220)
                .help("Choose the CV draft focus")

                Button("Close") {
                    dismiss()
                }
            }

            HStack {
                Button {
                    draft = store.generateCurrentCVDraft(variant: variant)
                } label: {
                    Label("Generate Draft", systemImage: "sparkles")
                }
                .help("Regenerate the editable CV draft")

                Button {
                    store.exportEditableCVDraft(draft, variant: variant)
                } label: {
                    Label("Export Markdown", systemImage: "square.and.arrow.up")
                }
                .disabled(draft.trimmed.isEmpty)
                .help("Export this draft as an editable Markdown file")

                Button {
                    store.exportEditableCVDraft(draft, variant: variant, asRTF: true)
                } label: {
                    Label("Export RTF", systemImage: "doc.richtext")
                }
                .disabled(draft.trimmed.isEmpty)
                .help("Export this draft as an editable RTF file")

                Button {
                    store.copyToClipboard(draft)
                } label: {
                    Label("Copy", systemImage: "doc.on.doc")
                }
                .disabled(draft.trimmed.isEmpty)
                .help("Copy the current draft text to the clipboard")

                Spacer()
            }

            Text(description)
                .foregroundStyle(.secondary)

            TextEditor(text: $draft)
                .font(.system(.body, design: .serif))
                .frame(minHeight: 430)
                .scrollContentBackground(.hidden)
                .padding(10)
                .background(.quaternary.opacity(0.25), in: RoundedRectangle(cornerRadius: 8))

            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(22)
        .onAppear {
            if draft.trimmed.isEmpty {
                draft = store.generateCurrentCVDraft(variant: variant)
            }
        }
        .onChange(of: variant) { _, newValue in
            draft = store.generateCurrentCVDraft(variant: newValue)
        }
    }

    private var description: String {
        variant.description
    }
}
