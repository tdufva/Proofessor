import SwiftUI

struct ReviewScansWizardView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: EvidenceStore
    @Binding var selection: EvidenceEntry.ID?
    let openEvidence: () -> Void
    @State private var schoolPreset: AaltoSchoolPreset = .aaltoWide
    @State private var careerStage: AaltoCareerStage = .tenure

    private var drafts: [EvidenceEntry] {
        store.scannedDraftEntriesForReview()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.lg) {
            header

            if drafts.isEmpty {
                AppEmptyState(
                    title: "No Scanned Drafts",
                    message: "Document scans are clear. New scanned files will appear here before they enter the dossier.",
                    systemImage: "text.viewfinder",
                    actionTitle: "Close",
                    actionImage: "checkmark",
                    action: { dismiss() }
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                presetControls

                ScrollView {
                    LazyVStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
                        ForEach(drafts) { entry in
                            draftCard(entry)
                        }
                    }
                    .padding(.vertical, 2)
                }
            }

            Text(store.lastMessage)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(AppDesign.Spacing.lg)
        .frame(minWidth: 760, idealWidth: 980, minHeight: 620, idealHeight: 720)
    }

    private var header: some View {
        PageHeader(
            title: "Review Scans",
            subtitle: "Confirm scanned drafts one by one: accept, edit, merge, or ignore.",
            systemImage: "text.viewfinder",
            trailing: AnyView(
                HStack {
                    StatusChip(text: "\(drafts.count) draft(s)", systemImage: "checklist", tone: drafts.isEmpty ? .success : .warning)
                    Button("Close") {
                        dismiss()
                    }
                    .keyboardShortcut(.cancelAction)
                }
            )
        )
    }

    private var presetControls: some View {
        HStack(spacing: AppDesign.Spacing.sm) {
            Picker("School", selection: $schoolPreset) {
                ForEach(AaltoSchoolPreset.allCases) { preset in
                    Text(preset.shortName).tag(preset)
                }
            }
            .frame(width: 150)

            Picker("Stage", selection: $careerStage) {
                ForEach(AaltoCareerStage.allCases) { stage in
                    Text(stage.shortName).tag(stage)
                }
            }
            .frame(width: 170)

            Text(AaltoCriteriaMatcher.guidance(school: schoolPreset, stage: careerStage))
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2)

            Spacer()
        }
        .padding(AppDesign.Spacing.sm)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
    }

    private func draftCard(_ entry: EvidenceEntry) -> some View {
        let duplicates = store.duplicateCandidates(for: entry)
        let recommendation = AaltoCriteriaMatcher.recommendation(
            for: entry,
            school: schoolPreset,
            stage: careerStage
        )
        let trace = EvidenceSourceTrace.entry(entry)

        return VStack(alignment: .leading, spacing: AppDesign.Spacing.md) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
                    HStack(spacing: AppDesign.Spacing.sm) {
                        StatusChip(text: entry.date.trimmed.isEmpty ? "No date" : entry.date, systemImage: "calendar", tone: entry.date.trimmed.isEmpty ? .warning : .neutral)
                        StatusChip(text: recommendation.dimension, systemImage: "target", tone: .accent)
                        StatusChip(text: recommendation.confidence.rawValue, systemImage: "gauge", tone: confidenceTone(recommendation.confidence))
                        StatusChip(text: "\(entry.completeness.score)%", systemImage: "gauge", tone: entry.completeness.score >= 80 ? .success : .warning)
                        if !duplicates.isEmpty {
                            StatusChip(text: "Possible duplicate", systemImage: "arrow.triangle.merge", tone: .warning)
                        }
                    }

                    Text(entry.title.trimmed.isEmpty ? "Untitled scanned draft" : entry.title)
                        .font(.title3.weight(.semibold))
                        .lineLimit(2)

                    Text(entry.displaySubtitle.isEmpty ? entry.category : entry.displaySubtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }

                Spacer()
            }

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 220), alignment: .top)], alignment: .leading, spacing: AppDesign.Spacing.sm) {
                reviewBox("Aalto dimension", value: "\(recommendation.dimension)\n\(recommendation.title)")
                reviewBox("Confidence", value: recommendation.confidenceNote)
                reviewBox("Why suggested", value: recommendation.reason)
                reviewBox("Proof found", value: proofSummary(entry))
                reviewBox("What is missing", value: entry.completeness.missing.isEmpty ? "Nothing obvious." : entry.completeness.missing.joined(separator: ", "))
                reviewBox("Why the app found this", value: sourceTraceSummary(trace))
            }

            if !duplicates.isEmpty {
                duplicatePanel(entry, duplicates: duplicates)
            }

            HStack {
                Button {
                    store.ignoreScannedDraft(entry.id)
                } label: {
                    Label("Ignore", systemImage: "xmark")
                }
                .help("Remove this draft from the scan review queue without deleting its source file")

                Button {
                    store.markScannedDraftProofMissing(entry.id)
                } label: {
                    Label("Proof Needed", systemImage: "paperclip.badge.ellipsis")
                }
                .help("Keep this draft, but mark it as needing better proof")

                Spacer()

                Button {
                    selection = entry.id
                    dismiss()
                    openEvidence()
                } label: {
                    Label("Edit", systemImage: "square.and.pencil")
                }
                .help("Open the full editable evidence record")

                Button {
                    store.acceptScannedDraft(entry.id)
                } label: {
                    Label("Accept", systemImage: "checkmark.circle")
                }
                .buttonStyle(.borderedProminent)
                .help("Confirm this draft and move it out of the scan review queue")
            }
        }
        .padding(AppDesign.Spacing.md)
        .background(AppDesign.cardFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .accessibilityElement(children: .contain)
    }

    private func duplicatePanel(_ entry: EvidenceEntry, duplicates: [EvidenceEntry]) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            Label("Possible duplicate records", systemImage: "arrow.triangle.merge")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.orange)

            ForEach(duplicates.prefix(3)) { duplicate in
                HStack(spacing: AppDesign.Spacing.sm) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(duplicate.title)
                            .font(.caption.weight(.medium))
                            .lineLimit(1)
                        Text(duplicate.displaySubtitle)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    Spacer()
                    Button {
                        selection = duplicate.id
                        dismiss()
                        openEvidence()
                    } label: {
                        Label("Open", systemImage: "arrow.right.circle")
                    }
                    .help("Open the existing record")

                    Button {
                        store.mergeDuplicateEntry(entry.id, into: duplicate.id)
                    } label: {
                        Label("Merge", systemImage: "arrow.triangle.merge")
                    }
                    .buttonStyle(.borderedProminent)
                    .help("Merge this scanned draft into the existing record")
                }
            }
        }
        .padding(AppDesign.Spacing.sm)
        .background(Color.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
    }

    private func reviewBox(_ title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.xs) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            Text(value.trimmed.isEmpty ? "Check this." : value)
                .font(.caption)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(AppDesign.Spacing.sm)
        .frame(maxWidth: .infinity, minHeight: 78, alignment: .topLeading)
        .background(AppDesign.quietFill, in: RoundedRectangle(cornerRadius: AppDesign.Radius.sm))
    }

    private func proofSummary(_ entry: EvidenceEntry) -> String {
        var parts: [String] = []
        if !entry.attachments.isEmpty {
            parts.append("\(entry.attachments.count) attachment(s)")
        }
        let urls = URLTools.extractURLs(from: [entry.source, entry.notes].joined(separator: "\n"))
        if !urls.isEmpty {
            parts.append("\(urls.count) source URL(s)")
        }
        return parts.isEmpty ? "Needs attachment or source URL before it is strong proof." : parts.joined(separator: ", ")
    }

    private func confidenceTone(_ confidence: AaltoCriteriaRecommendation.Confidence) -> StatusChip.Tone {
        switch confidence {
        case .high:
            return .success
        case .medium:
            return .accent
        case .review:
            return .warning
        }
    }

    private func sourceTraceSummary(_ trace: EvidenceSourceTrace) -> String {
        var parts = [
            "File: \(trace.fileName)",
            "Folder: \(trace.folder.trimmed.isEmpty ? "Workspace scan" : trace.folder)"
        ]
        if !trace.date.trimmed.isEmpty {
            parts.append("Date: \(trace.date)")
        }
        if !trace.snippet.trimmed.isEmpty {
            parts.append("Snippet: \(trace.snippet)")
        }
        if let link = trace.links.first {
            parts.append("Source link: \(link.absoluteString)")
        }
        return parts.joined(separator: "\n")
    }
}
