import AppKit
import SwiftUI
import UniformTypeIdentifiers

struct ProfilePicturePickerView: View {
    @Binding var path: String
    var compact: Bool = false

    private var image: NSImage? {
        guard !path.trimmed.isEmpty else { return nil }
        return NSImage(contentsOfFile: path)
    }

    private var pictureStatus: StatusChip.Tone {
        image == nil ? .neutral : .success
    }

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .center, spacing: AppDesign.Spacing.md) {
                thumbnail
                details
            }

            VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
                thumbnail
                details
            }
        }
        .accessibilityElement(children: .contain)
    }

    private var thumbnail: some View {
        Group {
            if let image {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: AppDesign.Radius.md)
                        .fill(AppDesign.quietFill)
                    Image(systemName: "person.crop.square")
                        .font(.system(size: compact ? 34 : 42))
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(width: compact ? 72 : 96, height: compact ? 72 : 96)
        .clipShape(RoundedRectangle(cornerRadius: AppDesign.Radius.md))
        .overlay(
            RoundedRectangle(cornerRadius: AppDesign.Radius.md)
                .strokeBorder(Color.secondary.opacity(0.16))
        )
        .help(image == nil ? "No profile picture selected" : "Selected profile picture")
    }

    private var details: some View {
        VStack(alignment: .leading, spacing: AppDesign.Spacing.sm) {
            HStack {
                Label("Profile Picture", systemImage: "person.crop.square")
                    .font(.caption.weight(.semibold))
                StatusChip(
                    text: image == nil ? "Optional" : "Selected",
                    systemImage: image == nil ? "circle" : "checkmark.circle",
                    tone: pictureStatus
                )
            }

            Text("Used by portrait and public-profile CV styles. TENK exports stay formal and ignore it.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            if !path.trimmed.isEmpty {
                Text(path)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .textSelection(.enabled)
            }

            HStack(spacing: AppDesign.Spacing.sm) {
                Button {
                    choosePicture()
                } label: {
                    Label(image == nil ? "Choose Image" : "Change Image", systemImage: "photo.badge.plus")
                }
                .help("Choose a JPG, PNG, HEIC, or other image file for public-facing CV styles")

                Button {
                    path = ""
                } label: {
                    Label("Remove", systemImage: "xmark.circle")
                }
                .disabled(path.trimmed.isEmpty)
                .help("Remove the saved profile picture path")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func choosePicture() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = [.image]
        panel.prompt = "Use Image"

        guard panel.runModal() == .OK, let url = panel.url else { return }
        path = url.standardizedFileURL.path
    }
}
