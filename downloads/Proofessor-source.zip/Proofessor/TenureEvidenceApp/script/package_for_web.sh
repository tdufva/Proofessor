#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SHARED_ROOT="$(cd "$ROOT_DIR/.." && pwd)"
APP_NAME="Proofessor"
APP_BUNDLE="$ROOT_DIR/dist/$APP_NAME.app"
WEB_DIST="$ROOT_DIR/dist/web"
SITE_DIST="$WEB_DIST/site"
DOWNLOAD_DIR="$SITE_DIST/downloads"
SOURCE_STAGE="$WEB_DIST/source/Proofessor"
APP_ZIP="$DOWNLOAD_DIR/Proofessor-macOS.zip"
SOURCE_ZIP="$DOWNLOAD_DIR/Proofessor-source.zip"
CHECKSUMS="$DOWNLOAD_DIR/checksums.txt"

cd "$ROOT_DIR"
"$ROOT_DIR/script/build_and_run.sh" --build-only

rm -rf "$WEB_DIST"
mkdir -p "$DOWNLOAD_DIR"

ditto -c -k --sequesterRsrc --keepParent "$APP_BUNDLE" "$APP_ZIP"

cd "$SHARED_ROOT"
mkdir -p "$SOURCE_STAGE"
mkdir -p "$SOURCE_STAGE/TenureEvidenceApp"
for item in Assets Sources Tests scripts script .codex Package.swift README.md DISTRIBUTION.md; do
  if [[ -e "$SHARED_ROOT/TenureEvidenceApp/$item" ]]; then
    ditto "$SHARED_ROOT/TenureEvidenceApp/$item" "$SOURCE_STAGE/TenureEvidenceApp/$item"
  fi
done
ditto "$SHARED_ROOT/EmptyWorkspaceTemplate" "$SOURCE_STAGE/EmptyWorkspaceTemplate"
ditto "$SHARED_ROOT/Documentation" "$SOURCE_STAGE/Documentation"
ditto "$SHARED_ROOT/WebsiteShareKit" "$SOURCE_STAGE/WebsiteShareKit"
cp "$SHARED_ROOT/README.md" "$SOURCE_STAGE/README.md"
cp "$SHARED_ROOT/.gitignore" "$SOURCE_STAGE/.gitignore"
ditto -c -k --norsrc --keepParent "$SOURCE_STAGE" "$SOURCE_ZIP"

cp -R "$SHARED_ROOT/WebsiteShareKit/." "$SITE_DIST/"
mkdir -p "$SITE_DIST/assets"
cp "$ROOT_DIR/Assets/AppIcon.iconset/icon_512x512.png" "$SITE_DIST/assets/app-icon.png"

cd "$DOWNLOAD_DIR"
shasum -a 256 "$(basename "$APP_ZIP")" "$(basename "$SOURCE_ZIP")" > "$CHECKSUMS"

echo "Website release created at: $SITE_DIST"
echo "App download: $APP_ZIP"
echo "Source download: $SOURCE_ZIP"
