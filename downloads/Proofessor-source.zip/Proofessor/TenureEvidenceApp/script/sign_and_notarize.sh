#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_NAME="Proofessor"
APP_BUNDLE="$ROOT_DIR/dist/$APP_NAME.app"
NOTARY_ZIP="$ROOT_DIR/dist/$APP_NAME-notarization.zip"
SIGNED_ZIP="$ROOT_DIR/dist/$APP_NAME-signed-notarized.zip"

SIGNING_IDENTITY="${SIGNING_IDENTITY:-}"
NOTARY_PROFILE="${NOTARY_PROFILE:-}"
APPLE_ID="${APPLE_ID:-}"
APPLE_TEAM_ID="${APPLE_TEAM_ID:-}"
APPLE_APP_PASSWORD="${APPLE_APP_PASSWORD:-}"
SKIP_NOTARIZATION="${SKIP_NOTARIZATION:-0}"

if [[ -z "$SIGNING_IDENTITY" ]]; then
  SIGNING_IDENTITY="$(security find-identity -p codesigning -v | awk -F '\"' '/Developer ID Application/ { print $2; exit }')"
fi

if [[ -z "$SIGNING_IDENTITY" ]]; then
  cat >&2 <<'MESSAGE'
No Developer ID Application signing identity was found.

Install an Apple Developer ID certificate in Keychain Access, or run:
  SIGNING_IDENTITY="Developer ID Application: Name (TEAMID)" ./script/sign_and_notarize.sh
MESSAGE
  exit 2
fi

"$ROOT_DIR/script/build_and_run.sh" --build-only

codesign --force --deep --options runtime --timestamp --sign "$SIGNING_IDENTITY" "$APP_BUNDLE"
codesign --verify --deep --strict --verbose=2 "$APP_BUNDLE"

rm -f "$NOTARY_ZIP" "$SIGNED_ZIP"
ditto -c -k --sequesterRsrc --keepParent "$APP_BUNDLE" "$NOTARY_ZIP"

if [[ "$SKIP_NOTARIZATION" == "1" ]]; then
  echo "Signed app created at: $APP_BUNDLE"
  echo "Notarization skipped because SKIP_NOTARIZATION=1."
  exit 0
fi

if [[ -n "$NOTARY_PROFILE" ]]; then
  xcrun notarytool submit "$NOTARY_ZIP" --keychain-profile "$NOTARY_PROFILE" --wait
elif [[ -n "$APPLE_ID" && -n "$APPLE_TEAM_ID" && -n "$APPLE_APP_PASSWORD" ]]; then
  xcrun notarytool submit "$NOTARY_ZIP" \
    --apple-id "$APPLE_ID" \
    --team-id "$APPLE_TEAM_ID" \
    --password "$APPLE_APP_PASSWORD" \
    --wait
else
  cat >&2 <<'MESSAGE'
The app was signed, but notarization credentials were not provided.

Use either:
  NOTARY_PROFILE="saved-notary-profile" ./script/sign_and_notarize.sh

or:
  APPLE_ID="you@example.com" APPLE_TEAM_ID="TEAMID" APPLE_APP_PASSWORD="app-specific-password" ./script/sign_and_notarize.sh
MESSAGE
  exit 3
fi

xcrun stapler staple "$APP_BUNDLE"
spctl -a -vv "$APP_BUNDLE"
ditto -c -k --sequesterRsrc --keepParent "$APP_BUNDLE" "$SIGNED_ZIP"

echo "Signed and notarized app: $APP_BUNDLE"
echo "Distributable zip: $SIGNED_ZIP"
