// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "ProofessorApp",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .executable(name: "Proofessor", targets: ["TenureEvidence"])
    ],
    targets: [
        .executableTarget(name: "TenureEvidence"),
        .testTarget(
            name: "TenureEvidenceTests",
            dependencies: ["TenureEvidence"]
        )
    ]
)
