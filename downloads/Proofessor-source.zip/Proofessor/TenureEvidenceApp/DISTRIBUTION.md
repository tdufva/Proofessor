# Distribution

Proofessor can be shared as a clean standalone macOS app, but public website distribution should use Developer ID signing and Apple notarization.

## Current requirement

The Mac that builds the public package needs:

- A valid `Developer ID Application` certificate in Keychain Access.
- Either a saved `notarytool` keychain profile or Apple ID notarization credentials.

Check certificates:

```sh
security find-identity -p codesigning -v
```

## Sign and notarize

With a saved notary profile:

```sh
NOTARY_PROFILE="ProofessorNotary" ./script/sign_and_notarize.sh
```

With explicit credentials:

```sh
APPLE_ID="you@example.com" \
APPLE_TEAM_ID="TEAMID" \
APPLE_APP_PASSWORD="app-specific-password" \
./script/sign_and_notarize.sh
```

If the certificate name is not detected automatically:

```sh
SIGNING_IDENTITY="Developer ID Application: Name (TEAMID)" \
NOTARY_PROFILE="ProofessorNotary" \
./script/sign_and_notarize.sh
```

The script builds the app, signs it with hardened runtime, submits it to Apple notarization, staples the ticket, validates Gatekeeper, and creates `dist/Proofessor-signed-notarized.zip`.

## Private testing

For private testing without notarization:

```sh
SIGNING_IDENTITY="Developer ID Application: Name (TEAMID)" \
SKIP_NOTARIZATION=1 \
./script/sign_and_notarize.sh
```

Do not use the private-testing zip as the public website download.
