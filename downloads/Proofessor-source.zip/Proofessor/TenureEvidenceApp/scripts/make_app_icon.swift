import AppKit
import CoreGraphics
import Foundation

let rootURL = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
let assetsURL = rootURL.appendingPathComponent("Assets")
let iconsetURL = assetsURL.appendingPathComponent("AppIcon.iconset")

try? FileManager.default.removeItem(at: iconsetURL)
try FileManager.default.createDirectory(at: iconsetURL, withIntermediateDirectories: true)

struct IconSize {
    let points: Int
    let scale: Int
    let filename: String

    var pixels: Int { points * scale }
}

let sizes = [
    IconSize(points: 16, scale: 1, filename: "icon_16x16.png"),
    IconSize(points: 16, scale: 2, filename: "icon_16x16@2x.png"),
    IconSize(points: 32, scale: 1, filename: "icon_32x32.png"),
    IconSize(points: 32, scale: 2, filename: "icon_32x32@2x.png"),
    IconSize(points: 128, scale: 1, filename: "icon_128x128.png"),
    IconSize(points: 128, scale: 2, filename: "icon_128x128@2x.png"),
    IconSize(points: 256, scale: 1, filename: "icon_256x256.png"),
    IconSize(points: 256, scale: 2, filename: "icon_256x256@2x.png"),
    IconSize(points: 512, scale: 1, filename: "icon_512x512.png"),
    IconSize(points: 512, scale: 2, filename: "icon_512x512@2x.png")
]

for size in sizes {
    let image = drawIconRep(pixelSize: size.pixels)
    let outputURL = iconsetURL.appendingPathComponent(size.filename)
    try writePNG(image, to: outputURL)
}

func drawIconRep(pixelSize: Int) -> NSBitmapImageRep {
    let bounds = NSRect(x: 0, y: 0, width: pixelSize, height: pixelSize)
    guard let bitmap = NSBitmapImageRep(
        bitmapDataPlanes: nil,
        pixelsWide: pixelSize,
        pixelsHigh: pixelSize,
        bitsPerSample: 8,
        samplesPerPixel: 4,
        hasAlpha: true,
        isPlanar: false,
        colorSpaceName: .deviceRGB,
        bytesPerRow: 0,
        bitsPerPixel: 0
    ) else {
        fatalError("Could not create bitmap")
    }

    bitmap.size = bounds.size
    guard let graphicsContext = NSGraphicsContext(bitmapImageRep: bitmap) else {
        fatalError("Could not create graphics context")
    }

    let previousContext = NSGraphicsContext.current
    NSGraphicsContext.current = graphicsContext
    graphicsContext.shouldAntialias = true

    let context = graphicsContext.cgContext
    context.saveGState()
    context.clear(bounds)
    context.scaleBy(x: CGFloat(pixelSize) / 1024.0, y: CGFloat(pixelSize) / 1024.0)
    drawBaseIcon()
    context.restoreGState()
    NSGraphicsContext.current = previousContext

    return bitmap
}

func drawBaseIcon() {
    let outer = NSRect(x: 64, y: 64, width: 896, height: 896)
    let backgroundPath = NSBezierPath(roundedRect: outer, xRadius: 210, yRadius: 210)
    backgroundPath.addClip()

    NSGradient(colors: [
        NSColor(calibratedRed: 0.05, green: 0.12, blue: 0.23, alpha: 1),
        NSColor(calibratedRed: 0.08, green: 0.28, blue: 0.36, alpha: 1),
        NSColor(calibratedRed: 0.13, green: 0.48, blue: 0.49, alpha: 1)
    ])?.draw(in: outer, angle: 45)

    drawSubtleGrid()
    drawDossier()
    drawMortarboard()
    drawSparkAndCheck()
    drawGloss()
}

func drawSubtleGrid() {
    NSColor.white.withAlphaComponent(0.075).setStroke()
    let path = NSBezierPath()
    path.lineWidth = 5

    for x in stride(from: 160, through: 850, by: 110) {
        path.move(to: NSPoint(x: x, y: 150))
        path.line(to: NSPoint(x: x + 110, y: 860))
    }

    for y in stride(from: 180, through: 800, by: 120) {
        path.move(to: NSPoint(x: 145, y: y))
        path.line(to: NSPoint(x: 860, y: y + 55))
    }

    path.stroke()
}

func drawDossier() {
    drawShadow(rect: NSRect(x: 232, y: 170, width: 600, height: 560), radius: 76, alpha: 0.32)

    let folderBack = rounded(NSRect(x: 214, y: 244, width: 610, height: 498), radius: 70)
    NSColor(calibratedRed: 0.95, green: 0.78, blue: 0.34, alpha: 1).setFill()
    folderBack.fill()

    let tab = rounded(NSRect(x: 262, y: 684, width: 252, height: 100), radius: 34)
    NSColor(calibratedRed: 0.98, green: 0.85, blue: 0.45, alpha: 1).setFill()
    tab.fill()

    let paper = rounded(NSRect(x: 286, y: 258, width: 476, height: 470), radius: 46)
    NSColor(calibratedRed: 0.99, green: 0.96, blue: 0.88, alpha: 1).setFill()
    paper.fill()

    NSColor(calibratedRed: 0.77, green: 0.67, blue: 0.53, alpha: 0.36).setStroke()
    paper.lineWidth = 5
    paper.stroke()

    drawBookmark()
    drawAcademicLines()
}

func drawBookmark() {
    let bookmark = NSBezierPath()
    bookmark.move(to: NSPoint(x: 646, y: 724))
    bookmark.line(to: NSPoint(x: 714, y: 724))
    bookmark.line(to: NSPoint(x: 714, y: 488))
    bookmark.line(to: NSPoint(x: 680, y: 526))
    bookmark.line(to: NSPoint(x: 646, y: 488))
    bookmark.close()
    NSColor(calibratedRed: 0.87, green: 0.22, blue: 0.26, alpha: 1).setFill()
    bookmark.fill()
}

func drawAcademicLines() {
    let lineColor = NSColor(calibratedRed: 0.18, green: 0.29, blue: 0.33, alpha: 0.42)
    lineColor.setStroke()
    let lines = NSBezierPath()
    lines.lineCapStyle = .round
    lines.lineWidth = 15

    for y in [628, 574, 520, 466] {
        lines.move(to: NSPoint(x: 350, y: y))
        lines.line(to: NSPoint(x: y == 466 ? 566 : 608, y: y))
    }

    lines.stroke()

    let tiny = NSBezierPath()
    tiny.lineCapStyle = .round
    tiny.lineWidth = 9
    NSColor(calibratedRed: 0.18, green: 0.29, blue: 0.33, alpha: 0.25).setStroke()

    for y in [384, 346, 308] {
        tiny.move(to: NSPoint(x: 350, y: y))
        tiny.line(to: NSPoint(x: 652, y: y))
    }

    tiny.stroke()
}

func drawMortarboard() {
    drawShadow(rect: NSRect(x: 260, y: 664, width: 540, height: 176), radius: 42, alpha: 0.26)

    let cap = NSBezierPath()
    cap.move(to: NSPoint(x: 238, y: 744))
    cap.line(to: NSPoint(x: 512, y: 864))
    cap.line(to: NSPoint(x: 786, y: 744))
    cap.line(to: NSPoint(x: 512, y: 636))
    cap.close()
    NSColor(calibratedRed: 0.06, green: 0.08, blue: 0.14, alpha: 1).setFill()
    cap.fill()

    NSColor(calibratedRed: 0.22, green: 0.54, blue: 0.58, alpha: 1).setStroke()
    cap.lineWidth = 9
    cap.stroke()

    let button = NSBezierPath(ovalIn: NSRect(x: 492, y: 735, width: 40, height: 40))
    NSColor(calibratedRed: 0.98, green: 0.82, blue: 0.29, alpha: 1).setFill()
    button.fill()

    let tassel = NSBezierPath()
    tassel.move(to: NSPoint(x: 514, y: 752))
    tassel.curve(to: NSPoint(x: 720, y: 608), controlPoint1: NSPoint(x: 608, y: 735), controlPoint2: NSPoint(x: 696, y: 688))
    NSColor(calibratedRed: 0.98, green: 0.75, blue: 0.22, alpha: 1).setStroke()
    tassel.lineCapStyle = .round
    tassel.lineWidth = 13
    tassel.stroke()

    let dot = NSBezierPath(ovalIn: NSRect(x: 697, y: 572, width: 52, height: 64))
    NSColor(calibratedRed: 0.98, green: 0.75, blue: 0.22, alpha: 1).setFill()
    dot.fill()
}

func drawSparkAndCheck() {
    let check = NSBezierPath()
    check.move(to: NSPoint(x: 378, y: 420))
    check.line(to: NSPoint(x: 462, y: 344))
    check.line(to: NSPoint(x: 612, y: 548))
    check.lineCapStyle = .round
    check.lineJoinStyle = .round
    check.lineWidth = 34
    NSColor(calibratedRed: 0.13, green: 0.62, blue: 0.55, alpha: 1).setStroke()
    check.stroke()

    let spark = NSBezierPath()
    spark.move(to: NSPoint(x: 764, y: 414))
    spark.line(to: NSPoint(x: 790, y: 478))
    spark.line(to: NSPoint(x: 854, y: 504))
    spark.line(to: NSPoint(x: 790, y: 530))
    spark.line(to: NSPoint(x: 764, y: 594))
    spark.line(to: NSPoint(x: 738, y: 530))
    spark.line(to: NSPoint(x: 674, y: 504))
    spark.line(to: NSPoint(x: 738, y: 478))
    spark.close()
    NSColor(calibratedRed: 0.98, green: 0.88, blue: 0.33, alpha: 1).setFill()
    spark.fill()
}

func drawGloss() {
    let gloss = NSBezierPath(roundedRect: NSRect(x: 112, y: 584, width: 798, height: 310), xRadius: 160, yRadius: 160)
    NSGradient(colors: [
        NSColor.white.withAlphaComponent(0.18),
        NSColor.white.withAlphaComponent(0.02)
    ])?.draw(in: gloss, angle: 90)
}

func rounded(_ rect: NSRect, radius: CGFloat) -> NSBezierPath {
    NSBezierPath(roundedRect: rect, xRadius: radius, yRadius: radius)
}

func drawShadow(rect: NSRect, radius: CGFloat, alpha: CGFloat) {
    NSGraphicsContext.saveGraphicsState()
    NSShadow.shadow(alpha: alpha).set()
    NSColor.black.withAlphaComponent(0.8).setFill()
    rounded(rect, radius: radius).fill()
    NSGraphicsContext.restoreGraphicsState()
}

func writePNG(_ bitmap: NSBitmapImageRep, to url: URL) throws {
    guard let data = bitmap.representation(using: .png, properties: [:]) else {
        fatalError("Could not encode PNG")
    }

    try data.write(to: url, options: .atomic)
}

extension NSShadow {
    static func shadow(alpha: CGFloat) -> NSShadow {
        let shadow = NSShadow()
        shadow.shadowColor = NSColor.black.withAlphaComponent(alpha)
        shadow.shadowBlurRadius = 28
        shadow.shadowOffset = NSSize(width: 0, height: -16)
        return shadow
    }
}
